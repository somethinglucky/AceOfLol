import { useEffect, useRef, useState } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { getSettings, putSettings, getProfile, getMessages, put, newId, resolveActiveBuddy } from '../storage/db.js'
import { streamChat, PROVIDERS } from '../ai/provider.js'
import { buildSystem, buildContext } from '../ai/promptBuilder.js'
import { preSendCheck, EXIT_TOKEN } from '../ai/safety.js'
import { limitsFor, modelLabel, DEMO_MODEL } from '../ai/local/models.js'
import ReplyStatus from '../components/ReplyStatus.jsx'
import { listInstalled, downloadModel, subscribe, getStatus } from '../ai/local/engine.js'
import { checkDevice, UNSUPPORTED_MESSAGE } from '../device/capability.js'
import { DEMO_BUDDY, buildDemoSystem } from '../demo/demoBuddy.js'
import Avatar from '../components/Avatar.jsx'
import SelectBuddy from '../components/SelectBuddy.jsx'
import { listMemories } from '../memory/store.js'
import { pickMemories } from '../memory/retrieve.js'
import { extractNow } from '../memory/extract.js'

const CLOUD = ['openai', 'anthropic', 'gemini', 'openrouter']

// Works out how this chat can actually run right now.
async function planFor(s, demo) {
  if (!demo && s.activeProvider !== 'local') {
    return s.providers[s.activeProvider]?.apiKey ? { mode: 'cloud', provider: s.activeProvider } : { mode: 'need-key' }
  }
  const device = await checkDevice()
  const installed = device.supported ? await listInstalled().catch(() => []) : []
  const preferred = s.providers.local?.model
  const modelUrl = installed.find((m) => m.url === preferred)?.url || installed[0]?.url || null
  if (modelUrl) return { mode: 'local', modelUrl }
  if (!device.supported) {
    const key = [s.activeProvider, ...CLOUD].find((p) => CLOUD.includes(p) && s.providers[p]?.apiKey)
    return key ? { mode: 'cloud', provider: key } : { mode: 'unsupported' }
  }
  return demo ? { mode: 'download' } : { mode: 'need-model' }
}

export default function Chat() {
  const nav = useNavigate()
  const [params] = useSearchParams()
  const isDemo = params.get('b') === 'demo'
  const [state, setState] = useState(null) // { buddy, buddies, needsPick, settings }
  const [plan, setPlan] = useState(null)
  const [msgs, setMsgs] = useState([])
  const [input, setInput] = useState('')
  const [live, setLive] = useState(null)   // text of the reply being streamed (null = none)
  const [busy, setBusy] = useState(false)
  const [note, setNote] = useState('')
  const [picking, setPicking] = useState(false)
  const [dl, setDl] = useState(null)       // demo model download progress
  const [engine, setEngine] = useState(getStatus())
  const abort = useRef(null)
  const dlAbort = useRef(null)
  const end = useRef(null)
  const buddyRef = useRef(null)
  const stopped = useRef(false)

  async function load() {
    const settings = await getSettings()
    if (isDemo) {
      const { buddies } = await resolveActiveBuddy()
      setState({ buddy: DEMO_BUDDY, buddies, settings }); setMsgs(await getMessages(DEMO_BUDDY.id)); setPlan(await planFor(settings, true))
      return
    }
    const r = await resolveActiveBuddy()
    setState({ ...r, settings })
    if (r.buddy) {
      setMsgs(await getMessages(r.buddy.id)); setPlan(await planFor(settings, false))
      extractNow(r.buddy, { minUserMsgs: 3, quietMs: 30 * 60 * 1000 })
    } else if (!r.buddies.length) nav('/buddy/edit', { replace: true })
  }
  useEffect(() => { load(); return () => { abort.current?.abort(); dlAbort.current?.abort() } }, [isDemo])
  useEffect(() => subscribe(setEngine), [])
  useEffect(() => { end.current?.scrollIntoView({ block: 'end' }) }, [msgs, live, note])
  useEffect(() => { buddyRef.current = isDemo ? null : state?.buddy || null }, [state, isDemo])
  // Leaving the app/tab is a natural end of conversation: let the buddy update their memories.
  useEffect(() => {
    const onHide = () => { if (document.visibilityState === 'hidden' && buddyRef.current) extractNow(buddyRef.current, { minUserMsgs: 3 }) }
    document.addEventListener('visibilitychange', onHide)
    return () => document.removeEventListener('visibilitychange', onHide)
  }, [])

  if (!state) return null
  const { buddy, buddies, settings } = state
  if (!buddy) return state.needsPick
    ? <SelectBuddy buddies={buddies} onPick={async (b) => { await putSettings({ activeBuddyId: b.id }); load() }} />
    : null

  const ready = plan && (plan.mode === 'local' || plan.mode === 'cloud')

  async function getDemoModel() {
    setNote(''); dlAbort.current = new AbortController(); setDl({ loaded: 0, total: 0 })
    try {
      await downloadModel(DEMO_MODEL.url, { signal: dlAbort.current.signal, onProgress: (loaded, total) => setDl({ loaded, total }) })
      const s = await getSettings()
      if (!s.providers.local?.model) await putSettings({ providers: { ...s.providers, local: { ...s.providers.local, model: DEMO_MODEL.url } } })
      setPlan(await planFor(await getSettings(), true))
    } catch (e) { if (e.name !== 'AbortError') setNote(e.message) }
    setDl(null)
  }

  async function send() {
    const text = input.trim()
    if (!text || busy) return
    const s = await getSettings()
    const pl = await planFor(s, isDemo)
    setPlan(pl)
    if (pl.mode !== 'local' && pl.mode !== 'cloud') return // the banner explains what to do

    setNote(''); setInput('')
    const userMsg = { id: newId(), buddyId: buddy.id, role: 'user', text, ts: Date.now(), source: 'text' }
    await put('message', userMsg)
    const history = [...msgs, userMsg]
    setMsgs(history)

    const pre = preSendCheck(text)
    if (pre?.block) {
      const m = { id: newId(), buddyId: buddy.id, role: 'buddy', text: pre.reply, ts: Date.now(), modelUsed: 'local-rule', source: 'text' }
      await put('message', m); setMsgs([...history, m]); return
    }

    const provider = pl.mode === 'local' ? 'local' : pl.provider
    const cfg = s.providers[provider] || {}
    const model = pl.mode === 'local' ? pl.modelUrl : cfg.model
    const lim = limitsFor(provider)
    setBusy(true); setLive(''); stopped.current = false
    abort.current = new AbortController()
    let acc = ''
    try {
      let system
      if (isDemo) system = buildDemoSystem(pl.mode === 'local' ? modelLabel(pl.modelUrl) : 'a cloud AI model')
      else {
        const profile = await getProfile()
        const recent = history.slice(-3).map((m) => m.text).join(' ')
        const memories = pickMemories(await listMemories(buddy.id), recent, { charBudget: lim.memoryChars, max: provider === 'local' ? 6 : 12 })
        system = buildSystem({ buddy, profile, memories, compact: provider === 'local' })
      }
      const ctx = buildContext(history.map((m) => ({ role: m.role === 'user' ? 'user' : 'assistant', text: m.text })), lim.historyChars)
      for await (const chunk of streamChat({ provider, apiKey: cfg.apiKey, model, system, messages: ctx, signal: abort.current.signal, sampling: s.sampling })) {
        acc += chunk; setLive(acc)
      }
    } catch (e) {
      if (e.name !== 'AbortError') setNote(e.message)
    }
    let final = acc.trim()
    if (final.startsWith(EXIT_TOKEN)) final = s.exitMessage
    if (final) {
      const m = { id: newId(), buddyId: buddy.id, role: 'buddy', text: final, ts: Date.now(), modelUsed: `${provider}:${modelLabel(model)}`, source: 'text' }
      await put('message', m); setMsgs([...history, m])
      if (!isDemo) extractNow(buddy, { minUserMsgs: 8 }) // background; never blocks the chat
    }
    else if (!acc.trim() && !stopped.current) setNote((n) => n || "No reply came back that time. Try sending your message again.")
    setLive(null); setBusy(false)
  }

  // While the streamed text could still turn into the exit token, keep showing the typing dots.
  const hideLive = live !== null && (live.trim() === '' || EXIT_TOKEN.startsWith(live.trim()) || live.trim().startsWith(EXIT_TOKEN))
  const sub = isDemo ? 'Demo · runs on your device' : plan?.mode === 'local' ? 'on this device' : PROVIDERS[plan?.provider || settings.activeProvider]?.label ? `via ${PROVIDERS[plan?.provider || settings.activeProvider].label}` : ''
  const pct = dl && dl.total ? Math.round((dl.loaded / dl.total) * 100) : 0

  return (
    <div className="chat">
      <div className="chat-head">
        <Avatar blob={buddy.avatar} name={buddy.name} size={36} />
        <div><strong>{buddy.name}</strong><div className="small muted">{sub}</div></div>
        {!isDemo && buddies.length > 1 && <button className="plain" onClick={() => setPicking(true)}>Switch</button>}
        {isDemo && buddies.length === 0 && <Link className="plain" to="/buddy/edit">Create your own</Link>}
      </div>
      <div className="chat-list">
        {msgs.length === 0 && live === null && ready && <p className="muted center-text">Say hi to {buddy.name}.</p>}
        {msgs.map((m) => <div key={m.id} className={`bubble ${m.role === 'user' ? 'me' : 'them'}`}>{m.text}</div>)}
        {live !== null && (hideLive
          ? <div className="bubble them typing"><i /><i /><i /></div>
          : <div className="bubble them">{live}</div>)}
        {busy && hideLive && (engine.stage === 'loading' || engine.stage === 'thinking') && <ReplyStatus stage={engine.stage} since={engine.since} />}
        {note && <div className="note">{note}</div>}
        <div ref={end} />
      </div>

      {plan && plan.mode === 'download' && (
        <div className="banner">
          <strong>Get Demo Buddy ready</strong>
          <p className="small muted">Demo Buddy runs on your phone, so it's free and private. This is a one-time download of about {DEMO_MODEL.sizeMB} MB. Wi-Fi is best.</p>
          {dl ? (
            <>
              <div className="small">{dl.total ? `${pct}% (${Math.round(dl.loaded / 1e6)} of ${Math.round(dl.total / 1e6)} MB)` : 'Starting...'}</div>
              <div className="bar"><div style={{ width: `${pct}%` }} /></div>
              <button className="quiet" onClick={() => dlAbort.current?.abort()}>Cancel</button>
            </>
          ) : <button className="btn" onClick={getDemoModel}>Download and start</button>}
        </div>
      )}
      {plan && plan.mode === 'unsupported' && (
        <div className="banner"><p className="small">{UNSUPPORTED_MESSAGE}</p><Link className="plain-btn" to="/premium">See premium</Link></div>
      )}
      {plan && plan.mode === 'need-model' && (
        <div className="banner"><p className="small">Your buddy needs an on-device model to think with. It's a one-time download.</p><Link className="plain-btn" to="/settings">Choose a model</Link></div>
      )}
      {plan && plan.mode === 'need-key' && (
        <div className="banner"><p className="small">Add your API key in Settings to chat with a cloud AI, or switch to an on-device model.</p><Link className="plain-btn" to="/settings">Open Settings</Link></div>
      )}

      <div className="composer">
        <textarea rows={1} value={input} placeholder="Message" disabled={!ready} onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey && window.matchMedia('(pointer: fine)').matches) { e.preventDefault(); send() } }} />
        <button className={`send ${busy ? 'stop' : ''}`} aria-label={busy ? 'Stop' : 'Send'} disabled={!busy && (!ready || !input.trim())}
          onClick={busy ? () => { stopped.current = true; abort.current?.abort() } : send}>{busy ? '■' : '↑'}</button>
      </div>
      {picking && <SelectBuddy buddies={buddies} onClose={() => setPicking(false)}
        onPick={async (b) => { await putSettings({ activeBuddyId: b.id }); setPicking(false); load() }} />}
    </div>
  )
}
