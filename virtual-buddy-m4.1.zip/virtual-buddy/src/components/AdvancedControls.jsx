import { useState } from 'react'
import { putSettings } from '../storage/db.js'
import { SAMPLING_DEFAULTS, SAMPLING_FIELDS, samplingFrom } from '../ai/local/models.js'

// Optional tuning for the on-device model. Safe defaults; Reset puts everything back.
export default function AdvancedControls({ settings, onChange }) {
  const [open, setOpen] = useState(false)
  const v = samplingFrom(settings.sampling)
  const save = async (patch) => { await putSettings({ sampling: { ...v, ...patch } }); onChange?.() }
  const reset = async () => { await putSettings({ sampling: null }); onChange?.() }
  const changed = JSON.stringify(v) !== JSON.stringify(SAMPLING_DEFAULTS)
  return (
    <section className="card adv">
      <h2>Advanced (on-device model)</h2>
      <p className="muted small">These change how the on-device model writes. They can make replies steadier or shorter, but they cannot make a small model smarter. A bigger model is the only thing that does that.</p>
      <button type="button" onClick={() => setOpen(!open)} aria-expanded={open}>{open ? 'Hide advanced controls' : 'Show advanced controls'}</button>
      {open && (
        <div className="stack">
          {SAMPLING_FIELDS.map((f) => (
            <label key={f.key}>{f.label}
              <small>{f.help}</small>
              <div className="adv-row">
                <input type="range" min={f.min} max={f.max} step={f.step} value={v[f.key]} onChange={(e) => save({ [f.key]: Number(e.target.value) })} />
                <input type="number" key={f.key + v[f.key]} min={f.min} max={f.max} step={f.step} defaultValue={v[f.key]} onBlur={(e) => { const n = Number(e.target.value); if (e.target.value !== '' && Number.isFinite(n)) save({ [f.key]: Math.min(f.max, Math.max(f.min, n)) }) }} />
              </div>
            </label>
          ))}
          <label>Seed
            <small>Leave empty for a fresh result each time. A number makes replies repeatable, which is handy for testing.</small>
            <input type="number" inputMode="numeric" placeholder="random" key={'seed' + v.seed} defaultValue={v.seed} onBlur={(e) => save({ seed: e.target.value === '' ? '' : Math.trunc(Number(e.target.value)) })} />
          </label>
          <button type="button" onClick={reset} disabled={!changed}>Reset to defaults</button>
        </div>
      )}
    </section>
  )
}
