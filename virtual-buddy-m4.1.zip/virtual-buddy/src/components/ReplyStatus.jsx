import { useEffect, useState } from 'react'

// Honest progress for the on-device model. The stage comes from the real engine state; the words only
// move forward inside the stage we are really in, and the dots/timer are real elapsed seconds.
const WORDS = {
  loading: ['Waking up', 'Loading', 'Initializing'],
  thinking: ['Remembering', 'Contemplating'],
}
const WORD_SECONDS = 8

function clock(s) { return s < 60 ? `${s}s` : `${Math.floor(s / 60)}m ${String(s % 60).padStart(2, '0')}s` }

export default function ReplyStatus({ stage, since }) {
  const [now, setNow] = useState(Date.now())
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t) }, [])
  if (!stage || !WORDS[stage]) return null
  const secs = Math.max(0, Math.floor((now - since) / 1000))
  const words = WORDS[stage]
  const i = Math.min(words.length - 1, Math.floor(secs / WORD_SECONDS))
  const dots = i === words.length - 1 ? secs - i * WORD_SECONDS : secs % WORD_SECONDS
  let hint = ''
  if (stage === 'loading') {
    if (secs >= 180) hint = "This is taking unusually long and may be stuck. If nothing changes soon, tap ■ and try a smaller model in Settings."
    else if (secs >= 45) hint = "Still loading. The first reply is slow because the model has to be read into memory. I can't see exact progress, but it hasn't failed."
    else hint = 'The first reply is the slowest. After this the model stays awake.'
  } else if (secs >= 60) hint = 'Still thinking. Older phones can be slow with long conversations.'
  return (
    <div className="note soft reply-status" role="status" aria-live="polite">
      <div className="rs-line">{words[i]}{'.'.repeat(dots)} <span className="rs-time">{clock(secs)}</span></div>
      {hint && <div className="rs-hint">{hint}</div>}
    </div>
  )
}
