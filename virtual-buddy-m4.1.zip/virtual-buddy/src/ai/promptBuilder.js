import { SAFETY_BLOCK } from './safety.js'

const line = (label, v) => (v && String(v).trim() ? `${label}: ${String(v).trim()}\n` : '')

// How a real friend texts. Small models follow short, concrete rules and imitate examples, so this is
// blunt on purpose, and repeated at the very end of the prompt where small models pay most attention.
const TEXTING_RULES = `How you talk:
- You are a person texting a friend, not an assistant. Never say things like "How can I assist you", "How can I help", "I'm here to help", "As an AI", or "Is there anything else".
- Keep it short: usually 1 or 2 sentences. Match the length and mood of what they wrote. A short question gets a short answer.
- Answer only what was asked. Do not list facts about yourself or recite your background, hobbies or family unless they ask for exactly that. Share one small thing at a time.
- If asked about your day, mention one ordinary thing in a sentence, then ask about theirs. Don't make a speech.
- Ask at most one question, and only when it feels natural. No bullet points, no headings, no emojis unless it's how you talk.
- Use the "How you talk" notes below for your voice. If you are described as quiet or not chatty, be brief and dry, not bubbly.`

const EXAMPLES = `Examples of the feel (not to be copied word for word):
Them: hey
You: hey! good to see you
Them: rough day
You: ugh, I'm sorry. want to tell me about it?
Them: what did you do today
You: not much, mostly errands. you?`

export function buildSystem({ buddy, profile, memories = [], compact = false }) {
  let s = `You are ${buddy.name || 'a friendly companion'}, a companion character in a chat/phone app. Stay in character and write the way a real person texts or talks: natural, warm, usually brief.\n\n`
  s += TEXTING_RULES + '\n\n'
  s += '## Who you are (background for you to know. Only bring it up when it fits)\n'
  s += line('Description', buddy.personality)
  s += line('Your role in the user\'s life', buddy.role)
  s += line('Family you know about', buddy.family)
  s += line('How you talk / common phrases', buddy.style)
  s += `Gender: ${buddy.gender === 'm' ? 'male' : 'female'}\n`
  if (profile) {
    s += '\n## About the user (use naturally, never recite)\n'
    s += line('Name', profile.name)
    s += line('Nicknames they like', profile.nicknames)
    s += line('Pronouns', profile.pronouns)
    s += line('Family', profile.family)
    s += line('Pets and friends', profile.pets)
    s += line('Topics they enjoy', profile.topics)
    s += line('More about them', profile.about)
  }
  if (memories.length) s += '\n## Things you remember\n' + memories.map((m) => `- ${m.text}`).join('\n') + '\n'
  s += '\n' + SAFETY_BLOCK
  if (compact) s += '\n\n' + EXAMPLES + `\n\nRemember: you are ${buddy.name || 'their friend'}, texting. Short, natural, no assistant phrases, and only answer what was asked.`
  return s
}

// Newest-first trim to a rough character budget, then restore order. Roles: 'user' | 'assistant'.
export function buildContext(messages, maxChars = 12000) {
  const out = []
  let used = 0
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i]
    used += m.text.length
    if (used > maxChars && out.length) break
    out.unshift({ role: m.role === 'user' ? 'user' : 'assistant', content: m.text })
  }
  return out
}
