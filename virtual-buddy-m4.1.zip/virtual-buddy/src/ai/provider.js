import { streamLocal } from './local/engine.js'

export const PROVIDERS = {
  local: { label: 'On this device (private)', keyHint: '' },
  openai: { label: 'OpenAI', keyHint: 'sk-...' },
  anthropic: { label: 'Anthropic', keyHint: 'sk-ant-...' },
  gemini: { label: 'Google Gemini', keyHint: 'AI...' },
  openrouter: { label: 'OpenRouter', keyHint: 'sk-or-...' },
}

// Providers need alternating roles starting with "user"; merge repeats and drop a leading assistant turn.
export function normalize(messages) {
  const out = []
  for (const m of messages) {
    if (out.length && out[out.length - 1].role === m.role) out[out.length - 1].content += '\n' + m.content
    else out.push({ ...m })
  }
  while (out.length && out[0].role !== 'user') out.shift()
  return out
}

// Yields the data payloads of an SSE response.
export async function* sseData(res) {
  const reader = res.body.getReader()
  const dec = new TextDecoder()
  let buf = ''
  for (;;) {
    const { done, value } = await reader.read()
    if (done) break
    buf += dec.decode(value, { stream: true })
    let i
    while ((i = buf.indexOf('\n')) >= 0) {
      const ln = buf.slice(0, i).replace(/\r$/, ''); buf = buf.slice(i + 1)
      if (ln.startsWith('data:')) { const d = ln.slice(5).trim(); if (d && d !== '[DONE]') yield d }
    }
  }
}

function friendlyError(status, body, label) {
  let detail = ''
  try { const j = JSON.parse(body); detail = j.error?.message || j.message || '' } catch { detail = body.slice(0, 200) }
  if (status === 401 || status === 403) return `${label} rejected the API key (${status}). Check the key in Settings.`
  if (status === 404) return `${label} could not find that model. Check the model name in Settings.${detail ? ' (' + detail + ')' : ''}`
  if (status === 429) return `${label} says you're out of quota or sending too fast (429). ${detail}`
  return `${label} error ${status}. ${detail}`
}

async function post(url, headers, body, signal, label) {
  let res
  try { res = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body), signal }) }
  catch (e) { if (e.name === 'AbortError') throw e; throw new Error(`Couldn't reach ${label}. Check your connection.`) }
  if (!res.ok) throw new Error(friendlyError(res.status, await res.text(), label))
  return res
}

export async function* streamChat({ provider, apiKey, model, system, messages, signal, sampling }) {
  const label = PROVIDERS[provider]?.label || provider
  const msgs = normalize(messages)
  if (provider === 'local') {
    yield* streamLocal({ modelUrl: model, system, messages: msgs, signal, sampling })
    return
  }
  if (!apiKey) throw new Error(`Add your ${label} API key in Settings first.`)

  if (provider === 'openai' || provider === 'openrouter') {
    const url = provider === 'openai' ? 'https://api.openai.com/v1/chat/completions' : 'https://openrouter.ai/api/v1/chat/completions'
    const res = await post(url, { authorization: `Bearer ${apiKey}` }, { model, stream: true, messages: [{ role: 'system', content: system }, ...msgs] }, signal, label)
    for await (const d of sseData(res)) { const t = JSON.parse(d).choices?.[0]?.delta?.content; if (t) yield t }
  } else if (provider === 'anthropic') {
    const res = await post('https://api.anthropic.com/v1/messages',
      { 'x-api-key': apiKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
      { model, max_tokens: 1024, stream: true, system, messages: msgs }, signal, label)
    for await (const d of sseData(res)) { const j = JSON.parse(d); if (j.type === 'content_block_delta' && j.delta?.text) yield j.delta.text }
  } else if (provider === 'gemini') {
    const res = await post(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:streamGenerateContent?alt=sse`,
      { 'x-goog-api-key': apiKey },
      { systemInstruction: { parts: [{ text: system }] }, contents: msgs.map((m) => ({ role: m.role === 'user' ? 'user' : 'model', parts: [{ text: m.content }] })) }, signal, label)
    for await (const d of sseData(res)) for (const p of JSON.parse(d).candidates?.[0]?.content?.parts || []) if (p.text) yield p.text
  } else {
    throw new Error('Unknown AI provider. Pick one in Settings.')
  }
}

// Runs a prompt to completion and returns the full text (used for background jobs like memory extraction).
export async function completeChat(args) {
  let out = ''
  for await (const chunk of streamChat(args)) out += chunk
  return out
}
