// Curated on-device models (GGUF, 4-bit). Sizes are approximate. If a link ever 404s the app says so and
// people can still pick their own .gguf file or paste a link in Settings.
export const CATALOG = [
  { id: 'qwen25-05b', name: 'Qwen2.5 0.5B', tier: 'tiny', sizeMB: 400, license: 'Apache 2.0',
    blurb: 'Smallest and fastest. Best for older or low-memory phones.',
    url: 'https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf' },
  { id: 'gemma3-1b', name: 'Gemma 3 1B', tier: 'small', sizeMB: 810, license: 'Gemma Terms of Use',
    blurb: 'A good balance of quality, speed and size.',
    url: 'https://huggingface.co/ggml-org/gemma-3-1b-it-GGUF/resolve/main/gemma-3-1b-it-Q4_K_M.gguf' },
  { id: 'llama32-1b', name: 'Llama 3.2 1B', tier: 'small', sizeMB: 810, license: 'Llama 3.2 Community License',
    blurb: 'A friendly conversationalist of about the same size.',
    url: 'https://huggingface.co/bartowski/Llama-3.2-1B-Instruct-GGUF/resolve/main/Llama-3.2-1B-Instruct-Q4_K_M.gguf' },
  { id: 'qwen25-15b', name: 'Qwen2.5 1.5B', tier: 'good', sizeMB: 1100, license: 'Apache 2.0',
    blurb: 'Noticeably smarter, needs a newer phone with plenty of memory.',
    url: 'https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf' },
]
export const DEMO_MODEL = CATALOG[0]
export const IMPORT_PREFIX = 'https://imported.local/'

// Small models have small context windows, so everything sent to them is trimmed harder.
export const LOCAL_LIMITS = { nCtx: 3072, historyChars: 3500, memoryChars: 1000, maxTokens: 512 }
// Advanced controls for on-device replies. Defaults favour short, steady, human-sounding texts.
export const SAMPLING_DEFAULTS = { temperature: 0.6, top_k: 40, top_p: 0.9, min_p: 0.05, repeat_penalty: 1.15, max_tokens: 200, seed: '' }
export const SAMPLING_FIELDS = [
  { key: 'temperature', label: 'Temperature', min: 0, max: 1.5, step: 0.05, help: 'Lower is calmer and more predictable. Higher is more varied, and small models get silly when it is too high.' },
  { key: 'top_k', label: 'Top K', min: 1, max: 200, step: 1, help: 'Only the K most likely next words are considered. Lower is safer.' },
  { key: 'top_p', label: 'Top P', min: 0.1, max: 1, step: 0.05, help: 'Considers only the most likely words that add up to this share of the probability.' },
  { key: 'min_p', label: 'Min P', min: 0, max: 0.5, step: 0.01, help: 'Drops words that are very unlikely compared to the best one. Helps small models stay on track.' },
  { key: 'repeat_penalty', label: 'Repeat penalty', min: 1, max: 1.6, step: 0.05, help: 'Discourages repeating itself. Too high makes replies odd.' },
  { key: 'max_tokens', label: 'Max reply length (tokens)', min: 30, max: 800, step: 10, help: 'A hard cap on reply length (about 3 tokens per 2 words). Short caps keep a chatty model from rambling.' },
]
export function samplingFrom(saved) { return { ...SAMPLING_DEFAULTS, ...(saved || {}) } }

export const CLOUD_LIMITS = { historyChars: 12000, memoryChars: 2500, maxTokens: 1024 }
export const limitsFor = (provider) => (provider === 'local' ? LOCAL_LIMITS : CLOUD_LIMITS)

export function modelLabel(url) {
  if (!url) return 'an on-device model'
  const hit = CATALOG.find((m) => m.url === url)
  if (hit) return hit.name
  try { return decodeURIComponent(url.split('/').pop()).replace(/\.gguf$/i, '') } catch { return 'an on-device model' }
}
