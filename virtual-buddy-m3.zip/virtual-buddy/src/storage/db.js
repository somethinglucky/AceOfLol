import { openDB } from 'idb'

export const STORES = ['buddy', 'userProfile', 'message', 'memory', 'schedule', 'settings']
const DEFAULT_SETTINGS = {
  id: 'main', theme: 'ice', splashFit: 'cover', buttonLayout: [],
  activeProvider: 'openai', // 'local' arrives in M4
  providers: {
    openai: { apiKey: '', model: 'gpt-4o-mini' },
    anthropic: { apiKey: '', model: 'claude-haiku-4-5' },
    gemini: { apiKey: '', model: 'gemini-flash-latest' },
    openrouter: { apiKey: '', model: 'openrouter/auto' },
  },
  localModelRef: null, activeBuddyId: null, premium: false,
  exitMessage: "You seem to be having a bad day. Let's talk later when you're feeling more like yourself.",
  onboarded: false, lastBackupAt: null,
}

let dbp
export function db() {
  dbp ||= openDB('virtual-buddy', 1, {
    upgrade(d) {
      d.createObjectStore('buddy', { keyPath: 'id' })
      d.createObjectStore('userProfile', { keyPath: 'id' })
      const msg = d.createObjectStore('message', { keyPath: 'id' }); msg.createIndex('byBuddy', 'buddyId')
      const mem = d.createObjectStore('memory', { keyPath: 'id' }); mem.createIndex('byBuddy', 'buddyId')
      const sch = d.createObjectStore('schedule', { keyPath: 'id' }); sch.createIndex('byBuddy', 'buddyId')
      d.createObjectStore('settings', { keyPath: 'id' })
    },
  })
  return dbp
}

export const newId = () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(16).slice(2))

export async function getSettings() {
  const saved = (await (await db()).get('settings', 'main')) || {}
  const providers = { ...DEFAULT_SETTINGS.providers }
  for (const k of Object.keys(providers)) providers[k] = { ...providers[k], ...((saved.providers || {})[k] || {}) }
  if (providers.gemini.model === 'gemini-2.5-flash') providers.gemini.model = DEFAULT_SETTINGS.providers.gemini.model // retired default
  return { ...DEFAULT_SETTINGS, ...saved, providers }
}
export async function putSettings(patch) { const next = { ...(await getSettings()), ...patch }; await (await db()).put('settings', next); return next }
export async function getAll(store) { return (await db()).getAll(store) }
export async function get(store, id) { return (await db()).get(store, id) }
export async function put(store, value) { return (await db()).put(store, value) }
export async function del(store, id) { return (await db()).delete(store, id) }
export async function clearStore(store) { return (await db()).clear(store) }

// ---- buddies / profile / messages ----
export async function getBuddies() { return (await getAll('buddy')).sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0)) }
export async function getProfile() { return (await get('userProfile', 'me')) || null }
export const saveProfile = (p) => put('userProfile', { ...p, id: 'me' })
export async function getMessages(buddyId) {
  return ((await (await db()).getAllFromIndex('message', 'byBuddy', buddyId)) || []).sort((a, b) => a.ts - b.ts)
}
export async function deleteBuddy(id) {
  const d = await db()
  for (const store of ['message', 'memory', 'schedule']) {
    const keys = await d.getAllKeysFromIndex(store, 'byBuddy', id)
    for (const k of keys) await d.delete(store, k)
  }
  await d.delete('buddy', id)
  const s = await getSettings()
  if (s.activeBuddyId === id) await putSettings({ activeBuddyId: null })
}
// Returns the buddy chat/call screens should use, fixing a stale activeBuddyId.
export async function resolveActiveBuddy() {
  const [buddies, s] = await Promise.all([getBuddies(), getSettings()])
  const found = buddies.find((b) => b.id === s.activeBuddyId)
  if (found) return { buddy: found, buddies, needsPick: false }
  if (buddies.length === 1) { await putSettings({ activeBuddyId: buddies[0].id }); return { buddy: buddies[0], buddies, needsPick: false } }
  return { buddy: null, buddies, needsPick: buddies.length > 1 }
}

export function downloadText(text, name, type = 'text/plain') {
  const a = document.createElement('a')
  a.href = URL.createObjectURL(new Blob([text], { type })); a.download = name; a.click()
  setTimeout(() => URL.revokeObjectURL(a.href), 5000)
}
