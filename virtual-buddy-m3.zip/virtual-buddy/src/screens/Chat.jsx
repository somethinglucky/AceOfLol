import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { getSettings, putSettings, getProfile, getMessages, put, newId, resolveActiveBuddy } from '../storage/db.js'
import { streamChat, PROVIDERS } from '../ai/provider.js'
import { buildSystem, buildContext } from '../ai/promptBuilder.js'
import { preSendCheck, EXIT_TOKEN } from '../ai/safety.js'
import Avatar from '../components/Avatar.jsx'
import SelectBuddy from '../components/SelectBuddy.jsx'
import { listMemories } from '../memory/store.js'
import { pickMemories } from '../memory/retrieve.js'
import { extractNow } from '../memory/extract.js'

export default function Chat() {
  const nav = useNavigate()
  const [state, setState] = useState(null) // { buddy, buddies, needsPick, settings }
  const [msgs, setMsgs] = useState([])
  const [input, setInput] = useState('')
  const [live, setLive] = useState(null)   // text of the reply being streamed (null = none)
  const [busy, setBusy] = useState(false)
  const [note, setNote] = useState('')
  const [picking, setPicking] = useState(false)
  const abort = useRef(null)
  const end = useRef(null)

  async function load() {
    const r = await resolveActiveBuddy()
    const settings = await getSettings()
    setState({ ...r, settings })
    if (r.buddy) { setMsgs(await getMessages(r.buddy.id)); extractNow(r.buddy, { minUserMsgs: 3, quietMs: 30 * 60 * 1000 }) }
    else if (!r.buddies.length) nav('/buddy/edit', { replace: true })
  }
  useEffect(() => { load(); return () => abort.current?.abort() }, [])
  useEffect(() => { end.current?.scrollIntoView({ block: 'end' }) }, [msgs, live, note])
  // Leaving the app/tab is a natural end of conversation: let the buddy update their memories.
  const buddyRef = useRef(null)
  useEffect(() => { buddyRef.current = state?.buddy || null }, [state])
  useEffect(() => {
    const onHide = () => { if (document.visibilityState === 'hidden' && buddyRef.current) extractNow(buddyRef.current, { minUserMsgs: 3 }) }
    document.addEventListener('visibilitychange', onHide)
    return () => document.removeEventListener('visibilitychange', onHide)
  }, [])

  if (!state) return null
  const { buddy, buddies, settings } = state
  if (!buddy) return state.needsPick
    ? <SelectBuddy buddies={buddies} onPick={async (b) => { await putSettings({ activeBuddyId: b.id }); load() }} />
    : null

  async function send() {
    const text = input.trim()
    if (!text || busy) return
    setNote(''); setInput('')
    const userMsg = { id: newId(), buddyId: buddy.id, role: 'user', text, ts: Date.now(), source: 'text' }
    await put('message', userMsg)
    const history = [...msgs, userMsg]
    setMsgs(history)

    const pre = preSendCheck(text)
    if (pre?.block) {
      const m = { id: newId(), buddyId: buddy.id, role: 'buddy', text: pre.reply, ts: Date.now(), modelUsed: 'local-rule', source: 'text' }
      await put('message', m); setMsgs([...history, m]); return
    }

    const s = await getSettings()
    const provider = s.activeProvider
    const cfg = s.providers[provider] || {}
    setBusy(true); setLive('')
    abort.current = new AbortController()
    let acc = ''
    try {
      const profile = await getProfile()
      const recent = history.slice(-3).map((m) => m.text).join(' ')
      const memories = pickMemories(await listMemories(buddy.id), recent)
      const system = buildSystem({ buddy, profile, memories })
      const ctx = buildContext(history.map((m) => ({ role: m.role === 'user' ? 'user' : 'assistant', text: m.text })))
      for await (const chunk of streamChat({ provider, apiKey: cfg.apiKey, model: cfg.model, system, messages: ctx, signal: abort.current.signal })) {
        acc += chunk; setLive(acc)
      }
    } catch (e) {
      if (e.name !== 'AbortError') setNote(e.message)
    }
    let final = acc.trim()
    if (final.startsWith(EXIT_TOKEN)) final = s.exitMessage
    if (final) {
      const m = { id: newId(), buddyId: buddy.id, role: 'buddy', text: final, ts: Date.now(), modelUsed: `${provider}:${cfg.model}`, source: 'text' }
      await put('message', m); setMsgs([...history, m])
      extractNow(buddy, { minUserMsgs: 8 }) // background; never blocks the chat
    }
    setLive(null); setBusy(false)
  }

  // While the streamed text could still turn into the exit token, keep showing the typing dots.
  const hideLive = live !== null && (live.trim() === '' || EXIT_TOKEN.startsWith(live.trim()) || live.trim().startsWith(EXIT_TOKEN))
  const label = PROVIDERS[settings.activeProvider]?.label

  return (
    <div className="chat">
      <div className="chat-head">
        <Avatar blob={buddy.avatar} name={buddy.name} size={36} />
        <div><strong>{buddy.name}</strong><div className="small muted">{label ? `via ${label}` : 'offline'}</div></div>
        {buddies.length > 1 && <button className="plain" onClick={() => setPicking(true)}>Switch</button>}
      </div>
      <div className="chat-list">
        {msgs.length === 0 && live === null && <p className="muted center-text">Say hi to {buddy.name}.</p>}
        {msgs.map((m) => <div key={m.id} className={`bubble ${m.role === 'user' ? 'me' : 'them'}`}>{m.text}</div>)}
        {live !== null && (hideLive
          ? <div className="bubble them typing"><i /><i /><i /></div>
          : <div className="bubble them">{live}</div>)}
        {note && <div className="note">{note}</div>}
        <div ref={end} />
      </div>
      <div className="composer">
        <textarea rows={1} value={input} placeholder="Message" onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey && window.matchMedia('(pointer: fine)').matches) { e.preventDefault(); send() } }} />
        <button className="send" aria-label="Send" disabled={busy || !input.trim()} onClick={send}>↑</button>
      </div>
      {picking && <SelectBuddy buddies={buddies} onClose={() => setPicking(false)}
        onPick={async (b) => { await putSettings({ activeBuddyId: b.id }); setPicking(false); load() }} />}
    </div>
  )
}
