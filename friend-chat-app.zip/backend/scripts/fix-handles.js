// One-time cleanup: regenerates any handle that contains a digit, left
// over from before HANDLE_CHARS excluded them (see routes/auth.js).
// Safe to run — public_handle only ever lives in the users table (nothing
// else stores a copy of it), so changing it here is instantly reflected
// everywhere it's displayed, with nothing left stale.
//
// Usage (from the backend/ folder): node scripts/fix-handles.js
//
// Safe to run more than once — if there's nothing left with a digit in
// it, it does nothing and says so.

const crypto = require('crypto');
const db = require('../src/db/connection');

const HANDLE_CHARS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
const HANDLE_LENGTH = 7;

function generateUniqueHandle(checkExists) {
  for (let attempt = 0; attempt < 10; attempt++) {
    let handle = '';
    const bytes = crypto.randomBytes(HANDLE_LENGTH);
    for (let i = 0; i < HANDLE_LENGTH; i++) {
      handle += HANDLE_CHARS[bytes[i] % HANDLE_CHARS.length];
    }
    if (!checkExists.get(handle)) return handle;
  }
  throw new Error('Could not generate a unique handle after 10 attempts');
}

const checkExists = db.prepare('SELECT 1 FROM users WHERE public_handle = ?');
const updateHandle = db.prepare('UPDATE users SET public_handle = ? WHERE id = ?');

// GLOB (not LIKE) so the digit-class match is case-sensitive-safe and
// doesn't need escaping — SQLite GLOB supports [0-9] character classes.
const affected = db.prepare("SELECT id, public_handle FROM users WHERE public_handle GLOB '*[0-9]*'").all();

if (affected.length === 0) {
  console.log('No handles contain digits — nothing to do.');
  process.exit(0);
}

console.log(`Found ${affected.length} handle(s) with digits. Regenerating...\n`);

for (const user of affected) {
  const oldHandle = user.public_handle;
  const newHandle = generateUniqueHandle(checkExists);
  updateHandle.run(newHandle, user.id);
  console.log(`${oldHandle}  ->  ${newHandle}`);
}

console.log('\nDone. Anyone whose handle just changed will see the new one next time they load the app.');
