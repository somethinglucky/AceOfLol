const express = require('express');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const db = require('../db/connection');
const { signToken, requireAuth } = require('../middleware/auth');

const router = express.Router();

// Mixed-case + digits, matching the "abcdEFg" style handle format.
const HANDLE_CHARS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
const HANDLE_LENGTH = 7;

function generateUniqueHandle() {
  const checkExists = db.prepare('SELECT 1 FROM users WHERE public_handle = ?');

  for (let attempt = 0; attempt < 10; attempt++) {
    let handle = '';
    const bytes = crypto.randomBytes(HANDLE_LENGTH);
    for (let i = 0; i < HANDLE_LENGTH; i++) {
      handle += HANDLE_CHARS[bytes[i] % HANDLE_CHARS.length];
    }
    if (!checkExists.get(handle)) {
      return handle;
    }
  }
  // 62^7 (~3.5 trillion) combinations makes this effectively unreachable,
  // but fail loudly rather than silently return a colliding handle.
  throw new Error('Could not generate a unique handle after 10 attempts');
}

// POST /auth/guest
// No body needed. Creates a brand-new guest identity — no email, no
// password, no nickname yet — and returns a token for it immediately.
// The frontend only calls this once per browser, the first time someone
// hits Send without an existing token stored.
router.post('/guest', (req, res) => {
  const userId = crypto.randomUUID();
  const profileId = crypto.randomUUID();
  const handle = generateUniqueHandle();

  const createGuest = db.transaction(() => {
    db.prepare(
      `INSERT INTO users (id, public_handle, is_registered) VALUES (?, ?, 0)`
    ).run(userId, handle);

    db.prepare(`INSERT INTO profiles (id, user_id) VALUES (?, ?)`).run(profileId, userId);
    db.prepare(`INSERT INTO profile_attributes (profile_id) VALUES (?)`).run(profileId);
    db.prepare(`INSERT INTO profile_preferences (profile_id) VALUES (?)`).run(profileId);
  });
  createGuest();

  const token = signToken(userId);
  res.status(201).json({
    token,
    user: { id: userId, handle, nickname: null, isRegistered: false },
  });
});

// POST /auth/signup
// For someone registering directly, with no prior guest identity at all.
// body: { email, password, nickname }
router.post('/signup', async (req, res) => {
  const { email, password, nickname } = req.body;

  if (!email || !password || !nickname) {
    return res.status(400).json({ error: 'email, password, and nickname are required' });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: 'Password must be at least 8 characters' });
  }

  const existing = db.prepare('SELECT 1 FROM users WHERE email = ?').get(email);
  if (existing) {
    return res.status(409).json({ error: 'An account with that email already exists' });
  }

  const userId = crypto.randomUUID();
  const profileId = crypto.randomUUID();
  const handle = generateUniqueHandle();
  const passwordHash = await bcrypt.hash(password, 12);

  const createAccount = db.transaction(() => {
    db.prepare(
      `INSERT INTO users (id, public_handle, email, password_hash, is_registered) VALUES (?, ?, ?, ?, 1)`
    ).run(userId, handle, email, passwordHash);

    db.prepare(`INSERT INTO profiles (id, user_id, nickname) VALUES (?, ?, ?)`).run(
      profileId,
      userId,
      nickname
    );
    db.prepare(`INSERT INTO profile_attributes (profile_id) VALUES (?)`).run(profileId);
    db.prepare(`INSERT INTO profile_preferences (profile_id) VALUES (?)`).run(profileId);
  });
  createAccount();

  const token = signToken(userId);
  res.status(201).json({
    token,
    user: { id: userId, handle, email, nickname, isRegistered: true },
  });
});

// POST /auth/register
// Upgrades an EXISTING guest identity into a full registered account —
// same user_id, same handle, same message history, just adds credentials.
// Requires the guest's token (Authorization header), same as any protected route.
// body: { email, password, nickname }
router.post('/register', requireAuth, async (req, res) => {
  const { email, password, nickname } = req.body;

  if (!email || !password || !nickname) {
    return res.status(400).json({ error: 'email, password, and nickname are required' });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: 'Password must be at least 8 characters' });
  }

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.userId);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  if (user.is_registered) {
    return res.status(409).json({ error: 'This identity is already registered' });
  }

  const existingEmail = db.prepare('SELECT 1 FROM users WHERE email = ?').get(email);
  if (existingEmail) {
    return res.status(409).json({ error: 'An account with that email already exists' });
  }

  const passwordHash = await bcrypt.hash(password, 12);

  const upgrade = db.transaction(() => {
    db.prepare(
      `UPDATE users SET email = ?, password_hash = ?, is_registered = 1 WHERE id = ?`
    ).run(email, passwordHash, req.userId);

    db.prepare(`UPDATE profiles SET nickname = ? WHERE user_id = ?`).run(nickname, req.userId);
  });
  upgrade();

  // Re-issue the token so the client always has a fresh one after any auth
  // state change, even though the subject (user id) hasn't changed.
  const token = signToken(req.userId);
  res.json({
    token,
    user: { id: req.userId, handle: user.public_handle, email, nickname, isRegistered: true },
  });
});

// POST /auth/login
// body: { email, password }
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'email and password are required' });
  }

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  const profile = db.prepare('SELECT nickname FROM profiles WHERE user_id = ?').get(user.id);
  const token = signToken(user.id);

  res.json({
    token,
    user: {
      id: user.id,
      handle: user.public_handle,
      email: user.email,
      nickname: profile ? profile.nickname : null,
      isRegistered: true,
    },
  });
});

module.exports = router;
