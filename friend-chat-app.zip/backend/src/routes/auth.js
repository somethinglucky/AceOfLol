const express = require('express');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const db = require('../db/connection');
const { signToken } = require('../middleware/auth');

const router = express.Router();

const HANDLE_CHARS = 'abcdefghijklmnopqrstuvwxyz0123456789';
const HANDLE_LENGTH = 7;

// Generates a random handle like "63ua1i" and retries on the rare collision.
// A uniqueness check per attempt is cheap thanks to the index on public_handle.
function generateUniqueHandle() {
  const checkExists = db.prepare('SELECT 1 FROM users WHERE public_handle = ?');

  for (let attempt = 0; attempt < 10; attempt++) {
    let handle = '';
    const bytes = crypto.randomBytes(HANDLE_LENGTH);
    for (let i = 0; i < HANDLE_LENGTH; i++) {
      handle += HANDLE_CHARS[bytes[i] % HANDLE_CHARS.length];
    }
    if (!checkExists.get(handle)) {
      return handle;
    }
  }
  // Astronomically unlikely with 36^7 (~78 billion) combinations, but fail loudly
  // rather than silently returning a colliding handle if it ever happens.
  throw new Error('Could not generate a unique handle after 10 attempts');
}

// POST /auth/signup
// body: { email, password, nickname }
router.post('/signup', async (req, res) => {
  const { email, password, nickname } = req.body;

  if (!email || !password || !nickname) {
    return res.status(400).json({ error: 'email, password, and nickname are required' });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: 'Password must be at least 8 characters' });
  }

  const existing = db.prepare('SELECT 1 FROM users WHERE email = ?').get(email);
  if (existing) {
    return res.status(409).json({ error: 'An account with that email already exists' });
  }

  const userId = crypto.randomUUID();
  const profileId = crypto.randomUUID();
  const handle = generateUniqueHandle();
  const passwordHash = await bcrypt.hash(password, 12);

  // Wrap the two inserts in a transaction so a failure never leaves a user
  // without a profile (or vice versa).
  const createAccount = db.transaction(() => {
    db.prepare(
      `INSERT INTO users (id, public_handle, email, password_hash) VALUES (?, ?, ?, ?)`
    ).run(userId, handle, email, passwordHash);

    db.prepare(
      `INSERT INTO profiles (id, user_id, nickname) VALUES (?, ?, ?)`
    ).run(profileId, userId, nickname);

    // Every profile gets an empty attributes/preferences row up front so later
    // UPDATE statements in profiles.js never have to check "does this row exist yet."
    db.prepare(`INSERT INTO profile_attributes (profile_id) VALUES (?)`).run(profileId);
    db.prepare(`INSERT INTO profile_preferences (profile_id) VALUES (?)`).run(profileId);
  });
  createAccount();

  const token = signToken(userId);
  res.status(201).json({
    token,
    user: { id: userId, handle, email, nickname },
  });
});

// POST /auth/login
// body: { email, password }
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'email and password are required' });
  }

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user) {
    // Same error for "no such user" and "wrong password" — don't leak which one it was.
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  const profile = db.prepare('SELECT nickname FROM profiles WHERE user_id = ?').get(user.id);
  const token = signToken(user.id);

  res.json({
    token,
    user: {
      id: user.id,
      handle: user.public_handle,
      email: user.email,
      nickname: profile ? profile.nickname : null,
    },
  });
});

module.exports = router;
