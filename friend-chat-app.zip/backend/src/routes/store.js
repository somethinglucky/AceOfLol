// ============================================================
// Public store routes — browsing the catalog and starting a purchase.
// Every store item is USD-only by schema constraint (see migration 007);
// this file never has an "pay in gems" branch to remove later, because
// there's nothing to remove.
//
// Checkout uses Stripe Checkout Sessions (hosted page) rather than
// building a card form by hand — no card data ever touches this server,
// and Stripe's own hosted page handles shipping-address collection for
// physical items, so there's no custom address form to build/validate here.
// ============================================================

const express = require('express');
const crypto = require('crypto');
const db = require('../db/connection');
const { requireRegistered } = require('../middleware/auth');
const storage = require('../storage/feedStorage'); // shared local-disk image storage, same one the feed uses

const router = express.Router();

function getStripe() {
  if (!process.env.STRIPE_SECRET_KEY) {
    throw new Error('STRIPE_SECRET_KEY is not set — add it to .env before taking payments.');
  }
  // eslint-disable-next-line global-require
  return require('stripe')(process.env.STRIPE_SECRET_KEY);
}

function serializeItem(row) {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    imageUrl: row.image_path ? storage.urlFor(row.image_path) : null,
    priceUsdCents: row.price_usd_cents,
    itemType: row.item_type,
    gemAmount: row.gem_amount,
    requiresShipping: !!row.requires_shipping,
  };
}

// GET /api/store/items — active listings only, newest-first within sort_order.
router.get('/items', (req, res) => {
  const rows = db
    .prepare(
      `SELECT * FROM store_items WHERE is_active = 1 ORDER BY sort_order ASC, created_at DESC`
    )
    .all();
  res.json({ items: rows.map(serializeItem) });
});

// GET /api/store/wallet — the caller's own gem balance. Registered users only,
// since guests can't hold a persistent identity worth crediting gems to.
router.get('/wallet', requireRegistered, (req, res) => {
  const gems = require('../services/gems');
  res.json({ balance: gems.getBalance(req.user.id) });
});

// POST /api/store/checkout — body: { itemId }. Creates a pending order +
// a Stripe Checkout Session, returns the session URL for the frontend to
// redirect to. The order is only ever marked 'paid' by the webhook handler
// in routes/webhooks.js, never here — this route just starts the payment.
router.post('/checkout', requireRegistered, async (req, res) => {
  const { itemId } = req.body || {};
  const item = db.prepare('SELECT * FROM store_items WHERE id = ? AND is_active = 1').get(itemId);
  if (!item) return res.status(404).json({ error: 'Item not found or no longer available.' });

  const orderId = crypto.randomUUID();
  db.prepare(
    `INSERT INTO orders (id, user_id, item_id, amount_usd_cents, status)
     VALUES (?, ?, ?, ?, 'pending')`
  ).run(orderId, req.user.id, item.id, item.price_usd_cents);

  try {
    const stripe = getStripe();
    const baseUrl = process.env.PUBLIC_APP_URL || 'https://aceof.lol';

    const sessionParams = {
      mode: 'payment',
      payment_method_types: ['card'],
      line_items: [
        {
          quantity: 1,
          price_data: {
            currency: 'usd',
            unit_amount: item.price_usd_cents,
            product_data: {
              name: item.name,
              description: item.description || undefined,
            },
          },
        },
      ],
      metadata: { orderId },
      success_url: `${baseUrl}/?page=store&checkout=success`,
      cancel_url: `${baseUrl}/?page=store&checkout=cancelled`,
    };

    // Only physical items collect a shipping address — gem packs and
    // digital items never do, since there's nothing to ship.
    if (item.requires_shipping) {
      sessionParams.shipping_address_collection = { allowed_countries: ['US', 'CA'] };
    }

    const session = await stripe.checkout.sessions.create(sessionParams);

    db.prepare('UPDATE orders SET stripe_checkout_session_id = ? WHERE id = ?').run(session.id, orderId);

    res.json({ checkoutUrl: session.url });
  } catch (err) {
    console.error('[store checkout] Stripe error:', err.message);
    db.prepare("UPDATE orders SET status = 'failed' WHERE id = ?").run(orderId);
    res.status(502).json({ error: 'Could not start checkout. Please try again.' });
  }
});

// GET /api/store/orders — the caller's own order history (Settings page /
// "my purchases" can use this later; not wired into any UI yet).
router.get('/orders', requireRegistered, (req, res) => {
  const rows = db
    .prepare(
      `SELECT o.id, o.amount_usd_cents AS amountUsdCents, o.status, o.created_at AS createdAt,
              si.name AS itemName
       FROM orders o JOIN store_items si ON si.id = o.item_id
       WHERE o.user_id = ?
       ORDER BY o.created_at DESC`
    )
    .all(req.user.id);
  res.json({ orders: rows });
});

module.exports = router;
