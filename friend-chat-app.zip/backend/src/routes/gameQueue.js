// ============================================================
// Play-a-Stranger speeddate queue (Games spec §7). Mounted with
// mergeParams at /api/games/:gameId/queue in server.js.
// ============================================================

const express = require('express');
const db = require('../db/connection');
const { requireRegistered } = require('../middleware/auth');
const { strangerSeatCost } = require('../games/pricing');
const gems = require('../services/gems');
const { createWaitingSession, markArrived } = require('../games/sessionEngine');

const router = express.Router({ mergeParams: true });

function isBlockedEitherWay(userA, userB) {
  return !!db
    .prepare('SELECT 1 FROM blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?)')
    .get(userA, userB, userB, userA);
}

function getGameDef(gameId) {
  return db.prepare('SELECT * FROM game_definitions WHERE game_id = ? AND is_active = 1').get(gameId);
}

// Tries to fill a full table for gameDef out of the current queue,
// respecting the block list (spec §7: "never matched with someone who has
// blocked them, or whom they've blocked"). Greedy pick, oldest first —
// fine at this scale, and correct is more important than clever here.
function tryMatch(gameDef) {
  const needed = gameDef.min_players;
  const candidates = db
    .prepare('SELECT user_id, joined_at FROM speeddate_queue WHERE game_id = ? ORDER BY joined_at ASC')
    .all(gameDef.game_id);

  const isPremium = (userId) => !!db.prepare('SELECT is_premium FROM users WHERE id = ?').get(userId)?.is_premium;

  const picked = [];
  for (const candidate of candidates) {
    if (picked.some((p) => isBlockedEitherWay(p, candidate.user_id))) continue;
    // Check affordability BEFORE picking anyone into the table — the
    // debit loop below must never fail partway through with some seats
    // already charged and others not (that used to be a real bug here:
    // a mid-loop failure left already-charged players still queued, so
    // the very next match attempt would charge them a second time for
    // the same seat). Bench anyone who can't afford it instead.
    const cost = strangerSeatCost(gameDef, isPremium(candidate.user_id));
    if (cost > 0 && gems.getBalance(candidate.user_id) < cost) continue;
    picked.push(candidate.user_id);
    if (picked.length === needed) break;
  }
  if (picked.length < needed) return null;

  for (const userId of picked) {
    const cost = strangerSeatCost(gameDef, isPremium(userId));
    if (cost > 0) gems.debit(userId, cost, 'game_stranger_charge', null, `Stranger match: ${gameDef.display_name}`);
  }

  picked.forEach((userId) =>
    db.prepare('DELETE FROM speeddate_queue WHERE game_id = ? AND user_id = ?').run(gameDef.game_id, userId)
  );

  // No scheduling for a stranger match — whoever joined the queue first
  // moves first, and every seat is marked arrived immediately since
  // there's no wait to route people in (spec §6 step 10 only applies to
  // the invite flow's scheduled wait).
  const sessionId = createWaitingSession({
    gameId: gameDef.game_id,
    playerIds: picked,
    firstMoverId: picked[0],
    source: 'stranger',
  });
  picked.forEach((userId) => markArrived(sessionId, userId));
  return sessionId;
}

// POST /api/games/:gameId/queue — join. Returns immediately whether a
// match was made right away (small tables fill fast) or the caller is
// just waiting.
router.post('/', requireRegistered, (req, res) => {
  const gameDef = getGameDef(req.params.gameId);
  if (!gameDef) return res.status(404).json({ error: 'Game not found.' });

  const alreadyQueued = db
    .prepare('SELECT 1 FROM speeddate_queue WHERE game_id = ? AND user_id = ?')
    .get(gameDef.game_id, req.user.id);
  if (!alreadyQueued) {
    db.prepare('INSERT INTO speeddate_queue (game_id, user_id) VALUES (?, ?)').run(gameDef.game_id, req.user.id);
  }

  const sessionId = tryMatch(gameDef);
  res.status(201).json({ queued: !sessionId, sessionId });
});

// GET /api/games/:gameId/queue/status — for the lobby to poll while
// waiting on a match (e.g. two players needed but only one queued so far).
router.get('/status', requireRegistered, (req, res) => {
  const gameDef = getGameDef(req.params.gameId);
  if (!gameDef) return res.status(404).json({ error: 'Game not found.' });

  const stillQueued = db
    .prepare('SELECT 1 FROM speeddate_queue WHERE game_id = ? AND user_id = ?')
    .get(gameDef.game_id, req.user.id);
  if (stillQueued) return res.json({ queued: true, sessionId: null });

  const resumable = db
    .prepare(
      `SELECT gsp.session_id AS id FROM game_session_players gsp
       JOIN game_sessions gs ON gs.id = gsp.session_id
       WHERE gsp.user_id = ? AND gs.game_id = ? AND gs.source = 'stranger' AND gs.status = 'active'
       ORDER BY gs.created_at DESC LIMIT 1`
    )
    .get(req.user.id, gameDef.game_id);
  res.json({ queued: false, sessionId: resumable ? resumable.id : null });
});

// DELETE /api/games/:gameId/queue — leave before a match is found.
router.delete('/', requireRegistered, (req, res) => {
  db.prepare('DELETE FROM speeddate_queue WHERE game_id = ? AND user_id = ?').run(req.params.gameId, req.user.id);
  res.json({ queued: false });
});

module.exports = router;
