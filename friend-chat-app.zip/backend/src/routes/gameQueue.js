// ============================================================
// Play-a-Stranger speeddate queue (Games spec §7). Mounted with
// mergeParams at /api/games/:gameId/queue in server.js.
// ============================================================

const express = require('express');
const db = require('../db/connection');
const { requireRegistered } = require('../middleware/auth');
const { strangerSeatCost } = require('../games/pricing');
const gems = require('../services/gems');
const { createWaitingSession, markArrived } = require('../games/sessionEngine');

const router = express.Router({ mergeParams: true });

// How long a queue entry counts as "genuinely still there" without a
// fresh heartbeat (see the /status poll below). Chosen to match sj's own
// read on real usage: someone who doesn't get matched in the first few
// seconds tends to give up and leave without explicitly clicking "leave
// queue" — so treating them as gone after a short, bounded window is
// closer to true than treating an untouched row as waiting indefinitely.
const QUEUE_FRESHNESS_SECONDS = 60;
// Rows older than this get swept out entirely (not just ignored) so the
// table doesn't accumulate garbage forever — deliberately longer than the
// freshness window so it never interferes with the check above, it's
// purely housekeeping.
const QUEUE_SWEEP_MINUTES = 10;

function isBlockedEitherWay(userA, userB) {
  return !!db
    .prepare('SELECT 1 FROM blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?)')
    .get(userA, userB, userB, userA);
}

function getGameDef(gameId) {
  return db.prepare('SELECT * FROM game_definitions WHERE game_id = ? AND is_active = 1').get(gameId);
}

function sweepStaleQueueRows() {
  db.prepare(`DELETE FROM speeddate_queue WHERE last_seen_at < datetime('now', '-${QUEUE_SWEEP_MINUTES} minutes')`).run();
}

// Tries to fill a full table for gameDef out of the current queue,
// respecting the block list (spec §7: "never matched with someone who has
// blocked them, or whom they've blocked"). Greedy pick, oldest first —
// fine at this scale, and correct is more important than clever here.
// Only considers candidates with a fresh heartbeat (see
// QUEUE_FRESHNESS_SECONDS) — otherwise a new joiner could get matched
// against someone who left minutes or hours ago and will never arrive.
function tryMatch(gameDef) {
  const needed = gameDef.min_players;
  const candidates = db
    .prepare(
      `SELECT user_id, joined_at FROM speeddate_queue
       WHERE game_id = ? AND last_seen_at > datetime('now', '-${QUEUE_FRESHNESS_SECONDS} seconds')
       ORDER BY joined_at ASC`
    )
    .all(gameDef.game_id);

  const isPremium = (userId) => !!db.prepare('SELECT is_premium FROM users WHERE id = ?').get(userId)?.is_premium;

  const picked = [];
  for (const candidate of candidates) {
    if (picked.some((p) => isBlockedEitherWay(p, candidate.user_id))) continue;
    // Check affordability BEFORE picking anyone into the table — the
    // debit loop below must never fail partway through with some seats
    // already charged and others not (that used to be a real bug here:
    // a mid-loop failure left already-charged players still queued, so
    // the very next match attempt would charge them a second time for
    // the same seat). Bench anyone who can't afford it instead.
    const cost = strangerSeatCost(gameDef, isPremium(candidate.user_id));
    if (cost > 0 && gems.getBalance(candidate.user_id) < cost) continue;
    picked.push(candidate.user_id);
    if (picked.length === needed) break;
  }
  if (picked.length < needed) return null;

  for (const userId of picked) {
    const cost = strangerSeatCost(gameDef, isPremium(userId));
    if (cost > 0) gems.debit(userId, cost, 'game_stranger_charge', null, `Stranger match: ${gameDef.display_name}`);
  }

  picked.forEach((userId) =>
    db.prepare('DELETE FROM speeddate_queue WHERE game_id = ? AND user_id = ?').run(gameDef.game_id, userId)
  );

  // No scheduling for a stranger match — whoever joined the queue first
  // moves first, and every seat is marked arrived immediately since
  // there's no wait to route people in (spec §6 step 10 only applies to
  // the invite flow's scheduled wait).
  const sessionId = createWaitingSession({
    gameId: gameDef.game_id,
    playerIds: picked,
    firstMoverId: picked[0],
    source: 'stranger',
  });
  picked.forEach((userId) => markArrived(sessionId, userId));
  return sessionId;
}

// POST /api/games/:gameId/queue — join. Returns immediately whether a
// match was made right away (small tables fill fast) or the caller is
// just waiting.
router.post('/', requireRegistered, (req, res) => {
  const gameDef = getGameDef(req.params.gameId);
  if (!gameDef) return res.status(404).json({ error: 'Game not found.' });

  sweepStaleQueueRows();

  const alreadyQueued = db
    .prepare('SELECT 1 FROM speeddate_queue WHERE game_id = ? AND user_id = ?')
    .get(gameDef.game_id, req.user.id);
  if (alreadyQueued) {
    // Rejoining counts as a heartbeat too — otherwise leaving the lobby
    // and tapping "Play a Stranger" again while still technically queued
    // wouldn't refresh anything.
    db.prepare("UPDATE speeddate_queue SET last_seen_at = datetime('now') WHERE game_id = ? AND user_id = ?").run(gameDef.game_id, req.user.id);
  } else {
    db.prepare(
      "INSERT INTO speeddate_queue (game_id, user_id, last_seen_at) VALUES (?, ?, datetime('now'))"
    ).run(gameDef.game_id, req.user.id);
  }

  const sessionId = tryMatch(gameDef);
  res.status(201).json({ queued: !sessionId, sessionId });
});

// GET /api/games/:gameId/queue/status — for the lobby to poll while
// waiting on a match. Doubles as this player's heartbeat: every poll
// refreshes last_seen_at, which is exactly what keeps a genuinely-present
// waiter fresh (and, implicitly, is why someone who closes the tab and
// stops polling goes stale within QUEUE_FRESHNESS_SECONDS instead of
// staying "waiting" forever).
router.get('/status', requireRegistered, (req, res) => {
  const gameDef = getGameDef(req.params.gameId);
  if (!gameDef) return res.status(404).json({ error: 'Game not found.' });

  const info = db
    .prepare('UPDATE speeddate_queue SET last_seen_at = datetime(\'now\') WHERE game_id = ? AND user_id = ?')
    .run(gameDef.game_id, req.user.id);
  if (info.changes > 0) return res.json({ queued: true, sessionId: null });

  const resumable = db
    .prepare(
      `SELECT gsp.session_id AS id FROM game_session_players gsp
       JOIN game_sessions gs ON gs.id = gsp.session_id
       WHERE gsp.user_id = ? AND gs.game_id = ? AND gs.source = 'stranger' AND gs.status = 'active'
       ORDER BY gs.created_at DESC LIMIT 1`
    )
    .get(req.user.id, gameDef.game_id);
  res.json({ queued: false, sessionId: resumable ? resumable.id : null });
});

// DELETE /api/games/:gameId/queue — leave before a match is found.
router.delete('/', requireRegistered, (req, res) => {
  db.prepare('DELETE FROM speeddate_queue WHERE game_id = ? AND user_id = ?').run(req.params.gameId, req.user.id);
  res.json({ queued: false });
});

module.exports = router;

