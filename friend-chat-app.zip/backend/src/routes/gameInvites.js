// ============================================================
// Invite Flow state machine (Games spec §6). Mounted at /api/game-invites.
//
// State diagram: draft (client-side only, nothing written until Submit)
// -> pending -> confirmed (-> a GameSession is created) -> expired
// branches off pending only, never off confirmed.
//
// Notification delivery: "invite sent" and "invite confirmed" (spec §11)
// go out as a DM (see services/dmMessages.js) — this is the primary way
// an invitee ever learns about an invite at all right now, not just a
// nice-to-have. Real push notifications and email still aren't built —
// there's no email-sending infrastructure in this app yet — and neither
// is the 24h/48h reminder scheduling, which needs a job scheduler this
// app doesn't have. Both are clean follow-ups once that infra exists.
// ============================================================

const express = require('express');
const crypto = require('crypto');
const db = require('../db/connection');
const { requireRegistered } = require('../middleware/auth');
const { inviteCost } = require('../games/pricing');
const gems = require('../services/gems');
const { createWaitingSession } = require('../games/sessionEngine');
const { sendDirectMessage } = require('../services/dmMessages');
const { getIo } = require('../sockets/ioBridge');

const router = express.Router();

// Keep in sync with frontend/src/data/inviteTemplates.js — the actual
// designs are a frontend concern (CSS today, real artwork later), but the
// backend still validates against the same id list so a stray/tampered
// value can't end up stored and then fail to resolve to anything at reveal
// time.
const VALID_TEMPLATE_IDS = ['classic', 'gold', 'midnight', 'botanical', 'noir'];

function nicknameOf(userId) {
  return db.prepare('SELECT nickname FROM profiles WHERE user_id = ?').get(userId)?.nickname || 'Someone';
}

function isBlockedEitherWay(userA, userB) {
  return !!db
    .prepare('SELECT 1 FROM blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?)')
    .get(userA, userB, userB, userA);
}

// Accepts a userId, handle, or email in one field, per the spec's "enters
// invitee's userID or email" — handle is a common enough thing to paste
// in from a NameTag that it's worth resolving too. Returns
// { inviteeId, inviteeEmail } — exactly one of which is set.
function resolveInvitee(input) {
  const byId = db.prepare('SELECT id FROM users WHERE id = ?').get(input);
  if (byId) return { inviteeId: byId.id, inviteeEmail: null };
  const byHandle = db.prepare('SELECT id FROM users WHERE public_handle = ?').get(input);
  if (byHandle) return { inviteeId: byHandle.id, inviteeEmail: null };
  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input)) return { inviteeId: null, inviteeEmail: input };
  return null;
}

// Lazily flips a stale pending invite to expired — there's no cron here,
// so this runs whenever an invite is read/acted on instead.
function expireIfNeeded(invite) {
  if (invite.status === 'pending' && new Date(invite.expires_at) <= new Date()) {
    db.prepare("UPDATE game_invites SET status = 'expired' WHERE id = ?").run(invite.id);
    return { ...invite, status: 'expired' };
  }
  return invite;
}

function userSummary(userId) {
  if (!userId) return null;
  const row = db
    .prepare('SELECT u.id, u.public_handle AS handle, p.nickname FROM users u JOIN profiles p ON p.user_id = u.id WHERE u.id = ?')
    .get(userId);
  return row || null;
}

// Includes the game's display name/icon and both parties' nickname/handle
// inline — the global Invites tab (DMsPage.jsx) lists invites across every
// game at once, so it needs enough here to render a full row without a
// second round trip per invite.
function serialize(invite) {
  const gameDef = db.prepare('SELECT display_name, icon FROM game_definitions WHERE game_id = ?').get(invite.game_id);
  return {
    id: invite.id,
    gameId: invite.game_id,
    gameName: gameDef?.display_name || invite.game_id,
    gameIcon: gameDef?.icon || '🎮',
    inviterId: invite.inviter_id,
    inviter: userSummary(invite.inviter_id),
    inviteeId: invite.invitee_id,
    invitee: userSummary(invite.invitee_id),
    inviteeEmail: invite.invitee_email,
    proposedDates: JSON.parse(invite.proposed_dates_json),
    chosenDate: invite.chosen_date,
    expiresAt: invite.expires_at,
    status: invite.status,
    sessionId: invite.session_id,
    gemCost: invite.gem_cost,
    templateId: invite.template_id,
  };
}

// How long after the LATEST proposed time an invite stays acceptable —
// past that, the invite was for a game that's already come and gone, so
// there's nothing meaningful left to accept. Replaces having the inviter
// pick a separate expiration themselves, which was really just asking
// them to answer the same question ("when does this stop making sense?")
// a second time in different words.
const EXPIRY_BUFFER_MINUTES = 15;

// POST /api/game-invites — spec §6 steps 1-3. Payment checkpoint happens
// here (step 2) if the game requires it.
router.post('/', requireRegistered, (req, res) => {
  const { gameId, invitee, proposedDates, templateId } = req.body;
  const gameDef = db.prepare('SELECT * FROM game_definitions WHERE game_id = ? AND is_active = 1').get(gameId);
  if (!gameDef) return res.status(404).json({ error: 'Game not found.' });

  const resolvedTemplateId = VALID_TEMPLATE_IDS.includes(templateId) ? templateId : 'classic';

  const resolved = invitee ? resolveInvitee(invitee) : null;
  if (!resolved) return res.status(400).json({ error: "Couldn't find that user — try their handle or email." });
  if (resolved.inviteeId === req.user.id) return res.status(400).json({ error: "You can't invite yourself." });
  if (resolved.inviteeId && isBlockedEitherWay(req.user.id, resolved.inviteeId)) {
    return res.status(403).json({ error: "You can't invite this person." });
  }

  if (!Array.isArray(proposedDates) || proposedDates.length === 0) {
    return res.status(400).json({ error: 'Pick at least one candidate date/time.' });
  }
  const latestProposed = Math.max(...proposedDates.map((d) => new Date(d).getTime()));
  if (!Number.isFinite(latestProposed)) {
    return res.status(400).json({ error: 'One of those candidate times is invalid.' });
  }
  const expiresAt = new Date(latestProposed + EXPIRY_BUFFER_MINUTES * 60 * 1000).toISOString();

  const cost = inviteCost(gameDef, !!req.user.isPremium);
  if (cost > 0) {
    try {
      gems.debit(req.user.id, cost, 'game_invite_charge', null, `Invite: ${gameDef.display_name}`);
    } catch {
      return res.status(402).json({ error: `Not enough gems — inviting to ${gameDef.display_name} costs ${cost}♦.` });
    }
  }

  const id = crypto.randomUUID();
  db.prepare(
    `INSERT INTO game_invites
       (id, game_id, inviter_id, invitee_id, invitee_email, proposed_dates_json, expires_at, gem_cost, template_id)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(id, gameId, req.user.id, resolved.inviteeId, resolved.inviteeEmail, JSON.stringify(proposedDates), expiresAt, cost, resolvedTemplateId);

  // Notification checkpoint (spec §11: "invite sent"). Real push/email
  // isn't built yet (see file header), but a DM is — and it's genuinely
  // the primary way an invitee would ever find out about this, so it's
  // not just a nice-to-have. Only possible when invited by an existing
  // account (invitee_email-only invites have no one to DM yet — that's
  // exactly the case email delivery will eventually cover).
  if (resolved.inviteeId) {
    sendDirectMessage(
      getIo(),
      req.user.id,
      resolved.inviteeId,
      `${nicknameOf(req.user.id)} invited you to play ${gameDef.display_name}. Tap to open your invitation.`,
      { kind: 'game_invite', metadata: { gameId, inviteId: id, templateId: resolvedTemplateId } }
    );
  }

  const invite = db.prepare('SELECT * FROM game_invites WHERE id = ?').get(id);
  res.status(201).json({ invite: serialize(invite) });
});

// GET /api/game-invites — everything the caller sent or received.
router.get('/', requireRegistered, (req, res) => {
  const rows = db
    .prepare('SELECT * FROM game_invites WHERE inviter_id = ? OR invitee_id = ? ORDER BY created_at DESC')
    .all(req.user.id, req.user.id)
    .map(expireIfNeeded);
  res.json({ invites: rows.map(serialize) });
});

router.get('/:id', requireRegistered, (req, res) => {
  const invite = db.prepare('SELECT * FROM game_invites WHERE id = ?').get(req.params.id);
  if (!invite) return res.status(404).json({ error: 'Invite not found.' });
  if (invite.inviter_id !== req.user.id && invite.invitee_id !== req.user.id) {
    return res.status(403).json({ error: 'Not your invite.' });
  }
  res.json({ invite: serialize(expireIfNeeded(invite)) });
});

// POST /api/game-invites/:id/respond — spec §6 steps 4-9. Invitee picks
// one of the proposed dates; this both confirms the invite AND creates
// the (waiting) GameSession in one step, with the invitee as first mover.
router.post('/:id/respond', requireRegistered, (req, res) => {
  let invite = db.prepare('SELECT * FROM game_invites WHERE id = ?').get(req.params.id);
  if (!invite) return res.status(404).json({ error: 'Invite not found.' });
  invite = expireIfNeeded(invite);
  if (invite.invitee_id !== req.user.id) return res.status(403).json({ error: 'Not your invite to respond to.' });
  if (invite.status !== 'pending') return res.status(400).json({ error: `Invite is ${invite.status}.` });

  const { chosenDate } = req.body;
  const proposed = JSON.parse(invite.proposed_dates_json);
  if (!proposed.includes(chosenDate)) {
    return res.status(400).json({ error: 'Pick one of the proposed dates.' });
  }

  const sessionId = createWaitingSession({
    gameId: invite.game_id,
    playerIds: [invite.inviter_id, invite.invitee_id],
    firstMoverId: invite.invitee_id, // "invitee moves first" — spec §6 step 9
    source: 'invite',
    inviteId: invite.id,
  });

  db.prepare(
    "UPDATE game_invites SET status = 'confirmed', chosen_date = ? WHERE id = ?"
  ).run(chosenDate, invite.id);

  // Notification checkpoint (spec §11: "invite confirmed", both players)
  // — full reminder scheduling (24h/48h logic) still isn't built (see
  // file header), but letting the inviter know it's on, the same way the
  // invitee found out about it, is.
  sendDirectMessage(
    getIo(),
    invite.invitee_id,
    invite.inviter_id,
    `${nicknameOf(invite.invitee_id)} accepted your invite! Your ${db.prepare('SELECT display_name FROM game_definitions WHERE game_id = ?').get(invite.game_id)?.display_name} game is on.`,
    { kind: 'game_invite', metadata: { gameId: invite.game_id, inviteId: invite.id, sessionId, templateId: invite.template_id } }
  );

  const updated = db.prepare('SELECT * FROM game_invites WHERE id = ?').get(invite.id);
  res.json({ invite: serialize(updated), sessionId });
});

// POST /api/game-invites/:id/cancel — inviter backing out before the
// invitee responds. Refunds the gem cost (nothing was ever played) —
// there's no dedicated ledger reason for this yet, so it's logged as an
// admin_adjustment with a clear note; a real 'invite_refund' reason is a
// clean follow-up if this needs to be queryable on its own later.
router.post('/:id/cancel', requireRegistered, (req, res) => {
  const invite = db.prepare('SELECT * FROM game_invites WHERE id = ?').get(req.params.id);
  if (!invite) return res.status(404).json({ error: 'Invite not found.' });
  if (invite.inviter_id !== req.user.id) return res.status(403).json({ error: 'Not your invite.' });
  if (invite.status !== 'pending') return res.status(400).json({ error: `Invite is ${invite.status}, can't cancel.` });

  db.prepare("UPDATE game_invites SET status = 'cancelled' WHERE id = ?").run(invite.id);
  if (invite.gem_cost > 0) {
    gems.credit(req.user.id, invite.gem_cost, 'admin_adjustment', invite.id, 'Invite cancelled — refund');
  }
  res.json({ invite: serialize({ ...invite, status: 'cancelled' }) });
});

module.exports = router;
module.exports.serialize = serialize;
