// ============================================================
// Invite Flow state machine (Games spec §6). Mounted at /api/game-invites.
//
// State diagram: draft (client-side only, nothing written until Submit)
// -> pending -> confirmed (-> a GameSession is created) -> expired
// branches off pending only, never off confirmed.
//
// Notification delivery (DM/email at each step, spec §11) is NOT built —
// this app has no email-sending or reminder-scheduling infrastructure at
// all yet, so there's nothing to hook into. Every point a notification
// would fire is marked with a comment; wiring that up is a clean follow-up
// once a notification system exists for the rest of the app too.
// ============================================================

const express = require('express');
const crypto = require('crypto');
const db = require('../db/connection');
const { requireRegistered } = require('../middleware/auth');
const { inviteCost } = require('../games/pricing');
const gems = require('../services/gems');
const { createWaitingSession } = require('../games/sessionEngine');

const router = express.Router();

function isBlockedEitherWay(userA, userB) {
  return !!db
    .prepare('SELECT 1 FROM blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?)')
    .get(userA, userB, userB, userA);
}

// Accepts a userId, handle, or email in one field, per the spec's "enters
// invitee's userID or email" — handle is a common enough thing to paste
// in from a NameTag that it's worth resolving too. Returns
// { inviteeId, inviteeEmail } — exactly one of which is set.
function resolveInvitee(input) {
  const byId = db.prepare('SELECT id FROM users WHERE id = ?').get(input);
  if (byId) return { inviteeId: byId.id, inviteeEmail: null };
  const byHandle = db.prepare('SELECT id FROM users WHERE public_handle = ?').get(input);
  if (byHandle) return { inviteeId: byHandle.id, inviteeEmail: null };
  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input)) return { inviteeId: null, inviteeEmail: input };
  return null;
}

// Lazily flips a stale pending invite to expired — there's no cron here,
// so this runs whenever an invite is read/acted on instead.
function expireIfNeeded(invite) {
  if (invite.status === 'pending' && new Date(invite.expires_at) <= new Date()) {
    db.prepare("UPDATE game_invites SET status = 'expired' WHERE id = ?").run(invite.id);
    return { ...invite, status: 'expired' };
  }
  return invite;
}

function serialize(invite) {
  return {
    id: invite.id,
    gameId: invite.game_id,
    inviterId: invite.inviter_id,
    inviteeId: invite.invitee_id,
    inviteeEmail: invite.invitee_email,
    proposedDates: JSON.parse(invite.proposed_dates_json),
    chosenDate: invite.chosen_date,
    expiresAt: invite.expires_at,
    status: invite.status,
    sessionId: invite.session_id,
    gemCost: invite.gem_cost,
  };
}

// POST /api/game-invites — spec §6 steps 1-3. Payment checkpoint happens
// here (step 2) if the game requires it.
router.post('/', requireRegistered, (req, res) => {
  const { gameId, invitee, proposedDates, expiresAt } = req.body;
  const gameDef = db.prepare('SELECT * FROM game_definitions WHERE game_id = ? AND is_active = 1').get(gameId);
  if (!gameDef) return res.status(404).json({ error: 'Game not found.' });

  const resolved = invitee ? resolveInvitee(invitee) : null;
  if (!resolved) return res.status(400).json({ error: "Couldn't find that user — try their handle or email." });
  if (resolved.inviteeId === req.user.id) return res.status(400).json({ error: "You can't invite yourself." });
  if (resolved.inviteeId && isBlockedEitherWay(req.user.id, resolved.inviteeId)) {
    return res.status(403).json({ error: "You can't invite this person." });
  }

  if (!Array.isArray(proposedDates) || proposedDates.length === 0) {
    return res.status(400).json({ error: 'Pick at least one candidate date/time.' });
  }
  if (!expiresAt || new Date(expiresAt) <= new Date()) {
    return res.status(400).json({ error: 'Expiration must be in the future.' });
  }

  const cost = inviteCost(gameDef, !!req.user.isPremium);
  if (cost > 0) {
    try {
      gems.debit(req.user.id, cost, 'game_invite_charge', null, `Invite: ${gameDef.display_name}`);
    } catch {
      return res.status(402).json({ error: `Not enough gems — inviting to ${gameDef.display_name} costs ${cost}♦.` });
    }
  }

  const id = crypto.randomUUID();
  db.prepare(
    `INSERT INTO game_invites
       (id, game_id, inviter_id, invitee_id, invitee_email, proposed_dates_json, expires_at, gem_cost)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(id, gameId, req.user.id, resolved.inviteeId, resolved.inviteeEmail, JSON.stringify(proposedDates), expiresAt, cost);

  // Notification checkpoint (spec §11: "invite sent") — not wired up, see
  // file header.

  const invite = db.prepare('SELECT * FROM game_invites WHERE id = ?').get(id);
  res.status(201).json({ invite: serialize(invite) });
});

// GET /api/game-invites — everything the caller sent or received.
router.get('/', requireRegistered, (req, res) => {
  const rows = db
    .prepare('SELECT * FROM game_invites WHERE inviter_id = ? OR invitee_id = ? ORDER BY created_at DESC')
    .all(req.user.id, req.user.id)
    .map(expireIfNeeded);
  res.json({ invites: rows.map(serialize) });
});

router.get('/:id', requireRegistered, (req, res) => {
  const invite = db.prepare('SELECT * FROM game_invites WHERE id = ?').get(req.params.id);
  if (!invite) return res.status(404).json({ error: 'Invite not found.' });
  if (invite.inviter_id !== req.user.id && invite.invitee_id !== req.user.id) {
    return res.status(403).json({ error: 'Not your invite.' });
  }
  res.json({ invite: serialize(expireIfNeeded(invite)) });
});

// POST /api/game-invites/:id/respond — spec §6 steps 4-9. Invitee picks
// one of the proposed dates; this both confirms the invite AND creates
// the (waiting) GameSession in one step, with the invitee as first mover.
router.post('/:id/respond', requireRegistered, (req, res) => {
  let invite = db.prepare('SELECT * FROM game_invites WHERE id = ?').get(req.params.id);
  if (!invite) return res.status(404).json({ error: 'Invite not found.' });
  invite = expireIfNeeded(invite);
  if (invite.invitee_id !== req.user.id) return res.status(403).json({ error: 'Not your invite to respond to.' });
  if (invite.status !== 'pending') return res.status(400).json({ error: `Invite is ${invite.status}.` });

  const { chosenDate } = req.body;
  const proposed = JSON.parse(invite.proposed_dates_json);
  if (!proposed.includes(chosenDate)) {
    return res.status(400).json({ error: 'Pick one of the proposed dates.' });
  }

  const sessionId = createWaitingSession({
    gameId: invite.game_id,
    playerIds: [invite.inviter_id, invite.invitee_id],
    firstMoverId: invite.invitee_id, // "invitee moves first" — spec §6 step 9
    source: 'invite',
    inviteId: invite.id,
  });

  db.prepare(
    "UPDATE game_invites SET status = 'confirmed', chosen_date = ? WHERE id = ?"
  ).run(chosenDate, invite.id);

  // Notification checkpoints (spec §11: "invite confirmed" to both
  // players, the 24h/48h reminder logic) — not wired up, see file header.

  const updated = db.prepare('SELECT * FROM game_invites WHERE id = ?').get(invite.id);
  res.json({ invite: serialize(updated), sessionId });
});

// POST /api/game-invites/:id/cancel — inviter backing out before the
// invitee responds. Refunds the gem cost (nothing was ever played) —
// there's no dedicated ledger reason for this yet, so it's logged as an
// admin_adjustment with a clear note; a real 'invite_refund' reason is a
// clean follow-up if this needs to be queryable on its own later.
router.post('/:id/cancel', requireRegistered, (req, res) => {
  const invite = db.prepare('SELECT * FROM game_invites WHERE id = ?').get(req.params.id);
  if (!invite) return res.status(404).json({ error: 'Invite not found.' });
  if (invite.inviter_id !== req.user.id) return res.status(403).json({ error: 'Not your invite.' });
  if (invite.status !== 'pending') return res.status(400).json({ error: `Invite is ${invite.status}, can't cancel.` });

  db.prepare("UPDATE game_invites SET status = 'cancelled' WHERE id = ?").run(invite.id);
  if (invite.gem_cost > 0) {
    gems.credit(req.user.id, invite.gem_cost, 'admin_adjustment', invite.id, 'Invite cancelled — refund');
  }
  res.json({ invite: serialize({ ...invite, status: 'cancelled' }) });
});

module.exports = router;
