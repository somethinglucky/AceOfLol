const express = require('express');
const db = require('../db/connection');
const { requireAuth } = require('../middleware/auth');
const { publicBirthInfo } = require('../utils/zodiac');

const router = express.Router();

const MULTI_FIELDS = ['gender', 'orientation', 'has_kids', 'pets', 'religion'];

const GENDER_VALUES = ['male', 'female', 'transman', 'transwoman', 'nonbinary', 'masc', 'fem', 'other'];
const ORIENTATION_VALUES = [
  'straight', 'gay', 'pan_bi', 'asexual', 'demisexual', 'homoflexible', 'heteroflexible', 'other',
];
const HAS_KIDS_VALUES = ['has_kids', 'doesnt_have_kids', 'wants_kids', 'doesnt_want_kids', 'open_to_kids'];
const PETS_VALUES = ['has_pets', 'doesnt_have_pets', 'wants_pets', 'doesnt_want_pets', 'open_to_pets'];
const RELIGION_VALUES = [
  'christian', 'atheist', 'agnostic', 'muslim', 'jewish', 'buddhist', 'pagan', 'taoist', 'shinto', 'other',
];
const VALID_VALUES = {
  gender: GENDER_VALUES,
  orientation: ORIENTATION_VALUES,
  has_kids: HAS_KIDS_VALUES,
  pets: PETS_VALUES,
  religion: RELIGION_VALUES,
};

// A curated starting point for hobby tags — broad, unambiguous categories
// people can converge on, rather than everyone inventing their own phrasing
// for the same interest. The interests table stays open-ended beyond this;
// this list just seeds it so early users have consistent options to pick
// from before a long tail of user-typed tags builds up naturally.
const STARTER_HOBBIES = [
  'reading', 'writing', 'poetry', 'hiking', 'camping', 'fishing', 'birdwatching', 'gardening',
  'cooking', 'baking', 'wine tasting', 'coffee', 'photography', 'painting', 'drawing', 'crafting',
  'knitting', 'woodworking', 'pottery', 'music', 'singing', 'playing guitar', 'playing piano',
  'concerts', 'dancing', 'movies', 'tv shows', 'anime', 'board games', 'video games', 'chess',
  'puzzles', 'reading manga', 'yoga', 'running', 'cycling', 'swimming', 'weightlifting',
  'martial arts', 'rock climbing', 'skateboarding', 'surfing', 'skiing', 'snowboarding',
  'travel', 'road trips', 'thrifting', 'fashion', 'volunteering', 'astrology', 'meditation',
  'collecting', 'cars', 'sports', 'stand-up comedy',
];

function getOrCreateInterestId(name) {
  const normalized = name.trim().toLowerCase();
  const existing = db.prepare('SELECT id FROM interests WHERE name = ?').get(normalized);
  if (existing) return existing.id;
  const result = db.prepare('INSERT INTO interests (name) VALUES (?)').run(normalized);
  return result.lastInsertRowid;
}

function getProfileRow(userId) {
  return db.prepare('SELECT * FROM profiles WHERE user_id = ?').get(userId);
}

function getMultiValues(profileId) {
  const rows = db
    .prepare('SELECT field_name, value FROM profile_multi_attributes WHERE profile_id = ?')
    .all(profileId);
  const grouped = { gender: [], orientation: [], has_kids: [], pets: [], religion: [] };
  rows.forEach((r) => grouped[r.field_name]?.push(r.value));
  return grouped;
}

function getHobbies(profileId) {
  return db
    .prepare(
      `SELECT i.name FROM interests i
       JOIN profile_interests pi ON pi.interest_id = i.id
       WHERE pi.profile_id = ?`
    )
    .all(profileId)
    .map((r) => r.name);
}

// Shapes one full profile object for API responses. includePrivate=true
// only for the profile's own owner (adds raw birthdate for editing).
function buildProfileResponse(profileRow, attrRow, includePrivate) {
  const { age, zodiac } = publicBirthInfo(profileRow.birthdate);
  return {
    userId: profileRow.user_id,
    nickname: profileRow.nickname,
    bio: profileRow.bio,
    lookingFor: profileRow.looking_for,
    avatarUrl: profileRow.avatar_url,
    age,
    zodiac,
    displayColor: profileRow.profile_display_color,
    displayFont: profileRow.profile_display_font,
    country: attrRow?.country ?? null,
    commitment: attrRow?.commitment ?? null,
    diet: attrRow?.diet ?? null,
    polyamory: attrRow?.polyamory ?? null,
    pronouns: attrRow?.pronouns ?? null,
    build: attrRow?.build ?? null,
    heightCm: attrRow?.height_cm ?? null,
    petsNote: attrRow?.pets_note ?? null,
    ...getMultiValues(profileRow.id),
    hobbies: getHobbies(profileRow.id),
    ...(includePrivate ? { birthdate: profileRow.birthdate } : {}),
  };
}

// GET /profiles/hobbies/suggestions — the starter list, for autocomplete
router.get('/hobbies/suggestions', (req, res) => {
  res.json({ hobbies: STARTER_HOBBIES });
});

// GET /profiles/handle-suggestions?q=admin — matches by nickname OR
// handle, case-insensitive prefix, so inviting someone doesn't require
// knowing their exact random handle: typing a nickname like "admin"
// surfaces every registered person whose nickname or handle starts with
// it, each labeled nickname@handle since nicknames aren't unique and the
// handle is what actually disambiguates who you mean. Registered users
// only among the RESULTS — a guest can't be invited (see
// games/gameInvites.js's resolveInvitee), so there's nothing to surface
// for one here either.
//
// Uses requireAuth, not requireRegistered — this route lives under
// /profiles, and requireRegistered only works on routes mounted under
// /api, where server.js runs optionalAuth first to populate req.user
// (requireRegistered just checks req.user.isRegistered; it doesn't
// authenticate anyone itself). Every other route in this file already
// uses requireAuth for exactly that reason — using requireRegistered
// here made this 403 with "Please register to do that." for every
// caller, registered or not, since req.user was never set on this path.
router.get('/handle-suggestions', requireAuth, (req, res) => {
  const q = (req.query.q || '').trim();
  if (q.length < 2) return res.json({ suggestions: [] });

  const like = `${q.replace(/[%_]/g, '\\$&')}%`; // escape SQL wildcard chars a real nickname/handle could contain
  const rows = db
    .prepare(
      `SELECT u.id, u.public_handle AS handle, p.nickname
       FROM users u JOIN profiles p ON p.user_id = u.id
       WHERE u.is_registered = 1 AND u.id != ?
         AND (p.nickname LIKE ? ESCAPE '\\' OR u.public_handle LIKE ? ESCAPE '\\')
       ORDER BY p.nickname COLLATE NOCASE ASC
       LIMIT 8`
    )
    .all(req.userId, like, like);
  res.json({ suggestions: rows });
});

// GET /profiles/me
router.get('/me', requireAuth, (req, res) => {
  const profile = getProfileRow(req.userId);
  if (!profile) return res.status(404).json({ error: 'Profile not found' });
  const attrs = db.prepare('SELECT * FROM profile_attributes WHERE profile_id = ?').get(profile.id);
  res.json(buildProfileResponse(profile, attrs, true));
});

// GET /profiles/:userId — public view of someone else's profile
router.get('/:userId', (req, res) => {
  const profile = getProfileRow(req.params.userId);
  if (!profile) return res.status(404).json({ error: 'Profile not found' });
  const user = db.prepare('SELECT public_handle, is_registered FROM users WHERE id = ?').get(req.params.userId);
  const attrs = db.prepare('SELECT * FROM profile_attributes WHERE profile_id = ?').get(profile.id);
  res.json({
    handle: user.public_handle,
    isRegistered: !!user.is_registered,
    ...buildProfileResponse(profile, attrs, false),
  });
});

// PUT /profiles/me — nickname, bio, lookingFor, single-select attributes,
// pronouns, height, petsNote, country, display color/font, birthdate.
// Every field is optional in the body — only the ones sent get updated.
router.put('/me', requireAuth, (req, res) => {
  const profile = getProfileRow(req.userId);
  if (!profile) return res.status(404).json({ error: 'Profile not found' });

  const {
    nickname, bio, lookingFor, birthdate, displayColor, displayFont,
    country, commitment, diet, polyamory, pronouns, build, heightCm, petsNote,
  } = req.body;

  if (pronouns != null && pronouns.length > 15) {
    return res.status(400).json({ error: 'Pronouns must be 15 characters or fewer' });
  }
  if (petsNote != null && petsNote.length > 100) {
    return res.status(400).json({ error: 'Pets note must be 100 characters or fewer' });
  }

  const updateProfile = db.prepare(`
    UPDATE profiles SET
      nickname = COALESCE(?, nickname),
      bio = COALESCE(?, bio),
      looking_for = COALESCE(?, looking_for),
      birthdate = COALESCE(?, birthdate),
      profile_display_color = COALESCE(?, profile_display_color),
      profile_display_font = COALESCE(?, profile_display_font),
      updated_at = datetime('now')
    WHERE id = ?
  `);
  updateProfile.run(nickname, bio, lookingFor, birthdate, displayColor, displayFont, profile.id);

  const updateAttrs = db.prepare(`
    UPDATE profile_attributes SET
      country = COALESCE(?, country),
      commitment = COALESCE(?, commitment),
      diet = COALESCE(?, diet),
      polyamory = COALESCE(?, polyamory),
      pronouns = COALESCE(?, pronouns),
      build = COALESCE(?, build),
      height_cm = COALESCE(?, height_cm),
      pets_note = COALESCE(?, pets_note)
    WHERE profile_id = ?
  `);
  updateAttrs.run(country, commitment, diet, polyamory, pronouns, build, heightCm, petsNote, profile.id);

  const updated = getProfileRow(req.userId);
  const attrs = db.prepare('SELECT * FROM profile_attributes WHERE profile_id = ?').get(profile.id);
  res.json(buildProfileResponse(updated, attrs, true));
});

// PUT /profiles/me/multi — replace all values for ONE multi-select field.
// body: { field: 'gender', values: ['nonbinary','other'] }
router.put('/me/multi', requireAuth, (req, res) => {
  const { field, values } = req.body;
  if (!MULTI_FIELDS.includes(field)) {
    return res.status(400).json({ error: `field must be one of: ${MULTI_FIELDS.join(', ')}` });
  }
  if (!Array.isArray(values)) {
    return res.status(400).json({ error: 'values must be an array' });
  }
  const invalid = values.filter((v) => !VALID_VALUES[field].includes(v));
  if (invalid.length > 0) {
    return res.status(400).json({ error: `Invalid value(s) for ${field}: ${invalid.join(', ')}` });
  }

  const profile = getProfileRow(req.userId);
  if (!profile) return res.status(404).json({ error: 'Profile not found' });

  const replace = db.transaction(() => {
    db.prepare('DELETE FROM profile_multi_attributes WHERE profile_id = ? AND field_name = ?').run(
      profile.id,
      field
    );
    const insert = db.prepare(
      'INSERT INTO profile_multi_attributes (profile_id, field_name, value) VALUES (?, ?, ?)'
    );
    values.forEach((v) => insert.run(profile.id, field, v));
  });
  replace();

  res.json({ field, values });
});

// PUT /profiles/me/hobbies — replace the full hobby tag list at once.
// body: { hobbies: ['hiking', 'chess', 'a brand new one someone typed'] }
router.put('/me/hobbies', requireAuth, (req, res) => {
  const { hobbies } = req.body;
  if (!Array.isArray(hobbies)) {
    return res.status(400).json({ error: 'hobbies must be an array' });
  }

  const profile = getProfileRow(req.userId);
  if (!profile) return res.status(404).json({ error: 'Profile not found' });

  const replace = db.transaction(() => {
    db.prepare('DELETE FROM profile_interests WHERE profile_id = ?').run(profile.id);
    const link = db.prepare(
      'INSERT OR IGNORE INTO profile_interests (profile_id, interest_id) VALUES (?, ?)'
    );
    hobbies.forEach((name) => {
      if (name.trim()) link.run(profile.id, getOrCreateInterestId(name));
    });
  });
  replace();

  res.json({ hobbies: getHobbies(profile.id) });
});

// GET /profiles/search — filter other people's profiles.
// Query params (all optional, repeatable for multi-select, e.g. ?gender=nonbinary&gender=other):
//   gender, orientation, hasKids, pets, religion (multi-select fields, any-match)
//   country, commitment, diet, polyamory, build (single-select, exact match)
//   hobby (matches against hobby tags)
//   minAge, maxAge, minHeightCm, maxHeightCm
router.get('/', (req, res) => {
  const {
    gender, orientation, hasKids, pets, religion,
    country, commitment, diet, polyamory, build,
    hobby, minAge, maxAge, minHeightCm, maxHeightCm,
  } = req.query;

  const toArray = (v) => (v === undefined ? [] : Array.isArray(v) ? v : [v]);

  let sql = `
    SELECT p.*, u.public_handle, u.is_registered, pa.country, pa.commitment, pa.diet,
           pa.polyamory, pa.build, pa.height_cm
    FROM profiles p
    JOIN users u ON u.id = p.user_id
    LEFT JOIN profile_attributes pa ON pa.profile_id = p.id
    WHERE u.is_registered = 1
  `;
  const params = [];

  function addMultiFilter(field, valuesRaw) {
    const values = toArray(valuesRaw);
    if (values.length === 0) return;
    const placeholders = values.map(() => '?').join(',');
    sql += ` AND p.id IN (
      SELECT profile_id FROM profile_multi_attributes
      WHERE field_name = ? AND value IN (${placeholders})
    )`;
    params.push(field, ...values);
  }

  addMultiFilter('gender', gender);
  addMultiFilter('orientation', orientation);
  addMultiFilter('has_kids', hasKids);
  addMultiFilter('pets', pets);
  addMultiFilter('religion', religion);

  if (country) {
    sql += ' AND pa.country = ?';
    params.push(country);
  }
  if (commitment) {
    sql += ' AND pa.commitment = ?';
    params.push(commitment);
  }
  if (diet) {
    sql += ' AND pa.diet = ?';
    params.push(diet);
  }
  if (polyamory) {
    sql += ' AND pa.polyamory = ?';
    params.push(polyamory);
  }
  if (build) {
    sql += ' AND pa.build = ?';
    params.push(build);
  }
  if (minHeightCm) {
    sql += ' AND pa.height_cm >= ?';
    params.push(Number(minHeightCm));
  }
  if (maxHeightCm) {
    sql += ' AND pa.height_cm <= ?';
    params.push(Number(maxHeightCm));
  }
  if (hobby) {
    sql += ` AND p.id IN (
      SELECT pi.profile_id FROM profile_interests pi
      JOIN interests i ON i.id = pi.interest_id
      WHERE i.name = ?
    )`;
    params.push(hobby.trim().toLowerCase());
  }

  sql += ' LIMIT 50';

  const rows = db.prepare(sql).all(...params);

  // Age filtering happens after the query since age is derived from
  // birthdate at read time, not stored as a queryable column.
  const results = rows
    .map((row) => {
      const { age, zodiac } = publicBirthInfo(row.birthdate);
      return {
        userId: row.user_id,
        handle: row.public_handle,
        nickname: row.nickname,
        avatarUrl: row.avatar_url,
        age,
        zodiac,
        displayColor: row.profile_display_color,
        country: row.country,
        commitment: row.commitment,
        diet: row.diet,
        polyamory: row.polyamory,
        build: row.build,
        heightCm: row.height_cm,
        ...getMultiValues(row.id),
        hobbies: getHobbies(row.id),
      };
    })
    .filter((r) => {
      if (minAge && (r.age === null || r.age < Number(minAge))) return false;
      if (maxAge && (r.age === null || r.age > Number(maxAge))) return false;
      return true;
    });

  res.json({ results });
});

module.exports = router;
