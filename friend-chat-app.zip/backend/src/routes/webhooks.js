// ============================================================
// Stripe webhooks. This is the ONLY place an order flips to 'paid' and the
// ONLY place a Stripe purchase credits gems — never trust the frontend's
// success-redirect URL for that, since the tab can close before it loads,
// or someone could hit that URL directly without ever paying.
//
// IMPORTANT deploy note: this route needs the RAW request body to verify
// Stripe's signature, but server.js calls app.use(express.json()) globally.
// This router is mounted in server.js BEFORE that global json() middleware,
// with its own express.raw() applied only to this path — do not move the
// mount order, or signature verification will fail on every request.
// ============================================================

const express = require('express');
const db = require('../db/connection');
const gems = require('../services/gems');

const router = express.Router();

function getStripe() {
  return require('stripe')(process.env.STRIPE_SECRET_KEY);
}

// POST /api/webhooks/stripe — raw body, verified via STRIPE_WEBHOOK_SECRET.
router.post('/stripe', (req, res) => {
  const signature = req.headers['stripe-signature'];
  let event;

  try {
    const stripe = getStripe();
    event = stripe.webhooks.constructEvent(req.body, signature, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('[stripe webhook] signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    handleCheckoutCompleted(session).catch((err) => {
      console.error('[stripe webhook] error handling checkout.session.completed:', err);
    });
  }

  // Always 200 quickly — Stripe retries on non-2xx, and we don't want a slow
  // downstream failure (e.g. a gems credit hiccup) to cause duplicate retries
  // to pile up. handleCheckoutCompleted is defensive against double-firing
  // (see the status check below) so a retry is harmless anyway.
  res.json({ received: true });
});

async function handleCheckoutCompleted(session) {
  const orderId = session.metadata && session.metadata.orderId;
  if (!orderId) {
    console.error('[stripe webhook] checkout.session.completed with no orderId in metadata:', session.id);
    return;
  }

  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  if (!order) {
    console.error('[stripe webhook] no matching order for id:', orderId);
    return;
  }

  // Idempotency: Stripe can deliver the same event more than once. If this
  // order is already paid, do nothing — most importantly, never credit gems
  // twice for one payment.
  if (order.status === 'paid') return;

  const item = db.prepare('SELECT * FROM store_items WHERE id = ?').get(order.item_id);

  const shippingJson = session.shipping_details
    ? JSON.stringify(session.shipping_details)
    : null;

  db.prepare(
    `UPDATE orders
     SET status = 'paid', stripe_payment_intent_id = ?, shipping_address_json = ?, paid_at = datetime('now')
     WHERE id = ?`
  ).run(session.payment_intent || null, shippingJson, orderId);

  // Gems are minted here and ONLY here for a Stripe purchase — gem_pack is
  // the only item_type this can ever fire for (enforced by the store_items
  // CHECK constraint, so `item` genuinely can't be a physical/digital item
  // with a gem_amount set).
  if (item && item.item_type === 'gem_pack' && item.gem_amount) {
    gems.credit(order.user_id, item.gem_amount, 'stripe_purchase', orderId);
  }
}

module.exports = router;
