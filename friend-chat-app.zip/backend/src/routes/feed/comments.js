// ============================================================
// Comments: threaded (nested replies), paginated at the
// top level only (10 per page). Same tree-building approach as
// the original module — fine at meme-scale comment volumes.
// Adapted: requireUser -> requireRegistered, author info from `profiles`.
// ============================================================

const express = require('express');
const db = require('../../db/connection');
const { requireRegistered } = require('../../middleware/auth');

const router = express.Router({ mergeParams: true });

const TOP_LEVEL_PAGE_SIZE = 10;

function fetchAllCommentsForPost(postId, viewerId) {
  const rows = db
    .prepare(
      `SELECT
            comments.id, comments.parent_id, comments.body,
            comments.like_count, comments.created_at,
            u.id AS user_id, u.public_handle AS handle,
            p.nickname, p.avatar_url
        FROM comments
        JOIN users u ON u.id = comments.user_id
        JOIN profiles p ON p.user_id = u.id
        WHERE comments.post_id = ? AND comments.is_hidden = 0
        ORDER BY comments.created_at ASC`
    )
    .all(postId);

  let likedSet = new Set();
  if (viewerId && rows.length) {
    const placeholders = rows.map(() => '?').join(',');
    const liked = db
      .prepare(`SELECT comment_id FROM comment_likes WHERE user_id = ? AND comment_id IN (${placeholders})`)
      .all(viewerId, ...rows.map((r) => r.id));
    likedSet = new Set(liked.map((r) => r.comment_id));
  }

  let hiddenSet = new Set();
  if (viewerId) {
    const hidden = db.prepare('SELECT comment_id FROM comment_hides WHERE user_id = ?').all(viewerId);
    hiddenSet = new Set(hidden.map((r) => r.comment_id));
  }

  const byId = new Map();
  rows.forEach((r) => {
    if (hiddenSet.has(r.id)) return;
    byId.set(r.id, {
      id: r.id,
      body: r.body,
      like_count: r.like_count,
      liked_by_viewer: likedSet.has(r.id),
      created_at: r.created_at,
      author: { id: r.user_id, handle: r.handle, nickname: r.nickname, avatar_url: r.avatar_url },
      replies: [],
      reply_count: 0,
    });
  });

  const topLevel = [];
  byId.forEach((node) => {
    const parentId = rows.find((r) => r.id === node.id).parent_id;
    if (parentId && byId.has(parentId)) {
      byId.get(parentId).replies.push(node);
    } else {
      topLevel.push(node);
    }
  });

  function fillReplyCounts(node) {
    let total = 0;
    for (const child of node.replies) {
      total += 1 + fillReplyCounts(child);
    }
    node.reply_count = total;
    return total;
  }
  topLevel.forEach(fillReplyCounts);

  return topLevel;
}

// GET /api/posts/:postId/comments?page=0 — viewing requires no auth
router.get('/', (req, res) => {
  const postId = Number(req.params.postId);
  const page = Math.max(0, parseInt(req.query.page, 10) || 0);

  const allTopLevel = fetchAllCommentsForPost(postId, req.user && req.user.id);
  const start = page * TOP_LEVEL_PAGE_SIZE;
  const pageItems = allTopLevel.slice(start, start + TOP_LEVEL_PAGE_SIZE);

  res.json({
    page,
    comments: pageItems,
    has_more: start + TOP_LEVEL_PAGE_SIZE < allTopLevel.length,
    total_top_level: allTopLevel.length,
  });
});

// POST /api/posts/:postId/comments — new top-level comment
router.post('/', requireRegistered, (req, res) => {
  const postId = Number(req.params.postId);
  const body = ((req.body && req.body.body) || '').trim();
  if (!body) return res.status(400).json({ error: 'Comment body is required.' });

  const post = db.prepare('SELECT id FROM posts WHERE id = ? AND is_hidden = 0').get(postId);
  if (!post) return res.status(404).json({ error: 'Post not found.' });

  const result = db
    .prepare(`INSERT INTO comments (post_id, user_id, parent_id, body) VALUES (?, ?, NULL, ?)`)
    .run(postId, req.user.id, body);

  res.status(201).json({
    id: result.lastInsertRowid,
    body,
    like_count: 0,
    liked_by_viewer: false,
    reply_count: 0,
    replies: [],
    created_at: new Date().toISOString(),
    author: { id: req.user.id, handle: req.user.handle, nickname: req.user.nickname, avatar_url: req.user.avatarUrl },
  });
});

module.exports = router;
