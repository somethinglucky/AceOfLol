// ============================================================
// Post creation, likes, shares, and post-menu actions
// (report / save / hide). "Follow this OP" is intentionally
// NOT handled here — see schema.sql note; it belongs to a
// future shared app-wide follow/block system.
// Adapted from the original module: requireUser -> requireRegistered
// (guests can view the feed but not post/like/report/save/hide, per
// sj's instruction), and author info now comes from `profiles`.
// ============================================================

const express = require('express');
const multer = require('multer');
const sharp = require('sharp');
const db = require('../../db/connection');
const storage = require('../../storage/feedStorage');
const { requireRegistered } = require('../../middleware/auth');

const router = express.Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 15 * 1024 * 1024 }, // 15MB cap
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    cb(null, allowed.includes(file.mimetype));
  },
});

// POST /api/posts — create a new post. multipart/form-data, field "image".
router.post('/', requireRegistered, upload.single('image'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'An image file is required.' });
  }

  let width = null, height = null;
  try {
    const metadata = await sharp(req.file.buffer).metadata();
    width = metadata.width || null;
    height = metadata.height || null;
  } catch (err) {
    return res.status(400).json({ error: 'Could not read image file.' });
  }

  const imagePath = storage.save(req.file.buffer, req.file.originalname);

  const insert = db.prepare(`
        INSERT INTO posts (user_id, image_path, image_width, image_height)
        VALUES (?, ?, ?, ?)
    `);
  const result = insert.run(req.user.id, imagePath, width, height);

  res.status(201).json({
    id: result.lastInsertRowid,
    image_url: storage.urlFor(imagePath),
    image_width: width,
    image_height: height,
    like_count: 0,
    comment_count: 0,
    share_count: 0,
    liked_by_viewer: false,
    author: {
      id: req.user.id,
      handle: req.user.handle,
      nickname: req.user.nickname,
      avatar_url: req.user.avatarUrl,
    },
  });
});

// POST/DELETE /api/posts/:id/like — toggle a like
router.post('/:id/like', requireRegistered, (req, res) => {
  const postId = Number(req.params.id);
  const post = db.prepare('SELECT id FROM posts WHERE id = ? AND is_hidden = 0').get(postId);
  if (!post) return res.status(404).json({ error: 'Post not found.' });

  try {
    db.prepare('INSERT INTO post_likes (post_id, user_id) VALUES (?, ?)').run(postId, req.user.id);
  } catch (err) {
    if (!/UNIQUE/.test(err.message)) throw err;
  }

  const { like_count } = db.prepare('SELECT like_count FROM posts WHERE id = ?').get(postId);
  res.json({ liked: true, like_count });
});

router.delete('/:id/like', requireRegistered, (req, res) => {
  const postId = Number(req.params.id);
  db.prepare('DELETE FROM post_likes WHERE post_id = ? AND user_id = ?').run(postId, req.user.id);

  const post = db.prepare('SELECT like_count FROM posts WHERE id = ?').get(postId);
  if (!post) return res.status(404).json({ error: 'Post not found.' });
  res.json({ liked: false, like_count: post.like_count });
});

// POST /api/posts/:id/share — log a share. Open to guests too, per spec.
router.post('/:id/share', (req, res) => {
  const postId = Number(req.params.id);
  const post = db.prepare('SELECT id FROM posts WHERE id = ? AND is_hidden = 0').get(postId);
  if (!post) return res.status(404).json({ error: 'Post not found.' });

  const anchorId = req.body && req.body.anchor_comment_id ? Number(req.body.anchor_comment_id) : null;

  db.prepare(`INSERT INTO shares (post_id, user_id, anchor_comment_id) VALUES (?, ?, ?)`).run(
    postId,
    req.user ? req.user.id : null,
    anchorId
  );

  const { share_count } = db.prepare('SELECT share_count FROM posts WHERE id = ?').get(postId);
  res.json({ share_count });
});

// Post-menu actions: report / save / hide (per-user).
router.post('/:id/report', requireRegistered, (req, res) => {
  const postId = Number(req.params.id);
  const post = db.prepare('SELECT id FROM posts WHERE id = ?').get(postId);
  if (!post) return res.status(404).json({ error: 'Post not found.' });

  db.prepare('INSERT INTO post_reports (user_id, post_id, reason) VALUES (?, ?, ?)').run(
    req.user.id,
    postId,
    (req.body && req.body.reason) || null
  );
  res.status(201).json({ reported: true });
});

router.post('/:id/save', requireRegistered, (req, res) => {
  const postId = Number(req.params.id);
  try {
    db.prepare('INSERT INTO saved_posts (user_id, post_id) VALUES (?, ?)').run(req.user.id, postId);
  } catch (err) {
    if (!/UNIQUE/.test(err.message)) throw err;
  }
  res.status(201).json({ saved: true });
});

router.delete('/:id/save', requireRegistered, (req, res) => {
  const postId = Number(req.params.id);
  db.prepare('DELETE FROM saved_posts WHERE user_id = ? AND post_id = ?').run(req.user.id, postId);
  res.json({ saved: false });
});

router.post('/:id/hide', requireRegistered, (req, res) => {
  const postId = Number(req.params.id);
  try {
    db.prepare('INSERT INTO post_hides (user_id, post_id) VALUES (?, ?)').run(req.user.id, postId);
  } catch (err) {
    if (!/UNIQUE/.test(err.message)) throw err;
  }
  res.status(201).json({ hidden: true });
});

// DELETE /api/posts/:id — the OP removing their own post, or a moderator
// removing anyone's. Reuses the existing posts.is_hidden column (already
// filtered out of every read query) rather than a real row delete, so a
// moderator action can be reversed if it turns out to be a mistake or a
// dispute — nothing here actually destroys the row or the image file.
router.delete('/:id', requireRegistered, (req, res) => {
  const postId = Number(req.params.id);
  const post = db.prepare('SELECT id, user_id FROM posts WHERE id = ? AND is_hidden = 0').get(postId);
  if (!post) return res.status(404).json({ error: 'Post not found.' });

  const isOwner = post.user_id === req.user.id;
  if (!isOwner && !req.user.isModerator) {
    return res.status(403).json({ error: 'You can only delete your own posts.' });
  }

  db.prepare('UPDATE posts SET is_hidden = 1 WHERE id = ?').run(postId);
  res.json({ deleted: true });
});

// POST /api/posts/:id/hate — "Hate this". Deliberately just a log line for
// a future admin stats dashboard (see content_hates in migrations/004) —
// it has NO effect on what this post's author or anyone else sees, and
// there's no corresponding read endpoint yet on purpose.
router.post('/:id/hate', requireRegistered, (req, res) => {
  const postId = Number(req.params.id);
  try {
    db.prepare("INSERT INTO content_hates (user_id, content_type, content_id) VALUES (?, 'post', ?)").run(req.user.id, postId);
  } catch (err) {
    if (!/UNIQUE/.test(err.message)) throw err;
  }
  res.status(201).json({ logged: true });
});

module.exports = router;
