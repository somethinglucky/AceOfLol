// ============================================================
// GET /api/feed — the main scrollable feed, with sort modes.
// Adapted from the original module: joins `profiles` (not `users`)
// for nickname/avatar_url, since that's where this app keeps them.
// Viewing requires no auth at all — guests can browse freely.
// ============================================================

const express = require('express');
const db = require('../../db/connection');
const { urlFor } = require('../../storage/feedStorage');
const { requireRegistered } = require('../../middleware/auth');

const router = express.Router();

const PAGE_SIZE = 20;

const BASE_SELECT = `
    SELECT
        posts.id, posts.image_path, posts.image_width, posts.image_height,
        posts.like_count, posts.comment_count, posts.share_count,
        posts.created_at,
        u.id AS user_id, u.public_handle AS handle,
        p.nickname, p.avatar_url
    FROM posts
    JOIN users u ON u.id = posts.user_id
    JOIN profiles p ON p.user_id = u.id
    WHERE posts.is_hidden = 0
`;

const QUERIES = {
  new: db.prepare(`${BASE_SELECT} ORDER BY posts.created_at DESC LIMIT ? OFFSET ?`),
  top: db.prepare(`${BASE_SELECT} ORDER BY posts.like_count DESC, posts.created_at DESC LIMIT ? OFFSET ?`),
  comments: db.prepare(`${BASE_SELECT} ORDER BY posts.comment_count DESC, posts.created_at DESC LIMIT ? OFFSET ?`),

  // "Popular" = trending on likes received in the last 48 hours, computed
  // live from post_likes rather than a stored counter, since the 48h
  // window constantly slides.
  popular: db.prepare(`
    SELECT
        posts.id, posts.image_path, posts.image_width, posts.image_height,
        posts.like_count, posts.comment_count, posts.share_count,
        posts.created_at,
        u.id AS user_id, u.public_handle AS handle,
        p.nickname, p.avatar_url,
        COUNT(post_likes.id) AS recent_like_count
    FROM posts
    JOIN users u ON u.id = posts.user_id
    JOIN profiles p ON p.user_id = u.id
    LEFT JOIN post_likes
        ON post_likes.post_id = posts.id
        AND post_likes.created_at >= datetime('now', '-48 hours')
    WHERE posts.is_hidden = 0
    GROUP BY posts.id
    ORDER BY recent_like_count DESC, posts.created_at DESC
    LIMIT ? OFFSET ?
  `),
};

function attachViewerLikeState(posts, userId) {
  if (!userId || posts.length === 0) {
    return posts.map((p) => ({ ...p, liked_by_viewer: false }));
  }
  const placeholders = posts.map(() => '?').join(',');
  const rows = db
    .prepare(`SELECT post_id FROM post_likes WHERE user_id = ? AND post_id IN (${placeholders})`)
    .all(userId, ...posts.map((p) => p.id));
  const likedSet = new Set(rows.map((r) => r.post_id));
  return posts.map((p) => ({ ...p, liked_by_viewer: likedSet.has(p.id) }));
}

function formatPost(row) {
  return {
    id: row.id,
    image_url: urlFor(row.image_path),
    image_width: row.image_width,
    image_height: row.image_height,
    like_count: row.like_count,
    comment_count: row.comment_count,
    share_count: row.share_count,
    created_at: row.created_at,
    liked_by_viewer: row.liked_by_viewer,
    author: {
      id: row.user_id,
      handle: row.handle,
      nickname: row.nickname,
      avatar_url: row.avatar_url,
    },
  };
}

// GET /api/feed?sort=new|popular|top|comments&page=0
// Note: this route is mounted WITHOUT requireAuth/optionalAuth applied
// globally — server.js applies optionalAuth to the whole /api router so
// req.user is available here if present, but a guest with no token at
// all still gets a full 200 response, per "guests can view the feed."
router.get('/', (req, res) => {
  const sort = QUERIES[req.query.sort] ? req.query.sort : 'new';
  const page = Math.max(0, parseInt(req.query.page, 10) || 0);
  const offset = page * PAGE_SIZE;

  let rows = QUERIES[sort].all(PAGE_SIZE, offset);

  if (req.user) {
    const hiddenRows = db.prepare('SELECT post_id FROM post_hides WHERE user_id = ?').all(req.user.id);
    const hiddenSet = new Set(hiddenRows.map((r) => r.post_id));
    rows = rows.filter((r) => !hiddenSet.has(r.id));
  }

  rows = attachViewerLikeState(rows, req.user && req.user.id);

  res.json({ sort, page, posts: rows.map(formatPost) });
});

// GET /api/feed/hidden — posts the current user has hidden (via the
// post-menu's "Hide post"), so Settings can list them and offer to
// unhide. Excludes anything a moderator has separately removed
// (posts.is_hidden = 1) — nothing to show or restore there.
router.get('/hidden', requireRegistered, (req, res) => {
  const rows = db
    .prepare(
      `SELECT posts.id, posts.image_path, posts.image_width, posts.image_height,
              posts.like_count, posts.comment_count, posts.share_count, posts.created_at,
              u.id AS user_id, u.public_handle AS handle, p.nickname, p.avatar_url
       FROM post_hides
       JOIN posts ON posts.id = post_hides.post_id
       JOIN users u ON u.id = posts.user_id
       JOIN profiles p ON p.user_id = u.id
       WHERE post_hides.user_id = ? AND posts.is_hidden = 0
       ORDER BY post_hides.created_at DESC`
    )
    .all(req.user.id);

  res.json({ posts: rows.map((r) => ({ ...formatPost(r), liked_by_viewer: false })) });
});

// DELETE /api/feed/hidden/:postId — unhide a post the user previously hid.
router.delete('/hidden/:postId', requireRegistered, (req, res) => {
  const info = db
    .prepare('DELETE FROM post_hides WHERE user_id = ? AND post_id = ?')
    .run(req.user.id, Number(req.params.postId));
  res.json({ unhidden: info.changes > 0 });
});

module.exports = router;
