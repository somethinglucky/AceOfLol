// ============================================================
// Actions on an individual comment, addressed by comment id
// directly. "Follow this commenter" / "Block user" deliberately
// omitted — deferred to the future shared follow/block system.
// Adapted: requireUser -> requireRegistered.
// ============================================================

const express = require('express');
const db = require('../../db/connection');
const { requireRegistered } = require('../../middleware/auth');

const router = express.Router();

function getComment(id) {
  return db.prepare('SELECT * FROM comments WHERE id = ? AND is_hidden = 0').get(id);
}

// POST /api/comments/:id/replies — reply to a comment (nested thread)
router.post('/:id/replies', requireRegistered, (req, res) => {
  const parentId = Number(req.params.id);
  const parent = getComment(parentId);
  if (!parent) return res.status(404).json({ error: 'Comment not found.' });

  const body = ((req.body && req.body.body) || '').trim();
  if (!body) return res.status(400).json({ error: 'Reply body is required.' });

  const result = db
    .prepare(`INSERT INTO comments (post_id, user_id, parent_id, body) VALUES (?, ?, ?, ?)`)
    .run(parent.post_id, req.user.id, parentId, body);

  res.status(201).json({
    id: result.lastInsertRowid,
    body,
    like_count: 0,
    liked_by_viewer: false,
    reply_count: 0,
    replies: [],
    created_at: new Date().toISOString(),
    author: { id: req.user.id, handle: req.user.handle, nickname: req.user.nickname, avatar_url: req.user.avatarUrl },
  });
});

router.post('/:id/like', requireRegistered, (req, res) => {
  const id = Number(req.params.id);
  if (!getComment(id)) return res.status(404).json({ error: 'Comment not found.' });

  try {
    db.prepare('INSERT INTO comment_likes (comment_id, user_id) VALUES (?, ?)').run(id, req.user.id);
  } catch (err) {
    if (!/UNIQUE/.test(err.message)) throw err;
  }
  const { like_count } = db.prepare('SELECT like_count FROM comments WHERE id = ?').get(id);
  res.json({ liked: true, like_count });
});

router.delete('/:id/like', requireRegistered, (req, res) => {
  const id = Number(req.params.id);
  db.prepare('DELETE FROM comment_likes WHERE comment_id = ? AND user_id = ?').run(id, req.user.id);
  const comment = db.prepare('SELECT like_count FROM comments WHERE id = ?').get(id);
  if (!comment) return res.status(404).json({ error: 'Comment not found.' });
  res.json({ liked: false, like_count: comment.like_count });
});

router.post('/:id/report', requireRegistered, (req, res) => {
  const id = Number(req.params.id);
  if (!getComment(id)) return res.status(404).json({ error: 'Comment not found.' });
  db.prepare('INSERT INTO comment_reports (user_id, comment_id, reason) VALUES (?, ?, ?)').run(
    req.user.id,
    id,
    (req.body && req.body.reason) || null
  );
  res.status(201).json({ reported: true });
});

router.post('/:id/save', requireRegistered, (req, res) => {
  const id = Number(req.params.id);
  try {
    db.prepare('INSERT INTO saved_comments (user_id, comment_id) VALUES (?, ?)').run(req.user.id, id);
  } catch (err) {
    if (!/UNIQUE/.test(err.message)) throw err;
  }
  res.status(201).json({ saved: true });
});

router.delete('/:id/save', requireRegistered, (req, res) => {
  const id = Number(req.params.id);
  db.prepare('DELETE FROM saved_comments WHERE user_id = ? AND comment_id = ?').run(req.user.id, id);
  res.json({ saved: false });
});

router.post('/:id/hide', requireRegistered, (req, res) => {
  const id = Number(req.params.id);
  try {
    db.prepare('INSERT INTO comment_hides (user_id, comment_id) VALUES (?, ?)').run(req.user.id, id);
  } catch (err) {
    if (!/UNIQUE/.test(err.message)) throw err;
  }
  res.status(201).json({ hidden: true });
});

// DELETE /api/comments/:id — same owner-or-moderator pattern as posts,
// same reversible is_hidden approach rather than a real row delete.
router.delete('/:id', requireRegistered, (req, res) => {
  const id = Number(req.params.id);
  const comment = getComment(id);
  if (!comment) return res.status(404).json({ error: 'Comment not found.' });

  const isOwner = comment.user_id === req.user.id;
  if (!isOwner && !req.user.isModerator) {
    return res.status(403).json({ error: 'You can only delete your own comments.' });
  }

  db.prepare('UPDATE comments SET is_hidden = 1 WHERE id = ?').run(id);
  res.json({ deleted: true });
});

// POST /api/comments/:id/hate — same log-only signal as posts/:id/hate.
router.post('/:id/hate', requireRegistered, (req, res) => {
  const id = Number(req.params.id);
  try {
    db.prepare("INSERT INTO content_hates (user_id, content_type, content_id) VALUES (?, 'comment', ?)").run(req.user.id, id);
  } catch (err) {
    if (!/UNIQUE/.test(err.message)) throw err;
  }
  res.status(201).json({ logged: true });
});

module.exports = router;
