// ============================================================
// Admin dashboard routes — everything here requires requireAdmin, applied
// once below rather than per-route, since every action in this file is
// admin-only by definition.
// ============================================================

const express = require('express');
const db = require('../db/connection');
const { requireAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(requireAdmin);

const VALID_ROLES = ['user', 'moderator', 'admin'];

// GET /api/admin/users?handle=<partial> — search by handle (case-insensitive,
// partial match) so an admin can find the account they mean to promote
// without needing the exact handle.
router.get('/users', (req, res) => {
  const query = (req.query.handle || '').trim();
  if (!query) return res.json({ users: [] });

  const rows = db
    .prepare(
      `SELECT u.id, u.public_handle AS handle, u.is_registered AS isRegistered,
              u.role, u.is_bot AS isBot, u.created_at AS createdAt,
              p.nickname
       FROM users u JOIN profiles p ON p.user_id = u.id
       WHERE u.public_handle LIKE ? ESCAPE '\\'
       ORDER BY u.created_at DESC
       LIMIT 20`
    )
    .all(`%${query.replace(/[%_\\]/g, (c) => `\\${c}`)}%`);

  res.json({
    users: rows.map((r) => ({ ...r, isRegistered: !!r.isRegistered, isBot: !!r.isBot })),
  });
});

// PUT /api/admin/users/:id/role — body: { role: 'user'|'moderator'|'admin' }
router.put('/users/:id/role', (req, res) => {
  const { role } = req.body;
  if (!VALID_ROLES.includes(role)) {
    return res.status(400).json({ error: `role must be one of: ${VALID_ROLES.join(', ')}` });
  }

  const user = db.prepare('SELECT id FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  // Guard rail: don't let an admin accidentally strip their OWN admin
  // access with no one else able to undo it. Doesn't prevent a second
  // admin from demoting a first one — only self-demotion is blocked.
  if (req.params.id === req.user.id && role !== 'admin') {
    return res.status(400).json({ error: "You can't remove your own admin access." });
  }

  db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, req.params.id);
  res.json({ id: req.params.id, role });
});

// PUT /api/admin/users/:id/bot — body: { isBot: boolean }. Separate from
// role on purpose (see migrations/003 note) — marking an account as a bot
// doesn't change its permission level, just how it's labeled.
router.put('/users/:id/bot', (req, res) => {
  const isBot = !!req.body.isBot;
  const user = db.prepare('SELECT id FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  db.prepare('UPDATE users SET is_bot = ? WHERE id = ?').run(isBot ? 1 : 0, req.params.id);
  res.json({ id: req.params.id, isBot });
});

module.exports = router;
