// ============================================================
// Admin dashboard routes — everything here requires requireAdmin, applied
// once below rather than per-route, since every action in this file is
// admin-only by definition.
// ============================================================

const express = require('express');
const crypto = require('crypto');
const multer = require('multer');
const sharp = require('sharp');
const db = require('../db/connection');
const { requireAdmin } = require('../middleware/auth');
const storage = require('../storage/feedStorage'); // shared local-disk image storage

const router = express.Router();
router.use(requireAdmin);

const VALID_ROLES = ['user', 'moderator', 'admin'];
const VALID_ITEM_TYPES = ['gem_pack', 'physical', 'digital'];

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 15 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    cb(null, allowed.includes(file.mimetype));
  },
});

// GET /api/admin/users?handle=<partial> — search by handle (case-insensitive,
// partial match) so an admin can find the account they mean to promote
// without needing the exact handle.
router.get('/users', (req, res) => {
  const query = (req.query.handle || '').trim();
  if (!query) return res.json({ users: [] });

  const rows = db
    .prepare(
      `SELECT u.id, u.public_handle AS handle, u.is_registered AS isRegistered,
              u.role, u.is_bot AS isBot, u.created_at AS createdAt,
              p.nickname
       FROM users u JOIN profiles p ON p.user_id = u.id
       WHERE u.public_handle LIKE ? ESCAPE '\\'
       ORDER BY u.created_at DESC
       LIMIT 20`
    )
    .all(`%${query.replace(/[%_\\]/g, (c) => `\\${c}`)}%`);

  res.json({
    users: rows.map((r) => ({ ...r, isRegistered: !!r.isRegistered, isBot: !!r.isBot })),
  });
});

// PUT /api/admin/users/:id/role — body: { role: 'user'|'moderator'|'admin' }
router.put('/users/:id/role', (req, res) => {
  const { role } = req.body;
  if (!VALID_ROLES.includes(role)) {
    return res.status(400).json({ error: `role must be one of: ${VALID_ROLES.join(', ')}` });
  }

  const user = db.prepare('SELECT id FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  // Guard rail: don't let an admin accidentally strip their OWN admin
  // access with no one else able to undo it. Doesn't prevent a second
  // admin from demoting a first one — only self-demotion is blocked.
  if (req.params.id === req.user.id && role !== 'admin') {
    return res.status(400).json({ error: "You can't remove your own admin access." });
  }

  db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, req.params.id);
  res.json({ id: req.params.id, role });
});

// PUT /api/admin/users/:id/bot — body: { isBot: boolean }. Separate from
// role on purpose (see migrations/003 note) — marking an account as a bot
// doesn't change its permission level, just how it's labeled.
router.put('/users/:id/bot', (req, res) => {
  const isBot = !!req.body.isBot;
  const user = db.prepare('SELECT id FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  db.prepare('UPDATE users SET is_bot = ? WHERE id = ?').run(isBot ? 1 : 0, req.params.id);
  res.json({ id: req.params.id, isBot });
});

// ------------------------------------------------------------
// Store item management (see migration 007). This is the only place
// store_items rows get created/edited/deleted — the storefront (routes/
// store.js) only ever reads is_active=1 rows.
// ------------------------------------------------------------

function serializeStoreItem(row) {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    imageUrl: row.image_path ? storage.urlFor(row.image_path) : null,
    priceUsdCents: row.price_usd_cents,
    itemType: row.item_type,
    gemAmount: row.gem_amount,
    requiresShipping: !!row.requires_shipping,
    isActive: !!row.is_active,
    sortOrder: row.sort_order,
    createdAt: row.created_at,
  };
}

function validateItemBody(body, { partial } = {}) {
  const errors = [];
  const itemType = body.itemType;
  if (!partial || itemType !== undefined) {
    if (!VALID_ITEM_TYPES.includes(itemType)) {
      errors.push(`itemType must be one of: ${VALID_ITEM_TYPES.join(', ')}`);
    }
  }
  if (!partial || body.name !== undefined) {
    if (!body.name || !body.name.trim()) errors.push('name is required');
  }
  if (!partial || body.priceUsdCents !== undefined) {
    if (!Number.isInteger(body.priceUsdCents) || body.priceUsdCents <= 0) {
      errors.push('priceUsdCents must be a positive integer (price in cents)');
    }
  }
  if (itemType === 'gem_pack') {
    if (!Number.isInteger(body.gemAmount) || body.gemAmount <= 0) {
      errors.push('gemAmount is required and must be a positive integer when itemType is gem_pack');
    }
  } else if (itemType && body.gemAmount != null) {
    errors.push('gemAmount must not be set unless itemType is gem_pack');
  }
  return errors;
}

// GET /api/admin/store-items — everything, including inactive, for the
// admin dashboard's management table.
router.get('/store-items', (req, res) => {
  const rows = db.prepare('SELECT * FROM store_items ORDER BY sort_order ASC, created_at DESC').all();
  res.json({ items: rows.map(serializeStoreItem) });
});

// POST /api/admin/store-items — multipart/form-data, optional field "image".
// Other fields arrive as form fields (strings), so numeric/boolean ones are
// coerced before validating.
router.post('/store-items', upload.single('image'), async (req, res) => {
  const body = {
    name: req.body.name,
    description: req.body.description || null,
    itemType: req.body.itemType,
    priceUsdCents: req.body.priceUsdCents !== undefined ? Number(req.body.priceUsdCents) : undefined,
    gemAmount: req.body.gemAmount !== undefined && req.body.gemAmount !== '' ? Number(req.body.gemAmount) : null,
    requiresShipping: req.body.requiresShipping === 'true' || req.body.requiresShipping === true,
    isActive: req.body.isActive === undefined ? true : (req.body.isActive === 'true' || req.body.isActive === true),
    sortOrder: req.body.sortOrder !== undefined ? Number(req.body.sortOrder) : 0,
  };

  const errors = validateItemBody(body);
  if (errors.length) return res.status(400).json({ error: errors.join('; ') });

  // Physical items can never grant gems and vice versa — belt-and-suspenders
  // on top of the store_items CHECK constraint, so the error message here is
  // friendlier than a raw SQLite constraint failure.
  if (body.itemType === 'physical' && body.gemAmount) {
    return res.status(400).json({ error: 'Physical items cannot grant gems.' });
  }

  let imagePath = null;
  if (req.file) {
    try {
      await sharp(req.file.buffer).metadata(); // validates it's a real image
    } catch {
      return res.status(400).json({ error: 'Could not read image file.' });
    }
    imagePath = storage.save(req.file.buffer, req.file.originalname);
  }

  const id = crypto.randomUUID();
  db.prepare(
    `INSERT INTO store_items
       (id, name, description, image_path, price_usd_cents, item_type, gem_amount,
        requires_shipping, is_active, sort_order, created_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    id, body.name.trim(), body.description, imagePath, body.priceUsdCents, body.itemType,
    body.gemAmount, body.requiresShipping ? 1 : 0, body.isActive ? 1 : 0, body.sortOrder, req.user.id
  );

  const row = db.prepare('SELECT * FROM store_items WHERE id = ?').get(id);
  res.status(201).json({ item: serializeStoreItem(row) });
});

// PUT /api/admin/store-items/:id — same shape as POST, but every field is
// optional; only what's provided gets updated. Also multipart, so a new
// image can be swapped in the same request.
router.put('/store-items/:id', upload.single('image'), async (req, res) => {
  const existing = db.prepare('SELECT * FROM store_items WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Item not found.' });

  const body = {};
  if (req.body.name !== undefined) body.name = req.body.name;
  if (req.body.description !== undefined) body.description = req.body.description;
  if (req.body.itemType !== undefined) body.itemType = req.body.itemType;
  if (req.body.priceUsdCents !== undefined) body.priceUsdCents = Number(req.body.priceUsdCents);
  if (req.body.gemAmount !== undefined) {
    body.gemAmount = req.body.gemAmount === '' ? null : Number(req.body.gemAmount);
  }
  if (req.body.requiresShipping !== undefined) {
    body.requiresShipping = req.body.requiresShipping === 'true' || req.body.requiresShipping === true;
  }
  if (req.body.isActive !== undefined) {
    body.isActive = req.body.isActive === 'true' || req.body.isActive === true;
  }
  if (req.body.sortOrder !== undefined) body.sortOrder = Number(req.body.sortOrder);

  const effectiveItemType = body.itemType !== undefined ? body.itemType : existing.item_type;
  const effectiveGemAmount = body.gemAmount !== undefined ? body.gemAmount : existing.gem_amount;

  const errors = validateItemBody(
    { ...body, itemType: effectiveItemType, gemAmount: effectiveGemAmount },
    { partial: true }
  );
  if (errors.length) return res.status(400).json({ error: errors.join('; ') });
  if (effectiveItemType !== 'gem_pack' && effectiveGemAmount) {
    return res.status(400).json({ error: `${effectiveItemType} items cannot grant gems.` });
  }

  let imagePath = existing.image_path;
  if (req.file) {
    try {
      await sharp(req.file.buffer).metadata();
    } catch {
      return res.status(400).json({ error: 'Could not read image file.' });
    }
    imagePath = storage.save(req.file.buffer, req.file.originalname);
  }

  db.prepare(
    `UPDATE store_items SET
       name = ?, description = ?, image_path = ?, price_usd_cents = ?, item_type = ?,
       gem_amount = ?, requires_shipping = ?, is_active = ?, sort_order = ?, updated_at = datetime('now')
     WHERE id = ?`
  ).run(
    body.name !== undefined ? body.name.trim() : existing.name,
    body.description !== undefined ? body.description : existing.description,
    imagePath,
    body.priceUsdCents !== undefined ? body.priceUsdCents : existing.price_usd_cents,
    effectiveItemType,
    effectiveGemAmount,
    body.requiresShipping !== undefined ? (body.requiresShipping ? 1 : 0) : existing.requires_shipping,
    body.isActive !== undefined ? (body.isActive ? 1 : 0) : existing.is_active,
    body.sortOrder !== undefined ? body.sortOrder : existing.sort_order,
    req.params.id
  );

  const row = db.prepare('SELECT * FROM store_items WHERE id = ?').get(req.params.id);
  res.json({ item: serializeStoreItem(row) });
});

// DELETE /api/admin/store-items/:id — hard delete, but orders.item_id
// REFERENCES store_items(id) with foreign_keys=ON and no cascade rule, so
// SQLite itself refuses to delete an item that any past order points to
// (protects order history from ever pointing at nothing). If that happens,
// tell the admin to deactivate (isActive: false) instead of deleting —
// deactivated items just stop showing up in the storefront.
router.delete('/store-items/:id', (req, res) => {
  const existing = db.prepare('SELECT id FROM store_items WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Item not found.' });

  try {
    db.prepare('DELETE FROM store_items WHERE id = ?').run(req.params.id);
  } catch (err) {
    if (/FOREIGN KEY constraint failed/i.test(err.message)) {
      return res.status(409).json({
        error: 'This item has past orders and cannot be deleted. Deactivate it instead so it stops showing in the store.',
      });
    }
    throw err;
  }
  res.json({ id: req.params.id, deleted: true });
});

module.exports = router;
