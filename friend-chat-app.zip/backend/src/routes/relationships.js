// ============================================================
// Follow/block — the one shared system for these two relationships,
// usable from chat, profiles, and the feed alike (not duplicated per
// feature). Mounted at /api/users/:userId/... in server.js.
// ============================================================

const express = require('express');
const db = require('../db/connection');
const { requireRegistered } = require('../middleware/auth');

const router = express.Router({ mergeParams: true });

function userExists(id) {
  return !!db.prepare('SELECT 1 FROM users WHERE id = ?').get(id);
}

// GET /api/users/:userId/relationship — how the viewer and this user
// relate: are they following, are they blocked (either direction), plus
// this user's follower/following counts. optionalAuth (applied to the
// whole /api router) means a guest or logged-out viewer still gets the
// counts, just with the relationship flags all false.
router.get('/relationship', (req, res) => {
  const { userId } = req.params;
  if (!userExists(userId)) return res.status(404).json({ error: 'User not found.' });

  const followerCount = db.prepare('SELECT COUNT(*) AS n FROM follows WHERE followed_id = ?').get(userId).n;
  const followingCount = db.prepare('SELECT COUNT(*) AS n FROM follows WHERE follower_id = ?').get(userId).n;

  let isFollowing = false;
  let isBlocking = false;
  let isBlockedBy = false;
  if (req.user) {
    isFollowing = !!db
      .prepare('SELECT 1 FROM follows WHERE follower_id = ? AND followed_id = ?')
      .get(req.user.id, userId);
    isBlocking = !!db
      .prepare('SELECT 1 FROM blocks WHERE blocker_id = ? AND blocked_id = ?')
      .get(req.user.id, userId);
    isBlockedBy = !!db
      .prepare('SELECT 1 FROM blocks WHERE blocker_id = ? AND blocked_id = ?')
      .get(userId, req.user.id);
  }

  res.json({ followerCount, followingCount, isFollowing, isBlocking, isBlockedBy });
});

router.post('/follow', requireRegistered, (req, res) => {
  const { userId } = req.params;
  if (userId === req.user.id) return res.status(400).json({ error: "You can't follow yourself." });
  if (!userExists(userId)) return res.status(404).json({ error: 'User not found.' });

  const isBlockedEitherWay =
    db.prepare('SELECT 1 FROM blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?)')
      .get(req.user.id, userId, userId, req.user.id);
  if (isBlockedEitherWay) {
    return res.status(403).json({ error: "You can't follow this user." });
  }

  try {
    db.prepare('INSERT INTO follows (follower_id, followed_id) VALUES (?, ?)').run(req.user.id, userId);
  } catch (err) {
    if (!/UNIQUE/.test(err.message)) throw err;
  }
  res.status(201).json({ isFollowing: true });
});

router.delete('/follow', requireRegistered, (req, res) => {
  const { userId } = req.params;
  db.prepare('DELETE FROM follows WHERE follower_id = ? AND followed_id = ?').run(req.user.id, userId);
  res.json({ isFollowing: false });
});

// Blocking also removes any follow between the two people in BOTH
// directions — you can't meaningfully follow someone you've just
// blocked, or stay followed by someone you don't want interacting
// with you at all.
router.post('/block', requireRegistered, (req, res) => {
  const { userId } = req.params;
  if (userId === req.user.id) return res.status(400).json({ error: "You can't block yourself." });
  if (!userExists(userId)) return res.status(404).json({ error: 'User not found.' });

  const applyBlock = db.transaction(() => {
    db.prepare('INSERT OR IGNORE INTO blocks (blocker_id, blocked_id) VALUES (?, ?)').run(req.user.id, userId);
    db.prepare('DELETE FROM follows WHERE (follower_id = ? AND followed_id = ?) OR (follower_id = ? AND followed_id = ?)')
      .run(req.user.id, userId, userId, req.user.id);
  });
  applyBlock();

  res.status(201).json({ isBlocking: true });
});

router.delete('/block', requireRegistered, (req, res) => {
  const { userId } = req.params;
  db.prepare('DELETE FROM blocks WHERE blocker_id = ? AND blocked_id = ?').run(req.user.id, userId);
  res.json({ isBlocking: false });
});

// POST /api/users/:userId/report — reporting the PERSON, from their
// profile's \u2666 menu. Distinct from reporting a specific post/comment/DM
// thread, which already have their own report tables.
router.post('/report', requireRegistered, (req, res) => {
  const { userId } = req.params;
  if (userId === req.user.id) return res.status(400).json({ error: "You can't report yourself." });
  if (!userExists(userId)) return res.status(404).json({ error: 'User not found.' });

  db.prepare('INSERT INTO user_reports (reporter_id, reported_user_id, reason) VALUES (?, ?, ?)')
    .run(req.user.id, userId, req.body.reason || null);
  res.status(201).json({ reported: true });
});

module.exports = router;
