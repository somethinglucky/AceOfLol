// ============================================================
// DM inbox + thread management (hide/clear/report). Sending and receiving
// messages themselves happen over the socket (see sockets/dmHandlers.js)
// for real-time delivery — this file is everything that's naturally a
// one-off REST action rather than a live event.
// ============================================================

const express = require('express');
const db = require('../db/connection');
const { requireRegistered } = require('../middleware/auth');

const router = express.Router();
router.use(requireRegistered); // guests can't DM — nothing in this file applies to them

function canonicalPair(idA, idB) {
  return idA < idB ? [idA, idB] : [idB, idA];
}

// Confirms the thread exists AND the caller is actually a participant in
// it — every route below that takes a :threadId needs this, since a
// thread id alone doesn't prove you're allowed to touch it.
function getOwnedThread(threadId, userId) {
  const thread = db.prepare('SELECT * FROM dm_threads WHERE id = ?').get(threadId);
  if (!thread) return null;
  if (thread.user_a_id !== userId && thread.user_b_id !== userId) return null;
  return thread;
}

// GET /api/dms/unread-count — total unread messages across every thread,
// for the hamburger-menu badge. Deliberately separate from GET / (the
// full inbox) since the badge needs this on every page load, not just
// while actually viewing DMs, and the full inbox query does a lot more
// work (a per-thread other-user lookup) than a badge needs.
router.get('/unread-count', (req, res) => {
  const { count } = db
    .prepare(
      `SELECT COUNT(*) AS count FROM dm_messages m
       JOIN dm_threads t ON t.id = m.thread_id
       WHERE (t.user_a_id = ? OR t.user_b_id = ?) AND m.sender_id != ? AND m.read_at IS NULL`
    )
    .get(req.user.id, req.user.id, req.user.id);
  res.json({ count });
});

// GET /api/dms — inbox: every thread with at least one message, excluding
// ones this user has hidden, or cleared with no new activity since.
router.get('/', (req, res) => {
  const rows = db
    .prepare(
      `SELECT
          t.id, t.last_message_at,
          CASE WHEN t.user_a_id = ? THEN t.user_b_id ELSE t.user_a_id END AS other_user_id,
          (SELECT body FROM dm_messages WHERE thread_id = t.id ORDER BY created_at DESC LIMIT 1) AS last_body,
          (SELECT COUNT(*) FROM dm_messages WHERE thread_id = t.id AND sender_id != ? AND read_at IS NULL) AS unread_count
       FROM dm_threads t
       WHERE (t.user_a_id = ? OR t.user_b_id = ?)
         AND NOT EXISTS (SELECT 1 FROM dm_thread_hides h WHERE h.user_id = ? AND h.thread_id = t.id)
         AND NOT EXISTS (
             SELECT 1 FROM dm_thread_clears c
             WHERE c.user_id = ? AND c.thread_id = t.id
               AND c.cleared_up_to_message_id >= (SELECT MAX(id) FROM dm_messages WHERE thread_id = t.id)
         )
       ORDER BY t.last_message_at DESC`
    )
    .all(req.user.id, req.user.id, req.user.id, req.user.id, req.user.id, req.user.id);

  const threads = rows.map((row) => {
    const other = db
      .prepare(
        `SELECT u.id, u.public_handle AS handle, u.is_registered AS isRegistered,
                p.nickname, p.avatar_url AS avatarUrl
         FROM users u JOIN profiles p ON p.user_id = u.id
         WHERE u.id = ?`
      )
      .get(row.other_user_id);
    return {
      threadId: row.id,
      lastMessageAt: row.last_message_at,
      lastMessagePreview: row.last_body,
      unreadCount: row.unread_count,
      otherUser: other,
    };
  });

  res.json({ threads });
});

// GET /api/dms/with/:userId — REST fallback for loading a conversation's
// history (the socket's join_dm_thread does the same thing for the live
// case) — useful for a first render before the socket has connected.
router.get('/with/:userId', (req, res) => {
  const otherUserId = req.params.userId;
  if (otherUserId === req.user.id) return res.status(400).json({ error: 'Invalid conversation.' });
  if (!db.prepare('SELECT 1 FROM users WHERE id = ?').get(otherUserId)) {
    return res.status(404).json({ error: 'User not found.' });
  }

  const [a, b] = canonicalPair(req.user.id, otherUserId);
  const thread = db.prepare('SELECT * FROM dm_threads WHERE user_a_id = ? AND user_b_id = ?').get(a, b);
  if (!thread) return res.json({ thread: null, messages: [] });

  const messages = db
    .prepare('SELECT id, sender_id, body, created_at, read_at FROM dm_messages WHERE thread_id = ? ORDER BY created_at ASC')
    .all(thread.id);

  res.json({ thread: { id: thread.id }, messages });
});

// GET /api/dms/hidden — recoverable hidden conversations, for Settings.
router.get('/hidden', (req, res) => {
  const rows = db
    .prepare(
      `SELECT
          t.id AS thread_id,
          CASE WHEN t.user_a_id = ? THEN t.user_b_id ELSE t.user_a_id END AS other_user_id
       FROM dm_thread_hides h
       JOIN dm_threads t ON t.id = h.thread_id
       WHERE h.user_id = ?
       ORDER BY h.created_at DESC`
    )
    .all(req.user.id, req.user.id);

  const threads = rows.map((row) => {
    const other = db
      .prepare(
        `SELECT u.id, u.public_handle AS handle, p.nickname
         FROM users u JOIN profiles p ON p.user_id = u.id WHERE u.id = ?`
      )
      .get(row.other_user_id);
    return { threadId: row.thread_id, otherUser: other };
  });

  res.json({ threads });
});

router.post('/:threadId/hide', (req, res) => {
  const thread = getOwnedThread(req.params.threadId, req.user.id);
  if (!thread) return res.status(404).json({ error: 'Conversation not found.' });
  try {
    db.prepare('INSERT INTO dm_thread_hides (user_id, thread_id) VALUES (?, ?)').run(req.user.id, thread.id);
  } catch (err) {
    if (!/UNIQUE/.test(err.message)) throw err;
  }
  res.status(201).json({ hidden: true });
});

router.delete('/:threadId/hide', (req, res) => {
  const thread = getOwnedThread(req.params.threadId, req.user.id);
  if (!thread) return res.status(404).json({ error: 'Conversation not found.' });
  db.prepare('DELETE FROM dm_thread_hides WHERE user_id = ? AND thread_id = ?').run(req.user.id, thread.id);
  res.json({ hidden: false });
});

// "Delete" from the UI's perspective — see migrations/005 for why this is
// a timestamp rather than a flag (lets the thread quietly come back if
// the other person messages again, rather than needing to be restored).
router.post('/:threadId/clear', (req, res) => {
  const thread = getOwnedThread(req.params.threadId, req.user.id);
  if (!thread) return res.status(404).json({ error: 'Conversation not found.' });

  const latest = db.prepare('SELECT COALESCE(MAX(id), 0) AS id FROM dm_messages WHERE thread_id = ?').get(thread.id);
  db.prepare(
    `INSERT INTO dm_thread_clears (user_id, thread_id, cleared_up_to_message_id) VALUES (?, ?, ?)
     ON CONFLICT (user_id, thread_id) DO UPDATE SET cleared_up_to_message_id = excluded.cleared_up_to_message_id`
  ).run(req.user.id, thread.id, latest.id);
  res.json({ cleared: true });
});

router.post('/:threadId/report', (req, res) => {
  const thread = getOwnedThread(req.params.threadId, req.user.id);
  if (!thread) return res.status(404).json({ error: 'Conversation not found.' });
  db.prepare('INSERT INTO dm_thread_reports (reporter_id, thread_id, reason) VALUES (?, ?, ?)')
    .run(req.user.id, thread.id, req.body.reason || null);
  res.status(201).json({ reported: true });
});

module.exports = router;
