// ============================================================
// GET /api/me — "who am I", for clients that only have a token and need
// to know the actual user id / moderator status behind it (e.g. the feed's
// plain-JS frontend, which isn't part of the React app and has nowhere
// else to get this). Mounted after optionalAuth, so req.user is already
// populated if a valid token was sent — this never blocks, guests included.
// ============================================================

const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  if (!req.user) return res.json({ user: null });
  res.json({
    user: {
      id: req.user.id,
      handle: req.user.handle,
      nickname: req.user.nickname,
      isRegistered: req.user.isRegistered,
      isModerator: req.user.isModerator,
      isAdmin: req.user.isAdmin,
      isBot: req.user.isBot,
    },
  });
});

module.exports = router;
