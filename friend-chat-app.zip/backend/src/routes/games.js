// ============================================================
// Games Hub + Lobby (Games spec §4–5). Mounted at /api/games in server.js.
//
// Note on guests: unlike Chat, games require a registered account — every
// path here eventually touches the gem wallet (even free games track
// wins on the leaderboard against a real user id), and letting a guest
// start a session that vanishes the moment their guest identity churns
// would break invites/leaderboards silently. This mirrors how DMs and
// follow/block already require registration.
// ============================================================

const express = require('express');
const db = require('../db/connection');
const { requireRegistered } = require('../middleware/auth');
const { serialize: serializeInvite } = require('./gameInvites');

const router = express.Router();

function serializeDefinition(row) {
  return {
    gameId: row.game_id,
    displayName: row.display_name,
    icon: row.icon,
    shortRules: row.short_rules,
    minPlayers: row.min_players,
    maxPlayers: row.max_players,
    accessTier: row.access_tier,
    usesCardTheme: !!row.uses_card_theme,
  };
}

// "Waiting" only counts a recent, still-live queue entry — see
// routes/gameQueue.js's QUEUE_FRESHNESS_SECONDS for why: without this, a
// person who joined the queue and just closed the tab (never explicitly
// left) would show as "waiting" forever, misleading the next person into
// expecting an instant match that was never coming.
const QUEUE_FRESHNESS_SECONDS = 60;

function someoneWaiting(gameId) {
  return !!db
    .prepare(`SELECT 1 FROM speeddate_queue WHERE game_id = ? AND last_seen_at > datetime('now', '-${QUEUE_FRESHNESS_SECONDS} seconds') LIMIT 1`)
    .get(gameId);
}

// GET /api/games — the hub grid (spec §4). "Waiting" is a boolean per the
// spec's own stated assumption (is someone waiting?, not a headcount).
router.get('/', (req, res) => {
  const rows = db
    .prepare('SELECT * FROM game_definitions WHERE is_active = 1 ORDER BY sort_order ASC')
    .all();
  const games = rows.map((row) => ({
    ...serializeDefinition(row),
    someoneWaiting: someoneWaiting(row.game_id),
  }));
  res.json({ games });
});

// GET /api/games/:gameId — the lobby (spec §5): definition, site-wide
// leaderboard for this game, and — if the caller is registered — whether
// they have a session already in flight worth resuming instead of
// starting a new invite/queue entry.
router.get('/:gameId', (req, res) => {
  const def = db.prepare('SELECT * FROM game_definitions WHERE game_id = ? AND is_active = 1').get(req.params.gameId);
  if (!def) return res.status(404).json({ error: 'Game not found.' });

  const leaderboard = db
    .prepare(
      `SELECT gl.user_id AS userId, gl.wins, gl.losses, gl.best_score AS bestScore,
              p.nickname, u.public_handle AS handle
       FROM game_leaderboard gl
       JOIN users u ON u.id = gl.user_id
       JOIN profiles p ON p.user_id = gl.user_id
       WHERE gl.game_id = ?
       ORDER BY gl.wins DESC, gl.best_score DESC
       LIMIT 20`
    )
    .all(def.game_id);

  let resumableSessionId = null;
  let queued = false;
  if (req.user) {
    const resumable = db
      .prepare(
        `SELECT gsp.session_id AS id FROM game_session_players gsp
         JOIN game_sessions gs ON gs.id = gsp.session_id
         WHERE gsp.user_id = ? AND gs.game_id = ? AND gs.status IN ('waiting', 'active')
         ORDER BY gs.created_at DESC LIMIT 1`
      )
      .get(req.user.id, def.game_id);
    resumableSessionId = resumable ? resumable.id : null;
    queued = !!db.prepare('SELECT 1 FROM speeddate_queue WHERE game_id = ? AND user_id = ?').get(def.game_id, req.user.id);
  }

  res.json({
    game: serializeDefinition(def),
    someoneWaiting: someoneWaiting(def.game_id),
    leaderboard,
    resumableSessionId,
    queued,
  });
});

// GET /api/games/:gameId/my-invites — convenience for the lobby's Invite
// button to show pending invites for THIS game without the client having
// to filter the full /api/game-invites list itself.
//
// BUG FIX: this used to return raw DB rows (snake_case: inviter_id,
// invitee_id, proposed_dates_json as an unparsed string) while the
// frontend (GameInvitePanel.jsx) reads camelCase fields the OTHER invite
// routes return via gameInvites.js's serialize() — so invite.inviteeId
// and invite.proposedDates were always undefined here, silently making
// every invite invisible ("I can only create a new invite, not see mine")
// regardless of whether real invites existed. Reusing the same
// serialize() as every other invite endpoint fixes it for good, rather
// than just patching this one route's shape by hand.
router.get('/:gameId/my-invites', requireRegistered, (req, res) => {
  const rows = db
    .prepare(
      `SELECT * FROM game_invites
       WHERE game_id = ? AND (inviter_id = ? OR invitee_id = ?)
       ORDER BY created_at DESC`
    )
    .all(req.params.gameId, req.user.id, req.user.id);
  res.json({ invites: rows.map(serializeInvite) });
});

module.exports = router;
