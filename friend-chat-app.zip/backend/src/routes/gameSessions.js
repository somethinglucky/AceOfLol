// ============================================================
// GameSession endpoints — mounted at /api/game-sessions. Moves happen
// over plain REST (not a socket event) so a page reload/reconnect never
// loses a move; the in-session chat overlay is the one thing that's
// socket-based (sockets/gameChatHandlers.js), same as the rest of the app.
// ============================================================

const express = require('express');
const db = require('../db/connection');
const { requireRegistered } = require('../middleware/auth');
const { getModule } = require('../games/registry');
const { markArrived, applyMoveAndPersist } = require('../games/sessionEngine');
const { notifySessionUpdate } = require('../sockets/ioBridge');

const router = express.Router();

function touchActivity(sessionId, userId) {
  db.prepare(
    "UPDATE game_session_players SET last_active_at = datetime('now') WHERE session_id = ? AND user_id = ?"
  ).run(sessionId, userId);
}

function loadSessionForViewer(sessionId, viewerId) {
  const session = db.prepare('SELECT * FROM game_sessions WHERE id = ?').get(sessionId);
  if (!session) return null;
  const seats = db
    .prepare(
      `SELECT gsp.*, p.nickname, u.public_handle AS handle
       FROM game_session_players gsp
       JOIN users u ON u.id = gsp.user_id
       JOIN profiles p ON p.user_id = gsp.user_id
       WHERE gsp.session_id = ? ORDER BY gsp.seat_index ASC`
    )
    .all(sessionId);
  if (!seats.some((s) => s.user_id === viewerId)) return { forbidden: true };

  const gameDef = db.prepare('SELECT * FROM game_definitions WHERE game_id = ?').get(session.game_id);
  const base = {
    id: session.id,
    gameId: session.game_id,
    gameName: gameDef ? gameDef.display_name : session.game_id,
    status: session.status,
    seats: seats.map((s) => ({
      userId: s.user_id,
      nickname: s.nickname,
      handle: s.handle,
      seatIndex: s.seat_index,
      isFirstMover: !!s.is_first_mover,
      arrived: !!s.arrived,
      // "Last seen" for the waiting-room screen — see migration 009.
      // Updated whenever that player's own client hits this endpoint
      // (see touchActivity above), not a general app-wide presence system.
      lastActiveAt: s.last_active_at,
    })),
    turnUserId: session.turn_user_id,
    result: session.result_json ? JSON.parse(session.result_json) : null,
  };

  if (session.status === 'active' || session.status === 'completed') {
    const mod = getModule(session.game_id);
    base.board = mod.renderState(JSON.parse(session.module_state), viewerId);
  }
  return base;
}

// GET /api/game-sessions/mine?gameId= — used by the lobby to offer
// "Resume" instead of starting a fresh invite/queue entry.
router.get('/mine', requireRegistered, (req, res) => {
  const { gameId } = req.query;
  const rows = db
    .prepare(
      `SELECT gs.id FROM game_sessions gs
       JOIN game_session_players gsp ON gsp.session_id = gs.id
       WHERE gsp.user_id = ? AND gs.status IN ('waiting','active') ${gameId ? 'AND gs.game_id = ?' : ''}
       ORDER BY gs.created_at DESC`
    )
    .all(...(gameId ? [req.user.id, gameId] : [req.user.id]));
  res.json({ sessionIds: rows.map((r) => r.id) });
});

router.get('/:id', requireRegistered, (req, res) => {
  const view = loadSessionForViewer(req.params.id, req.user.id);
  if (!view) return res.status(404).json({ error: 'Session not found.' });
  if (view.forbidden) return res.status(403).json({ error: 'Not your session.' });
  touchActivity(req.params.id, req.user.id);
  res.json({ session: view });
});

// POST /api/game-sessions/:id/arrive — spec §6 step 8: tapping the
// confirmation link routes a player in; the Shell only calls onGameStart
// once every required seat has done this. Safe to call repeatedly.
router.post('/:id/arrive', requireRegistered, (req, res) => {
  const check = loadSessionForViewer(req.params.id, req.user.id);
  if (!check) return res.status(404).json({ error: 'Session not found.' });
  if (check.forbidden) return res.status(403).json({ error: 'Not your session.' });

  markArrived(req.params.id, req.user.id);
  touchActivity(req.params.id, req.user.id);
  notifySessionUpdate(req.params.id);
  const view = loadSessionForViewer(req.params.id, req.user.id);
  res.json({ session: view });
});

// POST /api/game-sessions/:id/move — body: { moveData }, shape depends on
// the game (e.g. blackjack: { action: 'hit' | 'stand' }; go_fish:
// { rank: 'Q' }) — the Shell never validates the shape itself, that's the
// module's job (games/blackjack.js etc's applyMove).
router.post('/:id/move', requireRegistered, (req, res) => {
  const check = loadSessionForViewer(req.params.id, req.user.id);
  if (!check) return res.status(404).json({ error: 'Session not found.' });
  if (check.forbidden) return res.status(403).json({ error: 'Not your session.' });

  const { session, error } = applyMoveAndPersist(req.params.id, req.user.id, req.body.moveData || {});
  if (error) return res.status(400).json({ error });
  touchActivity(req.params.id, req.user.id);

  notifySessionUpdate(req.params.id);
  const view = loadSessionForViewer(req.params.id, req.user.id);
  res.json({ session: view });
});

module.exports = router;
