// ============================================================
// Checkers module — implements the Game Module Interface (Games spec §2).
// Standard American/English rules: men capture and move diagonally
// forward only; kings (crowned on reaching the far row) move and capture
// in all four diagonal directions; captures are MANDATORY whenever one
// is available anywhere on the board, and a capturing piece must keep
// jumping if another capture is immediately available to it (a "multi-
// jump"). Reaching the king row ends the turn immediately, even mid
// multi-jump — the common, easy-to-explain rule variant, rather than the
// less common one that lets a freshly-crowned king keep jumping the same
// turn.
// ============================================================

const BOARD_SIZE = 8;

const meta = {
  gameId: 'checkers',
  displayName: 'Checkers',
  minPlayers: 2,
  maxPlayers: 2,
  usesCardTheme: false, // not a card game — the card/background theme system doesn't apply here
};

function inBounds(row, col) {
  return row >= 0 && row < BOARD_SIZE && col >= 0 && col < BOARD_SIZE;
}

function isDarkSquare(row, col) {
  return (row + col) % 2 === 1;
}

function cloneBoard(board) {
  return board.map((row) => row.map((cell) => (cell ? { ...cell } : null)));
}

function sameSquare(a, b) {
  return a[0] === b[0] && a[1] === b[1];
}

function otherPlayer(playerIds, playerId) {
  return playerIds.find((id) => id !== playerId);
}

// One player's pieces move toward increasing row numbers, the other
// toward decreasing — set once at deal time based on seating order.
function directionsFor(playerIds) {
  const [p1, p2] = playerIds;
  return { [p1]: 1, [p2]: -1 };
}

function kingRowFor(playerId, directions) {
  return directions[playerId] === 1 ? BOARD_SIZE - 1 : 0;
}

// Every step and capture available to the single piece at (row, col),
// respecting its own forward direction unless it's a king. Doesn't apply
// the mandatory-capture rule itself — that's allMoves()'s job, since it
// depends on what EVERY piece on the board can do, not just this one.
function pieceMoves(board, directions, row, col) {
  const piece = board[row][col];
  if (!piece) return { steps: [], captures: [] };
  const dirs = piece.king ? [1, -1] : [directions[piece.owner]];
  const steps = [];
  const captures = [];

  for (const dr of dirs) {
    for (const dc of [-1, 1]) {
      const r1 = row + dr;
      const c1 = col + dc;
      if (!inBounds(r1, c1)) continue;

      if (!board[r1][c1]) {
        steps.push({ from: [row, col], to: [r1, c1], capture: null });
        continue;
      }
      if (board[r1][c1].owner !== piece.owner) {
        const r2 = row + 2 * dr;
        const c2 = col + 2 * dc;
        if (inBounds(r2, c2) && !board[r2][c2]) {
          captures.push({ from: [row, col], to: [r2, c2], capture: [r1, c1] });
        }
      }
    }
  }
  return { steps, captures };
}

// Every LEGAL move for `owner` right now — mandatory capture rule
// applied here: if any of their pieces has a capture available anywhere
// on the board, only capture moves are legal at all, from any piece.
function allMoves(board, directions, owner) {
  const allSteps = [];
  const allCaptures = [];
  for (let row = 0; row < BOARD_SIZE; row++) {
    for (let col = 0; col < BOARD_SIZE; col++) {
      const piece = board[row][col];
      if (!piece || piece.owner !== owner) continue;
      const { steps, captures } = pieceMoves(board, directions, row, col);
      allSteps.push(...steps);
      allCaptures.push(...captures);
    }
  }
  return allCaptures.length > 0 ? allCaptures : allSteps;
}

function createInitialState(playerIds, firstMoverId) {
  const board = Array.from({ length: BOARD_SIZE }, () => Array(BOARD_SIZE).fill(null));
  const [p1, p2] = playerIds;
  for (let row = 0; row < 3; row++) {
    for (let col = 0; col < BOARD_SIZE; col++) {
      if (isDarkSquare(row, col)) board[row][col] = { owner: p1, king: false };
    }
  }
  for (let row = BOARD_SIZE - 3; row < BOARD_SIZE; row++) {
    for (let col = 0; col < BOARD_SIZE; col++) {
      if (isDarkSquare(row, col)) board[row][col] = { owner: p2, king: false };
    }
  }

  return {
    board,
    playerIds,
    directions: directionsFor(playerIds),
    turn: firstMoverId,
    mustContinueFrom: null,
    lastEvent: { type: 'deal', firstMoverId },
  };
}

function applyMove(state, playerId, moveData) {
  if (state.turn !== playerId) return { state, error: "It's not your turn." };
  const from = moveData && moveData.from;
  const to = moveData && moveData.to;
  if (!Array.isArray(from) || !Array.isArray(to)) {
    return { state, error: 'Move must be { from: [row, col], to: [row, col] }.' };
  }

  if (state.mustContinueFrom && !sameSquare(from, state.mustContinueFrom)) {
    return { state, error: 'You must keep capturing with the same piece.' };
  }

  const legal = state.mustContinueFrom
    ? pieceMoves(state.board, state.directions, state.mustContinueFrom[0], state.mustContinueFrom[1]).captures
    : allMoves(state.board, state.directions, playerId);

  const match = legal.find((m) => sameSquare(m.from, from) && sameSquare(m.to, to));
  if (!match) return { state, error: 'Illegal move.' };

  const board = cloneBoard(state.board);
  const piece = board[match.from[0]][match.from[1]];
  board[match.from[0]][match.from[1]] = null;
  if (match.capture) board[match.capture[0]][match.capture[1]] = null;

  const kingRow = kingRowFor(playerId, state.directions);
  let kinged = false;
  if (!piece.king && match.to[0] === kingRow) {
    piece.king = true;
    kinged = true;
  }
  board[match.to[0]][match.to[1]] = piece;

  let turn = state.turn;
  let mustContinueFrom = null;
  // Reaching the king row always ends the turn, even mid multi-jump —
  // see the file header for why this variant was chosen.
  if (match.capture && !kinged) {
    const further = pieceMoves(board, state.directions, match.to[0], match.to[1]).captures;
    if (further.length > 0) {
      mustContinueFrom = match.to;
    } else {
      turn = otherPlayer(state.playerIds, playerId);
    }
  } else {
    turn = otherPlayer(state.playerIds, playerId);
  }

  const next = {
    ...state,
    board,
    turn,
    mustContinueFrom,
    lastEvent: { type: 'move', playerId, from: match.from, to: match.to, captured: !!match.capture, kinged, continuing: !!mustContinueFrom },
  };
  return { state: next, error: null };
}

// The game is over once the player whose turn it now is has no legal
// moves at all — either because they have no pieces left, or because
// every remaining piece is blocked. Both read the same way here: an
// empty move list.
function checkEnd(state) {
  const stuckPlayer = state.turn;
  const moves = allMoves(state.board, state.directions, stuckPlayer);
  if (moves.length > 0) return null;
  return { winnerId: otherPlayer(state.playerIds, stuckPlayer), scores: {} };
}

// renderState computes the viewer's own legal moves (only when it's
// actually their turn) so the Shell/frontend never needs to reimplement
// checkers rules just to know which squares are tappable — same
// "server is the source of truth" shape as the other modules, just more
// load-bearing here since the UI is select-a-piece/see-destinations
// rather than a fixed set of buttons.
function renderState(state, forUserId) {
  const isViewerTurn = state.turn === forUserId;
  const legalMoves = isViewerTurn
    ? state.mustContinueFrom
      ? pieceMoves(state.board, state.directions, state.mustContinueFrom[0], state.mustContinueFrom[1]).captures
      : allMoves(state.board, state.directions, forUserId)
    : [];

  return {
    board: state.board,
    turn: state.turn,
    mustContinueFrom: state.mustContinueFrom,
    legalMoves,
    lastEvent: state.lastEvent,
    // Lets the frontend orient the board so the viewer's own pieces are
    // always at the bottom of their screen, regardless of which "side"
    // they were dealt — without this every board would render from the
    // same fixed orientation and one player would be looking at their
    // own pieces upside-down relative to how they're used to playing.
    viewerDirection: state.directions[forUserId],
  };
}

module.exports = { meta, createInitialState, applyMove, checkEnd, renderState };
