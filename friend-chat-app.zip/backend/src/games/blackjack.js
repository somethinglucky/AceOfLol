// ============================================================
// Blackjack module — implements the Game Module Interface (Games spec §2).
// Player-vs-player per the spec's table (minPlayers/maxPlayers 2-2, no
// dealer seat): closest to 21 without busting wins. No side bets, no
// splitting/doubling for now — the shell only needs this to be a complete,
// correct two-player game to prove the interface end to end.
//
// The Shell (routes/games/*.js) never touches anything in `state` directly
// — it only calls the four functions below and stores/returns what they
// hand back. That's what "the Shell never needs to understand Blackjack
// rules" (spec §2) means in practice.
// ============================================================

const { freshShuffledDeck, rankOf } = require('./deck');

const meta = {
  gameId: 'blackjack',
  displayName: 'Blackjack',
  minPlayers: 2,
  maxPlayers: 2,
  usesCardTheme: true,
};

function cardValue(card) {
  const rank = rankOf(card);
  if (rank === 'A') return 11; // soft ace, adjusted for in handTotal
  if (['J', 'Q', 'K'].includes(rank)) return 10;
  return parseInt(rank, 10);
}

// Standard soft-ace adjustment: count aces as 11 unless that busts the
// hand, in which case drop them to 1 one at a time.
function handTotal(hand) {
  let total = hand.reduce((sum, c) => sum + cardValue(c), 0);
  let aces = hand.filter((c) => rankOf(c) === 'A').length;
  while (total > 21 && aces > 0) {
    total -= 10;
    aces -= 1;
  }
  return total;
}

// onSessionCreate + onGameStart collapsed into one: by the time the Shell
// calls this, all seats are filled (spec §6 step 10) and it already knows
// who the first mover is (the invitee, or whoever the queue matched first).
function createInitialState(playerIds, firstMoverId) {
  const deck = freshShuffledDeck();
  const hands = {};
  for (const id of playerIds) hands[id] = [deck.pop(), deck.pop()];

  return {
    deck,
    hands,
    standing: Object.fromEntries(playerIds.map((id) => [id, false])),
    busted: Object.fromEntries(playerIds.map((id) => [id, false])),
    turn: firstMoverId,
    playerIds,
    log: [`Cards dealt. ${firstMoverId} moves first.`],
  };
}

function nextTurn(state) {
  const idx = state.playerIds.indexOf(state.turn);
  const other = state.playerIds[(idx + 1) % state.playerIds.length];
  // Skip anyone already standing or busted — if that's everyone, the turn
  // value stops mattering because checkEnd will end the hand.
  if (state.standing[other] || state.busted[other]) {
    const allDone = state.playerIds.every((id) => state.standing[id] || state.busted[id]);
    return allDone ? state.turn : nextTurn({ ...state, turn: other });
  }
  return other;
}

// onMove — validates the move belongs to the player whose turn it is, then
// updates state. Returns { state, error } rather than throwing so the
// Shell can turn `error` straight into a 400 response.
function applyMove(state, playerId, moveData) {
  if (state.turn !== playerId) return { state, error: "It's not your turn." };
  if (state.standing[playerId] || state.busted[playerId]) {
    return { state, error: 'You are already done this hand.' };
  }

  const action = moveData && moveData.action;
  if (!['hit', 'stand'].includes(action)) {
    return { state, error: "Move must be { action: 'hit' | 'stand' }." };
  }

  const next = {
    ...state,
    hands: { ...state.hands },
    standing: { ...state.standing },
    busted: { ...state.busted },
    log: [...state.log],
  };

  if (action === 'stand') {
    next.standing[playerId] = true;
    next.log.push(`${playerId} stands on ${handTotal(next.hands[playerId])}.`);
  } else {
    const deck = [...next.deck];
    const card = deck.pop();
    next.deck = deck;
    next.hands[playerId] = [...next.hands[playerId], card];
    const total = handTotal(next.hands[playerId]);
    next.log.push(`${playerId} hits and draws ${card} (total ${total}).`);
    if (total > 21) {
      next.busted[playerId] = true;
      next.log.push(`${playerId} busts.`);
    }
  }

  next.turn = nextTurn(next);
  return { state: next, error: null };
}

// checkEnd — the hand is over once every player has either stood or
// busted. Returns null while still in progress, or the result the Shell
// writes to game_sessions.result_json and folds into the leaderboard.
function checkEnd(state) {
  const allDone = state.playerIds.every((id) => state.standing[id] || state.busted[id]);
  if (!allDone) return null;

  const scores = {};
  for (const id of state.playerIds) {
    scores[id] = state.busted[id] ? 0 : handTotal(state.hands[id]);
  }

  const standing = state.playerIds.filter((id) => !state.busted[id]);
  let winnerId = null;
  if (standing.length === 1) {
    winnerId = standing[0];
  } else if (standing.length > 1) {
    const best = Math.max(...standing.map((id) => scores[id]));
    const leaders = standing.filter((id) => scores[id] === best);
    winnerId = leaders.length === 1 ? leaders[0] : null; // tie/push
  }
  // standing.length === 0 (everyone busted) also falls through to winnerId: null

  return { winnerId, scores };
}

// renderState — hides nothing in Blackjack (both hands are always visible
// once dealt, same as a real table), but this is where a module with
// hidden information (Go Fish) earns its keep: the Shell calls this once
// per viewer, never sends raw `state` to the client.
function renderState(state, forUserId) {
  return {
    yourHand: state.hands[forUserId] || [],
    hands: state.hands,
    totals: Object.fromEntries(state.playerIds.map((id) => [id, handTotal(state.hands[id])])),
    standing: state.standing,
    busted: state.busted,
    turn: state.turn,
    cardsLeft: state.deck.length,
    log: state.log.slice(-8),
  };
}

module.exports = { meta, createInitialState, applyMove, checkEnd, renderState };
