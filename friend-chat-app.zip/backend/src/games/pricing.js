// ============================================================
// Monetization logic (Games spec §8). One function per mode, both built
// on the same rule of thumb the spec calls out: in an invite, the fee (if
// any) is charged once to the inviter and covers both seats; in a
// stranger match, there's no covering — each seat is billed independently
// off that individual player's own tier. That single distinction is the
// whole of §8's pricing table.
// ============================================================

const INVITE_COST = 2; // gems — covers both seats, charged once to the inviter
const STRANGER_SEAT_COST = 1; // gems — per seat, only for non-premium players

// gameDef: the game_definitions row. Free games are always free for
// everyone regardless of mode — this short-circuits both functions below.
function isFreeGame(gameDef) {
  return gameDef.access_tier === 'free';
}

// Returns the gem amount to charge the INVITER at invite-submission time
// (spec §6 step 2). 0 for a free game or a premium inviter — the invitee
// is never charged either way.
function inviteCost(gameDef, inviterIsPremium) {
  if (isFreeGame(gameDef)) return 0;
  return inviterIsPremium ? 0 : INVITE_COST;
}

// Returns the gem amount to charge ONE PLAYER when seated via the
// stranger queue (spec §7). Called once per seat, independently.
function strangerSeatCost(gameDef, playerIsPremium) {
  if (isFreeGame(gameDef)) return 0;
  return playerIsPremium ? 0 : STRANGER_SEAT_COST;
}

module.exports = { inviteCost, strangerSeatCost, INVITE_COST, STRANGER_SEAT_COST };
