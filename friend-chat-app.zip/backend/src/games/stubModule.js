// ============================================================
// Stub module — used for any game_definitions row without a real engine
// yet (War, Hearts today). Implements the same interface shape as
// blackjack.js/goFish.js so the Shell can host it identically: sessions
// get created, invites/speeddate/monetization all work, but there's no
// actual gameplay — the single "move" available just ends the game in a
// draw so the session can complete and the leaderboard flow is exercised.
//
// Swapping in a real engine later means writing a new module and adding
// one line to registry.js's MODULES map — nothing about the Shell,
// routes, or DB schema changes.
// ============================================================

function createInitialState(playerIds) {
  return {
    playerIds,
    log: [`This game's engine isn't built yet — tap "End (stub)" to finish the session.`],
  };
}

function applyMove(state, playerId, moveData) {
  if (moveData && moveData.action === 'end_stub') {
    return { state: { ...state, ended: true }, error: null };
  }
  return { state, error: "This game doesn't have real moves yet — only { action: 'end_stub' }." };
}

function checkEnd(state) {
  if (!state.ended) return null;
  return { winnerId: null, scores: Object.fromEntries(state.playerIds.map((id) => [id, 0])) };
}

function renderState(state) {
  return { log: state.log, note: 'This game is still being built.' };
}

module.exports = { createInitialState, applyMove, checkEnd, renderState };
