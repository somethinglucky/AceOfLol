// ============================================================
// Game Module Interface registry — the "plug" from the Games spec §2.
// This is the ONLY place the Shell (routes/games/*.js) looks up which
// module handles a given gameId. Every module exports the same four
// functions: createInitialState, applyMove, checkEnd, renderState.
// The Shell never imports blackjack.js/goFish.js directly.
// ============================================================

const blackjack = require('./blackjack');
const goFish = require('./goFish');
const checkers = require('./checkers');
const stub = require('./stubModule');

const MODULES = {
  blackjack,
  go_fish: goFish,
  checkers,
};

function getModule(gameId) {
  return MODULES[gameId] || stub;
}

module.exports = { getModule };
