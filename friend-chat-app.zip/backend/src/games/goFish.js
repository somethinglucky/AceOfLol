// ============================================================
// Go Fish module — implements the Game Module Interface (Games spec §2).
// Classic 2-player rules, simplified slightly: matching your ask always
// keeps your turn (real Go Fish agrees); drawing the exact rank you asked
// for off the deck also keeps your turn, same as the common house rule.
// ============================================================

const { freshShuffledDeck, rankOf, RANKS } = require('./deck');

const meta = {
  gameId: 'go_fish',
  displayName: 'Go Fish',
  minPlayers: 2,
  maxPlayers: 2,
  usesCardTheme: true,
};

const HAND_SIZE = 7; // standard deal for a 2-player game

function opponentOf(state, playerId) {
  return state.playerIds.find((id) => id !== playerId);
}

// Pulls any rank a player now holds all four of out of their hand and
// into their books. Called after every hand-changing move.
function collectBooks(state, playerId) {
  const hand = state.hands[playerId];
  const counts = {};
  for (const card of hand) counts[rankOf(card)] = (counts[rankOf(card)] || 0) + 1;

  const completed = Object.keys(counts).filter((rank) => counts[rank] === 4);
  if (completed.length === 0) return;

  state.hands[playerId] = hand.filter((card) => !completed.includes(rankOf(card)));
  state.books[playerId] = [...state.books[playerId], ...completed];
  for (const rank of completed) state.log.push(`${playerId} completes a book of ${rank}s!`);
}

// Real Go Fish rule: any time your hand goes empty mid-game and the pool
// still has cards, you draw one to keep playing. Without this, a player
// whose hand empties out (by giving away a match, or by asking their
// last card away) can get stuck on their own turn with nothing to ask
// with — a real deadlock caught by simulating a full game end-to-end.
function restockEmptyHands(state) {
  for (const id of state.playerIds) {
    if (state.hands[id].length === 0 && state.deck.length > 0) {
      const drawn = state.deck.pop();
      state.hands[id] = [drawn];
      state.log.push(`${id}'s hand was empty — draws a fresh card.`);
    }
  }
}

function createInitialState(playerIds, firstMoverId) {
  const deck = freshShuffledDeck();
  const hands = {};
  for (const id of playerIds) hands[id] = deck.splice(deck.length - HAND_SIZE, HAND_SIZE);

  return {
    deck,
    hands,
    books: Object.fromEntries(playerIds.map((id) => [id, []])),
    turn: firstMoverId,
    playerIds,
    log: [`Hands dealt, ${HAND_SIZE} cards each. ${firstMoverId} moves first.`],
  };
}

function applyMove(state, playerId, moveData) {
  if (state.turn !== playerId) return { state, error: "It's not your turn." };

  const rank = moveData && moveData.rank;
  if (!RANKS.includes(rank)) {
    return { state, error: "Move must be { action: 'ask', rank: '<A-K>' }." };
  }
  const askerHasRank = state.hands[playerId].some((c) => rankOf(c) === rank);
  if (!askerHasRank) {
    return { state, error: 'You can only ask for a rank you already hold.' };
  }

  const opponent = opponentOf(state, playerId);
  const next = { ...state, log: [...state.log] };
  next.hands = { [playerId]: [...state.hands[playerId]], [opponent]: [...state.hands[opponent]] };
  next.books = { [playerId]: [...state.books[playerId]], [opponent]: [...state.books[opponent]] };
  next.deck = [...state.deck];

  const matches = next.hands[opponent].filter((c) => rankOf(c) === rank);

  if (matches.length > 0) {
    next.hands[opponent] = next.hands[opponent].filter((c) => rankOf(c) !== rank);
    next.hands[playerId] = [...next.hands[playerId], ...matches];
    next.log.push(`${playerId} asks ${opponent} for ${rank}s — got ${matches.length}! Goes again.`);
    next.turn = playerId;
  } else if (next.deck.length > 0) {
    const drawn = next.deck.pop();
    next.hands[playerId] = [...next.hands[playerId], drawn];
    next.log.push(`${playerId} asks for ${rank}s — Go Fish! Draws a card.`);
    next.turn = rankOf(drawn) === rank ? playerId : opponent;
  } else {
    next.log.push(`${playerId} asks for ${rank}s — Go Fish, but the deck is empty.`);
    next.turn = opponent;
  }

  collectBooks(next, playerId);
  collectBooks(next, opponent);
  restockEmptyHands(next);

  return { state: next, error: null };
}

// The game is over once the deck is empty AND whoever's turn it is has no
// cards left to ask with — restockEmptyHands already guarantees that
// never happens while the deck still has cards, so this is a true
// stalemate, not a bug. (Both hands empty implies this too, since the
// deck must also be empty at that point — 52 cards can't vanish.)
function checkEnd(state) {
  if (!(state.deck.length === 0 && state.hands[state.turn].length === 0)) return null;

  const scores = Object.fromEntries(state.playerIds.map((id) => [id, state.books[id].length]));
  const best = Math.max(...Object.values(scores));
  const leaders = state.playerIds.filter((id) => scores[id] === best);
  return { winnerId: leaders.length === 1 ? leaders[0] : null, scores };
}

function renderState(state, forUserId) {
  const opponent = opponentOf(state, forUserId);
  return {
    yourHand: state.hands[forUserId] || [],
    opponentHandCount: (state.hands[opponent] || []).length,
    books: state.books,
    turn: state.turn,
    cardsLeft: state.deck.length,
    log: state.log.slice(-8),
  };
}

module.exports = { meta, createInitialState, applyMove, checkEnd, renderState };
