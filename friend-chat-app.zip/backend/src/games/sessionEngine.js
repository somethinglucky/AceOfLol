// ============================================================
// GameSession lifecycle — shared by both entry points (an invite's
// confirmed schedule, and a stranger-queue match). Spec §6 step 10: the
// Shell does not call onGameStart (here: does not flip status to
// 'active' or generate module state) until every required seat has
// "arrived" at the session. A stranger match has no scheduling wait, so
// both seats are marked arrived immediately on creation — same code path,
// zero special-casing.
// ============================================================

const crypto = require('crypto');
const db = require('../db/connection');
const { getModule } = require('./registry');

// Creates the GameSession + seat rows in 'waiting' state. firstMoverId
// must be one of playerIds — invite flow: the invitee (spec §6 step 9);
// stranger flow: whoever joined the queue first (games.js decides this).
function createWaitingSession({ gameId, playerIds, firstMoverId, source, inviteId }) {
  if (!playerIds.includes(firstMoverId)) {
    throw new Error('firstMoverId must be one of playerIds');
  }
  const id = crypto.randomUUID();
  db.prepare(
    `INSERT INTO game_sessions (id, game_id, status, seats_required, source)
     VALUES (?, ?, 'waiting', ?, ?)`
  ).run(id, gameId, playerIds.length, source);

  const insertPlayer = db.prepare(
    `INSERT INTO game_session_players (session_id, user_id, seat_index, is_first_mover)
     VALUES (?, ?, ?, ?)`
  );
  playerIds.forEach((userId, i) => insertPlayer.run(id, userId, i, userId === firstMoverId ? 1 : 0));

  if (inviteId) db.prepare('UPDATE game_invites SET session_id = ? WHERE id = ?').run(id, inviteId);

  return id;
}

// Marks one seat arrived; once every seat has arrived, calls the module's
// onGameStart equivalent (createInitialState) and flips the session to
// 'active'. Safe to call more than once for the same user (idempotent).
function markArrived(sessionId, userId) {
  const session = db.prepare('SELECT * FROM game_sessions WHERE id = ?').get(sessionId);
  if (!session) throw new Error('Session not found');
  if (session.status !== 'waiting') return session; // already started/completed — nothing to do

  db.prepare(
    `UPDATE game_session_players SET arrived = 1, arrived_at = datetime('now')
     WHERE session_id = ? AND user_id = ? AND arrived = 0`
  ).run(sessionId, userId);

  const seats = db.prepare('SELECT * FROM game_session_players WHERE session_id = ?').all(sessionId);
  const allArrived = seats.every((s) => s.arrived);
  if (!allArrived) return db.prepare('SELECT * FROM game_sessions WHERE id = ?').get(sessionId);

  const playerIds = seats.sort((a, b) => a.seat_index - b.seat_index).map((s) => s.user_id);
  const firstMover = seats.find((s) => s.is_first_mover).user_id;
  const mod = getModule(session.game_id);
  const state = mod.createInitialState(playerIds, firstMover);

  db.prepare(
    `UPDATE game_sessions SET status = 'active', module_state = ?, turn_user_id = ?, started_at = datetime('now')
     WHERE id = ?`
  ).run(JSON.stringify(state), state.turn || firstMover, sessionId);

  return db.prepare('SELECT * FROM game_sessions WHERE id = ?').get(sessionId);
}

// Applies a move, persists it, and — if the module reports the game is
// over — writes result_json + folds it into game_leaderboard. Returns the
// updated session row plus any move error (which the route turns into a
// 400 without persisting anything).
function applyMoveAndPersist(sessionId, userId, moveData) {
  const session = db.prepare('SELECT * FROM game_sessions WHERE id = ?').get(sessionId);
  if (!session) throw new Error('Session not found');
  if (session.status !== 'active') return { session, error: 'This game is not active.' };

  const mod = getModule(session.game_id);
  const state = JSON.parse(session.module_state);
  const { state: nextState, error } = mod.applyMove(state, userId, moveData);
  if (error) return { session, error };

  const end = mod.checkEnd(nextState);
  const updateSql = end
    ? `UPDATE game_sessions SET module_state = ?, turn_user_id = ?, status = 'completed', result_json = ?, completed_at = datetime('now') WHERE id = ?`
    : `UPDATE game_sessions SET module_state = ?, turn_user_id = ? WHERE id = ?`;
  const params = end
    ? [JSON.stringify(nextState), nextState.turn || null, JSON.stringify(end), sessionId]
    : [JSON.stringify(nextState), nextState.turn || null, sessionId];
  db.prepare(updateSql).run(...params);

  if (end) recordLeaderboard(session.game_id, session.id, end);

  return { session: db.prepare('SELECT * FROM game_sessions WHERE id = ?').get(sessionId), error: null };
}

const upsertLeaderboardRow = db.transaction((gameId, userId, won, score) => {
  db.prepare(
    `INSERT INTO game_leaderboard (game_id, user_id, wins, losses, best_score, updated_at)
     VALUES (?, ?, ?, ?, ?, datetime('now'))
     ON CONFLICT (game_id, user_id) DO UPDATE SET
       wins = wins + excluded.wins,
       losses = losses + excluded.losses,
       best_score = MAX(COALESCE(best_score, excluded.best_score), excluded.best_score),
       updated_at = datetime('now')`
  ).run(gameId, userId, won ? 1 : 0, won ? 0 : 1, score ?? null);
});

function recordLeaderboard(gameId, sessionId, result) {
  const seats = db.prepare('SELECT user_id FROM game_session_players WHERE session_id = ?').all(sessionId);
  for (const { user_id: userId } of seats) {
    const won = result.winnerId === userId;
    const score = result.scores ? result.scores[userId] : null;
    upsertLeaderboardRow(gameId, userId, won, score);
  }
}

module.exports = { createWaitingSession, markArrived, applyMoveAndPersist };
