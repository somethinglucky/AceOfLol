// ============================================================
// GameSession lifecycle — shared by both entry points (an invite's
// confirmed schedule, and a stranger-queue match). Spec §6 step 10: the
// Shell does not call onGameStart (here: does not flip status to
// 'active' or generate module state) until every required seat has
// "arrived" at the session. A stranger match has no scheduling wait, so
// both seats are marked arrived immediately on creation — same code path,
// zero special-casing.
// ============================================================

const crypto = require('crypto');
const db = require('../db/connection');
const { getModule } = require('./registry');

// Creates the GameSession + seat rows in 'waiting' state. firstMoverId
// must be one of playerIds — invite flow: the invitee (spec §6 step 9);
// stranger flow: whoever joined the queue first (games.js decides this).
function createWaitingSession({ gameId, playerIds, firstMoverId, source, inviteId }) {
  if (!playerIds.includes(firstMoverId)) {
    throw new Error('firstMoverId must be one of playerIds');
  }
  const id = crypto.randomUUID();
  db.prepare(
    `INSERT INTO game_sessions (id, game_id, status, seats_required, source)
     VALUES (?, ?, 'waiting', ?, ?)`
  ).run(id, gameId, playerIds.length, source);

  const insertPlayer = db.prepare(
    `INSERT INTO game_session_players (session_id, user_id, seat_index, is_first_mover)
     VALUES (?, ?, ?, ?)`
  );
  playerIds.forEach((userId, i) => insertPlayer.run(id, userId, i, userId === firstMoverId ? 1 : 0));

  if (inviteId) db.prepare('UPDATE game_invites SET session_id = ? WHERE id = ?').run(id, inviteId);

  return id;
}

// Marks one seat arrived; once every seat has arrived, calls the module's
// onGameStart equivalent (createInitialState) and flips the session to
// 'active'. Safe to call more than once for the same user (idempotent).
function markArrived(sessionId, userId) {
  const session = db.prepare('SELECT * FROM game_sessions WHERE id = ?').get(sessionId);
  if (!session) throw new Error('Session not found');
  if (session.status !== 'waiting') return session; // already started/completed — nothing to do

  db.prepare(
    `UPDATE game_session_players SET arrived = 1, arrived_at = datetime('now')
     WHERE session_id = ? AND user_id = ? AND arrived = 0`
  ).run(sessionId, userId);

  const seats = db.prepare('SELECT * FROM game_session_players WHERE session_id = ?').all(sessionId);
  const allArrived = seats.every((s) => s.arrived);
  if (!allArrived) return db.prepare('SELECT * FROM game_sessions WHERE id = ?').get(sessionId);

  const playerIds = seats.sort((a, b) => a.seat_index - b.seat_index).map((s) => s.user_id);
  const firstMover = seats.find((s) => s.is_first_mover).user_id;
  const mod = getModule(session.game_id);
  const state = mod.createInitialState(playerIds, firstMover);

  db.prepare(
    `UPDATE game_sessions SET status = 'active', module_state = ?, turn_user_id = ?, started_at = datetime('now')
     WHERE id = ?`
  ).run(JSON.stringify(state), state.turn || firstMover, sessionId);

  return db.prepare('SELECT * FROM game_sessions WHERE id = ?').get(sessionId);
}

// Applies a move, persists it, and — if the module reports the game is
// over — writes result_json + folds it into game_leaderboard. Returns the
// updated session row plus any move error (which the route turns into a
// 400 without persisting anything).
function applyMoveAndPersist(sessionId, userId, moveData) {
  const session = db.prepare('SELECT * FROM game_sessions WHERE id = ?').get(sessionId);
  if (!session) throw new Error('Session not found');
  if (session.status !== 'active') return { session, error: 'This game is not active.' };

  const mod = getModule(session.game_id);
  const state = JSON.parse(session.module_state);
  const { state: nextState, error } = mod.applyMove(state, userId, moveData);
  if (error) return { session, error };

  const end = mod.checkEnd(nextState);
  const updateSql = end
    ? `UPDATE game_sessions SET module_state = ?, turn_user_id = ?, status = 'completed', result_json = ?, completed_at = datetime('now') WHERE id = ?`
    : `UPDATE game_sessions SET module_state = ?, turn_user_id = ? WHERE id = ?`;
  const params = end
    ? [JSON.stringify(nextState), nextState.turn || null, JSON.stringify(end), sessionId]
    : [JSON.stringify(nextState), nextState.turn || null, sessionId];
  db.prepare(updateSql).run(...params);

  if (end) recordLeaderboard(session.game_id, session.id, end);

  return { session: db.prepare('SELECT * FROM game_sessions WHERE id = ?').get(sessionId), error: null };
}

const upsertLeaderboardRow = db.transaction((gameId, userId, won, score) => {
  db.prepare(
    `INSERT INTO game_leaderboard (game_id, user_id, wins, losses, best_score, updated_at)
     VALUES (?, ?, ?, ?, ?, datetime('now'))
     ON CONFLICT (game_id, user_id) DO UPDATE SET
       wins = wins + excluded.wins,
       losses = losses + excluded.losses,
       best_score = MAX(COALESCE(best_score, excluded.best_score), excluded.best_score),
       updated_at = datetime('now')`
  ).run(gameId, userId, won ? 1 : 0, won ? 0 : 1, score ?? null);
});

function recordLeaderboard(gameId, sessionId, result) {
  const seats = db.prepare('SELECT user_id FROM game_session_players WHERE session_id = ?').all(sessionId);
  for (const { user_id: userId } of seats) {
    const won = result.winnerId === userId;
    const score = result.scores ? result.scores[userId] : null;
    upsertLeaderboardRow(gameId, userId, won, score);
  }
}

// Lets a player bail out of a session they no longer want to be stuck in
// (the Lobby's "Quit old game" button). Two cases:
// - 'waiting' (never actually started — still waiting on seats to
//   arrive): nothing was played, so it just ends with no winner and no
//   leaderboard effect. There's nothing to forfeit.
// - 'active': the remaining player(s) win by forfeit, same as if they'd
//   won outright — this still counts on the leaderboard, since walking
//   away mid-game is meaningfully different from a session that never
//   got going.
// Idempotent: quitting an already-completed session is a no-op that just
// returns it as-is, so a double-tap or a stale button can't double-forfeit.
function quitSession(sessionId, quittingUserId) {
  const session = db.prepare('SELECT * FROM game_sessions WHERE id = ?').get(sessionId);
  if (!session) throw new Error('Session not found');
  if (session.status === 'completed') return session;

  if (session.status === 'active') {
    const seats = db.prepare('SELECT user_id FROM game_session_players WHERE session_id = ?').all(sessionId);
    const remaining = seats.map((s) => s.user_id).filter((id) => id !== quittingUserId);
    const result = { winnerId: remaining.length === 1 ? remaining[0] : null, scores: {}, quitBy: quittingUserId };
    db.prepare(
      `UPDATE game_sessions SET status = 'completed', result_json = ?, completed_at = datetime('now') WHERE id = ?`
    ).run(JSON.stringify(result), sessionId);
    recordLeaderboard(session.game_id, sessionId, result);
  } else {
    const result = { winnerId: null, scores: {}, quitBy: quittingUserId };
    db.prepare(
      `UPDATE game_sessions SET status = 'completed', result_json = ?, completed_at = datetime('now') WHERE id = ?`
    ).run(JSON.stringify(result), sessionId);
  }

  return db.prepare('SELECT * FROM game_sessions WHERE id = ?').get(sessionId);
}

// "Play Again" with the same person, without leaving the result screen to
// requeue and hope to land on them again — the exact friction sj flagged.
// Whoever taps first is recorded on the (now-completed) old session;
// when the OTHER seat also taps, a fresh session is created immediately
// for the same players and returned to that second caller — the route
// layer (routes/gameSessions.js) is responsible for telling the first
// caller via a socket push, since this function has no way to reach them.
//
// Pricing: treated the same as a stranger match (each non-premium player
// pays their own seat fee for a paid game) regardless of how the
// original session started — a mutual rematch has no "inviter" role to
// hang invite-pricing off of, both people are equally opting back in.
function requestRematch(sessionId, requestingUserId) {
  const session = db.prepare('SELECT * FROM game_sessions WHERE id = ?').get(sessionId);
  if (!session) throw new Error('Session not found');
  if (session.status !== 'completed') throw new Error('Game is not over yet.');

  const seats = db
    .prepare('SELECT * FROM game_session_players WHERE session_id = ? ORDER BY seat_index ASC')
    .all(sessionId);
  if (!seats.some((s) => s.user_id === requestingUserId)) throw new Error('Not your session.');

  if (!session.rematch_requested_by) {
    db.prepare('UPDATE game_sessions SET rematch_requested_by = ? WHERE id = ?').run(requestingUserId, sessionId);
    return { waiting: true };
  }
  if (session.rematch_requested_by === requestingUserId) {
    return { waiting: true }; // already asked — idempotent, not a second request
  }

  // The other seat already asked — start it now. Alternate who moves
  // first as a small fairness touch, rather than always favoring
  // whoever happened to be seat 0.
  const playerIds = seats.map((s) => s.user_id);
  const previousFirstMover = seats.find((s) => s.is_first_mover)?.user_id;
  const firstMoverId = playerIds.find((id) => id !== previousFirstMover) || playerIds[0];

  const newSessionId = createWaitingSession({
    gameId: session.game_id,
    playerIds,
    firstMoverId,
    // Reuses 'stranger' rather than a new source value — see migration
    // 014 for why (avoids a risky rebuild of a table with real FK
    // dependents, and behaviorally a rematch IS exactly a stranger-style
    // session: per-seat pricing, no scheduling, immediate start).
    source: 'stranger',
  });
  playerIds.forEach((userId) => markArrived(newSessionId, userId));

  // Carry the chat over rather than starting the new session's history
  // empty — sj's point: a rematch is a continuation of the same
  // conversation, not a reason to lose it. game_session_messages is
  // scoped per session_id, so without this the two of you would just
  // silently see nothing on rejoining even though you were mid-chat a
  // moment ago.
  db.prepare(
    `INSERT INTO game_session_messages (session_id, sender_id, body, created_at)
     SELECT ?, sender_id, body, created_at FROM game_session_messages WHERE session_id = ? ORDER BY created_at ASC`
  ).run(newSessionId, sessionId);

  return { waiting: false, sessionId: newSessionId, requestedBy: session.rematch_requested_by };
}

module.exports = { createWaitingSession, markArrived, applyMoveAndPersist, quitSession, requestRematch };
