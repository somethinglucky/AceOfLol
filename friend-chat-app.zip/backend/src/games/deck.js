// ============================================================
// Shared 52-card deck helpers, used by any module with usesCardTheme: true.
// Cards are plain strings like 'AS', '10H', 'KC' — cheap to store as JSON
// inside game_sessions.module_state and to compare with ===.
// ============================================================

const RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
const SUITS = ['S', 'H', 'D', 'C'];

function rankOf(card) {
  return card.slice(0, -1);
}

function suitOf(card) {
  return card.slice(-1);
}

// Fisher-Yates — Math.random() is fine here; these are casual card games,
// not anything with money riding on cryptographic shuffle guarantees.
function freshShuffledDeck() {
  const deck = [];
  for (const suit of SUITS) {
    for (const rank of RANKS) deck.push(`${rank}${suit}`);
  }
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

module.exports = { RANKS, SUITS, rankOf, suitOf, freshShuffledDeck };
