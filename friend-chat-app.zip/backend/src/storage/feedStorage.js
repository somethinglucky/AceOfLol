// ============================================================
// STORAGE ADAPTER for feed images — local disk for now.
// LATER (DigitalOcean Spaces): replace the body of save() with an
// S3-compatible upload and urlFor() to build the Spaces CDN URL.
// No route file needs to change — they only call save()/urlFor().
// Same deferred status as profile photo uploads (see profiles.js).
// ============================================================

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const UPLOAD_DIR = process.env.FEED_UPLOAD_DIR || path.join(__dirname, '../../uploads/feed');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

function save(buffer, originalFilename) {
  const ext = path.extname(originalFilename || '').toLowerCase() || '.jpg';
  const filename = `${crypto.randomUUID()}${ext}`;
  fs.writeFileSync(path.join(UPLOAD_DIR, filename), buffer);
  return filename;
}

// Served by nginx at /media/ (see nginx/app.conf) aliasing this same
// uploads/feed directory — the Node process never touches image bytes
// on the way back out, only on the way in.
function urlFor(imagePath) {
  return `/media/${imagePath}`;
}

module.exports = { save, urlFor };
