// Given a birthdate (YYYY-MM-DD string), returns { age, zodiac } for public
// display — the raw birthdate itself should never be sent to the frontend
// for anyone other than the profile's own owner (editing their own info).
const ZODIAC_RANGES = [
  { sign: 'capricorn', from: [12, 22], to: [1, 19] },
  { sign: 'aquarius', from: [1, 20], to: [2, 18] },
  { sign: 'pisces', from: [2, 19], to: [3, 20] },
  { sign: 'aries', from: [3, 21], to: [4, 19] },
  { sign: 'taurus', from: [4, 20], to: [5, 20] },
  { sign: 'gemini', from: [5, 21], to: [6, 20] },
  { sign: 'cancer', from: [6, 21], to: [7, 22] },
  { sign: 'leo', from: [7, 23], to: [8, 22] },
  { sign: 'virgo', from: [8, 23], to: [9, 22] },
  { sign: 'libra', from: [9, 23], to: [10, 22] },
  { sign: 'scorpio', from: [10, 23], to: [11, 21] },
  { sign: 'sagittarius', from: [11, 22], to: [12, 21] },
];

function getZodiac(month, day) {
  for (const { sign, from, to } of ZODIAC_RANGES) {
    const [fromMonth, fromDay] = from;
    const [toMonth, toDay] = to;
    if (fromMonth === toMonth) {
      if (month === fromMonth && day >= fromDay && day <= toDay) return sign;
    } else if (
      (month === fromMonth && day >= fromDay) ||
      (month === toMonth && day <= toDay)
    ) {
      return sign;
    }
  }
  return null; // should be unreachable given the ranges above cover the full year
}

function getAge(birthdate, today = new Date()) {
  const birth = new Date(birthdate);
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  return age;
}

function publicBirthInfo(birthdate) {
  if (!birthdate) return { age: null, zodiac: null };
  const birth = new Date(birthdate);
  return {
    age: getAge(birthdate),
    zodiac: getZodiac(birth.getMonth() + 1, birth.getDate()),
  };
}

module.exports = { publicBirthInfo, getAge, getZodiac };
