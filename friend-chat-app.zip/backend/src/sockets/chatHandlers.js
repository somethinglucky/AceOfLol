const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const db = require('../db/connection');

// Looks up the display info a chat bubble needs for whoever sent a message —
// nickname, handle, avatar, registration status. This is what makes the
// frontend able to tell registered users (show their photo) apart from
// guests (show a color swatch instead), rather than every message just
// carrying a bare user_id with nothing to render.
function getSenderInfo(userId) {
  return db
    .prepare(
      `SELECT u.public_handle AS handle, u.is_registered AS isRegistered,
              p.nickname, p.avatar_url AS avatarUrl
       FROM users u JOIN profiles p ON p.user_id = u.id
       WHERE u.id = ?`
    )
    .get(userId);
}

module.exports = function registerChatHandlers(io, socket) {
  let userId = null; // stays null for a visitor who hasn't sent a message yet

  socket.on('authenticate', (token) => {
    try {
      const payload = jwt.verify(token, process.env.JWT_SECRET);
      userId = payload.sub;
      socket.emit('authenticated');
    } catch {
      socket.emit('auth_error', 'Invalid token');
    }
  });

  socket.on('join_room', (roomId) => {
    const room = db.prepare('SELECT requires_registration FROM rooms WHERE id = ?').get(roomId);
    if (!room) {
      return socket.emit('room_error', 'Room not found');
    }

    if (room.requires_registration) {
      if (!userId) {
        return socket.emit('room_error', 'Please register to join this room');
      }
      const user = db.prepare('SELECT is_registered FROM users WHERE id = ?').get(userId);
      if (!user || !user.is_registered) {
        return socket.emit('room_error', 'Please register to join this room');
      }
    }

    socket.join(roomId);
    if (userId) socket.to(roomId).emit('user_joined', { userId });

    // Send recent history to the JOINING socket only (not broadcast to the
    // room) — this is what makes switching from the landing preview into
    // the full chat page (or just refreshing) not lose messages that
    // already happened before this socket connected. Each message is
    // enriched with sender info at read time, so a nickname change or a
    // new avatar shows up correctly even on old messages.
    const rawHistory = db
      .prepare(
        `SELECT id, room_id, user_id, content, created_at FROM messages
         WHERE room_id = ? ORDER BY created_at ASC LIMIT 50`
      )
      .all(roomId);
    const history = rawHistory.map((m) => ({ ...m, sender: getSenderInfo(m.user_id) }));
    socket.emit('room_history', { roomId, messages: history });
  });

  socket.on('send_message', ({ roomId, content }) => {
    if (!userId) return socket.emit('auth_error', 'Not authenticated yet');
    if (!content || !content.trim()) return;

    const room = db.prepare('SELECT requires_registration FROM rooms WHERE id = ?').get(roomId);
    if (!room) return socket.emit('room_error', 'Room not found');

    if (room.requires_registration) {
      const user = db.prepare('SELECT is_registered FROM users WHERE id = ?').get(userId);
      if (!user || !user.is_registered) {
        return socket.emit('room_error', 'Please register to post in this room');
      }
    }

    const message = {
      id: crypto.randomUUID(),
      room_id: roomId,
      user_id: userId,
      content: content.trim(),
      created_at: new Date().toISOString(),
    };

    db.prepare(
      `INSERT INTO messages (id, room_id, user_id, content, created_at) VALUES (?, ?, ?, ?, ?)`
    ).run(message.id, message.room_id, message.user_id, message.content, message.created_at);

    io.to(roomId).emit('new_message', { ...message, sender: getSenderInfo(userId) });
  });

  socket.on('leave_room', (roomId) => {
    socket.leave(roomId);
    if (userId) socket.to(roomId).emit('user_left', { userId });
  });
};
