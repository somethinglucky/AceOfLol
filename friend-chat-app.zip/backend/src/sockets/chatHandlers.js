const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const db = require('../db/connection');

module.exports = function registerChatHandlers(io, socket) {
  let userId = null; // stays null for a visitor who hasn't sent a message yet

  socket.on('authenticate', (token) => {
    try {
      const payload = jwt.verify(token, process.env.JWT_SECRET);
      userId = payload.sub;
      socket.emit('authenticated');
    } catch {
      socket.emit('auth_error', 'Invalid token');
    }
  });

  socket.on('join_room', (roomId) => {
    const room = db.prepare('SELECT requires_registration FROM rooms WHERE id = ?').get(roomId);
    if (!room) {
      return socket.emit('room_error', 'Room not found');
    }

    // Rooms that require registration need an authenticated, registered
    // user. Open rooms (like #everyone) can be joined — even just to watch
    // — by anyone, including someone with no identity at all yet.
    if (room.requires_registration) {
      if (!userId) {
        return socket.emit('room_error', 'Please register to join this room');
      }
      const user = db.prepare('SELECT is_registered FROM users WHERE id = ?').get(userId);
      if (!user || !user.is_registered) {
        return socket.emit('room_error', 'Please register to join this room');
      }
    }

    socket.join(roomId);
    if (userId) socket.to(roomId).emit('user_joined', { userId });
  });

  socket.on('send_message', ({ roomId, content }) => {
    // A visitor with no identity yet can't send — the frontend is
    // responsible for calling POST /auth/guest and authenticating the
    // socket BEFORE emitting this, the moment they first hit Send.
    if (!userId) return socket.emit('auth_error', 'Not authenticated yet');
    if (!content || !content.trim()) return;

    const room = db.prepare('SELECT requires_registration FROM rooms WHERE id = ?').get(roomId);
    if (!room) return socket.emit('room_error', 'Room not found');

    if (room.requires_registration) {
      const user = db.prepare('SELECT is_registered FROM users WHERE id = ?').get(userId);
      if (!user || !user.is_registered) {
        return socket.emit('room_error', 'Please register to post in this room');
      }
    }

    const message = {
      id: crypto.randomUUID(),
      room_id: roomId,
      user_id: userId,
      content: content.trim(),
      created_at: new Date().toISOString(),
    };

    db.prepare(
      `INSERT INTO messages (id, room_id, user_id, content, created_at) VALUES (?, ?, ?, ?, ?)`
    ).run(message.id, message.room_id, message.user_id, message.content, message.created_at);

    io.to(roomId).emit('new_message', message);
  });

  socket.on('leave_room', (roomId) => {
    socket.leave(roomId);
    if (userId) socket.to(roomId).emit('user_left', { userId });
  });
};
