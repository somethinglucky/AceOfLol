const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const db = require('../db/connection');

// This is intentionally minimal — just enough for "join a room, send/receive
// messages" to work end-to-end, matching step 2 of the build order. Presence,
// typing indicators, and moderation events can be added here later without
// touching server.js.
module.exports = function registerChatHandlers(io, socket) {
  let userId = null;

  // Client sends the JWT once after connecting, e.g.:
  //   socket.emit('authenticate', token)
  socket.on('authenticate', (token) => {
    try {
      const payload = jwt.verify(token, process.env.JWT_SECRET);
      userId = payload.sub;
      socket.emit('authenticated');
    } catch {
      socket.emit('auth_error', 'Invalid token');
    }
  });

  socket.on('join_room', (roomId) => {
    if (!userId) return socket.emit('auth_error', 'Authenticate first');
    socket.join(roomId);
    socket.to(roomId).emit('user_joined', { userId });
  });

  socket.on('send_message', ({ roomId, content }) => {
    if (!userId) return socket.emit('auth_error', 'Authenticate first');
    if (!content || !content.trim()) return;

    const message = {
      id: crypto.randomUUID(),
      room_id: roomId,
      user_id: userId,
      content: content.trim(),
      created_at: new Date().toISOString(),
    };

    db.prepare(
      `INSERT INTO messages (id, room_id, user_id, content, created_at) VALUES (?, ?, ?, ?, ?)`
    ).run(message.id, message.room_id, message.user_id, message.content, message.created_at);

    // Broadcast to everyone in the room, including the sender, so the UI
    // stays a single source of truth (the socket event) rather than the
    // sender optimistically rendering its own message differently.
    io.to(roomId).emit('new_message', message);
  });

  socket.on('leave_room', (roomId) => {
    socket.leave(roomId);
    socket.to(roomId).emit('user_left', { userId });
  });
};
