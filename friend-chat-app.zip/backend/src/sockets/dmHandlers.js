const jwt = require('jsonwebtoken');
const db = require('../db/connection');

function canonicalPair(idA, idB) {
  return idA < idB ? [idA, idB] : [idB, idA];
}

function pairRoom(idA, idB) {
  const [a, b] = canonicalPair(idA, idB);
  return `dm:${a}:${b}`;
}

function findThread(userA, userB) {
  const [a, b] = canonicalPair(userA, userB);
  return db.prepare('SELECT * FROM dm_threads WHERE user_a_id = ? AND user_b_id = ?').get(a, b);
}

function isBlockedEitherWay(userA, userB) {
  return !!db
    .prepare('SELECT 1 FROM blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?)')
    .get(userA, userB, userB, userA);
}

function getUserSummary(userId) {
  return db
    .prepare(
      `SELECT u.id, u.public_handle AS handle, u.is_registered AS isRegistered,
              p.nickname, p.avatar_url AS avatarUrl
       FROM users u JOIN profiles p ON p.user_id = u.id
       WHERE u.id = ?`
    )
    .get(userId);
}

module.exports = function registerDmHandlers(io, socket) {
  // Reuses whatever `authenticate` already set on this socket in
  // chatHandlers.js — both handlers listen for the same event, and
  // Socket.IO fires every listener bound to it. This one only adds the
  // personal room join; chatHandlers.js still owns setting `userId` itself,
  // so this handler tracks its own copy the same way.
  let userId = null;

  socket.on('authenticate', (token) => {
    try {
      const payload = jwt.verify(token, process.env.JWT_SECRET);
      userId = payload.sub;
      // A personal room, independent of any specific DM thread — this is
      // what lets the inbox (or an unread badge) update live even when
      // the person isn't currently looking at the thread a message just
      // arrived in.
      socket.join(`user:${userId}`);
    } catch {
      // chatHandlers.js already emits auth_error for this same failure —
      // nothing further to do here.
    }
  });

  // otherUserId, not a thread id — the thread may not exist yet (no
  // messages sent between these two people so far), and the caller has no
  // way to know a thread id for a conversation that hasn't started.
  socket.on('join_dm_thread', (otherUserId) => {
    if (!userId) return socket.emit('dm_error', 'Not authenticated yet');
    if (otherUserId === userId) return socket.emit('dm_error', 'Invalid conversation');

    // Join immediately, regardless of whether a thread row exists yet —
    // the room is keyed by the user pair, not the thread's db id, so both
    // participants can be listening for the very first message before it
    // creates any row at all.
    socket.join(pairRoom(userId, otherUserId));

    const thread = findThread(userId, otherUserId);
    if (!thread) {
      return socket.emit('dm_thread_history', { otherUserId, thread: null, messages: [] });
    }

    // Mark the other person's messages as read now that this thread is
    // actually open, and tell their sockets so a "seen" state (or just an
    // unread badge going away) can update live on their side too.
    db.prepare(
      "UPDATE dm_messages SET read_at = datetime('now') WHERE thread_id = ? AND sender_id = ? AND read_at IS NULL"
    ).run(thread.id, otherUserId);
    io.to(`user:${otherUserId}`).emit('dm_thread_read', { threadId: thread.id, readBy: userId });

    const messages = db
      .prepare('SELECT id, sender_id, body, created_at, read_at FROM dm_messages WHERE thread_id = ? ORDER BY created_at ASC')
      .all(thread.id);

    socket.emit('dm_thread_history', { otherUserId, thread: { id: thread.id }, messages });
  });

  socket.on('leave_dm_thread', (otherUserId) => {
    if (otherUserId) socket.leave(pairRoom(userId, otherUserId));
  });

  socket.on('send_dm_message', ({ otherUserId, body }) => {
    if (!userId) return socket.emit('dm_error', 'Not authenticated yet');
    if (!body || !body.trim()) return;
    if (otherUserId === userId) return socket.emit('dm_error', 'Invalid conversation');

    const sender = db.prepare('SELECT is_registered FROM users WHERE id = ?').get(userId);
    if (!sender || !sender.is_registered) {
      return socket.emit('dm_error', 'Only registered users can send messages');
    }
    if (!db.prepare('SELECT 1 FROM users WHERE id = ?').get(otherUserId)) {
      return socket.emit('dm_error', 'User not found');
    }
    if (isBlockedEitherWay(userId, otherUserId)) {
      return socket.emit('dm_error', "You can't message this person");
    }

    const [a, b] = canonicalPair(userId, otherUserId);
    const upsertThread = db.transaction(() => {
      db.prepare(
        `INSERT INTO dm_threads (user_a_id, user_b_id) VALUES (?, ?)
         ON CONFLICT (user_a_id, user_b_id) DO UPDATE SET last_message_at = datetime('now')`
      ).run(a, b);
      return db.prepare('SELECT id FROM dm_threads WHERE user_a_id = ? AND user_b_id = ?').get(a, b);
    });
    const thread = upsertThread();

    const info = db
      .prepare('INSERT INTO dm_messages (thread_id, sender_id, body) VALUES (?, ?, ?)')
      .run(thread.id, userId, body.trim());

    const message = db
      .prepare('SELECT id, sender_id, body, created_at, read_at FROM dm_messages WHERE id = ?')
      .get(info.lastInsertRowid);

    // Everyone in this conversation is already in the pair room from
    // join_dm_thread, regardless of whether this is the very first message
    // (which is what creates the thread row) or the hundredth.
    io.to(pairRoom(userId, otherUserId)).emit('new_dm_message', { threadId: thread.id, message });

    // Lightweight nudge for the recipient's inbox/badge, independent of
    // whether they currently have this specific thread open.
    io.to(`user:${otherUserId}`).emit('dm_inbox_update', {
      threadId: thread.id,
      otherUser: getUserSummary(userId),
      message,
    });
  });
};
