// ============================================================
// Tiny bridge so plain REST routes can still reach the Socket.IO
// instance — set once in server.js right after `io` is created. Used by:
// - routes/gameSessions.js, to push a lightweight "something changed,
//   refetch" nudge after a move (never broadcasts raw state itself,
//   since a module's renderState() hides different things from different
//   players — see notifySessionUpdate below).
// - routes/gameInvites.js (via services/dmMessages.js), to push the same
//   live dm_inbox_update/new_dm_message events a socket-sent DM would,
//   for a system-generated invite notification.
// ============================================================

let io = null;

function setIo(instance) {
  io = instance;
}

function getIo() {
  return io;
}

function notifySessionUpdate(sessionId) {
  if (io) io.to(`game:${sessionId}`).emit('game_state_update', { sessionId });
}

// Tells whoever's still sitting on the OLD (completed) session's result
// screen that the other player also wants a rematch and it's ready — see
// games/sessionEngine.js's requestRematch. Sent to the old session's
// room (both players are still in it via the chat overlay's socket join,
// even though the game itself is over) since that's the only channel
// available to reach someone who isn't the one making this request.
function notifyRematchReady(oldSessionId, newSessionId) {
  if (io) io.to(`game:${oldSessionId}`).emit('rematch_ready', { oldSessionId, newSessionId });
}

module.exports = { setIo, getIo, notifySessionUpdate, notifyRematchReady };
