// ============================================================
// Tiny bridge so plain REST routes (game moves happen over REST, not a
// socket event — see routes/gameSessions.js) can still push a lightweight
// "something changed, refetch" nudge to anyone watching a session. Kept
// deliberately dumb: it never broadcasts game state itself (that's always
// re-fetched and re-sanitized per-viewer via GET /api/game-sessions/:id,
// since a module's renderState() hides different things from different
// players — broadcasting raw state over a socket would leak that).
// ============================================================

let io = null;

function setIo(instance) {
  io = instance;
}

function notifySessionUpdate(sessionId) {
  if (io) io.to(`game:${sessionId}`).emit('game_state_update', { sessionId });
}

module.exports = { setIo, notifySessionUpdate };
