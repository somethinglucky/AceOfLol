// ============================================================
// Tiny bridge so plain REST routes can still reach the Socket.IO
// instance — set once in server.js right after `io` is created. Used by:
// - routes/gameSessions.js, to push a lightweight "something changed,
//   refetch" nudge after a move (never broadcasts raw state itself,
//   since a module's renderState() hides different things from different
//   players — see notifySessionUpdate below).
// - routes/gameInvites.js (via services/dmMessages.js), to push the same
//   live dm_inbox_update/new_dm_message events a socket-sent DM would,
//   for a system-generated invite notification.
// ============================================================

let io = null;

function setIo(instance) {
  io = instance;
}

function getIo() {
  return io;
}

function notifySessionUpdate(sessionId) {
  if (io) io.to(`game:${sessionId}`).emit('game_state_update', { sessionId });
}

module.exports = { setIo, getIo, notifySessionUpdate };
