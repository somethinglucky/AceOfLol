// ============================================================
// In-game chat overlay (Games spec §9) — a Shell-level socket feature so
// every game module gets it for free, same pattern as dmHandlers.js.
// Deliberately NOT persisted to a table: this is a lightweight per-session
// overlay, not a record either player would expect to revisit after the
// game ends (unlike DMs). If that turns out to be wanted later, this is
// the one place to add a game_session_messages table + a history fetch.
// ============================================================

const jwt = require('jsonwebtoken');
const db = require('../db/connection');

function isSeatedPlayer(sessionId, userId) {
  return !!db
    .prepare('SELECT 1 FROM game_session_players WHERE session_id = ? AND user_id = ?')
    .get(sessionId, userId);
}

module.exports = function registerGameChatHandlers(io, socket) {
  // Reuses the same 'authenticate' event chatHandlers.js/dmHandlers.js
  // already listen for — Socket.IO fires every bound listener.
  let userId = null;
  socket.on('authenticate', (token) => {
    try {
      userId = jwt.verify(token, process.env.JWT_SECRET).sub;
    } catch {
      // chatHandlers.js already emits auth_error for this — nothing more to do.
    }
  });

  socket.on('join_game_session', (sessionId) => {
    if (!userId) return socket.emit('game_chat_error', 'Not authenticated yet');
    if (!isSeatedPlayer(sessionId, userId)) return socket.emit('game_chat_error', "You're not seated in this game");
    socket.join(`game:${sessionId}`);
  });

  socket.on('leave_game_session', (sessionId) => {
    if (sessionId) socket.leave(`game:${sessionId}`);
  });

  socket.on('send_game_message', ({ sessionId, body }) => {
    if (!userId) return socket.emit('game_chat_error', 'Not authenticated yet');
    if (!body || !body.trim()) return;
    if (!isSeatedPlayer(sessionId, userId)) return socket.emit('game_chat_error', "You're not seated in this game");

    io.to(`game:${sessionId}`).emit('new_game_message', {
      sessionId,
      senderId: userId,
      body: body.trim(),
      createdAt: new Date().toISOString(),
    });
  });
};
