// ============================================================
// In-game chat overlay (Games spec §9) — a Shell-level socket feature so
// every game module gets it for free, same pattern as dmHandlers.js.
// Deliberately NOT persisted to a table: this is a lightweight per-session
// overlay, not a record either player would expect to revisit after the
// game ends (unlike DMs). If that turns out to be wanted later, this is
// the one place to add a game_session_messages table + a history fetch.
// ============================================================

// ============================================================
// In-game chat overlay (Games spec §9) — a Shell-level socket feature so
// every game module gets it for free, same pattern as dmHandlers.js.
// Persisted to game_session_messages (migration 010) and replayed on
// join_game_session, mirroring exactly how dmHandlers.js replays
// dm_messages history on join_dm_thread — without this, any message sent
// while the recipient's socket was transiently disconnected (a
// backgrounded phone, a network blip, or just switching between two
// devices to test) was lost forever with no way to ever see it. That was
// the actual root cause of a "messages from the other player never show
// up" report — confirmed from live pm2 logs showing repeated
// authenticate/rejoin cycles for the same userId (i.e. reconnects)
// between messages, which room membership alone can't survive.
// ============================================================

const jwt = require('jsonwebtoken');
const db = require('../db/connection');

// TEMPORARY diagnostic logging — every decision point in the join/send
// path logs to the server console with the socket id. Safe to strip out
// once the in-game chat bug is confirmed fixed; kept for now since it's
// what surfaced the real root cause above.
function log(...args) {
  console.log('[gameChat]', ...args);
}

function isSeatedPlayer(sessionId, userId) {
  const row = db
    .prepare('SELECT 1 FROM game_session_players WHERE session_id = ? AND user_id = ?')
    .get(sessionId, userId);
  return !!row;
}

module.exports = function registerGameChatHandlers(io, socket) {
  // Reuses the same 'authenticate' event chatHandlers.js/dmHandlers.js
  // already listen for — Socket.IO fires every bound listener.
  let userId = null;
  socket.on('authenticate', (token) => {
    try {
      userId = jwt.verify(token, process.env.JWT_SECRET).sub;
      log(`socket ${socket.id} authenticated as userId=${userId}`);
    } catch (err) {
      log(`socket ${socket.id} FAILED to authenticate:`, err.message);
      // chatHandlers.js already emits auth_error for this — nothing more to do.
    }
  });

  socket.on('join_game_session', (sessionId) => {
    log(`socket ${socket.id} (userId=${userId}) requesting join_game_session sessionId=${sessionId}`);
    if (!userId) {
      log(`  -> REJECTED: not authenticated yet`);
      return socket.emit('game_chat_error', 'Not authenticated yet');
    }
    const seated = isSeatedPlayer(sessionId, userId);
    if (!seated) {
      log(`  -> REJECTED: userId=${userId} is not a row in game_session_players for sessionId=${sessionId}`);
      return socket.emit('game_chat_error', "You're not seated in this game");
    }
    socket.join(`game:${sessionId}`);
    const room = io.sockets.adapter.rooms.get(`game:${sessionId}`);
    log(`  -> JOINED. Room game:${sessionId} now has sockets: [${room ? [...room].join(', ') : ''}]`);

    // Replay full history immediately, same as dmHandlers.js's
    // dm_thread_history on join_dm_thread — this is what makes a
    // reconnect (not just the very first join) safe: whatever this
    // player missed while disconnected, they see the instant they're
    // back, instead of it being gone forever.
    const messages = db
      .prepare('SELECT sender_id AS senderId, body, created_at AS createdAt FROM game_session_messages WHERE session_id = ? ORDER BY created_at ASC')
      .all(sessionId);
    socket.emit('game_chat_history', { sessionId, messages });
  });

  socket.on('leave_game_session', (sessionId) => {
    if (sessionId) socket.leave(`game:${sessionId}`);
  });

  socket.on('send_game_message', ({ sessionId, body }) => {
    log(`socket ${socket.id} (userId=${userId}) sending to sessionId=${sessionId}: "${body}"`);
    if (!userId) {
      log(`  -> REJECTED: not authenticated yet`);
      return socket.emit('game_chat_error', 'Not authenticated yet');
    }
    const trimmed = body && body.trim();
    if (!trimmed) return;
    if (!isSeatedPlayer(sessionId, userId)) {
      log(`  -> REJECTED: userId=${userId} is not a row in game_session_players for sessionId=${sessionId}`);
      return socket.emit('game_chat_error', "You're not seated in this game");
    }

    const createdAt = new Date().toISOString();
    db.prepare('INSERT INTO game_session_messages (session_id, sender_id, body, created_at) VALUES (?, ?, ?, ?)').run(
      sessionId,
      userId,
      trimmed,
      createdAt
    );

    const room = io.sockets.adapter.rooms.get(`game:${sessionId}`);
    log(`  -> BROADCASTING to room game:${sessionId}, current members: [${room ? [...room].join(', ') : '(empty/none)'}] (message is saved regardless, so a disconnected member still sees it on reconnect)`);

    io.to(`game:${sessionId}`).emit('new_game_message', {
      sessionId,
      senderId: userId,
      body: trimmed,
      createdAt,
    });
  });
};
