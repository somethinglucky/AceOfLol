// ============================================================
// Gems wallet helper. This is deliberately the ONLY place that writes to
// gem_wallets — every credit/debit goes through here so the wallet balance
// and the gem_transactions ledger can never drift apart, and so there's
// exactly one place to audit for "how can a gem balance change at all."
//
// There is intentionally no debitToFiat() / cashOut() function anywhere in
// this file, or this codebase. Gems are non-redeemable — that's enforced by
// the absence of the code path, not a check inside one.
// ============================================================

const db = require('../db/connection');

const VALID_REASONS = new Set([
  'stripe_purchase', 'treasure_chest', 'job_payout', 'store_spend',
  'p2p_trade', 'buyback', 'gift_sent', 'gift_received', 'admin_adjustment',
]);

function getBalance(userId) {
  const row = db.prepare('SELECT balance FROM gem_wallets WHERE user_id = ?').get(userId);
  return row ? row.balance : 0;
}

// Adds `amount` gems (positive = credit, negative = debit) to userId's
// wallet and records the ledger row, atomically. Throws if a debit would
// take the balance below zero (the wallet's CHECK (balance >= 0) is the
// backstop, but we check first to give a clean error instead of a raw
// SQLite constraint failure).
const _adjust = db.transaction((userId, amount, reason, refId, note) => {
  if (!VALID_REASONS.has(reason)) {
    throw new Error(`Invalid gem_transactions reason: ${reason}`);
  }
  if (!Number.isInteger(amount) || amount === 0) {
    throw new Error('amount must be a non-zero integer');
  }

  db.prepare('INSERT OR IGNORE INTO gem_wallets (user_id, balance) VALUES (?, 0)').run(userId);

  const current = getBalance(userId);
  if (current + amount < 0) {
    throw new Error('Insufficient gem balance.');
  }

  db.prepare('UPDATE gem_wallets SET balance = balance + ?, updated_at = datetime(\'now\') WHERE user_id = ?')
    .run(amount, userId);
  db.prepare(
    'INSERT INTO gem_transactions (user_id, amount, reason, ref_id, note) VALUES (?, ?, ?, ?, ?)'
  ).run(userId, amount, reason, refId || null, note || null);

  return getBalance(userId);
});

function credit(userId, amount, reason, refId, note) {
  if (amount <= 0) throw new Error('credit() amount must be positive — use debit() to remove gems');
  return _adjust(userId, amount, reason, refId, note);
}

function debit(userId, amount, reason, refId, note) {
  if (amount <= 0) throw new Error('debit() amount must be positive — it is subtracted internally');
  return _adjust(userId, -amount, reason, refId, note);
}

module.exports = { getBalance, credit, debit };
