// ============================================================
// Sends a DM programmatically from a REST route (not a live socket
// event) — used for system-generated notifications like a game invite.
// Mirrors sockets/dmHandlers.js's send_dm_message handler exactly (same
// thread upsert, same two socket events) so a message sent this way is
// indistinguishable to the recipient's client from one typed by hand —
// it shows up in their DM inbox, counts toward their unread badge, and
// gets marked read the same way once they open the thread.
// ============================================================

const db = require('../db/connection');

function canonicalPair(idA, idB) {
  return idA < idB ? [idA, idB] : [idB, idA];
}

function pairRoom(idA, idB) {
  const [a, b] = canonicalPair(idA, idB);
  return `dm:${a}:${b}`;
}

function getUserSummary(userId) {
  return db
    .prepare(
      `SELECT u.id, u.public_handle AS handle, u.is_registered AS isRegistered,
              p.nickname, p.avatar_url AS avatarUrl
       FROM users u JOIN profiles p ON p.user_id = u.id WHERE u.id = ?`
    )
    .get(userId);
}

// io may be null (e.g. sockets not wired up in some test context) — the
// message still gets persisted either way, it just won't push live.
// options.kind/options.metadata let a system message carry structured
// data (e.g. { kind: 'game_invite', metadata: { gameId, inviteId } }) so
// the client can render it as a tappable card instead of plain text —
// see DMsPage.jsx's message rendering. Omit both for an ordinary message.
function sendDirectMessage(io, fromUserId, toUserId, body, options = {}) {
  const { kind = 'text', metadata = null } = options;
  const [a, b] = canonicalPair(fromUserId, toUserId);
  const upsertThread = db.transaction(() => {
    db.prepare(
      `INSERT INTO dm_threads (user_a_id, user_b_id) VALUES (?, ?)
       ON CONFLICT (user_a_id, user_b_id) DO UPDATE SET last_message_at = datetime('now')`
    ).run(a, b);
    return db.prepare('SELECT id FROM dm_threads WHERE user_a_id = ? AND user_b_id = ?').get(a, b);
  });
  const thread = upsertThread();

  const info = db
    .prepare('INSERT INTO dm_messages (thread_id, sender_id, body, kind, metadata_json) VALUES (?, ?, ?, ?, ?)')
    .run(thread.id, fromUserId, body, kind, metadata ? JSON.stringify(metadata) : null);

  const message = db
    .prepare('SELECT id, sender_id, body, created_at, read_at, kind, metadata_json AS metadataJson FROM dm_messages WHERE id = ?')
    .get(info.lastInsertRowid);

  if (io) {
    io.to(pairRoom(fromUserId, toUserId)).emit('new_dm_message', { threadId: thread.id, message });
    io.to(`user:${toUserId}`).emit('dm_inbox_update', {
      threadId: thread.id,
      otherUser: getUserSummary(fromUserId),
      message,
    });
  }

  return { threadId: thread.id, message };
}

module.exports = { sendDirectMessage, _testExports: { canonicalPair } };
