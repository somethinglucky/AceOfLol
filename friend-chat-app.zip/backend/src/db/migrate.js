const fs = require('fs');
const path = require('path');

const MIGRATIONS_DIR = path.join(__dirname, 'migrations');

// Only files named like "002_add_follows.sql" are treated as migrations —
// this is what lets a README.md or other notes live in the same folder
// without accidentally being picked up and executed.
const MIGRATION_FILENAME = /^\d+_.*\.sql$/;

// Runs every migration in migrations/ that hasn't been applied yet, in
// filename order (hence the zero-padded numeric prefix convention — keep
// numbers at least 3 digits so 010 sorts after 009, not after 001).
//
// Each migration runs inside its own transaction: if a migration throws
// partway through, that migration's changes are rolled back and it stays
// unapplied so it's safe to fix the .sql file and restart, but any
// migrations that already succeeded before it stay applied.
function runMigrations(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      name       TEXT PRIMARY KEY,
      applied_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  const already = new Set(
    db.prepare('SELECT name FROM schema_migrations').all().map((r) => r.name)
  );

  const pending = fs
    .readdirSync(MIGRATIONS_DIR)
    .filter((f) => MIGRATION_FILENAME.test(f))
    .sort()
    .filter((f) => !already.has(f));

  if (pending.length === 0) return;

  const recordApplied = db.prepare('INSERT INTO schema_migrations (name) VALUES (?)');

  for (const file of pending) {
    const sql = fs.readFileSync(path.join(MIGRATIONS_DIR, file), 'utf8');
    console.log(`[migrate] applying ${file}`);

    const applyOne = db.transaction(() => {
      db.exec(sql);
      recordApplied.run(file);
    });
    applyOne();
  }
}

module.exports = { runMigrations, MIGRATIONS_DIR };
