const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');

// SQLite file lives next to the code by default — override with DB_PATH in .env
// if you want it somewhere else (e.g. a mounted volume).
const dbPath = process.env.DB_PATH || path.join(__dirname, '../../data/app.db');

// Make sure the containing folder exists (matters on a fresh droplet).
fs.mkdirSync(path.dirname(dbPath), { recursive: true });

const db = new Database(dbPath);

// Sensible defaults for a small single-server app:
db.pragma('journal_mode = WAL');   // lets reads and writes happen concurrently
db.pragma('foreign_keys = ON');    // enforce the REFERENCES constraints in schema.sql

// Run schema.sql on every startup — every statement uses CREATE TABLE IF NOT EXISTS,
// so this is safe to re-run and means you never forget to migrate a fresh droplet.
const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
db.exec(schema);

module.exports = db;
