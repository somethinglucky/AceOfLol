const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');
const { runMigrations } = require('./migrate');

// SQLite file lives next to the code by default — override with DB_PATH in .env
// if you want it somewhere else (e.g. a mounted volume).
const dbPath = process.env.DB_PATH || path.join(__dirname, '../../data/app.db');

// Make sure the containing folder exists (matters on a fresh droplet).
fs.mkdirSync(path.dirname(dbPath), { recursive: true });

const db = new Database(dbPath);

// Sensible defaults for a small single-server app:
db.pragma('journal_mode = WAL');   // lets reads and writes happen concurrently
db.pragma('foreign_keys = ON');    // enforce the REFERENCES constraints in schema.sql

// Run any not-yet-applied migration in ./migrations, in order, and record it —
// see migrations/README.md. This replaces re-running one big schema.sql on
// every startup; a fresh droplet gets everything via 001_baseline.sql, and an
// existing one only ever picks up what's genuinely new.
runMigrations(db);

module.exports = db;
