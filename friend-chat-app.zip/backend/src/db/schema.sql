-- Friend Chat App — SQLite schema
-- Run once at startup (connection.js handles this automatically if tables don't exist)

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  public_handle TEXT UNIQUE NOT NULL,   -- immutable, auto-generated, e.g. "63ua1i"
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  is_premium INTEGER NOT NULL DEFAULT 0,
  premium_expires_at TEXT
);

CREATE TABLE IF NOT EXISTS profiles (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  nickname TEXT NOT NULL,               -- user-chosen, not unique, editable anytime
  bio TEXT,
  birthdate TEXT,
  avatar_url TEXT,
  theme_color TEXT DEFAULT '#007AFF',
  theme_font TEXT DEFAULT 'system',
  theme_icon_set TEXT DEFAULT 'default',
  location_country TEXT,
  location_city TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS profile_attributes (
  profile_id TEXT PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  height_cm INTEGER,
  body_type TEXT CHECK (body_type IN ('skinny','fit','average','curvy','overweight','other')),
  hair_color TEXT CHECK (hair_color IN ('black','brown','blonde','red','gray','other')),
  eye_color TEXT CHECK (eye_color IN ('brown','blue','green','hazel','gray','other')),
  relationship_intent TEXT CHECK (relationship_intent IN ('platonic','romantic','either')),
  pets TEXT,                             -- JSON array from: dogs,cats,birds,farm_animals,reptiles,other
  political_view TEXT CHECK (political_view IN ('conservative','liberal','central','apolitical','other')),
  religion TEXT CHECK (religion IN (
    'atheist','agnostic','undecided','spiritual','christian','muslim','jewish','buddhist','zen',
    'hinduism','jainism','sikhism','daoist','confucianism','zoroastrianism','shinto','pagan',
    'witch','wicca','jedi','generally_for_evil','generally_for_beneficial','other'
  )),
  smoking TEXT CHECK (smoking IN ('never','sometimes','often')),
  diet TEXT CHECK (diet IN ('omnivore','vegan','pescatarian','fruitarian','other')),
  activity_level TEXT CHECK (activity_level IN ('very_active','somewhat_active','sedentary')),
  orientation TEXT CHECK (orientation IN ('gay','bi','straight','asexual','other')),
  has_kids TEXT CHECK (has_kids IN ('has_kids','no_kids','plans_kids')),
  education_level TEXT,
  occupation TEXT
);

-- Mirrors profile_attributes, but describes the RANGE of people the user wants to meet.
CREATE TABLE IF NOT EXISTS profile_preferences (
  profile_id TEXT PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  height_min_cm INTEGER,
  height_max_cm INTEGER,
  body_type_accepted TEXT,               -- JSON array, multi-select
  relationship_intent_accepted TEXT,
  pets_accepted TEXT,
  political_view_accepted TEXT,
  religion_accepted TEXT,
  smoking_accepted TEXT,
  diet_accepted TEXT,
  activity_level_accepted TEXT,
  orientation_accepted TEXT,
  has_kids_accepted TEXT,
  education_level_accepted TEXT
);

CREATE TABLE IF NOT EXISTS interests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL              -- lowercased, e.g. "hiking", "bird watching"
);
CREATE INDEX IF NOT EXISTS idx_interests_name ON interests(name);

CREATE TABLE IF NOT EXISTS profile_interests (
  profile_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  interest_id INTEGER NOT NULL REFERENCES interests(id) ON DELETE CASCADE,
  PRIMARY KEY (profile_id, interest_id)
);

CREATE TABLE IF NOT EXISTS rooms (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  topic_tag TEXT,
  is_public INTEGER NOT NULL DEFAULT 1,
  created_by TEXT REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  member_count INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS room_memberships (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id TEXT NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  joined_at TEXT NOT NULL DEFAULT (datetime('now')),
  role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('member','moderator','owner')),
  UNIQUE(room_id, user_id)
);

CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,                   -- ULID, generated in app code for sortable pagination
  room_id TEXT NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_messages_room_created ON messages(room_id, created_at);

CREATE TABLE IF NOT EXISTS swipes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  swiper_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  target_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  direction TEXT NOT NULL CHECK (direction IN ('like','pass')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(swiper_user_id, target_user_id)
);

CREATE TABLE IF NOT EXISTS matches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_a_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  user_b_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(user_a_id, user_b_id)
);

CREATE TABLE IF NOT EXISTS subscriptions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  stripe_customer_id TEXT,
  stripe_subscription_id TEXT,
  status TEXT CHECK (status IN ('active','canceled','past_due')),
  current_period_end TEXT
);
