-- Migration 011 — lets a DM message be more than plain text: a
-- system-generated game-invite notification (services/dmMessages.js)
-- can now carry a `kind` and small JSON payload so the client renders it
-- as a tappable card linking straight into the right game, instead of a
-- plain sentence the person has to manually act on by navigating there
-- themselves. Existing INSERT statements that don't mention these columns
-- (every hand-typed message, via dmHandlers.js) are unaffected — they
-- fall through to the defaults below, so this is fully backward
-- compatible with every DM sent before this migration.
ALTER TABLE dm_messages ADD COLUMN kind TEXT NOT NULL DEFAULT 'text';
ALTER TABLE dm_messages ADD COLUMN metadata_json TEXT;
