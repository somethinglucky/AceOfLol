-- Migration 012 — invitation "presentation" layer: the inviter picks a
-- card design at creation time, and the invitee gets a one-time reveal
-- moment before landing in the game itself (not on every visit — once
-- the envelope's opened, it stays open).
--
-- template_id is just a slug for now — see frontend/src/data/
-- inviteTemplates.js for the actual designs, which are CSS-rendered
-- placeholders until sj supplies real artwork. Swapping in real images
-- later only touches that one file, nothing here.
ALTER TABLE game_invites ADD COLUMN template_id TEXT NOT NULL DEFAULT 'classic';

-- Per-seat, not per-session: only the invitee ever gets a reveal (the
-- inviter picked the card themselves, there's nothing to surprise them
-- with), and per-seat is exactly what already distinguishes them
-- (is_first_mover) without needing a separate "which seat is the
-- invitee" lookup.
ALTER TABLE game_session_players ADD COLUMN reveal_seen_at TEXT;
