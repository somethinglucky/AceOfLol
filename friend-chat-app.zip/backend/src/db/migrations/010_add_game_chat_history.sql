-- Migration 010 — persist in-game chat messages (Games spec §9).
--
-- Reverses a design call from migration 008/gameChatHandlers.js's original
-- comment ("deliberately not persisted... a lightweight overlay, not a
-- record either player would expect to revisit"). That was wrong in
-- practice: without persistence, any message sent while the OTHER
-- player's socket happens to be transiently disconnected — a backgrounded
-- phone, a brief network blip, or just switching between two devices to
-- test — is lost forever, with no way for them to ever see it. DMs never
-- have this problem because dm_messages persists and dmHandlers.js
-- replays full history on join_dm_thread; this brings game chat in line
-- with that same, already-proven pattern.
CREATE TABLE IF NOT EXISTS game_session_messages (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id  TEXT NOT NULL REFERENCES game_sessions(id) ON DELETE CASCADE,
  sender_id   TEXT NOT NULL REFERENCES users(id),
  body        TEXT NOT NULL,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_game_session_messages_session ON game_session_messages(session_id, created_at);
