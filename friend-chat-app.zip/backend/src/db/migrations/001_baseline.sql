-- Migration 001 — baseline schema.
-- This is the exact schema that existed before the migration system was
-- introduced. Every statement uses CREATE TABLE IF NOT EXISTS, so re-running
-- it against a database that already has these tables is a safe no-op —
-- that matters because any droplet mid-flight when this shipped will already
-- have these tables and just needs this recorded as "applied", not re-created.

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  public_handle TEXT UNIQUE NOT NULL,   -- immutable, auto-generated, mixed-case e.g. "abcdEFg"
  email TEXT UNIQUE,                    -- NULL until a guest registers
  password_hash TEXT,                   -- NULL until a guest registers
  is_registered INTEGER NOT NULL DEFAULT 0,  -- 0 = guest (identified only by their handle), 1 = registered
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  is_premium INTEGER NOT NULL DEFAULT 0,
  premium_expires_at TEXT
);

CREATE TABLE IF NOT EXISTS profiles (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  nickname TEXT,                        -- NULL for guests (displayed as their handle instead); user-chosen, not unique, editable anytime once set
  bio TEXT,
  looking_for TEXT,                     -- "who I'm hoping to meet" — separate freeform field from bio
  birthdate TEXT,                       -- never shown publicly as a date; only derived age + zodiac are shown
  avatar_url TEXT,                      -- registered users' one photo; NULL for guests

  -- The VIEWER's own private app UI theme (settings screen, only visible to them).
  theme_color TEXT DEFAULT '#007AFF',
  theme_font TEXT DEFAULT 'system',
  theme_icon_set TEXT DEFAULT 'default',

  -- How THIS profile displays to other people looking at it — deliberately
  -- separate from theme_color/theme_font above, which only affects the
  -- owner's own view of the app.
  profile_display_color TEXT DEFAULT '#0a84ff',
  profile_display_font TEXT DEFAULT 'system',

  location_country TEXT,
  location_city TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Single-select (or free text) profile fields — one value each.
CREATE TABLE IF NOT EXISTS profile_attributes (
  profile_id TEXT PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  country TEXT,                          -- free text, country name only, no city/address
  commitment TEXT CHECK (commitment IN (
    'is_married','wants_marriage','doesnt_want_marriage','wants_qpr','open_to_qpr','open_to_marriage','other'
  )),
  diet TEXT CHECK (diet IN ('anything','carnivorous','vegetarian','vegan','pescatarian','flexitarian')),
  polyamory TEXT CHECK (polyamory IN (
    'in_polyamorous_relationship','open_to_polyamory','wants_polyamory','does_not_want_polyamory'
  )),
  pronouns TEXT CHECK (length(pronouns) <= 15),
  build TEXT CHECK (build IN ('thin','average','fit','athlete','curvy','overweight','bbp')),
  height_cm INTEGER,
  pets_note TEXT CHECK (length(pets_note) <= 100)  -- e.g. "have 2 cats, allergic to dogs"
);

-- Multi-select profile fields — a person can hold several values per field
-- (e.g. religion: ['buddhist','agnostic']). One shared table instead of five
-- near-identical ones, indexed on (field_name, value) so filtering by any
-- of these in search stays fast even as the table grows.
CREATE TABLE IF NOT EXISTS profile_multi_attributes (
  profile_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  field_name TEXT NOT NULL CHECK (field_name IN ('gender','orientation','has_kids','pets','religion')),
  value TEXT NOT NULL,
  PRIMARY KEY (profile_id, field_name, value)
);
CREATE INDEX IF NOT EXISTS idx_profile_multi_field_value ON profile_multi_attributes(field_name, value);

CREATE TABLE IF NOT EXISTS interests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL              -- lowercased, e.g. "hiking", "bird watching"
);
CREATE INDEX IF NOT EXISTS idx_interests_name ON interests(name);

CREATE TABLE IF NOT EXISTS profile_interests (
  profile_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  interest_id INTEGER NOT NULL REFERENCES interests(id) ON DELETE CASCADE,
  PRIMARY KEY (profile_id, interest_id)
);

CREATE TABLE IF NOT EXISTS rooms (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  topic_tag TEXT,
  is_public INTEGER NOT NULL DEFAULT 1,
  requires_registration INTEGER NOT NULL DEFAULT 1,  -- 0 = guests can view + chat (only #everyone, seeded below)
  created_by TEXT REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  member_count INTEGER NOT NULL DEFAULT 0
);

-- The one open room guests can view and chat in without any account at all.
INSERT OR IGNORE INTO rooms (id, name, description, is_public, requires_registration)
VALUES ('everyone', '#everyone', 'Open to everyone, no account needed', 1, 0);

CREATE TABLE IF NOT EXISTS room_memberships (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id TEXT NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  joined_at TEXT NOT NULL DEFAULT (datetime('now')),
  role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('member','moderator','owner')),
  UNIQUE(room_id, user_id)
);

CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,                   -- ULID, generated in app code for sortable pagination
  room_id TEXT NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_messages_room_created ON messages(room_id, created_at);

CREATE TABLE IF NOT EXISTS swipes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  swiper_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  target_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  direction TEXT NOT NULL CHECK (direction IN ('like','pass')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(swiper_user_id, target_user_id)
);

CREATE TABLE IF NOT EXISTS matches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_a_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  user_b_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(user_a_id, user_b_id)
);

CREATE TABLE IF NOT EXISTS subscriptions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  stripe_customer_id TEXT,
  stripe_subscription_id TEXT,
  status TEXT CHECK (status IN ('active','canceled','past_due')),
  current_period_end TEXT
);

-- ============================================================
-- "Memes" feed — posts, likes, comments, shares, hides, reports, saves.
-- Adapted from a separately-built module: user_id columns changed from
-- INTEGER to TEXT to match this app's real users(id) (a UUID string),
-- and its own placeholder users table dropped in favor of the real one
-- defined above. Everything else (structure, triggers, indexes) is
-- unchanged from the original design.
-- Follow/block are deliberately NOT modeled here — deferred to a future
-- shared, app-wide follow/block system usable from chat and profiles too.
-- ============================================================

CREATE TABLE IF NOT EXISTS posts (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    image_path      TEXT NOT NULL,
    image_width     INTEGER,
    image_height    INTEGER,
    like_count      INTEGER NOT NULL DEFAULT 0,
    comment_count   INTEGER NOT NULL DEFAULT 0,
    share_count     INTEGER NOT NULL DEFAULT 0,
    is_hidden       INTEGER NOT NULL DEFAULT 0,
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_posts_new      ON posts (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_posts_top      ON posts (like_count DESC);
CREATE INDEX IF NOT EXISTS idx_posts_comments ON posts (comment_count DESC);
CREATE INDEX IF NOT EXISTS idx_posts_user     ON posts (user_id);

CREATE TABLE IF NOT EXISTS post_likes (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id     INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (post_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_post_likes_created ON post_likes (created_at);

CREATE TABLE IF NOT EXISTS comments (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id         INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    user_id         TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    parent_id       INTEGER REFERENCES comments(id) ON DELETE CASCADE,
    body            TEXT NOT NULL,
    like_count      INTEGER NOT NULL DEFAULT 0,
    is_hidden       INTEGER NOT NULL DEFAULT 0,
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_comments_post   ON comments (post_id, parent_id);
CREATE INDEX IF NOT EXISTS idx_comments_parent ON comments (parent_id);

CREATE TABLE IF NOT EXISTS comment_likes (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    comment_id  INTEGER NOT NULL REFERENCES comments(id) ON DELETE CASCADE,
    user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (comment_id, user_id)
);

CREATE TABLE IF NOT EXISTS shares (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id           INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    user_id           TEXT REFERENCES users(id) ON DELETE SET NULL,
    anchor_comment_id INTEGER REFERENCES comments(id) ON DELETE SET NULL,
    created_at        TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_shares_post ON shares (post_id);

CREATE TABLE IF NOT EXISTS post_hides (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    post_id     INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (user_id, post_id)
);

CREATE TABLE IF NOT EXISTS post_reports (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    post_id     INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    reason      TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS comment_hides (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    comment_id  INTEGER NOT NULL REFERENCES comments(id) ON DELETE CASCADE,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (user_id, comment_id)
);

CREATE TABLE IF NOT EXISTS comment_reports (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    comment_id  INTEGER NOT NULL REFERENCES comments(id) ON DELETE CASCADE,
    reason      TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS saved_posts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    post_id     INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (user_id, post_id)
);

CREATE TABLE IF NOT EXISTS saved_comments (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    comment_id  INTEGER NOT NULL REFERENCES comments(id) ON DELETE CASCADE,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (user_id, comment_id)
);

CREATE TRIGGER IF NOT EXISTS trg_post_like_insert
AFTER INSERT ON post_likes
BEGIN
    UPDATE posts SET like_count = like_count + 1 WHERE id = NEW.post_id;
END;

CREATE TRIGGER IF NOT EXISTS trg_post_like_delete
AFTER DELETE ON post_likes
BEGIN
    UPDATE posts SET like_count = like_count - 1 WHERE id = OLD.post_id;
END;

CREATE TRIGGER IF NOT EXISTS trg_comment_like_insert
AFTER INSERT ON comment_likes
BEGIN
    UPDATE comments SET like_count = like_count + 1 WHERE id = NEW.comment_id;
END;

CREATE TRIGGER IF NOT EXISTS trg_comment_like_delete
AFTER DELETE ON comment_likes
BEGIN
    UPDATE comments SET like_count = like_count - 1 WHERE id = OLD.comment_id;
END;

CREATE TRIGGER IF NOT EXISTS trg_post_comment_insert
AFTER INSERT ON comments
BEGIN
    UPDATE posts SET comment_count = comment_count + 1 WHERE id = NEW.post_id;
END;

CREATE TRIGGER IF NOT EXISTS trg_post_comment_delete
AFTER DELETE ON comments
BEGIN
    UPDATE posts SET comment_count = comment_count - 1 WHERE id = OLD.post_id;
END;

CREATE TRIGGER IF NOT EXISTS trg_post_share_insert
AFTER INSERT ON shares
BEGIN
    UPDATE posts SET share_count = share_count + 1 WHERE id = NEW.post_id;
END;
