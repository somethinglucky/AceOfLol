-- Migration 009 — per-seat activity tracking, so a player waiting on
-- their opponent to arrive/move can see "last seen X ago" instead of a
-- silent spinner. Touched on every GET /api/game-sessions/:id a player's
-- own client makes (see routes/gameSessions.js) — since the frontend
-- already polls while waiting, that's a free, accurate activity signal
-- with no extra heartbeat plumbing needed.
ALTER TABLE game_session_players ADD COLUMN last_active_at TEXT;
