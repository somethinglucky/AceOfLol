-- Migration 015 — Checkers joins Blackjack and Go Fish as a real, free
-- game (games/checkers.js has a full engine — mandatory captures,
-- multi-jumps, kinging — not the shared stub). The original spec (§8)
-- always listed checkers alongside Blackjack/Go Fish as free; it just
-- hadn't been built yet.
INSERT OR IGNORE INTO game_definitions
  (game_id, display_name, icon, short_rules, min_players, max_players, access_tier, uses_card_theme, sort_order)
VALUES
  ('checkers', 'Checkers', '⛃', 'Capture your opponent''s pieces by jumping over them. Captures are mandatory when available. Reach the far row to become a king, which can move and capture in any diagonal direction.', 2, 2, 'free', 0, 2);

-- Shift War and Hearts down to keep the free games grouped first in the
-- hub's display order (sort_order is purely cosmetic — no other logic
-- depends on its value).
UPDATE game_definitions SET sort_order = 3 WHERE game_id = 'war';
UPDATE game_definitions SET sort_order = 4 WHERE game_id = 'hearts';
