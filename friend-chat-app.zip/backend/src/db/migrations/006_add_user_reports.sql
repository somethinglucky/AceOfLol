-- Reporting a PERSON directly (from their profile's \u2666 menu), distinct from
-- reporting a specific post/comment (post_reports/comment_reports) or DM
-- thread (dm_thread_reports) — same shape as those, logged for future
-- moderator review, no admin UI to look at these yet either.
CREATE TABLE IF NOT EXISTS user_reports (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    reporter_id       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    reported_user_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    reason            TEXT,
    created_at        TEXT NOT NULL DEFAULT (datetime('now')),
    CHECK (reporter_id != reported_user_id)
);
