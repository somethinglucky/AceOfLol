-- One thread per pair of users, canonically ordered (user_a_id < user_b_id
-- as plain TEXT comparison) so there's exactly one row per pair regardless
-- of who messaged whom first — no OR-based duplicate-checking needed
-- anywhere that reads this table.
CREATE TABLE IF NOT EXISTS dm_threads (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    user_a_id        TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    user_b_id        TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at       TEXT NOT NULL DEFAULT (datetime('now')),
    last_message_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (user_a_id, user_b_id),
    CHECK (user_a_id < user_b_id)
);

CREATE TABLE IF NOT EXISTS dm_messages (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    thread_id   INTEGER NOT NULL REFERENCES dm_threads(id) ON DELETE CASCADE,
    sender_id   TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    body        TEXT NOT NULL,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    read_at     TEXT  -- NULL until the recipient has opened the thread
);
CREATE INDEX IF NOT EXISTS idx_dm_messages_thread ON dm_messages(thread_id, created_at);

-- Hide: reversible, manual, persists regardless of new activity — same
-- model as post_hides, recoverable from a "Hidden conversations" list.
CREATE TABLE IF NOT EXISTS dm_thread_hides (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    thread_id   INTEGER NOT NULL REFERENCES dm_threads(id) ON DELETE CASCADE,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (user_id, thread_id)
);

-- "Delete": clears the thread from MY inbox, but — unlike Hide — it's not
-- meant to feel permanent or need a recovery list. Storing the id of the
-- newest message AT clear time (rather than a timestamp) is what lets a
-- thread naturally reappear the next time the other person messages
-- again: the inbox query just checks whether any message id is newer than
-- this. A timestamp would have worked too, except SQLite's datetime('now')
-- only has second precision — a clear and a same-second reply would tie
-- and the thread would incorrectly stay hidden. Message ids can't tie.
CREATE TABLE IF NOT EXISTS dm_thread_clears (
    id                       INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id                  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    thread_id                INTEGER NOT NULL REFERENCES dm_threads(id) ON DELETE CASCADE,
    cleared_up_to_message_id INTEGER NOT NULL,
    created_at               TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (user_id, thread_id)
);

-- Report — logged for future moderator review, same shape as post_reports.
CREATE TABLE IF NOT EXISTS dm_thread_reports (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    reporter_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    thread_id    INTEGER NOT NULL REFERENCES dm_threads(id) ON DELETE CASCADE,
    reason       TEXT,
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
