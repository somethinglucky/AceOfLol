-- Migration 013 — speeddate_queue freshness. Previously "someone's
-- waiting" meant "a row exists", with no expiry: someone who joined the
-- queue and then just closed the tab (never explicitly left) stayed
-- "waiting" forever, and — worse than the stale label alone — a new
-- joiner could get matched against them by tryMatch and land in a
-- session with someone who'll never arrive. last_seen_at is refreshed on
-- every status poll (see routes/gameQueue.js), so it tracks genuine
-- presence rather than just queue membership; joined_at is kept as-is for
-- fair FIFO ordering among people who are actually still there.
ALTER TABLE speeddate_queue ADD COLUMN last_seen_at TEXT NOT NULL DEFAULT (datetime('now'));
