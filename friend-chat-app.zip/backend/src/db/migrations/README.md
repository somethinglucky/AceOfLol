# Migrations

Every schema change from now on is a new file here, not an edit to an old one.

## Adding a new migration

1. Create `NNN_short_description.sql`, where `NNN` is the next number after
   the highest one currently in this folder, zero-padded to 3 digits
   (`002_add_follows.sql`, `003_add_dm_threads.sql`, ...). The number just
   needs to sort correctly — it doesn't need to be contiguous with any
   other numbering elsewhere in the project.
2. Write plain SQL: `CREATE TABLE`, `ALTER TABLE ... ADD COLUMN`, `CREATE
   INDEX`, etc. Prefer `CREATE TABLE IF NOT EXISTS` / `CREATE INDEX IF NOT
   EXISTS` so the file is safe to re-run by accident.
3. Deploy as usual (`git pull` → `pm2 restart friend-chat-app` on the
   droplet). `connection.js` calls `runMigrations()` on every backend
   startup — it applies any `.sql` file in this folder that isn't already
   recorded in the `schema_migrations` table, in filename order, and
   records it once it succeeds. **No manual migration step, no new
   deploy command to remember.**

## Rules

- **Never edit a migration file once it's been deployed anywhere**,
  even to fix a typo — write a new migration that corrects it instead.
  Editing an already-applied file does nothing on a droplet that already
  ran it (it's recorded as applied and won't re-run), so the fix would
  silently never take effect there.
- SQLite's `ALTER TABLE` can't drop or rename columns, add a `CHECK`
  constraint after the fact, or change a column's type. If you need any
  of those, the migration has to do the "create new table, copy the data
  across, drop the old, rename the new one" dance — ask the conversation
  building the feature to write that out in full rather than shortcutting it.
- `001_baseline.sql` is a snapshot of everything that existed before this
  system was introduced — it's what makes a *brand-new* droplet (no
  `app.db` yet) end up with the same schema as one that's been running
  since before migrations existed. Don't touch it.
