-- Replaces the single is_moderator boolean with a real role hierarchy.
-- Admin is treated as a superset of moderator everywhere in the app code
-- (any "can this person moderate?" check is role IN ('moderator','admin')),
-- so this is additive, not a breaking change to anything already using
-- is_moderator — that column is left in place (SQLite can't cheaply drop
-- columns) but nothing reads it after this migration.
--
-- is_bot marks an account as an automated moderator rather than a human.
-- It's independent of role on purpose: a bot account still just has
-- role='moderator' (or 'admin', if it ever needed that) and goes through
-- the exact same permission checks and API endpoints as a human moderator
-- — is_bot only exists so the dashboard/audit trail can label it as a bot
-- rather than a person, and so it can authenticate with a long-lived API
-- token instead of a normal login flow whenever that's actually built.
ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'
  CHECK (role IN ('user', 'moderator', 'admin'));
ALTER TABLE users ADD COLUMN is_bot INTEGER NOT NULL DEFAULT 0;

UPDATE users SET role = 'moderator' WHERE is_moderator = 1;
