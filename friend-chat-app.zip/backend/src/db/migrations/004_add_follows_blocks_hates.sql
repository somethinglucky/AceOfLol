-- Follows and blocks are directed relationships between two users. This is
-- the ONE shared system for both — chat, profiles, and the feed all read
-- and write these same two tables rather than each having their own.
--
-- Blocking removes any existing follow between the two people in BOTH
-- directions (handled in the route, not here) — you can't meaningfully
-- follow someone you've blocked, or be followed by someone who blocked
-- you. Enforcement of what a block actually DOES (hiding content, one day
-- hiding DM threads) lives in each feature's own read queries, checked in
-- both directions — see feed/feed.js and feed/comments.js for the pattern.
CREATE TABLE IF NOT EXISTS follows (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    follower_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    followed_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (follower_id, followed_id),
    CHECK (follower_id != followed_id)
);

CREATE TABLE IF NOT EXISTS blocks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    blocker_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    blocked_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (blocker_id, blocked_id),
    CHECK (blocker_id != blocked_id)
);

CREATE INDEX IF NOT EXISTS idx_follows_followed ON follows(followed_id);
CREATE INDEX IF NOT EXISTS idx_blocks_blocked ON blocks(blocked_id);

-- "Hate this" — deliberately NOT shown anywhere in the product (see sj's
-- spec: it shouldn't affect what anyone sees, it's just a signal for a
-- future admin stats dashboard). One row per user per piece of content;
-- content_type keeps this one shared table instead of a hates-for-posts
-- and a separate hates-for-comments table.
CREATE TABLE IF NOT EXISTS content_hates (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    content_type  TEXT NOT NULL CHECK (content_type IN ('post', 'comment')),
    content_id    INTEGER NOT NULL,
    created_at    TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (user_id, content_type, content_id)
);
