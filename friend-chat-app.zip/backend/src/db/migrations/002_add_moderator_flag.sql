-- Site-wide moderator flag. Separate from room_memberships.role (which is
-- per-room chat moderation) — this one gates cross-app moderation actions
-- like deleting other people's feed posts/comments. No admin UI to set this
-- yet, so for now it's set by hand on the droplet, e.g.:
--   node -e "require('./src/db/connection').prepare('UPDATE users SET is_moderator = 1 WHERE public_handle = ?').run('yourHandle')"
ALTER TABLE users ADD COLUMN is_moderator INTEGER NOT NULL DEFAULT 0;
