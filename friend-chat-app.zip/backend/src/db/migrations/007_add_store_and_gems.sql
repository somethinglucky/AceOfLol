-- Migration 007 — Store + Gems (♦) currency system.
--
-- Core rule this schema exists to enforce: store_items are ALWAYS priced in
-- USD (the `currency = 'usd'` CHECK makes this a database constraint, not
-- just a convention), and gems are only ever minted via a verified Stripe
-- webhook or an in-game earn event — never spent back into fiat by anyone,
-- anywhere. There is deliberately no "redeem gems for cash" code path at all.

-- One row per user holding their current balance. Denormalized (not derived
-- from summing gem_transactions on every read) since balance checks happen
-- on every gem spend and need to be fast + easy to lock with a transaction.
CREATE TABLE IF NOT EXISTS gem_wallets (
  user_id     TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  balance     INTEGER NOT NULL DEFAULT 0 CHECK (balance >= 0),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Append-only audit trail of every gem movement. Never UPDATE or DELETE a
-- row here — corrections are a new offsetting row, same as real ledgers.
-- This table is what makes "gems are non-redeemable, here's proof" a query
-- instead of a promise, if that's ever needed for compliance review.
CREATE TABLE IF NOT EXISTS gem_transactions (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount      INTEGER NOT NULL,   -- positive = credit, negative = debit; never 0
  reason      TEXT NOT NULL CHECK (reason IN (
    'stripe_purchase', 'treasure_chest', 'job_payout', 'store_spend',
    'p2p_trade', 'buyback', 'gift_sent', 'gift_received', 'admin_adjustment'
  )),
  ref_id      TEXT,               -- order id / job id / trade id this ties back to, for tracing
  note        TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_gem_transactions_user ON gem_transactions(user_id, created_at);

-- Store catalog. item_type='gem_pack' is the ONLY item type allowed to grant
-- gems (gem_amount required); 'physical' and 'digital' never touch the gems
-- ledger at all — they're plain USD purchases.
CREATE TABLE IF NOT EXISTS store_items (
  id                  TEXT PRIMARY KEY,
  name                TEXT NOT NULL,
  description         TEXT,
  image_path          TEXT,
  currency            TEXT NOT NULL DEFAULT 'usd' CHECK (currency = 'usd'),
  price_usd_cents     INTEGER NOT NULL CHECK (price_usd_cents > 0),
  item_type           TEXT NOT NULL CHECK (item_type IN ('gem_pack', 'physical', 'digital')),
  gem_amount          INTEGER CHECK (
    (item_type = 'gem_pack' AND gem_amount IS NOT NULL AND gem_amount > 0)
    OR (item_type != 'gem_pack' AND gem_amount IS NULL)
  ),
  requires_shipping   INTEGER NOT NULL DEFAULT 0 CHECK (requires_shipping IN (0, 1)),
  is_active           INTEGER NOT NULL DEFAULT 1,
  sort_order          INTEGER NOT NULL DEFAULT 0,
  created_by          TEXT REFERENCES users(id),
  created_at          TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at          TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_store_items_active ON store_items(is_active, sort_order);

-- One row per checkout attempt. Created 'pending' at checkout-session
-- creation time, flipped to 'paid' ONLY by the Stripe webhook handler after
-- Stripe itself confirms payment — never by the frontend's success redirect,
-- which can be spoofed or simply never fire.
CREATE TABLE IF NOT EXISTS orders (
  id                          TEXT PRIMARY KEY,
  user_id                     TEXT NOT NULL REFERENCES users(id),
  item_id                     TEXT NOT NULL REFERENCES store_items(id),
  stripe_checkout_session_id  TEXT UNIQUE,
  stripe_payment_intent_id    TEXT,
  amount_usd_cents            INTEGER NOT NULL,
  status                      TEXT NOT NULL DEFAULT 'pending' CHECK (
    status IN ('pending', 'paid', 'failed', 'refunded')
  ),
  shipping_address_json       TEXT,   -- set from Stripe's collected address, only when requires_shipping
  created_at                  TEXT NOT NULL DEFAULT (datetime('now')),
  paid_at                     TEXT
);
CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id, created_at);

-- Seed item: the one listing sj wants live right away.
INSERT OR IGNORE INTO store_items
  (id, name, description, currency, price_usd_cents, item_type, gem_amount, requires_shipping, is_active, sort_order)
VALUES
  ('gempack-intro-100', 'Buy Gems', '100♦ for $33 — special one time introductory offer!',
   'usd', 3300, 'gem_pack', 100, 0, 1, 0);
