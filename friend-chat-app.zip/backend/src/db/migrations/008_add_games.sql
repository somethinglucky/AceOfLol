-- Migration 008 — Multiplayer Game System (the "Shell" from the Games spec).
--
-- Design mirrors the spec's shell/module split: game_definitions is pure
-- metadata the Shell reads to render the Games hub + lobby (name, icon,
-- player counts, access tier). Actual gameplay state lives entirely inside
-- game_sessions.module_state as a JSON blob that each game module owns —
-- the Shell (routes/games layer) never parses what's inside it, it just
-- passes onMove() calls through and reads back renderState() output.

CREATE TABLE IF NOT EXISTS game_definitions (
  game_id           TEXT PRIMARY KEY,          -- slug, e.g. 'blackjack'
  display_name      TEXT NOT NULL,
  icon              TEXT NOT NULL,              -- emoji, shown on hub + lobby
  short_rules       TEXT NOT NULL,
  min_players       INTEGER NOT NULL,
  max_players       INTEGER NOT NULL,
  access_tier       TEXT NOT NULL CHECK (access_tier IN ('free', 'premium_or_pay')),
  uses_card_theme   INTEGER NOT NULL DEFAULT 1 CHECK (uses_card_theme IN (0, 1)),
  is_active         INTEGER NOT NULL DEFAULT 1,
  sort_order        INTEGER NOT NULL DEFAULT 0
);

-- Seed set: Blackjack + Go Fish have real engines (backend/src/games/).
-- War + Hearts are seeded so the Hub/Lobby/monetization/invite/speeddate
-- Shell can be built and tested end-to-end against a premium_or_pay game
-- right now — they run on the shared stub module (backend/src/games/
-- stubModule.js) until real engines are dropped into the registry, per
-- the spec's own "finish the interface first, even as a stub" build order.
INSERT OR IGNORE INTO game_definitions
  (game_id, display_name, icon, short_rules, min_players, max_players, access_tier, uses_card_theme, sort_order)
VALUES
  ('blackjack', 'Blackjack', '🃏', 'Closest to 21 without going over wins. Hit to take a card, Stand to hold what you have.', 2, 2, 'free', 1, 0),
  ('go_fish', 'Go Fish', '🎣', 'Ask your opponent for a card rank. Get a match and go again; guess wrong and draw. Collect four-of-a-kind books to score.', 2, 2, 'free', 1, 1),
  ('war', 'War', '⚔️', 'Both players flip a card — higher card wins the round and takes both cards. Most cards when the deck runs out wins.', 2, 2, 'premium_or_pay', 1, 2),
  ('hearts', 'Hearts', '♥️', 'Avoid taking hearts and the Queen of Spades. Lowest score when the deck runs out wins.', 3, 4, 'premium_or_pay', 1, 3);

-- One row per game session, whether it came from an invite or a stranger
-- match. seats_required lets the Shell know when everyone has arrived
-- (game_definitions.min_players at creation time) without re-reading the
-- definition on every poll.
CREATE TABLE IF NOT EXISTS game_sessions (
  id               TEXT PRIMARY KEY,
  game_id          TEXT NOT NULL REFERENCES game_definitions(game_id),
  status           TEXT NOT NULL DEFAULT 'waiting' CHECK (status IN ('waiting', 'active', 'completed')),
  seats_required   INTEGER NOT NULL,
  module_state     TEXT NOT NULL DEFAULT '{}',
  turn_user_id     TEXT REFERENCES users(id),   -- whose move it currently is, denormalized for fast lobby/notify checks
  result_json      TEXT,                        -- set once by onGameEnd — {winnerId, scores}
  source           TEXT NOT NULL CHECK (source IN ('invite', 'stranger')),
  created_at       TEXT NOT NULL DEFAULT (datetime('now')),
  started_at       TEXT,
  completed_at     TEXT
);

CREATE TABLE IF NOT EXISTS game_session_players (
  session_id       TEXT NOT NULL REFERENCES game_sessions(id) ON DELETE CASCADE,
  user_id          TEXT NOT NULL REFERENCES users(id),
  seat_index       INTEGER NOT NULL,
  is_first_mover   INTEGER NOT NULL DEFAULT 0 CHECK (is_first_mover IN (0, 1)),
  arrived          INTEGER NOT NULL DEFAULT 0 CHECK (arrived IN (0, 1)),   -- has this player tapped their confirmation link / joined the session screen
  arrived_at       TEXT,
  PRIMARY KEY (session_id, user_id)
);

-- Invite Flow state machine (spec section 6): draft is client-side only
-- (nothing written until Submit); pending -> confirmed happens when the
-- invitee picks a date; confirmed carries straight through to scheduled/
-- active implicitly via game_sessions once created; expired branches off
-- pending only.
CREATE TABLE IF NOT EXISTS game_invites (
  id                    TEXT PRIMARY KEY,
  game_id               TEXT NOT NULL REFERENCES game_definitions(game_id),
  inviter_id            TEXT NOT NULL REFERENCES users(id),
  invitee_id            TEXT REFERENCES users(id),        -- set when invited by existing userID
  invitee_email         TEXT,                              -- set when invited by email (no account match yet)
  proposed_dates_json   TEXT NOT NULL,                      -- array of ISO datetimes, inviter's candidate times
  chosen_date           TEXT,                               -- set once the invitee picks one (status -> confirmed)
  expires_at            TEXT NOT NULL,
  status                TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'expired', 'cancelled')),
  session_id            TEXT REFERENCES game_sessions(id),  -- set once confirmed creates the GameSession
  gem_cost              INTEGER NOT NULL DEFAULT 0,          -- what the inviter was actually charged, for refund/audit clarity
  created_at            TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_game_invites_invitee ON game_invites(invitee_id, status);
CREATE INDEX IF NOT EXISTS idx_game_invites_inviter ON game_invites(inviter_id, status);

-- Play-a-Stranger FIFO queue (spec section 7). One row per (game, user) —
-- a player can only be queued once per game at a time.
CREATE TABLE IF NOT EXISTS speeddate_queue (
  game_id     TEXT NOT NULL REFERENCES game_definitions(game_id),
  user_id     TEXT NOT NULL REFERENCES users(id),
  joined_at   TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (game_id, user_id)
);

-- Site-wide per-game leaderboard (spec section 5) — combined score across
-- a player's games of this type. wins/best_score are simple placeholders
-- a module's onGameEnd updates; "quickest time" isn't tracked yet (no
-- module reports a duration today) — a natural follow-up column.
CREATE TABLE IF NOT EXISTS game_leaderboard (
  game_id      TEXT NOT NULL REFERENCES game_definitions(game_id),
  user_id      TEXT NOT NULL REFERENCES users(id),
  wins         INTEGER NOT NULL DEFAULT 0,
  losses       INTEGER NOT NULL DEFAULT 0,
  best_score   INTEGER,
  updated_at   TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (game_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_game_leaderboard_rank ON game_leaderboard(game_id, wins DESC);

-- gem_transactions.reason (migration 007) doesn't include game-related
-- reasons yet, and SQLite can't widen a CHECK constraint with ALTER TABLE
-- — rebuild the table with the wider list, copy every row across
-- unchanged, then swap it in. Never edit 007's version of this directly;
-- this is the one-time "add to the list" migration going forward too.
CREATE TABLE gem_transactions_new (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount      INTEGER NOT NULL,
  reason      TEXT NOT NULL CHECK (reason IN (
    'stripe_purchase', 'treasure_chest', 'job_payout', 'store_spend',
    'p2p_trade', 'buyback', 'gift_sent', 'gift_received', 'admin_adjustment',
    'game_invite_charge', 'game_stranger_charge'
  )),
  ref_id      TEXT,
  note        TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
INSERT INTO gem_transactions_new SELECT * FROM gem_transactions;
DROP TABLE gem_transactions;
ALTER TABLE gem_transactions_new RENAME TO gem_transactions;
CREATE INDEX IF NOT EXISTS idx_gem_transactions_user ON gem_transactions(user_id, created_at);
