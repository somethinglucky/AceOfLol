const jwt = require('jsonwebtoken');
const db = require('../db/connection');

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  throw new Error('JWT_SECRET is not set — add it to your .env file');
}

function verifyToken(req) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return null;
  try {
    return jwt.verify(token, JWT_SECRET).sub; // returns userId, or null on failure
  } catch {
    return null;
  }
}

// Attaches req.userId when the request has a valid token.
// Use on any route that requires the caller to be logged in (guest OR registered).
function requireAuth(req, res, next) {
  const userId = verifyToken(req);
  if (!userId) {
    return res.status(401).json({ error: 'Missing or invalid auth token' });
  }
  req.userId = userId;
  next();
}

// Attaches req.user if a valid token identifies someone — guest or
// registered — but never blocks the request. Used for things anyone can
// VIEW (like the feed), where only some actions on top of viewing need
// registration. req.user is { id, handle, nickname, avatarUrl, isRegistered }
// or undefined if no valid identity was presented.
function optionalAuth(req, res, next) {
  const userId = verifyToken(req);
  if (userId) {
    const row = db
      .prepare(
        `SELECT u.id, u.public_handle AS handle, u.is_registered AS isRegistered,
                u.role, u.is_bot AS isBot,
                p.nickname, p.avatar_url AS avatarUrl
         FROM users u JOIN profiles p ON p.user_id = u.id
         WHERE u.id = ?`
      )
      .get(userId);
    if (row) {
      req.user = {
        ...row,
        isRegistered: !!row.isRegistered,
        isBot: !!row.isBot,
        // Admin is a superset of moderator everywhere in the app — anything
        // gated on "can this person moderate" should check isModerator,
        // which is true for admins too. Only gate on isAdmin for
        // admin-specific actions (the dashboard, promoting other people).
        isModerator: row.role === 'moderator' || row.role === 'admin',
        isAdmin: row.role === 'admin',
      };
    }
  }
  next();
}

// Blocks with 403 unless optionalAuth (must run first) found an admin.
// Use on every admin-dashboard route — promoting/demoting people is the
// one class of action that must never be reachable by a plain moderator.
function requireAdmin(req, res, next) {
  if (!req.user || !req.user.isAdmin) {
    return res.status(403).json({ error: 'Admins only.' });
  }
  next();
}

// Blocks with 403 unless optionalAuth (must run first) found a REGISTERED
// user — this is the "guests can view but not post/like/comment" gate.
function requireRegistered(req, res, next) {
  if (!req.user || !req.user.isRegistered) {
    return res.status(403).json({ error: 'Please register to do that.' });
  }
  next();
}

function signToken(userId) {
  // 30-day expiry is a reasonable default for a mobile app people stay logged into.
  return jwt.sign({ sub: userId }, JWT_SECRET, { expiresIn: '30d' });
}

module.exports = { requireAuth, optionalAuth, requireRegistered, requireAdmin, signToken };
