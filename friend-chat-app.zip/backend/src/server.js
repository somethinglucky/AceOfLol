require('dotenv').config();
const express = require('express');
const path = require('path');
const http = require('http');
const { Server } = require('socket.io');

const authRoutes = require('./routes/auth');
const profileRoutes = require('./routes/profiles');
const { optionalAuth } = require('./middleware/auth');
const feedRoutes = require('./routes/feed/feed');
const feedPostRoutes = require('./routes/feed/posts');
const feedCommentRoutes = require('./routes/feed/comments');
const feedCommentActionRoutes = require('./routes/feed/comment-actions');
// Room/message chat logic lives here — kept separate from server.js so this
// file stays a simple wiring point as more socket events get added.
const registerChatHandlers = require('./sockets/chatHandlers');

const app = express();
app.use(express.json());

// Basic health check — useful for confirming the droplet is serving before
// you point nginx/DNS at it.
app.get('/health', (req, res) => res.json({ status: 'ok' }));

app.use('/auth', authRoutes);
app.use('/profiles', profileRoutes);

// Feed routes: optionalAuth runs first so req.user is set for anyone with a
// valid token (guest or registered) without ever blocking the request —
// individual feed routes then use requireRegistered where posting/liking/
// commenting actually needs a registered account.
app.use('/api', optionalAuth);
app.use('/api/feed', feedRoutes);
app.use('/api/posts', feedPostRoutes);
app.use('/api/posts/:postId/comments', feedCommentRoutes);
app.use('/api/comments', feedCommentActionRoutes);

// Feed image uploads — served directly here rather than proxied through
// nginx's static frontend root, since these live outside the built SPA.
app.use('/media', express.static(process.env.FEED_UPLOAD_DIR || path.join(__dirname, '../uploads/feed')));

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }, // tighten this to your real domain once you have one
});

io.on('connection', (socket) => registerChatHandlers(io, socket));

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
