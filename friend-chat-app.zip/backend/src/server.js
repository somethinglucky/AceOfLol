require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const authRoutes = require('./routes/auth');
// Room/message chat logic lives here — kept separate from server.js so this
// file stays a simple wiring point as more socket events get added.
const registerChatHandlers = require('./sockets/chatHandlers');

const app = express();
app.use(express.json());

// Basic health check — useful for confirming the droplet is serving before
// you point nginx/DNS at it.
app.get('/health', (req, res) => res.json({ status: 'ok' }));

app.use('/auth', authRoutes);

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }, // tighten this to your real domain once you have one
});

io.on('connection', (socket) => registerChatHandlers(io, socket));

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
