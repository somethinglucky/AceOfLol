require('dotenv').config();
const express = require('express');
const path = require('path');
const http = require('http');
const { Server } = require('socket.io');

const authRoutes = require('./routes/auth');
const profileRoutes = require('./routes/profiles');
const { optionalAuth } = require('./middleware/auth');
const feedRoutes = require('./routes/feed/feed');
const feedPostRoutes = require('./routes/feed/posts');
const feedCommentRoutes = require('./routes/feed/comments');
const feedCommentActionRoutes = require('./routes/feed/comment-actions');
const meRoutes = require('./routes/me');
// Room/message chat logic lives here — kept separate from server.js so this
// file stays a simple wiring point as more socket events get added.
const registerChatHandlers = require('./sockets/chatHandlers');

const app = express();
app.use(express.json());

// Basic health check — useful for confirming the droplet is serving before
// you point nginx/DNS at it.
app.get('/health', (req, res) => res.json({ status: 'ok' }));

app.use('/auth', authRoutes);
app.use('/profiles', profileRoutes);

// Feed routes: optionalAuth runs first so req.user is set for anyone with a
// valid token (guest or registered) without ever blocking the request —
// individual feed routes then use requireRegistered where posting/liking/
// commenting actually needs a registered account.
app.use('/api', optionalAuth);
app.use('/api/me', meRoutes);
app.use('/api/feed', feedRoutes);
app.use('/api/posts', feedPostRoutes);
app.use('/api/posts/:postId/comments', feedCommentRoutes);
app.use('/api/comments', feedCommentActionRoutes);

// Feed image uploads — served directly here rather than proxied through
// nginx's static frontend root, since these live outside the built SPA.
app.use('/media', express.static(process.env.FEED_UPLOAD_DIR || path.join(__dirname, '../uploads/feed')));

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }, // tighten this to your real domain once you have one
});

io.on('connection', (socket) => registerChatHandlers(io, socket));

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});

// pm2 sends SIGTERM (or SIGINT if you Ctrl+C locally) to ask the process to
// stop before every restart/reload. Without handling it, Node's default exit
// path tears the process down while better-sqlite3's native prepared
// statements are still open, which is what throws the
// "Assertion failed: (env) != nullptr" native crash you'll see in pm2's
// error log on every restart. It's harmless (pm2 just starts the new
// process right after), but closing things in order avoids it entirely.
const db = require('./db/connection');

function shutdown(signal) {
  console.log(`${signal} received, shutting down gracefully`);
  io.close();
  server.close(() => {
    db.close();
    process.exit(0);
  });
  // Belt-and-suspenders: if something (a stuck socket, etc.) keeps
  // server.close() from ever calling back, don't hang forever — force exit.
  setTimeout(() => process.exit(0), 5000).unref();
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
