// ============================================================
// Sharing
// ------------------------------------------------------------
// ROUTING NOTE: post permalinks are built as `${origin}/memes/post/:id`
// below — a guess, since the main app's URL structure isn't decided
// yet. Update `postUrl()` once real routing for individual posts
// exists in the main chat app.
// ============================================================

const Share = (() => {
    function postUrl(postId, anchorCommentId) {
        const base = `${location.origin}/memes/post/${postId}`;
        return anchorCommentId ? `${base}?comment=${anchorCommentId}` : base;
    }

    // Renders the image + a small watermark onto an offscreen node,
    // then rasterizes it with html2canvas into a PNG blob. This is
    // what gets attached to native shares / downloads, so the source
    // is always visible on whatever platform the image ends up on.
    async function buildWatermarkedImage(imgEl) {
        const wrap = document.createElement('div');
        wrap.style.cssText = 'position:fixed; left:-9999px; top:0; background:#000; display:inline-block;';

        const clone = document.createElement('img');
        clone.src = imgEl.src;
        clone.style.cssText = 'display:block; max-width:600px;';

        const mark = document.createElement('div');
        mark.textContent = 'AceOf.Lol';
        mark.style.cssText = `
            position:absolute; top:10px; left:0; right:0; text-align:center;
            color:rgba(255,255,255,0.55); font:13px -apple-system, sans-serif;
            letter-spacing:0.02em; text-shadow:0 1px 2px rgba(0,0,0,0.6);
        `;

        wrap.style.position = 'fixed';
        wrap.appendChild(clone);
        wrap.appendChild(mark);
        document.body.appendChild(wrap);

        await new Promise((resolve, reject) => {
            if (clone.complete) return resolve();
            clone.onload = resolve;
            clone.onerror = reject;
        });

        try {
            const canvas = await html2canvas(wrap, { backgroundColor: '#000', useCORS: true });
            return await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
        } finally {
            wrap.remove();
        }
    }

    async function shareToPlatform(kind, post, imgEl, anchorCommentId) {
        const url = postUrl(post.id, anchorCommentId);
        const text = 'Check this out on AceOf.Lol';

        switch (kind) {
            case 'reddit':
                window.open(`https://www.reddit.com/submit?url=${encodeURIComponent(url)}&title=${encodeURIComponent(text)}`, '_blank');
                break;
            case 'x':
                window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`, '_blank');
                break;
            case 'text':
                window.location.href = `sms:?&body=${encodeURIComponent(text + ' ' + url)}`;
                break;
            case 'email':
                window.location.href = `mailto:?subject=${encodeURIComponent(text)}&body=${encodeURIComponent(url)}`;
                break;
            case 'copy':
                await navigator.clipboard.writeText(url);
                App.showToast('Link copied');
                break;
            case 'download': {
                const blob = await buildWatermarkedImage(imgEl);
                const a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = `aceoflol-${post.id}.png`;
                a.click();
                URL.revokeObjectURL(a.href);
                break;
            }
            case 'instagram':
            default: {
                // No reliable web share-intent for Instagram (or a generic
                // "other" target) — hand off to the OS share sheet, which
                // lets the person pick Instagram (or anything else) themselves.
                const blob = await buildWatermarkedImage(imgEl);
                const file = new File([blob], `aceoflol-${post.id}.png`, { type: 'image/png' });
                if (navigator.canShare && navigator.canShare({ files: [file] })) {
                    await navigator.share({ files: [file], title: text, text, url });
                } else if (navigator.share) {
                    await navigator.share({ title: text, text, url });
                } else {
                    // Last resort: download and let them attach it manually.
                    const a = document.createElement('a');
                    a.href = URL.createObjectURL(blob);
                    a.download = `aceoflol-${post.id}.png`;
                    a.click();
                    URL.revokeObjectURL(a.href);
                    App.showToast('Image saved — attach it in Instagram');
                }
            }
        }
    }

    return { shareToPlatform, postUrl };
})();
