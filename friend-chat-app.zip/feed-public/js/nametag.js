// Builds the "Nickname@handle" markup used everywhere a person's name is
// shown in the feed — nickname prominent, @handle smaller and muted.
// Mirrors frontend/src/components/NameTag.jsx; keep the two in sync if the
// format ever changes.
const NameTag = (() => {
    function escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str == null ? '' : String(str);
        return div.innerHTML;
    }

    // Returns an HTML string — caller sets it via innerHTML.
    function html(nickname, handle, isRegistered = true) {
        const displayNickname = nickname || (isRegistered ? handle : 'Guest');
        return (
            `<span class="nametag-nickname">${escapeHtml(displayNickname)}</span>` +
            `<span class="nametag-handle">@${escapeHtml(handle)}</span>`
        );
    }

    // Plain-text version (no markup) — for places like <img alt> or a
    // composer placeholder where HTML can't be used.
    function text(nickname, handle, isRegistered = true) {
        const displayNickname = nickname || (isRegistered ? handle : 'Guest');
        return `${displayNickname}@${handle}`;
    }

    return { html, text, escapeHtml };
})();
