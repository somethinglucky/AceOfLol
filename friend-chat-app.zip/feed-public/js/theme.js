// ============================================================
// Theme system
// ------------------------------------------------------------
// INTEGRATION SEAM: per-user color customization doesn't have a
// settings UI yet (per sj's note — not needed yet). This file is
// where that plugs in later: whatever settings screen gets built
// just needs to call `Theme.apply({...})` with the user's chosen
// colors, or write them to the same localStorage key this reads
// from on load. Nothing else in the app touches colors directly —
// every rule in css/style.css reads from the CSS variables this
// file sets on :root, so a real theme picker only needs to change
// this one file's data source, not any styling code.
// ============================================================

const Theme = (() => {
    const STORAGE_KEY = 'aceoflol_theme';

    // Default theme: an iOS-dark-mode-style palette (semantic names
    // borrowed from Apple's Human Interface Guidelines color roles),
    // since a media-heavy feed reads best with a dark canvas. Any of
    // these can be overridden per-user later.
    const DEFAULT_THEME = {
        '--color-bg': '#000000',
        '--color-bg-elevated': '#1c1c1e',
        '--color-bg-elevated-2': '#2c2c2e',
        '--color-separator': 'rgba(84, 84, 88, 0.65)',
        '--color-label': '#ffffff',
        '--color-label-secondary': 'rgba(235, 235, 245, 0.6)',
        '--color-label-tertiary': 'rgba(235, 235, 245, 0.3)',
        '--color-accent': '#0a84ff',       // iOS systemBlue — liked/active states
        '--color-accent-contrast': '#ffffff',
        '--color-destructive': '#ff453a',  // iOS systemRed — report/destructive actions
        '--color-watermark': 'rgba(255, 255, 255, 0.35)',
    };

    function apply(theme) {
        const root = document.documentElement;
        Object.entries(theme).forEach(([key, value]) => root.style.setProperty(key, value));
    }

    function load() {
        apply(DEFAULT_THEME);
        try {
            const stored = localStorage.getItem(STORAGE_KEY);
            if (stored) apply(JSON.parse(stored));
        } catch (_) {
            // malformed stored theme — default already applied, ignore
        }
    }

    return { apply, load, DEFAULT_THEME };
})();

Theme.load();
