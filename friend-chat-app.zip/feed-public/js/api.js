// ============================================================
// API wrapper
// ------------------------------------------------------------
// AUTH: uses the same JWT the main app stores in localStorage under
// 'token' (set at guest creation, login, or registration) — sent as a
// standard Bearer header, matching every other endpoint in this app.
// ============================================================

const Api = (() => {
    function authHeaders() {
        const token = localStorage.getItem('token');
        return token ? { 'Authorization': `Bearer ${token}` } : {};
    }

    async function request(path, options = {}) {
        const res = await fetch(path, {
            ...options,
            headers: { ...(options.headers || {}), ...authHeaders() },
        });
        if (!res.ok) {
            let message = `Request failed (${res.status})`;
            try {
                const body = await res.json();
                if (body.error) message = body.error;
            } catch (_) { /* ignore parse failure */ }
            const err = new Error(message);
            err.status = res.status;
            throw err;
        }
        if (res.status === 204) return null;
        return res.json();
    }

    function requestJson(path, method, data) {
        return request(path, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        });
    }

    return {
        getMe() {
            return request('/api/me');
        },
        getFeed(sort, page) {
            return request(`/api/feed?sort=${encodeURIComponent(sort)}&page=${page}`);
        },
        createPost(file) {
            const form = new FormData();
            form.append('image', file);
            return request('/api/posts', { method: 'POST', body: form });
        },
        like(postId) {
            return request(`/api/posts/${postId}/like`, { method: 'POST' });
        },
        unlike(postId) {
            return request(`/api/posts/${postId}/like`, { method: 'DELETE' });
        },
        share(postId, anchorCommentId) {
            return requestJson(`/api/posts/${postId}/share`, 'POST',
                anchorCommentId ? { anchor_comment_id: anchorCommentId } : {});
        },
        report(postId, reason) {
            return requestJson(`/api/posts/${postId}/report`, 'POST', { reason });
        },
        savePost(postId) {
            return request(`/api/posts/${postId}/save`, { method: 'POST' });
        },
        hidePost(postId) {
            return request(`/api/posts/${postId}/hide`, { method: 'POST' });
        },
        deletePost(postId) {
            return request(`/api/posts/${postId}`, { method: 'DELETE' });
        },
        getComments(postId, page) {
            return request(`/api/posts/${postId}/comments?page=${page}`);
        },
        postComment(postId, body) {
            return requestJson(`/api/posts/${postId}/comments`, 'POST', { body });
        },
        replyToComment(commentId, body) {
            return requestJson(`/api/comments/${commentId}/replies`, 'POST', { body });
        },
        likeComment(commentId) {
            return request(`/api/comments/${commentId}/like`, { method: 'POST' });
        },
        unlikeComment(commentId) {
            return request(`/api/comments/${commentId}/like`, { method: 'DELETE' });
        },
        reportComment(commentId, reason) {
            return requestJson(`/api/comments/${commentId}/report`, 'POST', { reason });
        },
        saveComment(commentId) {
            return request(`/api/comments/${commentId}/save`, { method: 'POST' });
        },
        hideComment(commentId) {
            return request(`/api/comments/${commentId}/hide`, { method: 'POST' });
        },
        deleteComment(commentId) {
            return request(`/api/comments/${commentId}`, { method: 'DELETE' });
        },
    };
})();
