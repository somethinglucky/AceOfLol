// ============================================================
// Comments
// ------------------------------------------------------------
// Rendering follows the spec's mockup exactly: replies are NOT
// visually indented. Instead, each reply shows a breadcrumb trail
// of its ancestors' "Nickname@handle" tags ("Bill@zZzOiYu Alice@aB3xY9 \u21C9")
// above it, and threads expand/collapse via \u2295/\u2296 rather than nesting depth.
//
// Name display goes through js/nametag.js everywhere (comment headers,
// breadcrumbs, reply placeholders) so it's identical to how posts, chat,
// and the rest of the app show names — nickname isn't unique, so the
// handle must always be shown alongside it or two people with the same
// chosen nickname become indistinguishable.
// ============================================================

const Comments = (() => {
    const commentMenuTemplate = document.getElementById('comment-menu-template');
    const composerTemplate = document.getElementById('composer-template');

    function formatCount(n) {
        return n >= 1000 ? `${(n / 1000).toFixed(1).replace(/\.0$/, '')}k` : String(n);
    }

    // ------------------------------------------------------------
    // Composer (used both for new top-level comments and replies)
    // ------------------------------------------------------------
    function buildComposer(onSubmit, placeholder) {
        const node = composerTemplate.content.firstElementChild.cloneNode(true);
        const input = node.querySelector('.composer-input');
        const send = node.querySelector('.composer-send');
        if (placeholder) input.placeholder = placeholder;

        input.addEventListener('input', () => {
            send.disabled = input.value.trim().length === 0;
        });
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !send.disabled) submit();
        });
        send.addEventListener('click', submit);

        async function submit() {
            const body = input.value.trim();
            if (!body) return;
            send.disabled = true;
            try {
                await onSubmit(body);
                input.value = '';
            } catch (err) {
                App.showToast(err.status === 401 ? 'Log in to comment' : 'Could not post comment');
            } finally {
                send.disabled = input.value.trim().length === 0;
            }
        }

        return node;
    }

    // ------------------------------------------------------------
    // A single comment node (and its collapsed/expanded replies)
    // ------------------------------------------------------------
    function renderComment(comment, postId, ancestorHandles, onCountChange) {
        const el = document.createElement('div');
        el.className = 'comment';

        if (ancestorHandles.length) {
            const breadcrumb = document.createElement('div');
            breadcrumb.className = 'comment-breadcrumb';
            breadcrumb.textContent = ancestorHandles.join(' ') + ' \u21C9';
            el.appendChild(breadcrumb);
        }

        const header = document.createElement('div');
        header.className = 'comment-header';
        header.innerHTML = `
            <span class="comment-nickname">${NameTag.html(comment.author.nickname, comment.author.handle, comment.author.isRegistered)}</span>
            <span class="comment-age">${timeAgo(comment.created_at)}</span>
        `;
        el.appendChild(header);

        const body = document.createElement('div');
        body.className = 'comment-body';
        body.textContent = comment.body;
        el.appendChild(body);

        const actions = document.createElement('div');
        actions.className = 'comment-actions';

        const likeBtn = document.createElement('button');
        likeBtn.className = 'caction-btn clike-btn';
        likeBtn.setAttribute('aria-pressed', String(comment.liked_by_viewer));
        likeBtn.innerHTML = `<span class="icon clike-icon">${comment.liked_by_viewer ? '&#9829;' : '&#9825;'}</span><span class="count">${formatCount(comment.like_count)}</span>`;
        actions.appendChild(likeBtn);

        const replyBtn = document.createElement('button');
        replyBtn.className = 'caction-btn creply-btn';
        replyBtn.innerHTML = `<span class="icon">&#9824;</span><span class="count">${comment.reply_count > 0 ? formatCount(comment.reply_count) : ''}</span>`;
        actions.appendChild(replyBtn);

        const shareBtn = document.createElement('button');
        shareBtn.className = 'caction-btn cshare-btn';
        shareBtn.innerHTML = `<span class="icon">&#9827;</span>`;
        actions.appendChild(shareBtn);

        const menuBtn = document.createElement('button');
        menuBtn.className = 'caction-btn cmenu-btn';
        menuBtn.innerHTML = `<span class="icon">&#9830;</span>`;
        actions.appendChild(menuBtn);

        let toggleBtn = null;
        if (comment.replies.length > 0) {
            toggleBtn = document.createElement('button');
            toggleBtn.className = 'caction-btn ctoggle-btn';
            toggleBtn.innerHTML = '<span class="icon">&#8853;</span>'; // collapsed by default (\u2295)
            actions.appendChild(toggleBtn);
        }

        el.appendChild(actions);

        // Reply composer slot (hidden until "Reply" tapped)
        const replySlot = document.createElement('div');
        replySlot.className = 'reply-composer-slot';
        el.appendChild(replySlot);

        // Replies container — collapsed by default, per spec
        const repliesEl = document.createElement('div');
        repliesEl.className = 'comment-replies';
        repliesEl.hidden = true;
        const childHandles = ancestorHandles.concat(NameTag.text(comment.author.nickname, comment.author.handle, comment.author.isRegistered));
        comment.replies.forEach(child => {
            repliesEl.appendChild(renderComment(child, postId, childHandles, onCountChange));
        });
        el.appendChild(repliesEl);

        // --- wire actions ---
        likeBtn.addEventListener('click', async () => {
            const wasLiked = likeBtn.getAttribute('aria-pressed') === 'true';
            const next = !wasLiked;
            likeBtn.setAttribute('aria-pressed', String(next));
            likeBtn.querySelector('.clike-icon').innerHTML = next ? '&#9829;' : '&#9825;';
            const delta = next ? 1 : -1;
            comment.like_count = Math.max(0, comment.like_count + delta);
            likeBtn.querySelector('.count').textContent = formatCount(comment.like_count);
            try {
                const result = next ? await Api.likeComment(comment.id) : await Api.unlikeComment(comment.id);
                comment.like_count = result.like_count;
                likeBtn.querySelector('.count').textContent = formatCount(result.like_count);
            } catch (err) {
                likeBtn.setAttribute('aria-pressed', String(wasLiked));
                likeBtn.querySelector('.clike-icon').innerHTML = wasLiked ? '&#9829;' : '&#9825;';
                comment.like_count = Math.max(0, comment.like_count - delta);
                likeBtn.querySelector('.count').textContent = formatCount(comment.like_count);
                App.showToast(err.status === 401 ? 'Log in to like comments' : 'Something went wrong');
            }
        });

        replyBtn.addEventListener('click', () => {
            if (replySlot.childElementCount > 0) {
                replySlot.innerHTML = '';
                return;
            }
            const composer = buildComposer(async (bodyText) => {
                const reply = await Api.replyToComment(comment.id, bodyText);
                comment.replies.push(reply);
                repliesEl.hidden = false;
                repliesEl.appendChild(renderComment(reply, postId, childHandles, onCountChange));
                comment.reply_count += 1;
                replyBtn.querySelector('.count').textContent = formatCount(comment.reply_count);
                if (!toggleBtn) {
                    toggleBtn = document.createElement('button');
                    toggleBtn.className = 'caction-btn ctoggle-btn';
                    toggleBtn.innerHTML = '<span class="icon">&#8854;</span>';
                    actions.appendChild(toggleBtn);
                    wireToggle();
                } else {
                    toggleBtn.innerHTML = '<span class="icon">&#8854;</span>'; // now expanded (\u2296)
                }
                replySlot.innerHTML = '';
                onCountChange(1);
            }, `Reply to ${NameTag.text(comment.author.nickname, comment.author.handle, comment.author.isRegistered)}\u2026`);
            replySlot.appendChild(composer);
            composer.querySelector('.composer-input').focus();
        });

        shareBtn.addEventListener('click', () => {
            Share.shareToPlatform('other', { id: postId }, document.querySelector(`.post[data-post-id="${postId}"] .post-image`), comment.id)
                .then(() => Api.share(postId, comment.id))
                .catch(() => App.showToast('Could not share'));
        });

        menuBtn.addEventListener('click', () => openCommentMenu(comment, el));

        function wireToggle() {
            toggleBtn.addEventListener('click', () => {
                const nowHidden = !repliesEl.hidden;
                repliesEl.hidden = nowHidden;
                toggleBtn.innerHTML = nowHidden
                    ? '<span class="icon">&#8853;</span>'  // collapsed \u2295
                    : '<span class="icon">&#8854;</span>'; // expanded \u2296
            });
        }
        if (toggleBtn) wireToggle();

        return el;
    }

    function openCommentMenu(comment, commentEl) {
        const sheetNode = commentMenuTemplate.content.firstElementChild.cloneNode(true);
        document.body.appendChild(sheetNode);

        const deleteBtn = sheetNode.querySelector('[data-action="delete"]');
        deleteBtn.hidden = !App.canDelete(comment.author.id);
        App.wireRelationshipButtons(sheetNode, comment.author.id);

        function close() { sheetNode.remove(); }
        sheetNode.addEventListener('click', (e) => { if (e.target === sheetNode) close(); });

        sheetNode.querySelectorAll('[data-action]').forEach(btn => {
            btn.addEventListener('click', async () => {
                const action = btn.dataset.action;
                close();
                try {
                    if (action === 'report') {
                        const reason = window.prompt('What\u2019s wrong with this comment? (optional)') || undefined;
                        await Api.reportComment(comment.id, reason);
                        App.showToast('Comment reported');
                    } else if (action === 'save') {
                        await Api.saveComment(comment.id);
                        App.showToast('Saved');
                    } else if (action === 'hide') {
                        await Api.hideComment(comment.id);
                        commentEl.remove();
                        App.showToast('Comment hidden');
                    } else if (action === 'hate') {
                        await Api.hateComment(comment.id);
                        App.showToast('Thanks for the feedback');
                    } else if (action === 'follow') {
                        await App.handleFollowAction(btn, comment.author.id);
                    } else if (action === 'block') {
                        const wasAlreadyBlocking = btn.dataset.blocking === '1';
                        const result = await App.handleBlockAction(btn, comment.author.id);
                        if (result !== 'cancelled' && !wasAlreadyBlocking) commentEl.remove();
                    } else if (action === 'delete') {
                        if (!window.confirm('Delete this comment? This can\u2019t be undone from here.')) return;
                        await Api.deleteComment(comment.id);
                        commentEl.remove();
                        App.showToast('Comment deleted');
                    }
                } catch (err) {
                    if (err.status === 403) {
                        App.showToast('You can only delete your own comments');
                    } else {
                        App.showToast(err.status === 401 ? 'Log in to do that' : 'Something went wrong');
                    }
                }
            });
        });
    }

    // ------------------------------------------------------------
    // Section entry point — called once per post, first time the
    // ♠ comments button is tapped. Fetches page 0 and renders the
    // composer + top-level threads + "View more" if applicable.
    // ------------------------------------------------------------
    async function open(post, sectionEl, onCountChange) {
        sectionEl.innerHTML = '';
        sectionEl.classList.add('comment-section-active');

        const listEl = document.createElement('div');
        listEl.className = 'comment-list';

        const newComposer = buildComposer(async (bodyText) => {
            const comment = await Api.postComment(post.id, bodyText);
            listEl.appendChild(renderComment(comment, post.id, [], onCountChange));
            onCountChange(1);
        }, 'Add a comment\u2026');

        sectionEl.appendChild(newComposer);
        sectionEl.appendChild(listEl);

        const loadMoreBtn = document.createElement('button');
        loadMoreBtn.className = 'view-more-btn';
        loadMoreBtn.textContent = 'View more comments';
        loadMoreBtn.hidden = true;
        sectionEl.appendChild(loadMoreBtn);

        let page = 0;

        async function loadPage() {
            const data = await Api.getComments(post.id, page);
            data.comments.forEach(comment => {
                listEl.appendChild(renderComment(comment, post.id, [], onCountChange));
            });
            loadMoreBtn.hidden = !data.has_more;
            page += 1;
        }

        loadMoreBtn.addEventListener('click', () => {
            loadMoreBtn.disabled = true;
            loadPage().finally(() => { loadMoreBtn.disabled = false; });
        });

        try {
            await loadPage();
        } catch (err) {
            listEl.textContent = 'Could not load comments.';
        }
    }

    return { open };
})();
