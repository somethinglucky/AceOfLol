// ============================================================
// Relative time formatting — matches the spec's examples exactly:
// "2 sec ago", "1 hr ago", "23 mo ago", "2 yrs ago"
// ============================================================

function timeAgo(isoString) {
    // SQLite's datetime('now') returns UTC without a timezone suffix;
    // append 'Z' so the browser parses it as UTC, not local time.
    const normalized = /Z|[+-]\d\d:\d\d$/.test(isoString) ? isoString : isoString.replace(' ', 'T') + 'Z';
    const then = new Date(normalized).getTime();
    const seconds = Math.max(0, Math.floor((Date.now() - then) / 1000));

    const units = [
        { limit: 60, div: 1, singular: 'sec', plural: 'sec' },
        { limit: 3600, div: 60, singular: 'min', plural: 'min' },
        { limit: 86400, div: 3600, singular: 'hr', plural: 'hrs' },
        { limit: 86400 * 30, div: 86400, singular: 'day', plural: 'days' },
        { limit: 86400 * 365, div: 86400 * 30, singular: 'mo', plural: 'mo' },
        { limit: Infinity, div: 86400 * 365, singular: 'yr', plural: 'yrs' },
    ];

    for (const unit of units) {
        if (seconds < unit.limit) {
            const value = Math.max(1, Math.floor(seconds / unit.div));
            const label = value === 1 ? unit.singular : unit.plural;
            return `${value} ${label} ago`;
        }
    }
    return 'just now';
}
