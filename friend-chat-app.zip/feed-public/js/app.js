// ============================================================
// Main feed application
// ============================================================

const App = (() => {
    const feedEl = document.getElementById('feed');
    const feedEmptyEl = document.getElementById('feed-empty');
    const sortPostBar = document.getElementById('sort-post-bar');
    const sortBtn = document.getElementById('sort-btn');
    const sortLabel = document.getElementById('sort-label');
    const sortMenu = document.getElementById('sort-menu');
    const postBtn = document.getElementById('post-btn');
    const fileInput = document.getElementById('file-input');
    const backBtn = document.getElementById('back-btn');
    const menuBtn = document.getElementById('menu-btn');
    const toastEl = document.getElementById('upload-toast');
    const postTemplate = document.getElementById('post-template');
    const shareSheetTemplate = document.getElementById('share-sheet-template');
    const postMenuTemplate = document.getElementById('post-menu-template');
    const appMenuTemplate = document.getElementById('app-menu-template');

    let sort = 'new';
    let page = 0;
    let loading = false;
    let reachedEnd = false;
    let currentUser = null; // { id, handle, nickname, isRegistered, isModerator } | null (guest/logged-out)

    // ------------------------------------------------------------
    // Toast
    // ------------------------------------------------------------
    let toastTimer = null;
    function showToast(message) {
        toastEl.textContent = message;
        toastEl.hidden = false;
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => { toastEl.hidden = true; }, 2200);
    }

    // ------------------------------------------------------------
    // Back button
    // ------------------------------------------------------------
    // Was relying on history.back() plus a nav-depth counter the main app
    // never actually wrote to — fragile (nothing guarantees a same-origin
    // history entry exists behind this page, e.g. a fresh tab, a home-screen
    // PWA launch, or a bookmark straight into /feed/). Since this page is
    // only ever reached from the main app's chat screen, a direct, always-
    // correct navigation back there is simpler and can't silently fail.
    function initBackButton() {
        backBtn.addEventListener('click', () => {
            window.location.href = '/';
        });
    }

    // ------------------------------------------------------------
    // Main app menu — mirrors frontend/src/components/MenuDrawer.jsx.
    // Every item except "Memes" (already here) is a full page navigation
    // back into the React app, landing on the requested page via the
    // `?page=` query param App.jsx reads on load.
    // ------------------------------------------------------------
    function initMenu() {
        menuBtn.addEventListener('click', openAppMenu);
    }

    function openAppMenu() {
        const node = appMenuTemplate.content.firstElementChild.cloneNode(true);
        document.body.appendChild(node);

        const adminBtn = node.querySelector('[data-role="admin"]');
        const modBtn = node.querySelector('[data-role="moderator"]');
        adminBtn.hidden = !(currentUser && currentUser.isAdmin);
        // isAdmin implies isModerator (see backend/src/middleware/auth.js),
        // so an admin sees both items here too, same as the React menu.
        modBtn.hidden = !(currentUser && currentUser.isModerator);

        function close() { node.remove(); }
        node.addEventListener('click', (e) => { if (e.target === node) close(); });
        node.querySelector('.app-menu-close').addEventListener('click', close);

        node.querySelectorAll('.app-menu-item').forEach((btn) => {
            btn.addEventListener('click', () => {
                const targetPage = btn.dataset.page;
                close();
                if (targetPage === 'feed') return; // already here
                window.location.href = `/?page=${encodeURIComponent(targetPage)}`;
            });
        });
    }

    // ------------------------------------------------------------
    // Sort/post bar: hides on scroll down, reappears scrolling up
    // ------------------------------------------------------------
    function initScrollHide() {
        let lastY = window.scrollY;
        let ticking = false;
        window.addEventListener('scroll', () => {
            if (ticking) return;
            ticking = true;
            requestAnimationFrame(() => {
                const y = window.scrollY;
                const scrollingDown = y > lastY;
                if (y < 40) {
                    sortPostBar.classList.remove('hidden');
                } else if (scrollingDown) {
                    sortPostBar.classList.add('hidden');
                } else {
                    sortPostBar.classList.remove('hidden');
                }
                lastY = y;
                ticking = false;
            });
        }, { passive: true });
    }

    // ------------------------------------------------------------
    // Sort dropdown
    // ------------------------------------------------------------
    function initSortMenu() {
        sortBtn.addEventListener('click', () => {
            const isOpen = !sortMenu.hidden;
            sortMenu.hidden = isOpen;
            sortBtn.setAttribute('aria-expanded', String(!isOpen));
        });

        sortMenu.addEventListener('click', (e) => {
            const item = e.target.closest('[data-sort]');
            if (!item) return;
            setSort(item.dataset.sort, item.textContent);
            sortMenu.hidden = true;
            sortBtn.setAttribute('aria-expanded', 'false');
        });

        document.addEventListener('click', (e) => {
            if (!sortMenu.hidden && !e.target.closest('.sort-wrap')) {
                sortMenu.hidden = true;
                sortBtn.setAttribute('aria-expanded', 'false');
            }
        });

        Array.from(sortMenu.children).forEach(li => {
            li.setAttribute('aria-selected', li.dataset.sort === sort ? 'true' : 'false');
        });
    }

    function setSort(newSort, label) {
        if (newSort === sort) return;
        sort = newSort;
        sortLabel.textContent = label;
        Array.from(sortMenu.children).forEach(li => {
            li.setAttribute('aria-selected', li.dataset.sort === sort ? 'true' : 'false');
        });
        resetFeed();
        loadNextPage();
    }

    // ------------------------------------------------------------
    // Feed rendering
    // ------------------------------------------------------------
    function resetFeed() {
        feedEl.innerHTML = '';
        page = 0;
        reachedEnd = false;
        feedEmptyEl.hidden = true;
    }

    function formatCount(n) {
        return n >= 1000 ? `${(n / 1000).toFixed(1).replace(/\.0$/, '')}k` : String(n);
    }

    function renderPost(post) {
        const node = postTemplate.content.firstElementChild.cloneNode(true);
        node.dataset.postId = post.id;

        const img = node.querySelector('.post-image');
        // Setting both the CSS aspect-ratio (on the wrapper) and the width/
        // height attributes (on the <img> itself) means the browser reserves
        // the correct final space immediately, before the image bytes have
        // even started downloading. Without this, a photo loads in at
        // whatever size the browser initially guesses, then snaps to its
        // real size once it arrives — and if that photo is above what
        // you're currently looking at (very likely while scrolling through
        // a bunch of posts you just uploaded), that snap shoves your scroll
        // position around, which is exactly the jumpiness being reported.
        if (post.image_width && post.image_height) {
            node.querySelector('.post-media').style.aspectRatio = `${post.image_width} / ${post.image_height}`;
            img.width = post.image_width;
            img.height = post.image_height;
        }
        img.src = post.image_url;
        img.alt = `Post by ${NameTag.text(post.author.nickname, post.author.handle, post.author.isRegistered)}`;

        node.querySelector('.post-avatar').src = post.author.avatar_url || '';
        node.querySelector('.post-nickname').innerHTML = NameTag.html(post.author.nickname, post.author.handle, post.author.isRegistered);
        node.querySelector('.post-age').textContent = timeAgo(post.created_at);

        const likeBtn = node.querySelector('.like-btn');
        const likeIcon = node.querySelector('.like-icon');
        const likeCount = node.querySelector('.like-count');
        likeBtn.setAttribute('aria-pressed', String(post.liked_by_viewer));
        likeIcon.innerHTML = post.liked_by_viewer ? '&#9829;' : '&#9825;';
        likeCount.textContent = formatCount(post.like_count);

        node.querySelector('.comment-count').textContent = formatCount(post.comment_count);
        node.querySelector('.share-count').textContent = formatCount(post.share_count);

        wirePostActions(node, post);
        feedEl.appendChild(node);
    }

    function wirePostActions(node, post) {
        const likeBtn = node.querySelector('.like-btn');
        const likeIcon = node.querySelector('.like-icon');
        const likeCount = node.querySelector('.like-count');

        likeBtn.addEventListener('click', async () => {
            const currentlyLiked = likeBtn.getAttribute('aria-pressed') === 'true';
            const nextLiked = !currentlyLiked;
            const delta = nextLiked ? 1 : -1;

            // Optimistic update
            likeBtn.setAttribute('aria-pressed', String(nextLiked));
            likeIcon.innerHTML = nextLiked ? '&#9829;' : '&#9825;';
            const newCount = Math.max(0, Number(post.like_count) + delta);
            post.like_count = newCount;
            likeCount.textContent = formatCount(newCount);

            try {
                const result = nextLiked ? await Api.like(post.id) : await Api.unlike(post.id);
                post.like_count = result.like_count;
                likeCount.textContent = formatCount(result.like_count);
            } catch (err) {
                // Revert on failure
                likeBtn.setAttribute('aria-pressed', String(currentlyLiked));
                likeIcon.innerHTML = currentlyLiked ? '&#9829;' : '&#9825;';
                post.like_count = Math.max(0, newCount - delta);
                likeCount.textContent = formatCount(post.like_count);
                if (err.status === 401) {
                    showToast('Log in to like posts');
                } else {
                    showToast('Something went wrong');
                }
            }
        });

        // Comments: lazy-loaded on first open, matching the spec's
        // "expands directly beneath that post within the feed" behavior.
        const commentBtn = node.querySelector('.comment-btn');
        const commentCountEl = node.querySelector('.comment-count');
        const commentSection = node.querySelector('.comment-section');
        commentBtn.addEventListener('click', () => {
            const opening = commentSection.hidden;
            commentSection.hidden = !opening;
            if (opening && !commentSection.dataset.loaded) {
                commentSection.dataset.loaded = 'true';
                Comments.open(post, commentSection, (delta) => {
                    post.comment_count = (post.comment_count || 0) + delta;
                    commentCountEl.textContent = formatCount(post.comment_count);
                });
            }
        });

        node.querySelector('.share-btn').addEventListener('click', () => openShareSheet(post, node.querySelector('.post-image'), node.querySelector('.share-count')));
        node.querySelector('.menu-btn-post').addEventListener('click', () => openPostMenu(post, node));
    }

    // ------------------------------------------------------------
    // Share sheet
    // ------------------------------------------------------------
    function openShareSheet(post, imgEl, shareCountEl) {
        const sheetNode = shareSheetTemplate.content.firstElementChild.cloneNode(true);
        document.body.appendChild(sheetNode);

        function close() { sheetNode.remove(); }

        sheetNode.addEventListener('click', (e) => {
            if (e.target === sheetNode) close(); // backdrop tap
        });

        sheetNode.querySelectorAll('[data-share]').forEach(btn => {
            btn.addEventListener('click', async () => {
                const kind = btn.dataset.share;
                close();
                if (kind === 'cancel') return;
                try {
                    await Share.shareToPlatform(kind, post, imgEl);
                    const result = await Api.share(post.id);
                    post.share_count = result.share_count;
                    shareCountEl.textContent = formatCount(result.share_count);
                } catch (err) {
                    if (err && err.name === 'AbortError') return; // user cancelled native sheet
                    showToast('Could not complete share');
                }
            });
        });
    }

    // ------------------------------------------------------------
    // Identity — who's viewing, so menus know whether to offer Delete.
    // Fetched once at load; guests/failed fetches just leave it null,
    // which correctly hides every owner/moderator-only control.
    // ------------------------------------------------------------
    async function loadCurrentUser() {
        try {
            const { user } = await Api.getMe();
            currentUser = user;
        } catch (err) {
            currentUser = null;
        }
    }

    function canDelete(authorId) {
        return !!currentUser && (currentUser.id === authorId || currentUser.isModerator);
    }

    // ------------------------------------------------------------
    // Post menu (report / save / hide / delete)
    // ------------------------------------------------------------
    function openPostMenu(post, postNode) {
        const sheetNode = postMenuTemplate.content.firstElementChild.cloneNode(true);
        document.body.appendChild(sheetNode);

        const deleteBtn = sheetNode.querySelector('[data-action="delete"]');
        deleteBtn.hidden = !canDelete(post.author.id);

        function close() { sheetNode.remove(); }
        sheetNode.addEventListener('click', (e) => { if (e.target === sheetNode) close(); });

        sheetNode.querySelectorAll('[data-action]').forEach(btn => {
            btn.addEventListener('click', async () => {
                const action = btn.dataset.action;
                close();
                try {
                    if (action === 'report') {
                        const reason = window.prompt('What\u2019s wrong with this post? (optional)') || undefined;
                        await Api.report(post.id, reason);
                        showToast('Post reported');
                    } else if (action === 'save') {
                        await Api.savePost(post.id);
                        showToast('Saved');
                    } else if (action === 'hide') {
                        await Api.hidePost(post.id);
                        postNode.remove();
                        showToast('Post hidden');
                    } else if (action === 'delete') {
                        if (!window.confirm('Delete this post? This can\u2019t be undone from here.')) return;
                        await Api.deletePost(post.id);
                        postNode.remove();
                        showToast('Post deleted');
                    }
                } catch (err) {
                    if (err.status === 401) {
                        showToast('Log in to do that');
                    } else if (err.status === 403) {
                        showToast('You can only delete your own posts');
                    } else {
                        showToast('Something went wrong');
                    }
                }
            });
        });
    }

    // ------------------------------------------------------------
    // Infinite scroll
    // ------------------------------------------------------------
    async function loadNextPage() {
        if (loading || reachedEnd) return;
        loading = true;
        try {
            const data = await Api.getFeed(sort, page);
            if (data.posts.length === 0) {
                reachedEnd = true;
                if (page === 0) feedEmptyEl.hidden = false;
                return;
            }
            data.posts.forEach(renderPost);
            page += 1;
        } catch (err) {
            showToast('Could not load feed');
        } finally {
            loading = false;
        }
    }

    function initInfiniteScroll() {
        const sentinel = document.createElement('div');
        sentinel.style.height = '1px';
        feedEl.after(sentinel);
        const observer = new IntersectionObserver((entries) => {
            if (entries[0].isIntersecting) loadNextPage();
        }, { rootMargin: '600px' });
        observer.observe(sentinel);
    }

    // ------------------------------------------------------------
    // Posting
    // ------------------------------------------------------------
    function initPosting() {
        postBtn.addEventListener('click', () => fileInput.click());
        fileInput.addEventListener('change', async () => {
            const file = fileInput.files[0];
            fileInput.value = '';
            if (!file) return;

            showToast('Posting\u2026');
            try {
                const post = await Api.createPost(file);
                showToast('Posted');
                // Per spec, new posts always land in "New" regardless of
                // which sort the poster is currently viewing; only splice
                // it into the visible feed if that's the sort in view.
                if (sort === 'new') {
                    const node = postTemplate.content.firstElementChild.cloneNode(true);
                    feedEl.prepend(node);
                    // Reuse renderPost's fill logic by removing the just-added
                    // empty node and rendering properly at the top.
                    node.remove();
                    prependPost(post);
                }
            } catch (err) {
                if (err.status === 401) {
                    showToast('Log in to post');
                } else {
                    showToast(err.message || 'Upload failed');
                }
            }
        });
    }

    function prependPost(post) {
        const node = postTemplate.content.firstElementChild.cloneNode(true);
        node.dataset.postId = post.id;
        const img = node.querySelector('.post-image');
        if (post.image_width && post.image_height) {
            node.querySelector('.post-media').style.aspectRatio = `${post.image_width} / ${post.image_height}`;
            img.width = post.image_width;
            img.height = post.image_height;
        }
        img.src = post.image_url;
        img.alt = `Post by ${NameTag.text(post.author.nickname, post.author.handle, post.author.isRegistered)}`;
        node.querySelector('.post-avatar').src = post.author.avatar_url || '';
        node.querySelector('.post-nickname').innerHTML = NameTag.html(post.author.nickname, post.author.handle, post.author.isRegistered);
        node.querySelector('.post-age').textContent = timeAgo(post.created_at || new Date().toISOString());
        node.querySelector('.like-count').textContent = '0';
        node.querySelector('.comment-count').textContent = '0';
        node.querySelector('.share-count').textContent = '0';
        wirePostActions(node, post);
        feedEl.prepend(node);
    }

    // ------------------------------------------------------------
    // Init
    // ------------------------------------------------------------
    function init() {
        initBackButton();
        initMenu();
        initScrollHide();
        initSortMenu();
        initPosting();
        initInfiniteScroll();
        loadCurrentUser();
        loadNextPage();
    }

    document.addEventListener('DOMContentLoaded', init);

    return { showToast, canDelete, getCurrentUser: () => currentUser };
})();
