# AceOfLol — Project Handoff (v2)

This is sj's mobile-only web app: a platonic friend-making chatroom app
with a Memes feed, DMs, follow/block/report, and an admin/moderator
system — all built from sj's phone across several very long Claude
conversations that kept needing to be split up for context reasons.

**This document is the map. The attached `friend-chat-app.zip` is the
actual current code.** Read this first, then dig into the zip for exact
implementation details before writing anything. If anything here and the
code disagree, trust the code — this doc is a snapshot, not a live source
of truth.

## Working style — read this before doing anything else

- **sj has no computer, builds entirely from a phone** via Termius (SSH
  app) and GitHub's mobile web upload flow. **The real deploy flow is
  `git pull` THEN `unzip -o friend-chat-app.zip`** — the zip itself is
  committed to the repo, and `git pull` alone does NOT update the actual
  source files pm2/nginx serve. This was the cause of a whole multi-turn
  debugging saga earlier — every deploy walkthrough must include the
  unzip step explicitly, spelled out as copy-pasteable commands, one
  step at a time. Never assume a step is obvious; sj is learning git,
  nginx, pm2, and Linux permissions as we go.
- **Give plain-text deploy instructions, not just interactive step
  cards** — sj has hit at least one client-side rendering issue where
  interactive cards ("Couldn't load this. Reload the page to continue.")
  failed to display and reloading didn't fix it. Since then, deploy
  steps get written out as plain numbered text in the message body too,
  not only via the step-card tool, so they're never blocked on a UI
  feature working.
- **sj is warm, enthusiastic, and genuinely technical-but-new** — explain
  *why*, not just *what*. Expect to troubleshoot real terminal output.
- **Test everything before shipping it.** This project has a real,
  hard-won lesson behind it: a `str_replace` edit once silently deleted a
  `const likeBtn = ...` declaration while inserting an unrelated feature,
  which broke the entire Memes feed in production. `node --check` (syntax
  only) did NOT catch it — it was a runtime `ReferenceError`. Since then,
  the standard is: for backend changes, actually start the server and hit
  the endpoints (curl scripts work well, see pattern in git history /
  ask if unsure); for feed (plain JS) changes, actually execute the code
  in a jsdom harness with fake data and check the real rendered DOM
  output, not just read the diff. Reading the code is not enough by
  itself — prove it runs.
- **Infra**: DigitalOcean droplet, Ubuntu, 1GB RAM + 1GB swap (native
  module compiles like better-sqlite3/sharp can OOM-crash `npm install`
  without the swap — rerun `npm install` if that happens, it's not a new
  problem). Domain `aceof.lol`, proxied through **Cloudflare** — SSL mode
  and DNS live there, and **Cloudflare's cache must be purged** (Caching →
  Configuration → Purge Everything) after most deploys or sj will see
  stale content. nginx serves the built frontend + proxies `/api/` +
  serves the feed's static files at `/feed/` + serves uploaded images at
  `/media/`. Backend runs via **pm2** as process name `friend-chat-app`.
  Repo lives at `/var/www/aceoflol` (NOT `/root/` — nginx's `www-data`
  user can't read `/root`).
- **Every new backend route prefix needs an explicit nginx `location`
  block**, or requests silently fall through to `try_files` and return
  the React app's HTML instead of JSON. So far `/api/`, `/feed/`, and
  `/media/` are covered — a genuinely new top-level prefix (not under
  `/api/`) would need a new block + telling sj to redeploy nginx config.

## Stack

- **Backend**: Node/Express, better-sqlite3 (single SQLite file,
  `backend/data/app.db`), Socket.IO for real-time chat AND DMs, JWT auth,
  bcrypt for passwords.
- **Frontend**: React + Vite + Tailwind, mobile-only PWA-style SPA. No
  router library — plain state-based page switching in `App.jsx`, kept in
  sync with a `?page=` URL param (via `history.replaceState`) so a reload
  or iOS's silent backgrounded-tab reload restores the same page instead
  of always dropping to Chat. `?viewProfile=<userId>` is a second,
  independent param used to open the profile overlay on load (see below).
  lucide-react for icons.
- **Feed ("Memes")**: a separately-built, self-contained static module
  (plain HTML/CSS/JS, no framework, no build step) at `feed-public/`,
  integrated into the same backend/database but served by nginx directly
  at `/feed/`. Navigating to it from the React menu is a real
  `window.location.href` page load, not client-side routing.

## Auth model

- **One `users` table for both guests and registered accounts** — same
  row; guests have `email`/`password_hash` = NULL and `is_registered = 0`.
  Registering later `UPDATE`s the SAME row (`backend/src/routes/auth.js`
  `/register`) — same id, same handle, same history.
- **Handles**: 7-character letters-only (upper + lower case, NO digits —
  the original generator wrongly included digits; this was found and
  fixed, plus `backend/scripts/fix-handles.js` exists to regenerate any
  already-issued handle that still has a digit in it), auto-generated,
  immutable, unique. Displayed EVERYWHERE as `Nickname@handle` — nickname
  prominent, handle smaller/muted — via a shared `NameTag` React component
  and `feed-public/js/nametag.js`. Handle is the disambiguator since
  nicknames are NOT unique and can collide.
- **Guests get a handle instantly** the moment they first send a chat
  message (`LandingPage.jsx`) — no signup needed to watch/post in
  `#everyone`. But guests are blocked from: posting to the feed, DMs,
  follow/block/report actions, and the admin/moderator dashboards.
- **Sign up / log in**: top-left button says "Sign Up/In" (was
  previously mislabeled "Register" and — this was a real bug — hard-
  locked anyone with an existing guest identity into register-only mode
  with the login toggle hidden entirely; fixed in `AuthPage.jsx` so login
  is always reachable). Guests tapping "My Profile" in the menu are sent
  to this same auth page instead of the profile editor, since a guest has
  no registered profile yet.
- **Three auth middleware functions** in `backend/src/middleware/auth.js`:
  `requireAuth` (any valid token, guest or registered — used where guests
  can act on their own stuff), `optionalAuth` (attaches `req.user` if
  present, never blocks — applied to the whole `/api` prefix), and
  `requireRegistered` (403s guests). Plus `requireAdmin` (403s anyone
  whose `role !== 'admin'`).
- **Roles**: `users.role` is `'user' | 'moderator' | 'admin'` (a single
  column, not separate booleans — admin is treated as a superset of
  moderator everywhere: `isModerator = role IN ('moderator','admin')`).
  `users.is_bot` is a separate, orthogonal flag for labeling an account as
  an automated moderator later — it doesn't change permissions by itself.
  Promoting/demoting happens via the **Admin Dashboard** (`/admin` page,
  gated both client-side for UX and server-side via `requireAdmin` on
  every `/api/admin/*` route) — search by handle, set role, toggle bot
  flag, self-demotion blocked. **No bootstrap admin exists on a fresh
  droplet** — the very first admin has to be set by hand:
  `node -e "require('./src/db/connection').prepare('UPDATE users SET role=? WHERE public_handle=?').run('admin','theirHandle')"`
  from inside `backend/`.
- Tokens are JWTs (`JWT_SECRET` in `.env`, 30-day expiry), read from
  `Authorization: Bearer <token>`. Frontend stores it in
  `localStorage.getItem('token')`. The feed's static JS uses the exact
  same key/header convention.

## Database — migrations, not a single schema.sql

**There IS a real migration system now** (this used to be a known gap —
it's fixed). `backend/src/db/schema.sql` is a dead file (just a pointer
comment) — the real schema lives as numbered files in
`backend/src/db/migrations/`, applied automatically on every backend
startup by `backend/src/db/migrate.js` (tracked in a `schema_migrations`
table, each file applied at most once, in filename order). **Read
`backend/src/db/migrations/README.md` before writing a new migration** —
short version: new file `NNN_description.sql`, never edit an
already-shipped one, SQLite can't drop/rename columns via `ALTER TABLE`
(needs the rebuild-the-table dance if that's ever needed).

Current migrations and what they did:
1. `001_baseline.sql` — original schema snapshot (users, profiles,
   rooms/messages, the full feed schema: posts/comments/likes/
   hides/reports/saves, swipes/matches [defined, swipe UI never built],
   subscriptions [defined, billing never built]).
2. `002_add_moderator_flag.sql` — `users.is_moderator` (superseded by 003).
3. `003_add_role_hierarchy.sql` — `users.role` + `users.is_bot`,
   migrating any existing `is_moderator=1` forward.
4. `004_add_follows_blocks_hates.sql` — `follows`, `blocks` (directed,
   canonical-pair-free — these are NOT pair-unique like DMs, just
   directed edges), `content_hates` (log-only "Hate this" signal, no UI
   reads it yet — it's for a future admin stats dashboard).
5. `005_add_dms.sql` — `dm_threads` (one row per pair, canonically
   ordered `user_a_id < user_b_id` so there's exactly one thread per
   pair), `dm_messages`, `dm_thread_hides`, `dm_thread_clears` (the
   "Delete" action — stores a message-id watermark, NOT a timestamp,
   specifically because SQLite's `datetime('now')` only has second
   precision and a clear+same-second-reply would otherwise tie and stay
   incorrectly hidden — this was a real bug caught by testing),
   `dm_thread_reports`.
6. `006_add_user_reports.sql` — `user_reports`, for reporting a PERSON
   directly (from their profile's ♦ menu), distinct from post/comment/
   DM-thread reports which already existed.

All user-facing ids are TEXT UUIDs; post/comment/message ids are
`INTEGER AUTOINCREMENT` (fine, they're internal).

## What's built and working

1. **Chat** — Socket.IO, `#everyone` open to guests. Auto-rejoin on
   reconnect via `frontend/src/api/socket.js`'s `joinRoom`/`leaveRoom`
   helpers (always use these, never raw `socket.emit`, or messages go
   stale on mobile reconnects). Tapping a name OR avatar on someone
   else's message opens their profile (see Profile-viewing below).
2. **Landing page** — guest-minting "watch first, join instantly" hook.
3. **Full profile system** — dating-style optional fields, one photo
   (upload mechanism still NOT built — profile photo uploads are a real
   gap, see below), per-profile display color/font distinct from the
   viewer's own app theme.
4. **Search** — filter registered users by profile fields. (Not
   currently wired to open a full profile on tap — a real, if minor,
   gap; see below.)
5. **The feed ("Memes")** — posts with images (local disk storage via
   `backend/src/storage/feedStorage.js`, meant to move to cloud storage
   eventually, same deferred status as profile photos), likes, threaded
   comments (breadcrumb-trail style, not indentation — see
   `feed-public/js/comments.js`'s doc comment), sort tabs. Image
   dimensions are sent from upload time and used to reserve layout space
   client-side (`aspect-ratio` + width/height attrs) specifically to
   prevent scroll-jumping when images load late — this was a real
   reported bug, now fixed in both `renderPost` and `prependPost`.
6. **The ♦ sub-menu** (posts and comments) — now fully matches the
   original spec: **Follow, Save, Hide, Hate this, Report, Block,
   Delete** (Delete only shown to the post/comment's own author or a
   moderator), Cancel. Follow/Block buttons fetch live relationship
   state when the menu opens and show Follow/Unfollow, Block/Unblock
   accordingly.
7. **Follow / Block** — ONE shared system (`follows`/`blocks` tables,
   `backend/src/routes/relationships.js`, mounted at
   `/api/users/:userId/...`), used identically from the feed's ♦ menu
   AND from `ProfileCard`. Blocking auto-removes any existing follow
   between the two people in both directions, and blocks a
   follow-attempt in either direction while a block exists. Feed queries
   (`feed/feed.js`, `feed/comments.js`) filter out blocked users' content
   in BOTH directions using a `NOT IN (SELECT ...)` subquery pattern
   (with an empty-string sentinel for anonymous viewers) — verified with
   a real integration test, not just read.
8. **"Hate this"** — log-only (`content_hates` table), explicitly has NO
   effect on what anyone sees, exists purely for a future admin stats
   view sj wants eventually.
9. **Reporting** — three separate, parallel systems by design (not
   consolidated, since they report different things): `post_reports` /
   `comment_reports` (pre-existing, content-level), `dm_thread_reports`
   (a conversation), `user_reports` (a person, via their profile's ♦
   menu). None have an admin review UI yet — they're logged only.
10. **Direct Messages** — real-time via Socket.IO
    (`backend/src/sockets/dmHandlers.js`, mirroring chat's join/send
    pattern almost exactly). **Important design point**: the Socket.IO
    room is keyed by the canonical user PAIR (`dm:<a>:<b>`), NOT by the
    thread's database id — this was a real bug found by testing: keying
    by thread id meant the recipient of a brand-new conversation's first
    message (who joined before any thread/row existed) never actually
    joined any room and missed the live push. Inbox listing, hide/unhide
    (reversible, recoverable via `GET /api/dms/hidden` — Settings has NO
    UI for this yet, unlike hidden posts, see gaps below), clear/"Delete"
    (NOT reversible via a list, but auto-reappears if the other person
    messages again — that's the point of the message-id watermark), and
    report are all plain REST (`backend/src/routes/dms.js`). Guests are
    blocked from all of it, both client-side and server-side (both REST
    and the socket handler check `is_registered`). Blocked users can't
    message each other, but existing thread history stays fully visible/
    manageable by either party (hide/report/delete still work).
    **"Likes" (the other half of the "DM's & Likes" menu item) is NOT
    built** — that's tied to the future Discover/swipe feature.
11. **Profile-viewing, from anywhere** — `ProfileCard` was lifted out of
    `ChatPage` to live as a single top-level overlay in `App.jsx`,
    controlled by a `viewProfile` state and a shared `handleViewProfile`
    handler threaded into every page that needs it (chat messages — both
    avatar and nickname are clickable; DM conversation headers; the feed,
    which is a separate static app and reaches in via a
    `?viewProfile=<userId>` URL param that gets consumed once on load).
12. **Profile action row** — below the picture and Nickname@handle, one
    full-width row of exactly 4 unicode-symbol buttons, no numbers/counts
    shown anywhere: **♡/♥** (follow/unfollow toggle — heart fills in when
    following), **♠** (message this person — opens/starts a DM thread),
    **♣** (invite to a game or virtual date — a stub `window.alert`, the
    game system doesn't exist yet), **♦** (opens a small dropdown: Send
    Gift [stub, not built], Block/Unblock, Report). Follow/Message are
    disabled (greyed, with a `title` tooltip) rather than hidden when the
    viewed person has blocked you, so the row's width stays consistent.
13. **Admin Dashboard** (`/admin` page) — search users by handle, set
    role, toggle bot flag. **Moderation Dashboard** (`/moderation` page)
    exists as a real page with the correct access gate but is an EMPTY
    placeholder — no actual moderation tools built into it yet (that's a
    natural next step: surfacing the various `*_reports` tables, hidden/
    deleted content, etc.).
14. **Menu system** — hamburger menu is role-aware: a regular user sees
    the 12-item list (My Profile, DM's & Likes, Chat, Memes, Store,
    Premium, Search, Discover, Games, Settings, About, Review); a
    moderator additionally sees **Moderation** above My Profile; an admin
    additionally sees **Admin** above that. Same logic duplicated
    correctly in both the React `MenuDrawer.jsx` and the feed's own
    plain-JS drawer (`feed-public/index.html`'s `app-menu-template` +
    `app.js`'s `openAppMenu`) — the two are NOT the same component and
    must be kept in sync by hand if the item list ever changes again.
    Unbuilt menu destinations (Store, Premium, Discover, Games, About,
    Review) land on a real `ComingSoonPage` (has the full menu, never a
    dead end) rather than a blank page.
15. **Settings page** — currently just has a "Hidden posts" section
    (view/unhide posts you've hidden from the feed). Does NOT yet have
    the equivalent for hidden DM conversations, even though the backend
    endpoint (`GET /api/dms/hidden`) already exists for it — see gaps.
16. **pm2/native-module stability** — graceful SIGTERM/SIGINT shutdown in
    `server.js` (closes the socket server + db cleanly) AND
    `better-sqlite3` bumped to `^13.0.0` (from `^11.3.0`) were BOTH
    needed to fully resolve a native crash
    (`Assertion failed: (env) != nullptr`) that used to spam the pm2
    error log on every single restart — this was actually a Node 24.19.0
    regression breaking the addon style `better-sqlite3@11.x` used;
    upgrading past it was the real fix, not just the graceful shutdown.

## Known gaps / natural next steps

Roughly in the order they'd probably come up:

- **Moderation Dashboard has no actual content yet** — reports
  (post/comment/DM-thread/user), hidden/deleted content review, "Hate
  this" stats — all logged already, nothing surfaces them.
- **Hidden DM conversations have no Settings UI** — the backend
  (`GET /api/dms/hidden`) is ready; Settings just needs a section like
  the existing "Hidden posts" one.
- **Profile photo upload** — profiles support one photo but there's no
  upload mechanism built (same deferred status as when this doc was
  first written).
- **Search doesn't link to full profiles** — tapping a search result
  doesn't currently open `ProfileCard`; every other surface (chat, feed,
  DMs) does now, search is the one that got missed.
- **Store, Discover, Games, Premium, About, Review** — all still
  `ComingSoonPage` stubs, zero design conversation had yet. Store is
  deliberately left visible ("coming soon") rather than hidden, to build
  hype — sj has no products yet.
- **"Likes" half of "DM's & Likes"** — waits on the Discover/swipe
  feature (schema for `swipes`/`matches` already exists from the very
  original baseline, unused).
- **Automated bot moderator** — sj wants at least one eventually. Design
  is already accommodated (`is_bot` flag + `role='moderator'`, same
  account, same endpoints) but nothing beyond the flag exists — an
  actual bot needs a way to authenticate without an interactive login
  (a generated long-lived API token from the dashboard, most likely).
- **Send Gift / game invites** — both explicitly stubbed
  (`window.alert`), no monetization or game system underneath.
- **Cloud image storage** — feed images are local disk on the droplet;
  moving to something like DigitalOcean Spaces was flagged as worth
  doing "eventually" a while back and still hasn't happened.

## Suggested first question to ask sj

Given how much is already built, it's worth just asking plainly which of
the above gaps (or something not listed here) sj wants to tackle next,
rather than guessing — this project has consistently gone well when
scope gets confirmed with a quick question or two before diving in, and
gone sideways on the few occasions something was assumed instead
(the Search/Premium menu items, "Hate this"'s meaning, and the deploy
flow's missing `unzip -o` step were all real examples of this both
going right and, once, going expensively wrong).
