# AceOfLol — Project Handoff for New Features

This is a mobile-only web app (platonic friend-making chat + dating-style
profiles + a memes feed), built entirely from sj's phone across a very long
conversation with Claude. That conversation is being split up for context
reasons — **this document is the map; the attached `friend-chat-app.zip` is
the actual current code.** Read this first, then dig into the zip for
exact implementation details before writing anything.

## What sj wants built in THIS conversation
- The hamburger menu system (currently a stub with placeholder items)
- Following / blocking (explicitly wanted as ONE shared system usable from
  chat, profiles, AND the feed — not duplicated per-feature)
- Reporting (the feed already has its own report tables/routes; consider
  whether chat/profile reporting should share that or get its own)
- A store (monetization — details not yet discussed with sj, ask)
- Settings page (currently a stub)
- DMs (direct messages between users — not built yet)

## Working style — important context
- **sj has no computer, builds entirely from a phone** via Termius (SSH
  app) and GitHub's mobile web upload flow — no local git CLI. Deployment
  is: Claude writes code → zips it → sj downloads → uploads to a GitHub
  repo via the web UI → `git pull` on the droplet → `unzip -o` → rebuild →
  `pm2 restart`. Always give sj copy-pasteable terminal commands, one step
  at a time, and expect to troubleshoot real terminal output — sj is
  learning as they go (git, nginx, pm2, Linux permissions were all new).
- **sj is warm, enthusiastic, and genuinely technical-but-new** — explain
  *why*, not just *what*, the way this conversation has been doing. Use
  step_card_display_v0 for deploy walkthroughs.
- **Infra**: DigitalOcean droplet, Ubuntu, resized to 1GB RAM + a 1GB swap
  file (native module compiles like better-sqlite3/sharp can OOM-crash on
  install without the swap — this has happened twice). Domain is
  `aceof.lol`, proxied through **Cloudflare** (matters for SSL mode and
  DNS). nginx serves the built frontend + proxies API routes + serves the
  separately-built feed's static files. Backend runs via **pm2** as
  process name `friend-chat-app`. Repo lives at `/var/www/aceoflol` on the
  droplet (NOT `/root/` — nginx's `www-data` user can't read `/root`,
  learned that one the hard way).

## Stack
- **Backend**: Node/Express, better-sqlite3 (single SQLite file,
  `backend/data/app.db`), Socket.IO for real-time chat, JWT auth
  (`jsonwebtoken`), bcrypt for passwords.
- **Frontend**: React + Vite + Tailwind, mobile-only PWA-style SPA, no
  router library (plain state-based page switching in `App.jsx`).
  lucide-react for icons.
- **Feed**: a separately-built, self-contained module (plain HTML/CSS/JS,
  no framework) integrated into the same backend process and database, but
  served by nginx as its own static site at `/feed/`. Full details below.

## Auth model — READ THIS CAREFULLY, it's the foundation everything else sits on
- **One `users` table for both guests and registered accounts** — same
  row, guests just have `email`/`password_hash` = NULL and
  `is_registered = 0`. Registering later `UPDATE`s the SAME row (see
  `backend/src/routes/auth.js` `/register`) — same user id, same handle,
  same history. Never create a second row for the same person.
- **Handles**: 7-character mixed-case alphanumeric (e.g. `abcdEFg`),
  auto-generated, immutable, unique. Displayed as `nickname@handle`
  (nickname editable, handle never is).
- **Guests get a handle instantly**, with zero signup, the moment they
  first send a chat message (see `LandingPage.jsx` — this is the "hook":
  visitors watch the `#everyone` room live before ever being asked to sign
  up, and posting their first message silently mints a guest identity).
- **Three auth middleware functions** in `backend/src/middleware/auth.js`:
  - `requireAuth` — blocks unless ANY valid token (guest OR registered).
    Used where guests should still be able to act on their own stuff
    (e.g. editing their own profile).
  - `optionalAuth` — attaches `req.user` (`{id, handle, nickname,
    avatarUrl, isRegistered}`) if a valid token is present, but NEVER
    blocks. Used for anything guests can view.
  - `requireRegistered` — blocks with 403 unless `optionalAuth` (must run
    first) found a REGISTERED user. **This is almost certainly the right
    gate for follow/block/DM/store purchases too** — sj has been
    consistent that guests can look but not really participate.
- Tokens are JWTs signed with `JWT_SECRET` (in `.env`, 30-day expiry),
  read from `Authorization: Bearer <token>` header. Frontend stores it in
  `localStorage.getItem('token')`. The feed's static JS uses the exact
  same key/header — reuse this convention for any new feature.

## Database — schema.sql is the single source of truth
- One file: `backend/src/db/schema.sql`, run automatically on every
  backend startup via `CREATE TABLE IF NOT EXISTS` (see
  `backend/src/db/connection.js`).
- **⚠️ There is NO migration system yet.** `CREATE TABLE IF NOT EXISTS`
  does NOT add columns to existing tables. Every schema change so far has
  required telling sj to `rm backend/data/app.db` and restart (destroying
  all data) — acceptable pre-launch, since there are no real users yet,
  but **flag this loudly to sj before their first real user signs up**,
  and consider whether this conversation should finally build a real
  migration mechanism (e.g. a `schema_migrations` table + numbered
  migration files) rather than perpetuating the reset-and-pray pattern.
- All user-facing ids are TEXT UUIDs (`users.id`, `profiles.id`, etc.) —
  NOT integers. Post/comment/message ids in the feed and chat are
  `INTEGER AUTOINCREMENT` (that's fine, they're internal, only
  `user_id`/`profile_id` foreign keys need to be TEXT).
- Key tables already defined: `users`, `profiles`, `profile_attributes`
  (single-select fields), `profile_multi_attributes` (a shared EAV-style
  table for multi-select fields like gender/orientation/religion — see
  schema comments for why this pattern was chosen over one table per
  field), `interests` + `profile_interests` (hobbies, tag-based, reusable
  for other tagging needs), `rooms`, `room_memberships`, `messages`,
  `swipes`, `matches` (defined but swipe/discovery UI not built yet),
  `subscriptions` (Stripe fields defined, billing not built yet), and the
  full feed schema (`posts`, `post_likes`, `comments`, `comment_likes`,
  `shares`, `post_hides`, `post_reports`, `comment_hides`,
  `comment_reports`, `saved_posts`, `saved_comments`, with triggers
  keeping count columns in sync).

## What's already built and working
1. **Chat** — Socket.IO rooms, `#everyone` is open to guests
   (view + post), other rooms would require `requires_registration = 1`
   (schema supports this per-room flag; only `#everyone` exists so far, no
   UI yet for browsing/creating rooms). Auto-rejoin on reconnect was just
   added (`frontend/src/api/socket.js` `joinRoom`/`leaveRoom` helpers) to
   fix a real bug where mobile reconnects silently stopped delivering
   messages — **use these helpers, not raw `socket.emit('join_room', ...)`,
   for any new realtime feature (e.g. DMs) or messages will go stale the
   same way.**
2. **Landing page** — the "watch first, join instantly" hook described
   above.
3. **Full profile system** — huge set of optional dating-style fields
   (gender, orientation, commitment, kids, pets+note, diet, religion,
   polyamory, pronouns, build, height, bio, "looking for", hobbies,
   country, birthdate → publicly shown only as age+zodiac never the raw
   date). One photo per profile (upload mechanism NOT built — see below).
   Each profile has its OWN display color/font (`profile_display_color`,
   `profile_display_font` columns) shown to OTHER people viewing it —
   **deliberately separate** from the viewer's own app theme
   (`ThemeContext.jsx`'s `theme_color`/`theme_font`, which only affects
   how the app looks to yourself). Don't conflate these two theme
   concepts when building settings.
4. **Search** — filter other registered users by any combination of the
   profile fields above.
5. **The feed** — see dedicated section below.
6. **Menu drawer** (`frontend/src/components/MenuDrawer.jsx`) — currently
   has: Feed, Search, Discover (stub, reserved for a future Tinder-style
   swipe/premium-matching mode, NOT built), My Profile, Premium (stub),
   Settings (stub). **This is what you're extending.**

## The feed — integration seams you should know about
Built in a separate conversation, then integrated into this one. Fully
working now, but has known deferred pieces:
- **Follow/block are deliberately NOT in the feed's post/comment menus** —
  this was intentional, because sj wants ONE shared follow/block system
  usable from chat, profiles, and the feed, not three separate ones. This
  is very likely a big part of what you're building. Whatever you design,
  the feed's report/save/hide pattern (`post_hides`, `post_reports`,
  `saved_posts` etc., all keyed by `user_id`) is a reasonable model to
  follow for consistency, and the feed's route files
  (`backend/src/routes/feed/*.js`) are the place you'd wire in "hide posts
  from blocked users" filtering once block exists.
- **Feed images use local disk storage** (`backend/src/storage/feedStorage.js`),
  served via nginx `/media/` → proxied to Node's `express.static`. Meant
  to be swapped for DigitalOcean Spaces later — same deferred status as
  profile photo uploads. If you build a store needing product images, or
  DMs needing image attachments, consider whether this is finally the
  moment to build real cloud storage once, rather than a third local-disk
  placeholder.
- **The feed's static frontend is separate from the React app** — plain
  JS at `feed-public/`, served by nginx directly at `/feed/`
  (`location /feed/ { alias ...; }` in `nginx/app.conf`), NOT part of the
  Vite build. Navigating to it from the React menu is a real
  `window.location.href` page load, not client-side routing (see
  `MenuDrawer.jsx`'s `handleItemClick`). It shares auth via the same
  `localStorage.token` and shares accent-color theming via a JSON blob at
  `localStorage.aceoflol_theme` (see `ThemeContext.jsx`'s `syncFeedTheme`
  and `feed-public/js/theme.js`). If you build Settings and it lets people
  change their theme, make sure it keeps writing to both places.
- The feed also has a `sessionStorage.aceoflol_nav_depth` counter its own
  JS uses to decide whether its back button should be enabled — the React
  side just resets it to `'1'` before navigating in.

## Known real bugs fixed during this project (patterns worth remembering)
- **nginx needs an explicit `location` block for every new backend route
  prefix**, or requests silently fall through to `try_files` and return
  the React app's HTML instead of JSON (this actually happened — `/profiles/`
  was missing for a while and broke profile editing silently). **If you
  add new backend routes under a new prefix, remember to update
  `nginx/app.conf` AND tell sj to redeploy it** — this is the single
  easiest thing to forget.
- **better-sqlite3 rejects `undefined` bind params but allows `null`** —
  a recent bug was an `if (x !== undefined && x.length > N)` check that
  should have been `x != null` (loose), since legitimately-unset fields
  arrive as `null`, not `undefined`, and `null !== undefined` is `true` in
  JS. Watch for this pattern in any new optional-field validation.
- Deployment pain points sj has hit and now knows how to handle: OOM
  kills during npm install (fixed via swap), nginx `sites-enabled` vs
  `sites-available` confusion, permission-denied serving from `/root/`,
  stale localStorage tokens after a DB reset ("User not found" errors),
  browser/Cloudflare caching making deploys look like they didn't work.

## Conventions to keep following
- Warm, explain-the-why tone in all deploy instructions; use
  `step_card_display_v0` for anything multi-step.
- Prefer editing existing files over introducing new patterns
  (e.g. reuse the `interests` tag table pattern for any new
  tagging-like feature rather than inventing another one).
- Every schema change → remind sj this currently means a full DB reset
  pre-launch, and that this conversation might be the right place to fix
  that permanently.
- Every new backend route prefix → update `nginx/app.conf` in the same
  turn, not as an afterthought.

## Suggested first question to ask sj
Given "a store" is mentioned with zero detail (what's being sold?
premium subscriptions via the existing `subscriptions`/Stripe fields
already stubbed in schema.sql? Virtual goods? Something else?) and DMs
raise real design questions (can guests DM? does blocking someone hide
DMs? is there a shared "conversation" concept with chat rooms?) — it's
worth asking sj to clarify scope for store and DMs before building,
the same way this conversation asked clarifying questions at each major
new feature.
