// ============================================================
// A bank of classic, public-domain-style riddles for "Joker" — the
// waiting-room companion (GameSessionPage.jsx) that keeps someone
// entertained (and, per sj's framing, practicing quick back-and-forth
// texting) while they wait for their invite partner to arrive. These are
// traditional folk riddles rephrased in plain language, not quoted from
// any particular copyrighted collection.
// ============================================================

export const RIDDLES = [
  { question: "What has keys but can't open a single lock?", answer: 'A piano' },
  { question: 'What has to be broken before you can use it?', answer: 'An egg' },
  { question: 'What gets wetter the more it dries?', answer: 'A towel' },
  { question: 'What has a face and two hands but no arms or legs?', answer: 'A clock' },
  { question: "What has an eye but can't see?", answer: 'A needle' },
  { question: 'What can travel all around the world while staying in one corner?', answer: 'A stamp' },
  { question: "What comes down but never goes up?", answer: 'Rain' },
  { question: 'What has many teeth but cannot bite?', answer: 'A comb' },
  { question: "What has a neck but no head?", answer: 'A bottle' },
  { question: 'What gets bigger the more you take away from it?', answer: 'A hole' },
  { question: 'What can you catch but not throw?', answer: 'A cold' },
  { question: 'What has hands but cannot clap?', answer: 'A clock' },
  { question: 'What has one head, one foot, and four legs?', answer: 'A bed' },
  { question: 'What kind of room has no doors or windows?', answer: 'A mushroom' },
  { question: 'What goes up but never comes down?', answer: 'Your age' },
  { question: 'What has a thumb and four fingers but is not alive?', answer: 'A glove' },
  { question: 'What can fill a room but takes up no space?', answer: 'Light' },
  { question: 'What word becomes shorter when you add two letters to it?', answer: '"Short" — add "er" and it becomes "shorter"' },
  { question: 'What runs but never walks, has a mouth but never talks, has a bed but never sleeps, and has a head but never weeps?', answer: 'A river' },
  { question: 'The more of this there is, the less you see. What is it?', answer: 'Darkness' },
  { question: "What invention lets you look right through a wall?", answer: 'A window' },
  { question: 'What is full of holes but still holds water?', answer: 'A sponge' },
  { question: "What kind of tree can you carry in your hand?", answer: 'A palm (as in the palm of your hand)' },
  { question: 'What can you put in a bucket to make it weigh less?', answer: 'A hole' },
  { question: 'What has a head, a tail, is orange, and has no legs?', answer: 'A penny' },
  { question: 'What word contains 26 letters but only has three syllables?', answer: 'Alphabet' },
  { question: 'What has a lot of eyes but cannot see?', answer: 'A potato' },
  { question: 'What can you serve but never eat?', answer: 'A tennis ball' },
  { question: 'What can you make that nobody — not even you — can see?', answer: 'Noise' },
  { question: 'What has a bottom at the top?', answer: 'Your legs' },
  { question: 'What is easy to get into but hard to get out of?', answer: 'Trouble' },
  {
    question:
      'I am a five-letter word. Remove my first letter and I become a form of energy. Remove my first two letters and I become something needed to live. Rearrange my final three letters and you can drink me. What am I?',
    answer: 'Wheat',
  },
  { question: 'What starts with E, ends with E, but contains one letter?', answer: 'An envelope' },
  { question: 'What has a tongue but cannot talk?', answer: 'A shoe' },
  { question: 'What has 13 hearts but no other organs?', answer: 'A deck of cards' },
  { question: 'Five machines take five minutes to make five widgets. How long would 100 machines take to make 100 widgets?', answer: 'Five minutes' },
  {
    question: 'Two fathers and two sons go fishing. Each catches one fish, yet they bring home only three fish. How is that possible?',
    answer: 'There are only three people: a grandfather, his son, and his grandson',
  },
  {
    question: "An electric train is traveling west at 60 miles per hour while a strong wind blows east at 40 miles per hour. Which direction does the train's smoke travel?",
    answer: "An electric train doesn't produce smoke",
  },
  { question: 'Where does today come before yesterday?', answer: 'The dictionary' },
  { question: 'I am not alive, but I can die. What am I?', answer: 'A battery' },
  { question: 'What lives if you feed it, but dies if you give it a drink?', answer: 'Fire' },
  { question: 'What can you drive that has wheels and also flies but never leaves the ground?', answer: 'A garbage truck' },
  { question: 'What has a neck but has no head?', answer: 'A guitar' },
  { question: 'What word is pronounced the same if you take away four of its five letters?', answer: 'Queue' },
  { question: 'What is so fragile that saying its name breaks it?', answer: 'Silence' },
  {
    question: 'Two frail bodies joined as one, the longer I stand, the more I run. All I hold, I\u2019m sure to spill, young I tumble, old I\u2019m still. What am I?',
    answer: 'An hourglass',
  },
  {
    question:
      'Where I go, my brother follows, we\u2019ve soul and skin, though we are hollow. We\u2019re welcome friends on any road, we share the weight of every load. We do our best work after breaking, on my own I\u2019m not worth taking. What am I?',
    answer: 'A boot',
  },
  { question: "I can fall from the sky, but I cannot climb higher, I spring with no legs, I run but don't tire. What am I?", answer: 'Water' },
  { question: 'Always wax, yet always wane: I melt, succumb\u00e9d to the flame. Lighting darkness, with fate unblessed, I soon devolve to shapeless mess.', answer: 'A candle' },
  { question: 'Without wings, I fly. Without eyes, I cry. What am I?', answer: 'A cloud' },
  { question: "It looks sorry, very sorry, when you're feeling sad, and looks happy, very happy, whenever you are glad.", answer: 'A mirror' },
  { question: 'Some say that TWO and TWO always will make FOUR, so, how can these numbers be shown as eighteen more?', answer: 'When they are written as 22' },
  { question: 'Can you name a kind of doors, always open wide? Always very close to you, wherever you abide.', answer: 'Outdoors' },
  { question: "It's not for an elephant, nor for clothes, but it's a trunk. It grows and grows.", answer: 'A tree trunk' },
];

export function randomRiddle(excludeQuestion) {
  const pool = excludeQuestion ? RIDDLES.filter((r) => r.question !== excludeQuestion) : RIDDLES;
  return pool[Math.floor(Math.random() * pool.length)];
}
