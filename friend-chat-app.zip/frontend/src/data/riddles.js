// ============================================================
// A bank of classic, public-domain-style riddles for "Joker" — the
// waiting-room companion (GameSessionPage.jsx) that keeps someone
// entertained (and, per sj's framing, practicing quick back-and-forth
// texting) while they wait for their invite partner to arrive. These are
// traditional folk riddles rephrased in plain language, not quoted from
// any particular copyrighted collection.
// ============================================================

export const RIDDLES = [
  { question: "What has keys but can't open a single lock?", answer: 'A piano' },
  { question: 'What has to be broken before you can use it?', answer: 'An egg' },
  { question: 'What gets wetter the more it dries?', answer: 'A towel' },
  { question: 'What has a face and two hands but no arms or legs?', answer: 'A clock' },
  { question: "What has an eye but can't see?", answer: 'A needle' },
  { question: 'What can travel all around the world while staying in one corner?', answer: 'A stamp' },
  { question: "What comes down but never goes up?", answer: 'Rain' },
  { question: 'What has many teeth but cannot bite?', answer: 'A comb' },
  { question: "What has a neck but no head?", answer: 'A bottle' },
  { question: 'What gets bigger the more you take away from it?', answer: 'A hole' },
  { question: 'What can you catch but not throw?', answer: 'A cold' },
  { question: 'What has hands but cannot clap?', answer: 'A clock' },
  { question: "What runs but never walks, has a mouth but never talks?", answer: 'A river' },
  { question: 'What has one head, one foot, and four legs?', answer: 'A bed' },
  { question: 'What kind of room has no doors or windows?', answer: 'A mushroom' },
  { question: 'What goes up but never comes down?', answer: 'Your age' },
  { question: 'What has a thumb and four fingers but is not alive?', answer: 'A glove' },
  { question: 'What can fill a room but takes up no space?', answer: 'Light' },
  { question: 'What word becomes shorter when you add two letters to it?', answer: '"Short" — add "er" and it becomes "shorter"' },
  { question: 'What has a bed but never sleeps, and a mouth but never eats?', answer: 'A river' },
  { question: 'The more of this there is, the less you see. What is it?', answer: 'Darkness' },
  { question: "What invention lets you look right through a wall?", answer: 'A window' },
  { question: 'What is full of holes but still holds water?', answer: 'A sponge' },
  { question: "What kind of tree can you carry in your hand?", answer: 'A palm (as in the palm of your hand)' },
];

export function randomRiddle(excludeQuestion) {
  const pool = excludeQuestion ? RIDDLES.filter((r) => r.question !== excludeQuestion) : RIDDLES;
  return pool[Math.floor(Math.random() * pool.length)];
}
