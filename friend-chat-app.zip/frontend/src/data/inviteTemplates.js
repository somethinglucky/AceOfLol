// ============================================================
// Invitation card designs — the inviter picks one of these when creating
// a game invite (GameInvitePanel.jsx), and it's what the invitee sees on
// the reveal page (InvitationRevealPage.jsx) and, in miniature, on the
// DM card itself (DMsPage.jsx).
//
// These are CSS-rendered placeholders, deliberately built so real
// artwork drops in with a one-line change: once sj supplies PNGs, set
// `imageUrl` on the matching template below and every component that
// renders a template already prefers imageUrl over the CSS look when
// it's present — nothing else needs to change.
//
// Kept intentionally elegant/formal rather than romantic (no hearts, no
// roses) — these go out between friends as often as anything else, so
// the design language is "you've been invited somewhere special",
// closer to a gala or a members' club than a date.
// ============================================================

export const INVITE_TEMPLATES = [
  {
    id: 'classic',
    label: 'Ivory & Gold',
    imageUrl: null,
    background: 'linear-gradient(160deg, #faf6ec 0%, #f0e6cf 100%)',
    borderColor: '#c9a95c',
    textColor: '#3a2f1c',
    accentColor: '#a8823a',
    ornament: '❦',
  },
  {
    id: 'gold',
    label: 'Black Tie',
    imageUrl: null,
    background: 'linear-gradient(160deg, #16140f 0%, #2b2418 100%)',
    borderColor: '#d4af6a',
    textColor: '#f3e6c8',
    accentColor: '#d4af6a',
    ornament: '✦',
  },
  {
    id: 'midnight',
    label: 'Midnight Gala',
    imageUrl: null,
    background: 'linear-gradient(160deg, #0e1330 0%, #232a5c 100%)',
    borderColor: '#8fa3e0',
    textColor: '#eef1fb',
    accentColor: '#9fb4ff',
    ornament: '✧',
  },
  {
    id: 'botanical',
    label: 'Botanical',
    imageUrl: null,
    background: 'linear-gradient(160deg, #16241c 0%, #26402e 100%)',
    borderColor: '#c9b26a',
    textColor: '#eef3ea',
    accentColor: '#9fc98a',
    ornament: '⚜',
  },
  {
    id: 'noir',
    label: 'Noir',
    imageUrl: null,
    background: 'linear-gradient(160deg, #1a1a1a 0%, #050505 100%)',
    borderColor: '#e8e8e8',
    textColor: '#f2f2f2',
    accentColor: '#d0d0d0',
    ornament: '◆',
  },
];

export function getInviteTemplate(id) {
  return INVITE_TEMPLATES.find((t) => t.id === id) || INVITE_TEMPLATES[0];
}
