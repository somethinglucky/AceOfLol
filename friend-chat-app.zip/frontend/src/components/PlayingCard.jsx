// Renders a card code like '10H' or 'AS' as a small chip — red for
// hearts/diamonds, dark for clubs/spades. Shared by any card-theme game's
// board rendering (Blackjack, Go Fish today).
const SUIT_SYMBOLS = { S: '♠', H: '♥', D: '♦', C: '♣' };

export default function PlayingCard({ card, size = 'md', faceDown = false }) {
  const dims = size === 'sm' ? 'w-8 h-11 text-[12px]' : 'w-11 h-[60px] text-[15px]';

  if (faceDown) {
    return (
      <div
        className={`${dims} rounded-md border flex items-center justify-center shrink-0`}
        style={{ background: 'var(--theme-accent)', borderColor: 'var(--color-border)', opacity: 0.6 }}
      />
    );
  }

  const rank = card.slice(0, -1);
  const suit = card.slice(-1);
  const isRed = suit === 'H' || suit === 'D';

  return (
    <div
      className={`${dims} rounded-md border flex flex-col items-center justify-center font-bold shrink-0 bg-white`}
      style={{ borderColor: 'var(--color-border)', color: isRed ? '#e0193f' : '#1a1a1a' }}
    >
      <span>{rank}</span>
      <span>{SUIT_SYMBOLS[suit]}</span>
    </div>
  );
}
