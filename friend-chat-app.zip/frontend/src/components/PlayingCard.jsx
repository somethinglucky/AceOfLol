// Renders a card code like '10H' or 'AS' as a small chip — red for
// hearts/diamonds, dark for clubs/spades. Shared by any card-theme game's
// board rendering (Blackjack, Go Fish today).
const SUIT_SYMBOLS = { S: '♠', H: '♥', D: '♦', C: '♣' };

const CARD_DIMS = {
  sm: { w: 32, h: 44, font: 12 },
  md: { w: 44, h: 60, font: 15 },
};

export default function PlayingCard({ card, size = 'md', faceDown = false, scale = 1 }) {
  const base = CARD_DIMS[size] || CARD_DIMS.md;
  const style = {
    width: base.w * scale,
    height: base.h * scale,
    fontSize: base.font * scale,
  };

  if (faceDown) {
    return (
      <div
        className="rounded-md border flex items-center justify-center shrink-0"
        style={{ ...style, background: 'var(--theme-accent)', borderColor: 'var(--color-border)', opacity: 0.6 }}
      />
    );
  }

  const rank = card.slice(0, -1);
  const suit = card.slice(-1);
  const isRed = suit === 'H' || suit === 'D';

  return (
    <div
      className="rounded-md border flex flex-col items-center justify-center font-bold shrink-0 bg-white"
      style={{ ...style, borderColor: 'var(--color-border)', color: isRed ? '#e0193f' : '#1a1a1a' }}
    >
      <span>{rank}</span>
      <span>{SUIT_SYMBOLS[suit]}</span>
    </div>
  );
}
