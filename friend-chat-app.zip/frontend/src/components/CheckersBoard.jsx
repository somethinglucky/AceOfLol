import { useState } from 'react';

// The server (games/checkers.js) is the only place checkers rules
// actually live — this component just draws whatever board it's handed
// and only ever offers moves that appear in board.legalMoves, which the
// server only populates when it's genuinely this viewer's turn. Tapping
// an illegal destination simply can't happen here, so there's no need to
// duplicate the mandatory-capture/multi-jump rules client-side just to
// keep the UI honest.
export default function CheckersBoard({ board, currentUserId, isMyTurn, sending, onMove }) {
  const [selected, setSelected] = useState(null); // [row, col] | null

  // board.viewerDirection flips the display so the viewer's own pieces
  // are always nearest the bottom of their screen, regardless of which
  // side they were actually dealt. The player whose pieces start at rows
  // 0-2 (direction +1, advancing toward row 7) needs the flip — without
  // it, a plain top-to-bottom grid render puts THEIR pieces at the top
  // and the opponent's at the bottom, backwards from what's wanted. The
  // other player (direction -1, pieces start at rows 5-7) already lands
  // at the bottom with no flip needed. (This was backwards in an earlier
  // version — caught and fixed after tracing through concretely.)
  const flip = board.viewerDirection === 1;
  const fromDisplay = (dRow, dCol) => (flip ? [7 - dRow, 7 - dCol] : [dRow, dCol]);

  const forcedSquare = board.mustContinueFrom;
  const activeSquare = forcedSquare || selected;
  const destinationsFromActive = activeSquare
    ? board.legalMoves.filter((m) => m.from[0] === activeSquare[0] && m.from[1] === activeSquare[1])
    : [];
  const selectableSquares = new Set(board.legalMoves.map((m) => `${m.from[0]},${m.from[1]}`));

  function handleTap(row, col) {
    if (!isMyTurn || sending) return;
    const key = `${row},${col}`;
    const dest = destinationsFromActive.find((m) => m.to[0] === row && m.to[1] === col);
    if (dest) {
      onMove({ from: dest.from, to: dest.to });
      setSelected(null);
      return;
    }
    if (!forcedSquare && selectableSquares.has(key)) {
      setSelected(selected && selected[0] === row && selected[1] === col ? null : [row, col]);
    }
  }

  const cells = [];
  for (let dRow = 0; dRow < 8; dRow++) {
    for (let dCol = 0; dCol < 8; dCol++) {
      const [row, col] = fromDisplay(dRow, dCol);
      const piece = board.board[row][col];
      const isDark = (row + col) % 2 === 1;
      const isActive = activeSquare && activeSquare[0] === row && activeSquare[1] === col;
      const isDestination = destinationsFromActive.some((m) => m.to[0] === row && m.to[1] === col);
      const isSelectable = !forcedSquare && selectableSquares.has(`${row},${col}`);

      cells.push(
        <button
          key={`${dRow}-${dCol}`}
          onClick={() => handleTap(row, col)}
          disabled={!isMyTurn || sending || (!isDestination && !isSelectable)}
          className="aspect-square flex items-center justify-center relative"
          style={{ background: isDark ? '#3a2a1e' : '#e8d9c4' }}
        >
          {isDestination && <span className="absolute w-3 h-3 rounded-full" style={{ background: 'var(--theme-accent)', opacity: 0.8 }} />}
          {piece && (
            <span
              className="rounded-full flex items-center justify-center"
              style={{
                width: '78%',
                height: '78%',
                background: piece.owner === currentUserId ? 'var(--theme-accent)' : '#4a4a4a',
                border: isActive ? '3px solid white' : '2px solid rgba(255,255,255,0.3)',
                boxShadow: '0 2px 4px rgba(0,0,0,0.4)',
              }}
            >
              {piece.king && <span style={{ color: 'white', fontSize: '60%' }}>♛</span>}
            </span>
          )}
        </button>
      );
    }
  }

  return (
    <div className="flex flex-col items-center gap-2">
      <div className="grid grid-cols-8 w-full max-w-xs rounded-lg overflow-hidden border" style={{ borderColor: 'var(--color-border)' }}>
        {cells}
      </div>
      <div className="flex items-center gap-4 text-[12px]" style={{ color: 'var(--color-text-secondary)' }}>
        <span className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-full inline-block" style={{ background: 'var(--theme-accent)' }} /> You
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-full inline-block" style={{ background: '#4a4a4a' }} /> Opponent
        </span>
      </div>
      {forcedSquare && isMyTurn && (
        <p className="text-[12px]" style={{ color: 'var(--theme-accent)' }}>You must keep capturing with the highlighted piece.</p>
      )}
    </div>
  );
}
