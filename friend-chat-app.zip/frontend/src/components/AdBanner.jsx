// Deliberately static — no carousel, no animation. A non-moving banner is
// both the cheapest ad unit to build and the least disruptive to a chat UI.
// adSrc/adHref come from whatever ad network gets wired in later; until then
// this renders a plain placeholder so the layout space is reserved from day one.
export default function AdBanner({ adImageUrl, adHref }) {
  const content = (
    <div style={{ paddingTop: 'env(safe-area-inset-top, 0px)', background: 'var(--color-bubble-received)' }}>
      <div
        className="w-full h-[50px] flex items-center justify-center text-xs font-medium"
        style={{ color: 'var(--color-text-secondary)' }}
      >
      {adImageUrl ? (
        <img src={adImageUrl} alt="Advertisement" className="h-full w-full object-cover" />
      ) : (
        'Ad space'
      )}
      </div>
    </div>
  );

  return adHref ? (
    <a href={adHref} target="_blank" rel="noopener noreferrer sponsored">
      {content}
    </a>
  ) : (
    content
  );
}
