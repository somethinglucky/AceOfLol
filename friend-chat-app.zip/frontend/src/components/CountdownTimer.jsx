import { useEffect, useState } from 'react';

function partsUntil(targetIso) {
  const diffMs = new Date(targetIso).getTime() - Date.now();
  if (diffMs <= 0) return null;
  const totalSeconds = Math.floor(diffMs / 1000);
  return {
    hours: Math.floor(totalSeconds / 3600),
    minutes: Math.floor((totalSeconds % 3600) / 60),
    seconds: totalSeconds % 60,
  };
}

function pad(n) {
  return String(n).padStart(2, '0');
}

// Purely atmospheric — it does NOT gate anything. The game already starts
// the moment both seats have arrived regardless of the scheduled time
// (see games/sessionEngine.js's markArrived), so arriving early and
// having both people show up just starts the game early. This is here so
// an early arrival isn't just a blank waiting screen — it's "here's when
// this was planned for", counting down, until it hits zero.
export default function CountdownTimer({ targetIso }) {
  const [parts, setParts] = useState(() => partsUntil(targetIso));

  useEffect(() => {
    const interval = setInterval(() => setParts(partsUntil(targetIso)), 1000);
    return () => clearInterval(interval);
  }, [targetIso]);

  if (!parts) {
    return <p className="text-[13px]" style={{ color: 'var(--theme-accent)' }}>Any moment now…</p>;
  }

  return (
    <div className="flex flex-col items-center gap-1">
      <p className="text-[11px] uppercase tracking-wide" style={{ color: 'var(--color-text-secondary)' }}>
        Your game begins in
      </p>
      <p className="text-[22px] font-semibold tabular-nums" style={{ color: 'var(--theme-accent)' }}>
        {parts.hours > 0 ? `${pad(parts.hours)}:` : ''}{pad(parts.minutes)}:{pad(parts.seconds)}
      </p>
    </div>
  );
}
