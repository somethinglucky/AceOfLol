import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { api } from '../api/client';
import { colorFromString } from '../utils/colorHash';
import { FONT_OPTIONS } from '../theme/ThemeContext';
import NameTag from './NameTag';

const LABEL_MAPS = {
  // Rendered as-is via a simple humanize pass rather than a full lookup
  // table for every enum here — good enough for a profile card glance,
  // where the edit form (which needs exact valid values) is the place
  // that uses the precise option lists.
};

function humanize(value) {
  if (!value) return null;
  return value.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

function Row({ label, children }) {
  if (!children || (Array.isArray(children) && children.length === 0)) return null;
  return (
    <div className="flex justify-between text-[14px] py-1.5 border-b" style={{ borderColor: 'var(--color-border)' }}>
      <span style={{ color: 'var(--color-text-secondary)' }}>{label}</span>
      <span className="text-right max-w-[60%]">{Array.isArray(children) ? children.join(', ') : children}</span>
    </div>
  );
}

// userId: null means "closed". isGuestAvatar/guestHandle let this component
// render a guest's color swatch (no fetchable profile exists worth showing
// beyond "this is an anonymous guest"). currentUserId is the viewer's own
// id — used to hide Follow/Block when someone taps their own avatar/profile.
export default function ProfileCard({ userId, isGuestAvatar, guestHandle, guestNickname, currentUserId, viewerIsRegistered, onMessage, onClose }) {
  const [profile, setProfile] = useState(null);
  const [error, setError] = useState('');
  const [relationship, setRelationship] = useState(null); // { isFollowing, isBlocking, ... } | null while loading
  const [relBusy, setRelBusy] = useState(false);
  const [moreMenuOpen, setMoreMenuOpen] = useState(false);

  useEffect(() => {
    if (!userId || isGuestAvatar) return;
    setProfile(null);
    setError('');
    api.getProfile(userId).then(setProfile).catch((err) => setError(err.message));
  }, [userId, isGuestAvatar]);

  useEffect(() => {
    if (!userId || isGuestAvatar || userId === currentUserId || !viewerIsRegistered) {
      setRelationship(null);
      return;
    }
    api.getRelationship(userId).then(setRelationship).catch(() => setRelationship(null));
  }, [userId, isGuestAvatar, currentUserId, viewerIsRegistered]);

  async function handleFollowToggle() {
    setRelBusy(true);
    try {
      if (relationship.isFollowing) {
        await api.unfollow(userId);
        setRelationship((r) => ({ ...r, isFollowing: false }));
      } else {
        await api.follow(userId);
        setRelationship((r) => ({ ...r, isFollowing: true }));
      }
    } finally {
      setRelBusy(false);
    }
  }

  async function handleBlockToggle() {
    if (!relationship.isBlocking && !window.confirm('Block this person? You won\u2019t see their posts or comments anymore.')) {
      return;
    }
    setRelBusy(true);
    try {
      if (relationship.isBlocking) {
        await api.unblock(userId);
        setRelationship((r) => ({ ...r, isBlocking: false }));
      } else {
        await api.block(userId);
        setRelationship((r) => ({ ...r, isBlocking: true, isFollowing: false }));
      }
    } finally {
      setRelBusy(false);
    }
  }

  async function handleReportUser() {
    setMoreMenuOpen(false);
    const reason = window.prompt('What\u2019s wrong with this person? (optional)') || undefined;
    try {
      await api.reportUser(userId, reason);
      window.alert('Thanks \u2014 this has been reported.');
    } catch {
      window.alert('Something went wrong reporting this person.');
    }
  }

  function handleGameInvite() {
    window.alert('Coming soon \u2014 games and virtual dates aren\u2019t set up yet!');
  }

  if (!userId) return null;

  if (isGuestAvatar) {
    return (
      <div className="fixed inset-0 z-50 flex flex-col items-center justify-center px-6" style={{ background: 'var(--color-bg)' }}>
        <button onClick={onClose} className="absolute top-3 right-3 h-8 w-8 rounded-full flex items-center justify-center" style={{ background: 'var(--color-bubble-received)', top: 'calc(env(safe-area-inset-top) + 12px)' }} aria-label="Close">
          <X size={18} color="var(--color-text-secondary)" />
        </button>
        <div className="h-24 w-24 rounded-full mb-4" style={{ background: colorFromString(guestHandle || userId) }} />
        <NameTag nickname={guestNickname} handle={guestHandle} isRegistered={false} size="lg" />
        <p className="text-sm mt-2 text-center max-w-xs" style={{ color: 'var(--color-text-secondary)' }}>
          This person hasn't registered yet, so there's no profile to show — just their chat identity.
        </p>
      </div>
    );
  }

  const fontStack = profile ? FONT_OPTIONS[profile.displayFont]?.stack || FONT_OPTIONS.system.stack : undefined;
  const accent = profile?.displayColor || '#0a84ff';

  return (
    <div className="fixed inset-0 z-50 flex flex-col overflow-y-auto" style={{ background: 'var(--color-bg)', fontFamily: fontStack }}>
      <div className="flex justify-end p-3" style={{ paddingTop: 'calc(env(safe-area-inset-top) + 12px)' }}>
        <button onClick={onClose} className="h-8 w-8 rounded-full flex items-center justify-center" style={{ background: 'var(--color-bubble-received)' }} aria-label="Close profile">
          <X size={18} color="var(--color-text-secondary)" />
        </button>
      </div>

      {error && <p className="text-center text-sm px-6" style={{ color: '#ff375f' }}>{error}</p>}

      {profile && (
        <div className="flex flex-col items-center px-6 pb-10">
          <div className="h-28 w-28 rounded-full overflow-hidden flex items-center justify-center mb-4" style={{ background: 'var(--color-bubble-received)', border: `3px solid ${accent}` }}>
            {profile.avatarUrl ? (
              <img src={profile.avatarUrl} alt="" className="h-full w-full object-cover" />
            ) : (
              <span className="text-3xl font-semibold" style={{ color: accent }}>
                {(profile.nickname || profile.handle || '?')[0].toUpperCase()}
              </span>
            )}
          </div>

          <NameTag nickname={profile.nickname} handle={profile.handle} size="lg" nicknameColor={accent} />
          {(profile.age || profile.zodiac) && (
            <p className="text-sm mt-1.5" style={{ color: 'var(--color-text-secondary)' }}>
              {[profile.zodiac && humanize(profile.zodiac), profile.age].filter(Boolean).join(' · ')}
            </p>
          )}

          {relationship && (
            <div className="w-full mt-3 mb-4">
              {relationship.isBlockedBy && (
                <p className="text-[13px] text-center mb-2" style={{ color: 'var(--color-text-secondary)' }}>
                  This person has blocked you.
                </p>
              )}
              <div className="flex w-full items-stretch">
                <button
                  onClick={handleFollowToggle}
                  disabled={relBusy || relationship.isBlockedBy}
                  title={relationship.isBlockedBy ? 'This person has blocked you' : relationship.isFollowing ? 'Unfollow' : 'Follow'}
                  className="flex-1 py-2 text-3xl leading-none flex items-center justify-center disabled:opacity-30"
                  style={{ color: relationship.isFollowing ? '#ff375f' : 'var(--color-text)' }}
                  aria-label={relationship.isFollowing ? 'Unfollow' : 'Follow'}
                >
                  {relationship.isFollowing ? '\u2665' : '\u2661'}
                </button>
                <button
                  onClick={() => onMessage({ id: userId, nickname: profile.nickname, handle: profile.handle, isRegistered: true })}
                  disabled={relationship.isBlockedBy || relationship.isBlocking}
                  title={relationship.isBlockedBy || relationship.isBlocking ? "You can't message this person" : 'Message'}
                  className="flex-1 py-2 text-3xl leading-none flex items-center justify-center disabled:opacity-30"
                  style={{ color: 'var(--color-text)' }}
                  aria-label="Message"
                >
                  {'\u2660'}
                </button>
                <button
                  onClick={handleGameInvite}
                  title="Invite to a game or virtual date"
                  className="flex-1 py-2 text-3xl leading-none flex items-center justify-center"
                  style={{ color: 'var(--color-text)' }}
                  aria-label="Invite to a game or virtual date"
                >
                  {'\u2663'}
                </button>
                <div className="relative flex-1">
                  <button
                    onClick={() => setMoreMenuOpen((v) => !v)}
                    title="More"
                    className="w-full py-2 text-3xl leading-none flex items-center justify-center"
                    style={{ color: 'var(--color-text)' }}
                    aria-label="More options"
                  >
                    {'\u2666'}
                  </button>
                  {moreMenuOpen && (
                    <>
                      <div className="fixed inset-0 z-10" onClick={() => setMoreMenuOpen(false)} />
                      <div
                        className="absolute right-0 top-12 z-20 rounded-xl overflow-hidden shadow-lg w-48"
                        style={{ background: 'var(--color-bubble-received)' }}
                      >
                        <button
                          onClick={() => { setMoreMenuOpen(false); window.alert('Coming soon \u2014 gifts aren\u2019t set up yet!'); }}
                          className="w-full text-left px-3 py-2.5 text-[14px]"
                          style={{ color: 'var(--color-text)' }}
                        >
                          Send Gift
                        </button>
                        <button
                          onClick={() => { setMoreMenuOpen(false); handleBlockToggle(); }}
                          disabled={relBusy}
                          className="w-full text-left px-3 py-2.5 text-[14px]"
                          style={{ color: 'var(--color-text)' }}
                        >
                          {relationship.isBlocking ? 'Unblock' : 'Block'}
                        </button>
                        <button onClick={handleReportUser} className="w-full text-left px-3 py-2.5 text-[14px]" style={{ color: '#ff375f' }}>
                          Report
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          )}
          {!relationship && <div className="mb-4" />}

          {profile.bio && <p className="text-center text-[15px] mb-4">{profile.bio}</p>}

          {profile.hobbies?.length > 0 && (
            <div className="flex flex-wrap gap-2 justify-center mb-5">
              {profile.hobbies.map((tag) => (
                <span key={tag} className="text-xs font-medium px-3 py-1.5 rounded-full" style={{ background: accent, color: '#fff' }}>
                  {tag}
                </span>
              ))}
            </div>
          )}

          {profile.lookingFor && (
            <div className="w-full mb-4">
              <p className="text-xs font-semibold mb-1" style={{ color: 'var(--color-text-secondary)' }}>LOOKING FOR</p>
              <p className="text-[15px]">{profile.lookingFor}</p>
            </div>
          )}

          <div className="w-full">
            <Row label="Gender">{profile.gender?.map(humanize)}</Row>
            <Row label="Orientation">{profile.orientation?.map(humanize)}</Row>
            <Row label="Pronouns">{profile.pronouns}</Row>
            <Row label="Country">{profile.country}</Row>
            <Row label="Build">{humanize(profile.build)}</Row>
            <Row label="Height">{profile.heightCm ? `${profile.heightCm} cm` : null}</Row>
            <Row label="Commitment">{humanize(profile.commitment)}</Row>
            <Row label="Has kids">{profile.has_kids?.map(humanize)}</Row>
            <Row label="Pets">{profile.pets?.map(humanize)}</Row>
            {profile.petsNote && <Row label="Pet notes">{profile.petsNote}</Row>}
            <Row label="Diet">{humanize(profile.diet)}</Row>
            <Row label="Religion">{profile.religion?.map(humanize)}</Row>
            <Row label="Polyamory">{humanize(profile.polyamory)}</Row>
          </div>
        </div>
      )}
    </div>
  );
}
