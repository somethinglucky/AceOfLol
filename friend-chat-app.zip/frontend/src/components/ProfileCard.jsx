import { X } from 'lucide-react';

// profile shape: { nickname, handle, avatar_url, bio, interests: string[] }
export default function ProfileCard({ profile, onClose }) {
  if (!profile) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col"
      style={{ background: 'var(--color-bg)' }}
    >
      <div className="flex justify-end p-3" style={{ paddingTop: 'calc(env(safe-area-inset-top) + 12px)' }}>
        <button
          onClick={onClose}
          className="h-8 w-8 rounded-full flex items-center justify-center"
          style={{ background: 'var(--color-bubble-received)' }}
          aria-label="Close profile"
        >
          <X size={18} color="var(--color-text-secondary)" />
        </button>
      </div>

      <div className="flex flex-col items-center px-6 pt-4">
        <div
          className="h-28 w-28 rounded-full overflow-hidden flex items-center justify-center mb-4"
          style={{ background: 'var(--color-bubble-received)' }}
        >
          {profile.avatar_url ? (
            <img src={profile.avatar_url} alt="" className="h-full w-full object-cover" />
          ) : (
            <span className="text-3xl font-semibold text-[var(--color-text-secondary)]">
              {(profile.nickname || '?')[0].toUpperCase()}
            </span>
          )}
        </div>

        <h1 className="text-2xl font-semibold">{profile.nickname}</h1>
        <p className="text-sm mb-4" style={{ color: 'var(--color-text-secondary)' }}>
          @{profile.handle}
        </p>

        {profile.bio && (
          <p className="text-center text-[15px] mb-5" style={{ color: 'var(--color-text)' }}>
            {profile.bio}
          </p>
        )}

        {profile.interests?.length > 0 && (
          <div className="flex flex-wrap gap-2 justify-center">
            {profile.interests.map((tag) => (
              <span
                key={tag}
                className="text-xs font-medium px-3 py-1.5 rounded-full"
                style={{ background: 'var(--color-bubble-received)', color: 'var(--color-text)' }}
              >
                {tag}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
