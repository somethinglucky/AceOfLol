import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { api } from '../api/client';
import { colorFromString } from '../utils/colorHash';
import { FONT_OPTIONS } from '../theme/ThemeContext';

const LABEL_MAPS = {
  // Rendered as-is via a simple humanize pass rather than a full lookup
  // table for every enum here — good enough for a profile card glance,
  // where the edit form (which needs exact valid values) is the place
  // that uses the precise option lists.
};

function humanize(value) {
  if (!value) return null;
  return value.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

function Row({ label, children }) {
  if (!children || (Array.isArray(children) && children.length === 0)) return null;
  return (
    <div className="flex justify-between text-[14px] py-1.5 border-b" style={{ borderColor: 'var(--color-border)' }}>
      <span style={{ color: 'var(--color-text-secondary)' }}>{label}</span>
      <span className="text-right max-w-[60%]">{Array.isArray(children) ? children.join(', ') : children}</span>
    </div>
  );
}

// userId: null means "closed". isGuestAvatar/guestHandle let this component
// render a guest's color swatch (no fetchable profile exists worth showing
// beyond "this is an anonymous guest").
export default function ProfileCard({ userId, isGuestAvatar, guestHandle, onClose }) {
  const [profile, setProfile] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!userId || isGuestAvatar) return;
    setProfile(null);
    setError('');
    api.getProfile(userId).then(setProfile).catch((err) => setError(err.message));
  }, [userId, isGuestAvatar]);

  if (!userId) return null;

  if (isGuestAvatar) {
    return (
      <div className="fixed inset-0 z-50 flex flex-col items-center justify-center px-6" style={{ background: 'var(--color-bg)' }}>
        <button onClick={onClose} className="absolute top-3 right-3 h-8 w-8 rounded-full flex items-center justify-center" style={{ background: 'var(--color-bubble-received)', top: 'calc(env(safe-area-inset-top) + 12px)' }} aria-label="Close">
          <X size={18} color="var(--color-text-secondary)" />
        </button>
        <div className="h-24 w-24 rounded-full mb-4" style={{ background: colorFromString(guestHandle || userId) }} />
        <h1 className="text-xl font-semibold">{guestHandle}</h1>
        <p className="text-sm mt-2 text-center max-w-xs" style={{ color: 'var(--color-text-secondary)' }}>
          This person hasn't registered yet, so there's no profile to show — just their chat handle.
        </p>
      </div>
    );
  }

  const fontStack = profile ? FONT_OPTIONS[profile.displayFont]?.stack || FONT_OPTIONS.system.stack : undefined;
  const accent = profile?.displayColor || '#0a84ff';

  return (
    <div className="fixed inset-0 z-50 flex flex-col overflow-y-auto" style={{ background: 'var(--color-bg)', fontFamily: fontStack }}>
      <div className="flex justify-end p-3" style={{ paddingTop: 'calc(env(safe-area-inset-top) + 12px)' }}>
        <button onClick={onClose} className="h-8 w-8 rounded-full flex items-center justify-center" style={{ background: 'var(--color-bubble-received)' }} aria-label="Close profile">
          <X size={18} color="var(--color-text-secondary)" />
        </button>
      </div>

      {error && <p className="text-center text-sm px-6" style={{ color: '#ff375f' }}>{error}</p>}

      {profile && (
        <div className="flex flex-col items-center px-6 pb-10">
          <div className="h-28 w-28 rounded-full overflow-hidden flex items-center justify-center mb-4" style={{ background: 'var(--color-bubble-received)', border: `3px solid ${accent}` }}>
            {profile.avatarUrl ? (
              <img src={profile.avatarUrl} alt="" className="h-full w-full object-cover" />
            ) : (
              <span className="text-3xl font-semibold" style={{ color: accent }}>
                {(profile.nickname || profile.handle || '?')[0].toUpperCase()}
              </span>
            )}
          </div>

          <h1 className="text-2xl font-semibold" style={{ color: accent }}>{profile.nickname || profile.handle}</h1>
          <p className="text-sm mb-1" style={{ color: 'var(--color-text-secondary)' }}>@{profile.handle}</p>
          {(profile.age || profile.zodiac) && (
            <p className="text-sm mb-4" style={{ color: 'var(--color-text-secondary)' }}>
              {[profile.zodiac && humanize(profile.zodiac), profile.age].filter(Boolean).join(' · ')}
            </p>
          )}

          {profile.bio && <p className="text-center text-[15px] mb-4">{profile.bio}</p>}

          {profile.hobbies?.length > 0 && (
            <div className="flex flex-wrap gap-2 justify-center mb-5">
              {profile.hobbies.map((tag) => (
                <span key={tag} className="text-xs font-medium px-3 py-1.5 rounded-full" style={{ background: accent, color: '#fff' }}>
                  {tag}
                </span>
              ))}
            </div>
          )}

          {profile.lookingFor && (
            <div className="w-full mb-4">
              <p className="text-xs font-semibold mb-1" style={{ color: 'var(--color-text-secondary)' }}>LOOKING FOR</p>
              <p className="text-[15px]">{profile.lookingFor}</p>
            </div>
          )}

          <div className="w-full">
            <Row label="Gender">{profile.gender?.map(humanize)}</Row>
            <Row label="Orientation">{profile.orientation?.map(humanize)}</Row>
            <Row label="Pronouns">{profile.pronouns}</Row>
            <Row label="Country">{profile.country}</Row>
            <Row label="Build">{humanize(profile.build)}</Row>
            <Row label="Height">{profile.heightCm ? `${profile.heightCm} cm` : null}</Row>
            <Row label="Commitment">{humanize(profile.commitment)}</Row>
            <Row label="Has kids">{profile.has_kids?.map(humanize)}</Row>
            <Row label="Pets">{profile.pets?.map(humanize)}</Row>
            {profile.petsNote && <Row label="Pet notes">{profile.petsNote}</Row>}
            <Row label="Diet">{humanize(profile.diet)}</Row>
            <Row label="Religion">{profile.religion?.map(humanize)}</Row>
            <Row label="Polyamory">{humanize(profile.polyamory)}</Row>
          </div>
        </div>
      )}
    </div>
  );
}
