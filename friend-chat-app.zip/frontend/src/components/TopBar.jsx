import { Menu } from 'lucide-react';
import NameTag from './NameTag';

// user: null (pure anonymous visitor) | { handle, nickname, isRegistered }
export default function TopBar({ siteName, user, onAuthClick, onMenuClick }) {
  return (
    <div
      className="flex items-center justify-between px-3 py-2 border-b shrink-0"
      style={{
        borderColor: 'var(--color-border)',
        background: 'var(--color-bg-elevated)',
        paddingTop: 'calc(env(safe-area-inset-top) + 8px)',
      }}
    >
      <div className="w-24 flex justify-start overflow-hidden">
        {user?.isRegistered ? (
          <NameTag nickname={user.nickname} handle={user.handle} isRegistered className="truncate" size="sm" />
        ) : (
          <button
            onClick={onAuthClick}
            className="text-[13px] font-semibold"
            style={{ color: 'var(--theme-accent)' }}
          >
            {user ? 'Register' : 'Log In'}
          </button>
        )}
      </div>

      <h1 className="text-[17px] font-semibold truncate">{siteName}</h1>

      <div className="w-24 flex justify-end">
        <button onClick={onMenuClick} className="h-8 w-8 flex items-center justify-center" aria-label="Open menu">
          <Menu size={22} color="var(--color-text)" />
        </button>
      </div>
    </div>
  );
}
