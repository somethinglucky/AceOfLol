import { ArrowLeft, Menu } from 'lucide-react';
import AdBanner from './AdBanner';

// user: null (pure anonymous visitor) | { handle, nickname, isRegistered }
// unreadCount: badge shown over the hamburger icon (DMs, likes, and game
// invites all land here — see App.jsx for how it's computed). Omit or
// pass 0 to show no badge; the button itself is the same single tap
// target either way, so tapping the badge and tapping the hamburger do
// exactly the same thing (open the menu) — there's nothing to wire up
// separately for that.
//
// onBack: pass App.jsx's handleBack and the top-left button is a "<"
// that returns to wherever the person actually came from (see App.jsx's
// pageHistory). Omit it — as ChatPage does, and only ChatPage — and the
// button falls back to Logout (registered) or Sign Up/In (guest/signed
// out) instead, since chat is the root everything else's back button
// eventually leads to; there's nowhere further back to go from it.
// This one prop is what makes every page share the exact same top
// structure (ad space, then back/auth — site name — menu) with chat as
// the one deliberate exception on just the left button.
export default function TopBar({ siteName, user, unreadCount = 0, onBack, onAuthClick, onMenuClick, onLogout }) {
  return (
    <>
      <AdBanner />
      <div
        className="flex items-center justify-between px-3 py-2 border-b shrink-0"
        style={{ borderColor: 'var(--color-border)', background: 'var(--color-bg-elevated)' }}
      >
        <div className="w-16 flex justify-start">
          {onBack ? (
            <button onClick={onBack} className="h-8 w-8 flex items-center justify-center -ml-1" aria-label="Back">
              <ArrowLeft size={22} color="var(--color-text)" />
            </button>
          ) : user?.isRegistered ? (
            // No confirmation prompt on purpose — logging out is fully
            // reversible (just log back in), so a confirm dialog would
            // only ever be friction.
            <button onClick={onLogout} className="text-[13px] font-semibold" style={{ color: 'var(--theme-accent)' }}>
              Logout
            </button>
          ) : (
            <button onClick={onAuthClick} className="text-[13px] font-semibold" style={{ color: 'var(--theme-accent)' }}>
              Sign Up/In
            </button>
          )}
        </div>

        <h1 className="text-[17px] font-semibold truncate">{siteName}</h1>

        <div className="w-16 flex justify-end">
          <button onClick={onMenuClick} className="relative h-8 w-8 flex items-center justify-center" aria-label="Open menu">
            <Menu size={22} color="var(--color-text)" />
            {unreadCount > 0 && (
              <span
                className="absolute -top-0.5 -right-0.5 h-4 min-w-4 px-1 rounded-full text-[10px] font-semibold text-white flex items-center justify-center"
                style={{ background: '#ff375f' }}
              >
                {unreadCount > 99 ? '99+' : unreadCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </>
  );
}
