import { useEffect, useRef, useState } from 'react';
import { Send } from 'lucide-react';
import { randomRiddle } from '../data/riddles';

// "Joker" isn't a real account — no user row, no handle, nothing
// persisted. It only exists as long as this component is mounted, which
// GameSessionPage only does while the viewer is alone in a 'waiting'
// invite session; the moment the other person arrives, this unmounts and
// every trace of it is gone, same as it never happened. That statelessness
// is deliberate, not a shortcut: giving it a real account would mean it
// shows up in search, leaderboards, DM lists, block lists — all the
// machinery built for actual people — for an entity that was never one.
// A purely local, ephemeral "character" is the honest shape for what
// this actually is.
export default function JokerRiddle() {
  const [exchanges, setExchanges] = useState(() => {
    const first = randomRiddle();
    return [{ type: 'riddle', text: first.question, answer: first.answer }];
  });
  const [guess, setGuess] = useState('');
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: 'nearest' });
  }, [exchanges]);

  function currentRiddle() {
    return [...exchanges].reverse().find((e) => e.type === 'riddle');
  }

  function handleGuess(e) {
    e.preventDefault();
    const trimmed = guess.trim();
    if (!trimmed) return;
    const riddle = currentRiddle();
    const next = randomRiddle(riddle?.text);
    setExchanges((prev) => [
      ...prev,
      { type: 'you', text: trimmed },
      { type: 'reveal', text: `The answer was: ${riddle.answer}` },
      { type: 'riddle', text: next.question, answer: next.answer },
    ]);
    setGuess('');
  }

  return (
    <div className="w-full max-w-sm rounded-2xl p-2.5 flex flex-col gap-1.5" style={{ background: 'var(--color-bg-elevated)', border: '1px solid var(--color-border)' }}>
      <p className="text-[10px] uppercase tracking-wide text-center" style={{ color: 'var(--color-text-secondary)' }}>
        While you wait…
      </p>
      <div className="flex flex-col gap-1 max-h-32 overflow-y-auto px-1">
        {exchanges.map((e, i) => {
          if (e.type === 'riddle') {
            return (
              <div key={i} className="flex items-start gap-1.5">
                <span className="text-[15px] shrink-0">🃏</span>
                <div className="px-2.5 py-1 rounded-2xl text-[12px]" style={{ background: 'var(--color-bubble-received)', color: 'var(--color-text)' }}>
                  <span className="block text-[9px] font-semibold mb-0.5" style={{ color: 'var(--theme-accent)' }}>Joker</span>
                  {e.text}
                </div>
              </div>
            );
          }
          if (e.type === 'you') {
            return (
              <div key={i} className="flex justify-end">
                <div className="max-w-[75%] px-2.5 py-1 rounded-2xl text-[12px]" style={{ background: 'var(--theme-accent)', color: '#fff' }}>
                  {e.text}
                </div>
              </div>
            );
          }
          return (
            <p key={i} className="text-[11px] text-center italic" style={{ color: 'var(--color-text-secondary)' }}>
              {e.text}
            </p>
          );
        })}
        <div ref={endRef} />
      </div>
      <form onSubmit={handleGuess} className="flex items-center gap-2">
        <input
          value={guess}
          onChange={(ev) => setGuess(ev.target.value)}
          placeholder="Your guess…"
          className="flex-1 rounded-full px-3 py-1.5 text-[13px]"
          style={{ background: 'var(--color-bg)', border: '1px solid var(--color-border)', color: 'var(--color-text)' }}
        />
        <button type="submit" className="h-8 w-8 rounded-full flex items-center justify-center shrink-0" style={{ background: 'var(--theme-accent)' }}>
          <Send size={14} color="white" />
        </button>
      </form>
    </div>
  );
}
