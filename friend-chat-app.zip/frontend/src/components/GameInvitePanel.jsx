import { useEffect, useState } from 'react';
import { api } from '../api/client';

function formatDate(iso) {
  try {
    return new Date(iso).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  } catch {
    return iso;
  }
}

// The Invite Flow (Games spec §6) — create an invite, or respond to one
// sitting in your inbox. Kept as its own panel since it's the most
// stateful piece of the Lobby (§6 calls it out as "the most stateful part
// of the system"), separate from the simpler Settings/Rules modals.
export default function GameInvitePanel({ gameId, gameName, currentUserId, onClose, onSessionCreated }) {
  const [invites, setInvites] = useState(null);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  // New-invite form state
  const [invitee, setInvitee] = useState('');
  const [dateInputs, setDateInputs] = useState(['']);
  const [expiresAt, setExpiresAt] = useState('');
  const [submitting, setSubmitting] = useState(false);

  function loadInvites() {
    api.getGameInvitesFor(gameId).then((data) => setInvites(data.invites)).catch(() => setError("Couldn't load invites."));
  }

  useEffect(loadInvites, [gameId]);

  function updateDateInput(i, value) {
    setDateInputs((prev) => prev.map((d, idx) => (idx === i ? value : d)));
  }

  async function handleCreateInvite(e) {
    e.preventDefault();
    setError('');
    const proposedDates = dateInputs.filter(Boolean).map((d) => new Date(d).toISOString());
    if (proposedDates.length === 0) return setError('Pick at least one candidate date/time.');
    if (!expiresAt) return setError('Pick an expiration date/time.');

    setSubmitting(true);
    try {
      await api.createGameInvite({
        gameId,
        invitee: invitee.trim(),
        proposedDates,
        expiresAt: new Date(expiresAt).toISOString(),
      });
      setNotice('Invite sent!');
      setInvitee('');
      setDateInputs(['']);
      setExpiresAt('');
      loadInvites();
    } catch (err) {
      setError(err.message || "Couldn't send that invite.");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleRespond(invite, chosenDate) {
    setError('');
    try {
      const { sessionId } = await api.respondToGameInvite(invite.id, chosenDate);
      onSessionCreated(sessionId);
    } catch (err) {
      setError(err.message || "Couldn't confirm that invite.");
      loadInvites();
    }
  }

  async function handleCancel(invite) {
    setError('');
    try {
      await api.cancelGameInvite(invite.id);
      loadInvites();
    } catch (err) {
      setError(err.message || "Couldn't cancel that invite.");
    }
  }

  const received = (invites || []).filter((i) => i.inviteeId === currentUserId);
  const sent = (invites || []).filter((i) => i.inviterId === currentUserId);

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" style={{ background: 'rgba(0,0,0,0.35)' }} onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-h-[85vh] overflow-y-auto rounded-t-2xl p-4 flex flex-col gap-4"
        style={{ background: 'var(--color-bg-elevated)' }}
      >
        <div className="flex items-center justify-between">
          <h3 className="text-[17px] font-semibold">Invite to {gameName}</h3>
          <button onClick={onClose} className="text-[14px]" style={{ color: 'var(--color-text-secondary)' }}>Close</button>
        </div>

        {error && <p className="text-[13px]" style={{ color: '#ff375f' }}>{error}</p>}
        {notice && <p className="text-[13px]" style={{ color: 'var(--theme-accent)' }}>{notice}</p>}

        <form onSubmit={handleCreateInvite} className="flex flex-col gap-2">
          <p className="text-[13px] font-semibold" style={{ color: 'var(--color-text-secondary)' }}>New invite</p>
          <input
            value={invitee}
            onChange={(e) => setInvitee(e.target.value)}
            placeholder="Their handle or email"
            className="rounded-lg px-3 py-2 text-[14px]"
            style={{ background: 'var(--color-bg)', border: '1px solid var(--color-border)', color: 'var(--color-text)' }}
          />
          <p className="text-[12px]" style={{ color: 'var(--color-text-secondary)' }}>Candidate date(s)/time(s):</p>
          {dateInputs.map((d, i) => (
            <input
              key={i}
              type="datetime-local"
              value={d}
              onChange={(e) => updateDateInput(i, e.target.value)}
              className="rounded-lg px-3 py-2 text-[14px]"
              style={{ background: 'var(--color-bg)', border: '1px solid var(--color-border)', color: 'var(--color-text)' }}
            />
          ))}
          <button
            type="button"
            onClick={() => setDateInputs((prev) => [...prev, ''])}
            className="text-[13px] self-start"
            style={{ color: 'var(--theme-accent)' }}
          >
            + Add another candidate time
          </button>
          <p className="text-[12px] mt-1" style={{ color: 'var(--color-text-secondary)' }}>Invite expires at:</p>
          <input
            type="datetime-local"
            value={expiresAt}
            onChange={(e) => setExpiresAt(e.target.value)}
            className="rounded-lg px-3 py-2 text-[14px]"
            style={{ background: 'var(--color-bg)', border: '1px solid var(--color-border)', color: 'var(--color-text)' }}
          />
          <button
            type="submit"
            disabled={submitting}
            className="mt-1 rounded-full py-2 text-[14px] font-semibold text-white disabled:opacity-60"
            style={{ background: 'var(--theme-accent)' }}
          >
            {submitting ? 'Sending…' : 'Send Invite'}
          </button>
        </form>

        {received.length > 0 && (
          <div className="flex flex-col gap-2">
            <p className="text-[13px] font-semibold" style={{ color: 'var(--color-text-secondary)' }}>Invites for you</p>
            {received.map((invite) => (
              <div key={invite.id} className="rounded-lg p-3" style={{ background: 'var(--color-bg)', border: '1px solid var(--color-border)' }}>
                <p className="text-[13px]" style={{ color: 'var(--color-text-secondary)' }}>
                  Status: {invite.status}{invite.chosenDate ? ` — ${formatDate(invite.chosenDate)}` : ''}
                </p>
                {invite.status === 'pending' && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {invite.proposedDates.map((d) => (
                      <button
                        key={d}
                        onClick={() => handleRespond(invite, d)}
                        className="text-[12px] px-2 py-1 rounded-full"
                        style={{ background: 'var(--theme-accent)', color: 'white' }}
                      >
                        {formatDate(d)}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {sent.length > 0 && (
          <div className="flex flex-col gap-2">
            <p className="text-[13px] font-semibold" style={{ color: 'var(--color-text-secondary)' }}>Your sent invites</p>
            {sent.map((invite) => (
              <div key={invite.id} className="rounded-lg p-3 flex items-center justify-between" style={{ background: 'var(--color-bg)', border: '1px solid var(--color-border)' }}>
                <p className="text-[13px]" style={{ color: 'var(--color-text-secondary)' }}>
                  Status: {invite.status}{invite.chosenDate ? ` — ${formatDate(invite.chosenDate)}` : ''}
                  {invite.gemCost > 0 ? ` — ${invite.gemCost}♦` : ''}
                </p>
                {invite.status === 'pending' && (
                  <button onClick={() => handleCancel(invite)} className="text-[12px]" style={{ color: '#ff375f' }}>Cancel</button>
                )}
                {invite.status === 'confirmed' && invite.sessionId && (
                  <button onClick={() => onSessionCreated(invite.sessionId)} className="text-[12px]" style={{ color: 'var(--theme-accent)' }}>Open</button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
