import { useEffect, useRef, useState } from 'react';
import { api } from '../api/client';
import { INVITE_TEMPLATES } from '../data/inviteTemplates';
import InvitationCard from './InvitationCard';

function formatDate(iso) {
  try {
    return new Date(iso).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  } catch {
    return iso;
  }
}

// The Invite Flow (Games spec §6) — create an invite, or respond to one
// sitting in your inbox. Kept as its own panel since it's the most
// stateful piece of the Lobby (§6 calls it out as "the most stateful part
// of the system"), separate from the simpler Settings/Rules modals.
export default function GameInvitePanel({ gameId, gameName, currentUserId, onClose, onSessionCreated }) {
  const [invites, setInvites] = useState(null);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  // New-invite form state
  const [invitee, setInvitee] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [dateInputs, setDateInputs] = useState(['']);
  const [templateId, setTemplateId] = useState(INVITE_TEMPLATES[0].id);
  const [submitting, setSubmitting] = useState(false);
  const suggestionsRequestId = useRef(0);

  function loadInvites() {
    api.getGameInvitesFor(gameId).then((data) => setInvites(data.invites)).catch(() => setError("Couldn't load invites."));
  }

  useEffect(loadInvites, [gameId]);

  // Debounced handle/nickname lookup — waits for a short pause in typing
  // rather than firing on every keystroke, and ignores any response that
  // isn't from the most recent request (a slower earlier request landing
  // after a faster later one would otherwise show stale suggestions).
  useEffect(() => {
    const query = invitee.trim();
    if (query.length < 2 || query.includes('@')) {
      setSuggestions([]);
      return undefined;
    }
    const requestId = ++suggestionsRequestId.current;
    const timeout = setTimeout(() => {
      api
        .getHandleSuggestions(query)
        .then((data) => {
          if (requestId === suggestionsRequestId.current) setSuggestions(data.suggestions);
        })
        .catch(() => {});
    }, 250);
    return () => clearTimeout(timeout);
  }, [invitee]);

  function updateDateInput(i, value) {
    setDateInputs((prev) => prev.map((d, idx) => (idx === i ? value : d)));
  }

  async function handleCreateInvite(e) {
    e.preventDefault();
    setError('');
    const proposedDates = dateInputs.filter(Boolean).map((d) => new Date(d).toISOString());
    if (proposedDates.length === 0) return setError('Pick at least one candidate date/time.');

    setSubmitting(true);
    try {
      await api.createGameInvite({
        gameId,
        invitee: invitee.trim(),
        proposedDates,
        templateId,
      });
      setNotice('Invite sent!');
      setInvitee('');
      setDateInputs(['']);
      setTemplateId(INVITE_TEMPLATES[0].id);
      loadInvites();
    } catch (err) {
      setError(err.message || "Couldn't send that invite.");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleRespond(invite, chosenDate) {
    setError('');
    try {
      const { sessionId } = await api.respondToGameInvite(invite.id, chosenDate);
      onSessionCreated(sessionId);
    } catch (err) {
      setError(err.message || "Couldn't confirm that invite.");
      loadInvites();
    }
  }

  async function handleCancel(invite) {
    setError('');
    try {
      await api.cancelGameInvite(invite.id);
      loadInvites();
    } catch (err) {
      setError(err.message || "Couldn't cancel that invite.");
    }
  }

  const received = (invites || []).filter((i) => i.inviteeId === currentUserId);
  const sent = (invites || []).filter((i) => i.inviterId === currentUserId);

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" style={{ background: 'rgba(0,0,0,0.35)' }} onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-h-[85vh] overflow-y-auto rounded-t-2xl p-4 flex flex-col gap-4"
        style={{ background: 'var(--color-bg-elevated)' }}
      >
        <div className="flex items-center justify-between">
          <h3 className="text-[17px] font-semibold">Invite to {gameName}</h3>
          <button onClick={onClose} className="text-[14px]" style={{ color: 'var(--color-text-secondary)' }}>Close</button>
        </div>

        {error && <p className="text-[13px]" style={{ color: '#ff375f' }}>{error}</p>}
        {notice && <p className="text-[13px]" style={{ color: 'var(--theme-accent)' }}>{notice}</p>}

        <form onSubmit={handleCreateInvite} className="flex flex-col gap-2">
          <p className="text-[13px] font-semibold" style={{ color: 'var(--color-text-secondary)' }}>New invite</p>

          <p className="text-[12px]" style={{ color: 'var(--color-text-secondary)' }}>Choose an invitation card:</p>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {INVITE_TEMPLATES.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTemplateId(t.id)}
                className="rounded-lg p-0.5 shrink-0"
                style={{ border: templateId === t.id ? '2px solid var(--theme-accent)' : '2px solid transparent' }}
              >
                <InvitationCard templateId={t.id} size="sm" />
              </button>
            ))}
          </div>

          <div className="relative mt-1">
            <input
              value={invitee}
              onChange={(e) => { setInvitee(e.target.value); setShowSuggestions(true); }}
              onFocus={() => setShowSuggestions(true)}
              onBlur={() => setTimeout(() => setShowSuggestions(false), 150)}
              placeholder="Their handle or email"
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck="false"
              className="w-full rounded-lg px-3 py-2 text-[14px]"
              style={{ background: 'var(--color-bg)', border: '1px solid var(--color-border)', color: 'var(--color-text)' }}
            />
            {showSuggestions && suggestions.length > 0 && (
              <div
                className="absolute left-0 right-0 top-full mt-1 rounded-lg overflow-hidden z-10"
                style={{ background: 'var(--color-bg-elevated)', border: '1px solid var(--color-border)' }}
              >
                {suggestions.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    // onMouseDown (not onClick) fires before the input's
                    // onBlur closes the dropdown, so the tap actually
                    // registers instead of the list disappearing first.
                    onMouseDown={() => { setInvitee(s.handle); setShowSuggestions(false); }}
                    className="w-full text-left px-3 py-2 text-[13px]"
                    style={{ color: 'var(--color-text)' }}
                  >
                    {s.nickname}@{s.handle}
                  </button>
                ))}
              </div>
            )}
          </div>
          <p className="text-[12px]" style={{ color: 'var(--color-text-secondary)' }}>Candidate date(s)/time(s):</p>
          {dateInputs.map((d, i) => (
            <input
              key={i}
              type="datetime-local"
              value={d}
              onChange={(e) => updateDateInput(i, e.target.value)}
              className="rounded-lg px-3 py-2 text-[14px]"
              style={{ background: 'var(--color-bg)', border: '1px solid var(--color-border)', color: 'var(--color-text)' }}
            />
          ))}
          <button
            type="button"
            onClick={() => setDateInputs((prev) => [...prev, ''])}
            className="text-[13px] self-start"
            style={{ color: 'var(--theme-accent)' }}
          >
            + Add another candidate time
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="mt-1 rounded-full py-2 text-[14px] font-semibold text-white disabled:opacity-60"
            style={{ background: 'var(--theme-accent)' }}
          >
            {submitting ? 'Sending…' : 'Send Invite'}
          </button>
        </form>

        {received.length > 0 && (
          <div className="flex flex-col gap-2">
            <p className="text-[13px] font-semibold" style={{ color: 'var(--color-text-secondary)' }}>Invites for you</p>
            {received.map((invite) => (
              <div key={invite.id} className="rounded-lg p-3 flex gap-3" style={{ background: 'var(--color-bg)', border: '1px solid var(--color-border)' }}>
                <InvitationCard templateId={invite.templateId} size="sm" />
                <div className="flex-1 min-w-0">
                  <p className="text-[13px]" style={{ color: 'var(--color-text-secondary)' }}>
                    Status: {invite.status}{invite.chosenDate ? ` — ${formatDate(invite.chosenDate)}` : ''}
                  </p>
                  {invite.status === 'pending' && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {invite.proposedDates.map((d) => (
                        <button
                          key={d}
                          onClick={() => handleRespond(invite, d)}
                          className="text-[12px] px-2 py-1 rounded-full"
                          style={{ background: 'var(--theme-accent)', color: 'white' }}
                        >
                          {formatDate(d)}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {sent.length > 0 && (
          <div className="flex flex-col gap-2">
            <p className="text-[13px] font-semibold" style={{ color: 'var(--color-text-secondary)' }}>Your sent invites</p>
            {sent.map((invite) => (
              <div key={invite.id} className="rounded-lg p-3 flex items-center gap-3" style={{ background: 'var(--color-bg)', border: '1px solid var(--color-border)' }}>
                <InvitationCard templateId={invite.templateId} size="sm" />
                <div className="flex-1 min-w-0">
                  <p className="text-[13px]" style={{ color: 'var(--color-text-secondary)' }}>
                    Status: {invite.status}{invite.chosenDate ? ` — ${formatDate(invite.chosenDate)}` : ''}
                    {invite.gemCost > 0 ? ` — ${invite.gemCost}♦` : ''}
                  </p>
                  {invite.status === 'pending' && (
                    <button onClick={() => handleCancel(invite)} className="text-[12px] mt-1" style={{ color: '#ff375f' }}>Cancel</button>
                  )}
                  {invite.status === 'confirmed' && invite.sessionId && (
                    <button onClick={() => onSessionCreated(invite.sessionId)} className="text-[12px] mt-1" style={{ color: 'var(--theme-accent)' }}>Open</button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
