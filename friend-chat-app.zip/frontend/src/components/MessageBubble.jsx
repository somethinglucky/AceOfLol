// currentUserId lets us tell "my messages" (right-aligned, accent color) apart
// from everyone else's (left-aligned, neutral gray) — the core iMessage pattern.
export default function MessageBubble({ message, currentUserId, onAvatarTap }) {
  const isMine = message.user_id === currentUserId;

  return (
    <div className={`flex items-end gap-2 px-3 py-1 ${isMine ? 'flex-row-reverse' : 'flex-row'}`}>
      {!isMine && (
        <button
          onClick={() => onAvatarTap(message.user_id)}
          className="h-8 w-8 shrink-0 rounded-full overflow-hidden bg-[var(--color-bubble-received)] flex items-center justify-center"
          aria-label="View profile"
        >
          {message.avatar_url ? (
            <img src={message.avatar_url} alt="" className="h-full w-full object-cover" />
          ) : (
            <span className="text-xs font-medium text-[var(--color-text-secondary)]">
              {(message.nickname || '?')[0].toUpperCase()}
            </span>
          )}
        </button>
      )}

      <div
        className="max-w-[75%] px-3.5 py-2 text-[15px] leading-snug"
        style={{
          borderRadius: 'var(--radius-bubble)',
          background: isMine ? 'var(--theme-accent)' : 'var(--color-bubble-received)',
          color: isMine ? '#ffffff' : 'var(--color-text)',
        }}
      >
        {!isMine && (
          <div className="text-[11px] font-medium mb-0.5 text-[var(--color-text-secondary)]">
            {message.nickname}
          </div>
        )}
        {message.content}
      </div>
    </div>
  );
}
