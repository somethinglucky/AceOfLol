import { colorFromString } from '../utils/colorHash';

// message.sender is enriched server-side: { handle, isRegistered, nickname, avatarUrl }
export default function MessageBubble({ message, currentUserId, onAvatarTap }) {
  const isMine = message.user_id === currentUserId;
  const sender = message.sender || {};
  const displayName = sender.nickname || sender.handle || '?';

  return (
    <div className={`flex items-end gap-2 px-3 py-1 ${isMine ? 'flex-row-reverse' : 'flex-row'}`}>
      {!isMine && (
        <button
          onClick={() => onAvatarTap(message.user_id, sender)}
          className="h-8 w-8 shrink-0 rounded-full overflow-hidden flex items-center justify-center"
          style={{ background: sender.isRegistered ? 'var(--color-bubble-received)' : colorFromString(sender.handle || message.user_id) }}
          aria-label="View profile"
        >
          {sender.isRegistered && sender.avatarUrl ? (
            <img src={sender.avatarUrl} alt="" className="h-full w-full object-cover" />
          ) : sender.isRegistered ? (
            <span className="text-xs font-medium text-[var(--color-text-secondary)]">
              {displayName[0]?.toUpperCase()}
            </span>
          ) : null /* guests show a plain color swatch, no letter — a color is
                       recognizable across messages without implying an
                       identity more permanent than "same guest, this session" */}
        </button>
      )}

      <div
        className="max-w-[75%] px-3.5 py-2 text-[15px] leading-snug"
        style={{
          borderRadius: 'var(--radius-bubble)',
          background: isMine ? 'var(--theme-accent)' : 'var(--color-bubble-received)',
          color: isMine ? '#ffffff' : 'var(--color-text)',
        }}
      >
        {!isMine && (
          <div className="text-[11px] font-medium mb-0.5 text-[var(--color-text-secondary)]">
            {displayName}
          </div>
        )}
        {message.content}
      </div>
    </div>
  );
}
