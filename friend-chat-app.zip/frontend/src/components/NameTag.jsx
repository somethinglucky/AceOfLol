// Displays a person's name the one consistent way, everywhere: their
// chosen nickname (which anyone can set to anything, and isn't unique)
// immediately followed by their permanent, unique @handle in smaller,
// muted text — e.g. "Bill@zZzOiYu". Nickname and handle should never be
// shown apart, since the handle is what actually identifies a specific
// person when nicknames collide.
//
// `size` scales both parts together: 'sm' for tight spaces (message
// bubbles, list rows), 'md' (default) for most contexts, 'lg' for a
// profile header.
const SIZES = {
  sm: { nickname: 'text-[13px]', handle: 'text-[11px]' },
  md: { nickname: 'text-[15px]', handle: 'text-[13px]' },
  lg: { nickname: 'text-[22px]', handle: 'text-[15px]' },
};

export default function NameTag({ nickname, handle, isRegistered = true, size = 'md', nicknameColor, className = '' }) {
  const s = SIZES[size] || SIZES.md;
  // A registered account always has a nickname (set at signup); a guest
  // hasn't chosen one, so "Guest" is the label until they do.
  const displayNickname = nickname || (isRegistered ? handle : 'Guest');

  return (
    <span className={className}>
      <span className={`${s.nickname} font-semibold`} style={{ color: nicknameColor || 'var(--color-text)' }}>
        {displayNickname}
      </span>
      <span className={`${s.handle} font-normal`} style={{ color: 'var(--color-text-secondary)' }}>
        @{handle}
      </span>
    </span>
  );
}
