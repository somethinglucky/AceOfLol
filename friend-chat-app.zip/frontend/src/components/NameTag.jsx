import { useProfileNav } from '../context/ProfileNavContext';

// Displays a person's name the one consistent way, everywhere: their
// chosen nickname (which anyone can set to anything, and isn't unique)
// immediately followed by their permanent, unique @handle in smaller,
// muted text — e.g. "Bill@zZzOiYu". Nickname and handle should never be
// shown apart, since the handle is what actually identifies a specific
// person when nicknames collide.
//
// Pass `userId` and every NameTag becomes a link to that person's
// profile, full stop — including the viewer's own, so tapping your own
// name always behaves the same way tapping anyone else's does. Omit
// `userId` (e.g. inside ProfileCard itself, where you're already looking
// at that profile) and it just renders as plain text, unclickable.
//
// `size` scales both parts together: 'sm' for tight spaces (message
// bubbles, list rows), 'md' (default) for most contexts, 'lg' for a
// profile header.
const SIZES = {
  sm: { nickname: 'text-[13px]', handle: 'text-[11px]' },
  md: { nickname: 'text-[15px]', handle: 'text-[13px]' },
  lg: { nickname: 'text-[22px]', handle: 'text-[15px]' },
};

export default function NameTag({ nickname, handle, isRegistered = true, size = 'md', nicknameColor, className = '', userId, sender }) {
  const openProfile = useProfileNav();
  const s = SIZES[size] || SIZES.md;
  // A registered account always has a nickname (set at signup); a guest
  // hasn't chosen one, so "Guest" is the label until they do.
  const displayNickname = nickname || (isRegistered ? handle : 'Guest');

  const content = (
    <>
      <span className={`${s.nickname} font-semibold`} style={{ color: nicknameColor || 'var(--color-text)' }}>
        {displayNickname}
      </span>
      <span className={`${s.handle} font-normal`} style={{ color: 'var(--color-text-secondary)' }}>
        @{handle}
      </span>
    </>
  );

  if (userId && openProfile) {
    return (
      <button
        type="button"
        onClick={(e) => {
          // Stops a NameTag nested inside a bigger clickable row (a DM
          // inbox item, say, whose own tap opens the conversation) from
          // ALSO triggering that outer action — tapping the name should
          // only ever mean "view this profile", nothing else at the
          // same time.
          e.stopPropagation();
          openProfile(userId, sender);
        }}
        className={`text-left ${className}`}
      >
        {content}
      </button>
    );
  }

  return <span className={className}>{content}</span>;
}
