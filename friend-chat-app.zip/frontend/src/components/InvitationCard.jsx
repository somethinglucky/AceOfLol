import { getInviteTemplate } from '../data/inviteTemplates';

// Renders one invitation design. Used at three sizes:
// - 'sm': the miniature preview inside GameInvitePanel's template picker
// - 'md': the card embedded in a DM message
// - 'lg': the full reveal page the invitee sees before entering the game
//
// Prefers an actual image (template.imageUrl) once real artwork exists;
// falls back to the CSS look below until then — see inviteTemplates.js.
export default function InvitationCard({ templateId, size = 'md', title, subtitle, gameIcon, gameName }) {
  const t = getInviteTemplate(templateId);

  const dims = {
    sm: { w: 72, h: 96, padding: 8, ornament: 16, title: 10 },
    md: { w: 220, h: 140, padding: 14, ornament: 22, title: 15 },
    lg: { w: 300, h: 420, padding: 28, ornament: 40, title: 22 },
  }[size];

  if (t.imageUrl) {
    return (
      <img
        src={t.imageUrl}
        alt={t.label}
        style={{ width: dims.w, height: dims.h, objectFit: 'cover', borderRadius: 12 }}
      />
    );
  }

  return (
    <div
      className="flex flex-col items-center justify-center text-center rounded-xl shrink-0"
      style={{
        width: dims.w,
        height: dims.h,
        padding: dims.padding,
        background: t.background,
        border: `1px solid ${t.borderColor}`,
        boxShadow: size === 'lg' ? `0 0 0 1px ${t.borderColor}55, 0 12px 40px rgba(0,0,0,0.35)` : 'none',
        color: t.textColor,
      }}
    >
      <span style={{ fontSize: dims.ornament, color: t.accentColor, lineHeight: 1 }}>{t.ornament}</span>
      {size === 'lg' && gameIcon && (
        <span className="mt-3" style={{ fontSize: 40 }}>{gameIcon}</span>
      )}
      {title && (
        <p
          className="mt-2 font-semibold"
          style={{ fontSize: dims.title, color: t.textColor, letterSpacing: size === 'lg' ? '0.03em' : 0 }}
        >
          {title}
        </p>
      )}
      {subtitle && size !== 'sm' && (
        <p className="mt-1" style={{ fontSize: size === 'lg' ? 14 : 11, color: t.accentColor }}>
          {subtitle}
        </p>
      )}
      {size === 'lg' && gameName && (
        <p className="mt-4 text-[13px]" style={{ color: t.accentColor, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
          {gameName}
        </p>
      )}
      <span className="mt-3" style={{ fontSize: dims.ornament * 0.5, color: t.accentColor, opacity: 0.7 }}>{t.ornament}</span>
    </div>
  );
}
