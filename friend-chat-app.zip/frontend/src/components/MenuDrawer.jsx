import { X, Settings, User, Sparkles, Compass, Search, Image } from 'lucide-react';

const ITEMS = [
  { key: 'feed', label: 'Feed', icon: Image },
  { key: 'search', label: 'Search', icon: Search },
  { key: 'discover', label: 'Discover', icon: Compass },
  { key: 'profile', label: 'My Profile', icon: User },
  { key: 'premium', label: 'Premium', icon: Sparkles },
  { key: 'settings', label: 'Settings', icon: Settings },
];

export default function MenuDrawer({ open, onClose, onNavigate }) {
  function handleItemClick(key) {
    if (key === 'feed') {
      // The feed is a separately-built static app (not a React route), so
      // this is a real page navigation, not a state change. Resetting the
      // nav-depth counter to 1 here is what makes the feed's own back
      // button correctly disable itself at its entry screen, per its
      // README — it increments this itself as the person drills further in.
      sessionStorage.setItem('aceoflol_nav_depth', '1');
      onClose();
      window.location.href = '/feed/';
      return;
    }
    onNavigate(key);
    onClose();
  }

  return (
    <>
      {/* Backdrop — tapping it closes the drawer, standard mobile pattern */}
      <div
        onClick={onClose}
        className={`fixed inset-0 z-40 bg-black/30 transition-opacity ${
          open ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      />

      <div
        className={`fixed top-0 right-0 z-50 h-full w-64 flex flex-col transition-transform duration-200 ${
          open ? 'translate-x-0' : 'translate-x-full'
        }`}
        style={{ background: 'var(--color-bg-elevated)', paddingTop: 'env(safe-area-inset-top)' }}
      >
        <div className="flex justify-end p-3">
          <button onClick={onClose} className="h-8 w-8 flex items-center justify-center" aria-label="Close menu">
            <X size={20} color="var(--color-text-secondary)" />
          </button>
        </div>

        <nav className="flex flex-col px-2 gap-1">
          {ITEMS.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => handleItemClick(key)}
              className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-[15px] font-medium text-left"
              style={{ color: 'var(--color-text)' }}
            >
              <Icon size={20} color="var(--theme-accent)" />
              {label}
            </button>
          ))}
        </nav>
      </div>
    </>
  );
}
