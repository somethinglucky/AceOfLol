import {
  X, Settings, User, Compass, Image, MessagesSquare, MessageCircle,
  ShoppingBag, Gamepad, Info, Star, Search, Sparkles, ShieldCheck, ShieldAlert,
} from 'lucide-react';

const ITEMS = [
  { key: 'profile', label: 'My Profile', icon: User },
  { key: 'dms', label: "DMs, Friends & Invites", icon: MessagesSquare },
  { key: 'chat', label: 'Chat', icon: MessageCircle },
  { key: 'feed', label: 'Memes', icon: Image },
  { key: 'store', label: 'Store', icon: ShoppingBag },
  { key: 'search', label: 'Search', icon: Search },
  { key: 'games', label: 'Games', icon: Gamepad },
  // Premium, Discover, About, Settings, and Review are hidden for the MVP
  // beta launch — the pages behind them aren't built yet. Their ITEMS
  // entries (and their icon imports) still exist commented out below so
  // restoring one later is a one-line uncomment, not a rebuild:
  // { key: 'premium', label: 'Premium', icon: Sparkles },
  // { key: 'discover', label: 'Discover', icon: Compass },
  // { key: 'settings', label: 'Settings', icon: Settings },
  // { key: 'about', label: 'About', icon: Info },
  // { key: 'review', label: 'Review', icon: Star },
];

const ADMIN_ITEM = { key: 'admin', label: 'Admin', icon: ShieldCheck };
const MODERATION_ITEM = { key: 'moderation', label: 'Moderation', icon: ShieldAlert };

// isAdmin/isModerator are UX only — hiding these buttons for everyone else
// is a courtesy, not the security boundary. Every admin/moderator action
// still requires the backend's own role check regardless of what's shown
// here. isAdmin implies isModerator (see backend/src/middleware/auth.js),
// so an admin sees both items; a plain moderator sees only Moderation.
export default function MenuDrawer({ open, onClose, onNavigate, isAdmin, isModerator, unreadCount = 0 }) {
  const items = [
    ...(isAdmin ? [ADMIN_ITEM] : []),
    ...(isModerator ? [MODERATION_ITEM] : []),
    ...ITEMS,
  ];

  function handleItemClick(key) {
    if (key === 'feed') {
      // The feed is a separately-built static app (not a React route), so
      // this is a real page navigation, not a state change. Its own back
      // button always returns to '/' directly (see feed-public/js/app.js).
      onClose();
      window.location.href = '/feed/';
      return;
    }
    onNavigate(key);
    onClose();
  }

  return (
    <>
      {/* Backdrop — tapping it closes the drawer, standard mobile pattern */}
      <div
        onClick={onClose}
        className={`fixed inset-0 z-40 bg-black/30 transition-opacity ${
          open ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      />

      <div
        className={`fixed top-0 right-0 z-50 h-full w-64 flex flex-col transition-transform duration-200 ${
          open ? 'translate-x-0' : 'translate-x-full'
        }`}
        style={{ background: 'var(--color-bg-elevated)', paddingTop: 'env(safe-area-inset-top)' }}
      >
        <div className="flex justify-end p-3">
          <button onClick={onClose} className="h-8 w-8 flex items-center justify-center" aria-label="Close menu">
            <X size={20} color="var(--color-text-secondary)" />
          </button>
        </div>

        <nav className="flex flex-col px-2 gap-1">
          {items.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => handleItemClick(key)}
              className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-[15px] font-medium text-left"
              style={{ color: 'var(--color-text)' }}
            >
              <Icon size={20} color="var(--theme-accent)" />
              {label}
              {key === 'dms' && unreadCount > 0 && (
                <span
                  className="ml-auto h-5 min-w-5 px-1.5 rounded-full text-[12px] font-semibold text-white flex items-center justify-center"
                  style={{ background: '#ff375f' }}
                >
                  {unreadCount > 99 ? '99+' : unreadCount}
                </span>
              )}
            </button>
          ))}
        </nav>
      </div>
    </>
  );
}
