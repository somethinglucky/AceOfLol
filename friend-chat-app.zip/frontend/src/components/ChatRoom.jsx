import { useEffect, useRef, useState } from 'react';
import { connectSocket, joinRoom, leaveRoom } from '../api/socket';
import MessageBubble from './MessageBubble';
import { Send } from 'lucide-react';

// Merges history with any messages already present, deduping by id and
// keeping chronological order — used whenever room_history arrives, since
// a few new_message events may have already landed before it does.
function mergeMessages(existing, incoming) {
  const byId = new Map(incoming.map((m) => [m.id, m]));
  existing.forEach((m) => {
    if (!byId.has(m.id)) byId.set(m.id, m);
  });
  return Array.from(byId.values()).sort((a, b) => a.created_at.localeCompare(b.created_at));
}

export default function ChatRoom({ roomId, currentUserId, onAvatarTap }) {
  const [messages, setMessages] = useState([]);
  const [draft, setDraft] = useState('');
  const scrollRef = useRef(null);

  useEffect(() => {
    const socket = connectSocket();
    joinRoom(roomId);

    const handleNewMessage = (msg) => {
      if (msg.room_id === roomId) setMessages((prev) => [...prev, msg]);
    };
    const handleHistory = ({ roomId: rid, messages: history }) => {
      if (rid === roomId) setMessages((prev) => mergeMessages(prev, history));
    };

    socket.on('new_message', handleNewMessage);
    socket.on('room_history', handleHistory);

    return () => {
      leaveRoom(roomId);
      socket.off('new_message', handleNewMessage);
      socket.off('room_history', handleHistory);
    };
  }, [roomId]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ block: 'end' });
  }, [messages]);

  function handleSend() {
    if (!draft.trim()) return;
    connectSocket().emit('send_message', { roomId, content: draft.trim() });
    setDraft('');
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto py-2">
        {messages.map((msg) => (
          <MessageBubble
            key={msg.id}
            message={msg}
            currentUserId={currentUserId}
            onAvatarTap={onAvatarTap}
          />
        ))}
        <div ref={scrollRef} />
      </div>

      <div
        className="flex items-center gap-2 px-3 py-2 border-t"
        style={{
          borderColor: 'var(--color-border)',
          background: 'var(--color-bg-elevated)',
          paddingBottom: 'calc(env(safe-area-inset-bottom) + 8px)',
        }}
      >
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Message"
          className="flex-1 rounded-full px-4 py-2 text-[15px] outline-none"
          style={{ background: 'var(--color-bubble-received)', color: 'var(--color-text)' }}
        />
        <button
          onClick={handleSend}
          disabled={!draft.trim()}
          className="h-9 w-9 rounded-full flex items-center justify-center shrink-0 disabled:opacity-40"
          style={{ background: 'var(--theme-accent)' }}
          aria-label="Send message"
        >
          <Send size={16} color="#ffffff" />
        </button>
      </div>
    </div>
  );
}
