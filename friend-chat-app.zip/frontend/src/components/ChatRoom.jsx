import { useEffect, useRef, useState } from 'react';
import { connectSocket } from '../api/socket';
import MessageBubble from './MessageBubble';
import { Send } from 'lucide-react';

export default function ChatRoom({ roomId, currentUserId, onAvatarTap }) {
  const [messages, setMessages] = useState([]);
  const [draft, setDraft] = useState('');
  const scrollRef = useRef(null);

  useEffect(() => {
    const socket = connectSocket();
    socket.emit('join_room', roomId);

    const handleNewMessage = (msg) => {
      if (msg.room_id === roomId) setMessages((prev) => [...prev, msg]);
    };
    socket.on('new_message', handleNewMessage);

    return () => {
      socket.emit('leave_room', roomId);
      socket.off('new_message', handleNewMessage);
    };
  }, [roomId]);

  // Keep the view pinned to the newest message, like every chat app does.
  useEffect(() => {
    scrollRef.current?.scrollIntoView({ block: 'end' });
  }, [messages]);

  function handleSend() {
    if (!draft.trim()) return;
    connectSocket().emit('send_message', { roomId, content: draft.trim() });
    setDraft('');
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto py-2">
        {messages.map((msg) => (
          <MessageBubble
            key={msg.id}
            message={msg}
            currentUserId={currentUserId}
            onAvatarTap={onAvatarTap}
          />
        ))}
        <div ref={scrollRef} />
      </div>

      <div
        className="flex items-center gap-2 px-3 py-2 border-t"
        style={{
          borderColor: 'var(--color-border)',
          background: 'var(--color-bg-elevated)',
          paddingBottom: 'calc(env(safe-area-inset-bottom) + 8px)',
        }}
      >
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Message"
          className="flex-1 rounded-full px-4 py-2 text-[15px] outline-none"
          style={{ background: 'var(--color-bubble-received)', color: 'var(--color-text)' }}
        />
        <button
          onClick={handleSend}
          disabled={!draft.trim()}
          className="h-9 w-9 rounded-full flex items-center justify-center shrink-0 disabled:opacity-40"
          style={{ background: 'var(--theme-accent)' }}
          aria-label="Send message"
        >
          <Send size={16} color="#ffffff" />
        </button>
      </div>
    </div>
  );
}
