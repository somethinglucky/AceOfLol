import { useState } from 'react';
import { ThemeProvider } from './theme/ThemeContext';
import AuthPage from './pages/AuthPage';
import ChatPage from './pages/ChatPage';

// Deliberately not pulling in a routing library for four screens on a
// mobile-only single-page app — plain state keeps the bundle smaller and
// the flow easy to follow. Revisit if the page count grows a lot.
export default function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState('chat');

  if (!user) {
    return (
      <ThemeProvider initialTheme={null}>
        <AuthPage onAuthed={setUser} />
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider initialTheme={user.theme}>
      {page === 'chat' && (
        <ChatPage
          roomId="general"
          roomName="General"
          currentUserId={user.id}
          onNavigate={setPage}
        />
      )}
      {/* Discover / Profile / Premium / Settings pages plug in here as they're built — 
          each just needs to call onNavigate('chat') to return. */}
      {page !== 'chat' && (
        <div className="flex flex-col items-center justify-center h-screen gap-4">
          <p style={{ color: 'var(--color-text-secondary)' }}>
            {page.charAt(0).toUpperCase() + page.slice(1)} — coming next
          </p>
          <button onClick={() => setPage('chat')} style={{ color: 'var(--theme-accent)' }}>
            Back to chat
          </button>
        </div>
      )}
    </ThemeProvider>
  );
}
