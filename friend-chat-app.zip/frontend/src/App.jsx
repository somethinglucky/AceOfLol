import { useEffect, useState } from 'react';
import { ThemeProvider } from './theme/ThemeContext';
import LandingPage from './pages/LandingPage';
import ChatPage from './pages/ChatPage';
import AuthPage from './pages/AuthPage';
import ProfileEditPage from './pages/ProfileEditPage';
import SearchPage from './pages/SearchPage';

const SITE_NAME = 'AceOfLol';

export default function App() {
  const [user, setUser] = useState(null); // null | { id, handle, nickname, isRegistered }
  const [page, setPage] = useState('landing'); // 'landing' | 'chat' | anything from the menu
  const [authOpen, setAuthOpen] = useState(false);

  // Returning visitor with a saved token (guest or registered) skips the
  // landing page entirely and goes straight into chat.
  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    const savedToken = localStorage.getItem('token');
    if (savedUser && savedToken) {
      setUser(JSON.parse(savedUser));
      setPage('chat');
    }
  }, []);

  function handleJoinedAsGuest(guestUser) {
    setUser(guestUser);
    setPage('chat');
  }

  function handleAuthed(updatedUser) {
    setUser(updatedUser);
    setAuthOpen(false);
    setPage('chat');
  }

  return (
    <ThemeProvider initialTheme={null}>
      {page === 'landing' && (
        <LandingPage
          siteName={SITE_NAME}
          onJoined={handleJoinedAsGuest}
          onAuthClick={() => setAuthOpen(true)}
        />
      )}

      {page === 'chat' && (
        <ChatPage
          siteName={SITE_NAME}
          roomId="everyone"
          user={user}
          onNavigate={setPage}
          onAuthClick={() => setAuthOpen(true)}
        />
      )}

      {page === 'profile' && <ProfileEditPage onBack={() => setPage('chat')} />}
      {page === 'search' && <SearchPage onBack={() => setPage('chat')} />}

      {page !== 'landing' && page !== 'chat' && page !== 'profile' && page !== 'search' && (
        <div className="flex flex-col items-center justify-center h-screen gap-4">
          <p style={{ color: 'var(--color-text-secondary)' }}>
            {page.charAt(0).toUpperCase() + page.slice(1)} — coming next
          </p>
          <button onClick={() => setPage('chat')} style={{ color: 'var(--theme-accent)' }}>
            Back to chat
          </button>
        </div>
      )}

      {/* Reachable from the top-left button on both landing and chat pages.
          isGuestUpgrade determines whether submitting calls /auth/register
          (adding credentials to the existing guest) or /auth/signup (fresh). */}
      {authOpen && (
        <AuthPage
          isGuestUpgrade={!!user && !user.isRegistered}
          onAuthed={handleAuthed}
          onClose={() => setAuthOpen(false)}
        />
      )}
    </ThemeProvider>
  );
}
