import { useEffect, useState } from 'react';
import { ThemeProvider } from './theme/ThemeContext';
import LandingPage from './pages/LandingPage';
import ChatPage from './pages/ChatPage';
import AuthPage from './pages/AuthPage';
import ProfileEditPage from './pages/ProfileEditPage';
import SearchPage from './pages/SearchPage';
import SettingsPage from './pages/SettingsPage';
import ComingSoonPage from './pages/ComingSoonPage';

const SITE_NAME = 'AceOfLol';
const REAL_PAGES = ['landing', 'chat', 'profile', 'search', 'settings'];

export default function App() {
  const [user, setUser] = useState(null); // null | { id, handle, nickname, isRegistered }
  const [page, setPage] = useState('landing'); // 'landing' | 'chat' | anything from the menu
  const [authOpen, setAuthOpen] = useState(false);

  // Returning visitor with a saved token (guest or registered) skips the
  // landing page entirely and goes straight into chat — or, if the URL has
  // a `?page=` (either from a direct link like the feed's menu, or because
  // we're restoring after a reload — see the sync effect below), that page.
  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    const savedToken = localStorage.getItem('token');
    if (savedUser && savedToken) {
      setUser(JSON.parse(savedUser));
      const requestedPage = new URLSearchParams(window.location.search).get('page');
      setPage(requestedPage || 'chat');
    }
  }, []);

  // This app has no router — every page lives purely in `page` state, so
  // without this, the address bar always just shows "/" no matter which
  // page you're on. That's invisible on a deliberate in-app tap, but it
  // means ANY reload (a stray pull-to-refresh, or iOS silently reloading a
  // backgrounded tab to reclaim memory, which is common) has nothing to
  // recover the current page from and always falls back to chat — which is
  // exactly what looks like "tapping Profile/Search bounces me to Chat."
  // Keeping the URL in sync (via replaceState, so it doesn't create a new
  // browser-history entry per tap) fixes that: any reload now restores
  // whichever page was actually open.
  useEffect(() => {
    if (page === 'landing') return;
    const url = page === 'chat' ? window.location.pathname : `${window.location.pathname}?page=${page}`;
    if (url !== window.location.pathname + window.location.search) {
      window.history.replaceState({}, '', url);
    }
  }, [page]);

  function handleJoinedAsGuest(guestUser) {
    setUser(guestUser);
    setPage('chat');
  }

  function handleAuthed(updatedUser) {
    setUser(updatedUser);
    setAuthOpen(false);
    setPage('chat');
  }

  return (
    <ThemeProvider initialTheme={null}>
      {page === 'landing' && (
        <LandingPage
          siteName={SITE_NAME}
          onJoined={handleJoinedAsGuest}
          onAuthClick={() => setAuthOpen(true)}
        />
      )}

      {page === 'chat' && (
        <ChatPage
          siteName={SITE_NAME}
          roomId="everyone"
          user={user}
          onNavigate={setPage}
          onAuthClick={() => setAuthOpen(true)}
        />
      )}

      {page === 'profile' && <ProfileEditPage onBack={() => setPage('chat')} />}
      {page === 'search' && <SearchPage onBack={() => setPage('chat')} />}

      {page === 'settings' && (
        <SettingsPage siteName={SITE_NAME} user={user} onNavigate={setPage} onAuthClick={() => setAuthOpen(true)} />
      )}

      {!REAL_PAGES.includes(page) && (
        <ComingSoonPage page={page} siteName={SITE_NAME} user={user} onNavigate={setPage} onAuthClick={() => setAuthOpen(true)} />
      )}

      {/* Reachable from the top-left button on both landing and chat pages.
          isGuestUpgrade determines whether submitting calls /auth/register
          (adding credentials to the existing guest) or /auth/signup (fresh). */}
      {authOpen && (
        <AuthPage
          isGuestUpgrade={!!user && !user.isRegistered}
          onAuthed={handleAuthed}
          onClose={() => setAuthOpen(false)}
        />
      )}
    </ThemeProvider>
  );
}
