import { useEffect, useState } from 'react';
import { ThemeProvider } from './theme/ThemeContext';
import { api } from './api/client';
import LandingPage from './pages/LandingPage';
import ChatPage from './pages/ChatPage';
import AuthPage from './pages/AuthPage';
import ProfileEditPage from './pages/ProfileEditPage';
import SearchPage from './pages/SearchPage';
import SettingsPage from './pages/SettingsPage';
import ComingSoonPage from './pages/ComingSoonPage';
import AdminDashboardPage from './pages/AdminDashboardPage';
import ModerationDashboardPage from './pages/ModerationDashboardPage';

const SITE_NAME = 'AceOfLol';
const REAL_PAGES = ['landing', 'chat', 'profile', 'search', 'settings', 'admin', 'moderation'];

export default function App() {
  const [user, setUser] = useState(null); // null | { id, handle, nickname, isRegistered }
  const [currentUserInfo, setCurrentUserInfo] = useState(null); // live role info from /api/me
  const [page, setPage] = useState('landing'); // 'landing' | 'chat' | anything from the menu
  const [authOpen, setAuthOpen] = useState(false);

  // Role (moderator/admin) isn't part of the login/guest response and can
  // change mid-session (an admin promoting someone right now, for
  // instance), so it's fetched fresh from /api/me whenever we have a user
  // rather than trusted from whatever was true at login time. This is also
  // what the feed's plain-JS menu uses the exact same endpoint for.
  useEffect(() => {
    if (!user) {
      setCurrentUserInfo(null);
      return;
    }
    api.getMe().then((data) => setCurrentUserInfo(data.user)).catch(() => setCurrentUserInfo(null));
  }, [user]);

  // Returning visitor with a saved token (guest or registered) skips the
  // landing page entirely and goes straight into chat — or, if the URL has
  // a `?page=` (either from a direct link like the feed's menu, or because
  // we're restoring after a reload — see the sync effect below), that page.
  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    const savedToken = localStorage.getItem('token');
    if (savedUser && savedToken) {
      setUser(JSON.parse(savedUser));
      const requestedPage = new URLSearchParams(window.location.search).get('page');
      setPage(requestedPage || 'chat');
    }
  }, []);

  // This app has no router — every page lives purely in `page` state, so
  // without this, the address bar always just shows "/" no matter which
  // page you're on. That's invisible on a deliberate in-app tap, but it
  // means ANY reload (a stray pull-to-refresh, or iOS silently reloading a
  // backgrounded tab to reclaim memory, which is common) has nothing to
  // recover the current page from and always falls back to chat — which is
  // exactly what looks like "tapping Profile/Search bounces me to Chat."
  // Keeping the URL in sync (via replaceState, so it doesn't create a new
  // browser-history entry per tap) fixes that: any reload now restores
  // whichever page was actually open.
  useEffect(() => {
    if (page === 'landing') return;
    const url = page === 'chat' ? window.location.pathname : `${window.location.pathname}?page=${page}`;
    if (url !== window.location.pathname + window.location.search) {
      window.history.replaceState({}, '', url);
    }
  }, [page]);

  function handleJoinedAsGuest(guestUser) {
    setUser(guestUser);
    setPage('chat');
  }

  function handleAuthed(updatedUser) {
    setUser(updatedUser);
    setAuthOpen(false);
    setPage('chat');
  }

  // No confirmation prompt on purpose — logging out is fully reversible
  // (just log back in), so a confirm dialog would only ever be friction.
  function handleLogout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
    setCurrentUserInfo(null);
    setPage('landing');
  }

  // The one navigation rule that needs to live above individual pages:
  // a guest tapping "My Profile" doesn't have a registered profile to
  // edit yet, so send them to sign up/in instead of into ProfileEditPage.
  // Everything else navigates exactly like setPage always did.
  function handleNavigate(key) {
    if (key === 'profile' && !user?.isRegistered) {
      setAuthOpen(true);
      return;
    }
    setPage(key);
  }

  return (
    <ThemeProvider initialTheme={null}>
      {page === 'landing' && (
        <LandingPage
          siteName={SITE_NAME}
          onJoined={handleJoinedAsGuest}
          onAuthClick={() => setAuthOpen(true)}
        />
      )}

      {page === 'chat' && (
        <ChatPage
          siteName={SITE_NAME}
          roomId="everyone"
          user={user}
          isAdmin={currentUserInfo?.isAdmin}
          isModerator={currentUserInfo?.isModerator}
          onNavigate={handleNavigate}
          onAuthClick={() => setAuthOpen(true)}
          onLogout={handleLogout}
        />
      )}

      {page === 'profile' && <ProfileEditPage onBack={() => setPage('chat')} />}
      {page === 'search' && <SearchPage onBack={() => setPage('chat')} />}

      {page === 'settings' && (
        <SettingsPage siteName={SITE_NAME} user={user} isAdmin={currentUserInfo?.isAdmin} isModerator={currentUserInfo?.isModerator} onNavigate={handleNavigate} onAuthClick={() => setAuthOpen(true)} onLogout={handleLogout} />
      )}

      {page === 'admin' && (
        <AdminDashboardPage
          siteName={SITE_NAME}
          user={user}
          currentUserInfo={currentUserInfo}
          onNavigate={handleNavigate}
          onAuthClick={() => setAuthOpen(true)}
          onLogout={handleLogout}
        />
      )}

      {page === 'moderation' && (
        <ModerationDashboardPage
          siteName={SITE_NAME}
          user={user}
          currentUserInfo={currentUserInfo}
          onNavigate={handleNavigate}
          onAuthClick={() => setAuthOpen(true)}
          onLogout={handleLogout}
        />
      )}

      {!REAL_PAGES.includes(page) && (
        <ComingSoonPage page={page} siteName={SITE_NAME} user={user} isAdmin={currentUserInfo?.isAdmin} isModerator={currentUserInfo?.isModerator} onNavigate={handleNavigate} onAuthClick={() => setAuthOpen(true)} onLogout={handleLogout} />
      )}

      {/* Reachable from the top-left button on every page, and automatically
          when a guest taps "My Profile" (see handleNavigate above).
          isGuestUpgrade only sets the default starting mode and what
          submitting 'register' does — login is always available too, since
          a guest might want a different, already-existing account instead
          of upgrading this one. */}
      {authOpen && (
        <AuthPage
          isGuestUpgrade={!!user && !user.isRegistered}
          onAuthed={handleAuthed}
          onClose={() => setAuthOpen(false)}
        />
      )}
    </ThemeProvider>
  );
}
