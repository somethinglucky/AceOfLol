import { useEffect, useState } from 'react';
import { ThemeProvider } from './theme/ThemeContext';
import { ProfileNavProvider } from './context/ProfileNavContext';
import { api } from './api/client';
import { connectSocket } from './api/socket';
import LandingPage from './pages/LandingPage';
import ChatPage from './pages/ChatPage';
import AuthPage from './pages/AuthPage';
import ProfileEditPage from './pages/ProfileEditPage';
import SearchPage from './pages/SearchPage';
import SettingsPage from './pages/SettingsPage';
import ComingSoonPage from './pages/ComingSoonPage';
import AdminDashboardPage from './pages/AdminDashboardPage';
import ModerationDashboardPage from './pages/ModerationDashboardPage';
import DMsPage from './pages/DMsPage';
import StorePage from './pages/StorePage';
import GamesPage from './pages/GamesPage';
import ProfileCard from './components/ProfileCard';

const SITE_NAME = 'AceOf.Lol';
const REAL_PAGES = ['landing', 'chat', 'profile', 'search', 'settings', 'admin', 'moderation', 'dms', 'store', 'games'];

export default function App() {
  const [user, setUser] = useState(null); // null | { id, handle, nickname, isRegistered }
  const [currentUserInfo, setCurrentUserInfo] = useState(null); // live role info from /api/me
  const [page, setPage] = useState('landing'); // 'landing' | 'chat' | anything from the menu
  // Everywhere except chat, the top-left button is a real "back to
  // wherever I actually came from" — this is the stack that makes that
  // true instead of every back button just hardcoding 'chat'. Pushed by
  // goToPage below; popped by handleBack. Chat is the root: an empty
  // stack means there's nowhere further back to go, which is exactly
  // when TopBar falls back to showing Logout/Sign Up-In instead of a
  // back arrow.
  const [pageHistory, setPageHistory] = useState([]);
  const [authOpen, setAuthOpen] = useState(false);
  const [dmTarget, setDmTarget] = useState(null); // set by ProfileCard's Message button to jump straight into a conversation
  const [gameDeepLink, setGameDeepLink] = useState(null); // set by a DM invite card / Invites tab to jump straight into a game
  // Profile viewing lives here, above individual pages, since it needs to
  // be reachable from anywhere a name/avatar is tapped — chat, the feed
  // (a separate static app, reaching in via ?viewProfile= below), DMs,
  // wherever. { userId } for a registered person | { isGuestAvatar: true,
  // guestHandle, guestNickname } for a guest chat sender | null (closed).
  const [viewProfile, setViewProfile] = useState(null);

  // Unread badge shown over the hamburger menu (see TopBar/MenuDrawer) —
  // DMs, likes-as-DMs, and game invites all land in here, since invites
  // are delivered as a regular DM (see backend/src/routes/gameInvites.js)
  // rather than needing their own separate counter. Suppressed to 0 while
  // actually on the DMs page (see displayedUnreadCount below) rather than
  // marked read in bulk, so the per-thread unread badges inside the DM
  // inbox itself — which only clear when that specific thread is opened —
  // stay accurate; leaving the page re-syncs to whatever's genuinely
  // still unread at that point.
  const [unreadDmCount, setUnreadDmCount] = useState(0);
  const displayedUnreadCount = page === 'dms' ? 0 : unreadDmCount;

  function refreshUnreadCount() {
    api.getDmUnreadCount().then((data) => setUnreadDmCount(data.count)).catch(() => {});
  }

  // A live socket connection just for this badge, independent of whether
  // any particular page (DMs, a game session) has its own reason to be
  // connected — the badge needs to update even while sitting on, say,
  // the Store page. connectSocket() is idempotent, so this doesn't create
  // a second connection if one already exists for another reason.
  useEffect(() => {
    if (!user?.isRegistered) {
      setUnreadDmCount(0);
      return undefined;
    }
    refreshUnreadCount();
    const socket = connectSocket();
    const onInboxUpdate = () => refreshUnreadCount();
    socket.on('dm_inbox_update', onInboxUpdate);
    return () => socket.off('dm_inbox_update', onInboxUpdate);
  }, [user?.isRegistered]);

  // Re-sync the true count on leaving the DMs page — see
  // displayedUnreadCount above for why this isn't a bulk mark-read.
  useEffect(() => {
    if (page !== 'dms' && user?.isRegistered) refreshUnreadCount();
  }, [page]);

  // Role (moderator/admin) isn't part of the login/guest response and can
  // change mid-session (an admin promoting someone right now, for
  // instance), so it's fetched fresh from /api/me whenever we have a user
  // rather than trusted from whatever was true at login time. This is also
  // what the feed's plain-JS menu uses the exact same endpoint for.
  useEffect(() => {
    if (!user) {
      setCurrentUserInfo(null);
      return;
    }
    api.getMe().then((data) => setCurrentUserInfo(data.user)).catch(() => setCurrentUserInfo(null));
  }, [user]);

  // Returning visitor with a saved token (guest or registered) skips the
  // landing page entirely and goes straight into chat — or, if the URL has
  // a `?page=` (either from a direct link like the feed's menu, or because
  // we're restoring after a reload — see the sync effect below), that page.
  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    const savedToken = localStorage.getItem('token');
    if (savedUser && savedToken) {
      setUser(JSON.parse(savedUser));
      const params = new URLSearchParams(window.location.search);
      const requestedPage = params.get('page');
      setPage(requestedPage || 'chat');
      const viewProfileUserId = params.get('viewProfile');
      if (viewProfileUserId) setViewProfile({ userId: viewProfileUserId });
    }
  }, []);

  // This app has no router — every page lives purely in `page` state, so
  // without this, the address bar always just shows "/" no matter which
  // page you're on. That's invisible on a deliberate in-app tap, but it
  // means ANY reload (a stray pull-to-refresh, or iOS silently reloading a
  // backgrounded tab to reclaim memory, which is common) has nothing to
  // recover the current page from and always falls back to chat — which is
  // exactly what looks like "tapping Profile/Search bounces me to Chat."
  // Keeping the URL in sync (via replaceState, so it doesn't create a new
  // browser-history entry per tap) fixes that: any reload now restores
  // whichever page was actually open.
  useEffect(() => {
    if (page === 'landing') return;
    const url = page === 'chat' ? window.location.pathname : `${window.location.pathname}?page=${page}`;
    if (url !== window.location.pathname + window.location.search) {
      window.history.replaceState({}, '', url);
    }
  }, [page]);

  function handleJoinedAsGuest(guestUser) {
    setUser(guestUser);
    setPageHistory([]);
    setPage('chat');
  }

  function handleAuthed(updatedUser) {
    setUser(updatedUser);
    setAuthOpen(false);
    setPageHistory([]);
    setPage('chat');
  }

  // No confirmation prompt on purpose — logging out is fully reversible
  // (just log back in), so a confirm dialog would only ever be friction.
  function handleLogout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
    setCurrentUserInfo(null);
    setPageHistory([]);
    setPage('landing');
  }

  // The single place that actually changes `page` for a real navigation
  // (as opposed to a hard reset like login/logout above) — pushes the
  // page being LEFT onto the history stack, which is what lets every
  // page's back button return to wherever the person actually came from
  // instead of always going to one hardcoded place. Doesn't push if
  // already on that page (avoids a same-page entry from a redundant
  // navigate call).
  function goToPage(key) {
    setPageHistory((prev) => (page === key ? prev : [...prev, page]));
    setPage(key);
  }

  // The one navigation rule that needs to live above individual pages:
  // a guest tapping "My Profile" doesn't have a registered profile to
  // edit yet, so send them to sign up/in instead of into ProfileEditPage.
  // Everything else navigates exactly like setPage always did.
  function handleNavigate(key) {
    if (key === 'profile' && !user?.isRegistered) {
      setAuthOpen(true);
      return;
    }
    goToPage(key);
  }

  // The universal top-left back button everywhere except chat (see
  // TopBar.jsx) — pop the history stack and return there. An empty stack
  // (nothing to go back to — you're already at the root) falls back to
  // chat rather than doing nothing, though in practice TopBar hides the
  // back button entirely once you're actually on chat.
  function handleBack() {
    setPageHistory((prev) => {
      if (prev.length === 0) {
        setPage('chat');
        return [];
      }
      const next = [...prev];
      const previous = next.pop();
      setPage(previous);
      return next;
    });
  }

  // Called from anywhere a name/avatar is tapped — chat messages, the
  // feed (via the URL param above), DM conversations, wherever. sender is
  // the enriched {handle, nickname, isRegistered, avatarUrl} object chat
  // already attaches to messages; feed/DM authors are always registered
  // (posting/DMing both require it), so sender is optional there.
  function handleViewProfile(userId, sender) {
    if (sender && !sender.isRegistered) {
      setViewProfile({ isGuestAvatar: true, guestHandle: sender.handle, guestNickname: sender.nickname });
    } else {
      setViewProfile({ userId });
    }
  }

  // Called from ProfileCard's \u2660 button — jumps straight into that
  // conversation instead of landing on the inbox first.
  function handleStartDm(target) {
    setViewProfile(null);
    setDmTarget(target);
    goToPage('dms');
  }

  // Called from a game-invite DM card, or the global Invites tab's "Open"
  // button (see DMsPage.jsx / InvitesTab.jsx) — jumps straight into that
  // specific game instead of leaving the person to find it themselves via
  // Games → [game] → Invite. { gameId, sessionId? } — sessionId means the
  // invite's already confirmed and the game is waiting/active, so land
  // straight in the session; otherwise land in that game's lobby with the
  // Invite panel already open so the pending invite is right there.
  function handleOpenGame(target) {
    setGameDeepLink(target);
    goToPage('games');
  }

  return (
    <ThemeProvider initialTheme={null}>
    <ProfileNavProvider onOpenProfile={handleViewProfile}>
      {page === 'landing' && (
        <LandingPage
          siteName={SITE_NAME}
          onJoined={handleJoinedAsGuest}
          onAuthClick={() => setAuthOpen(true)}
        />
      )}

      {page === 'chat' && (
        <ChatPage
          siteName={SITE_NAME}
          roomId="everyone"
          user={user}
          isAdmin={currentUserInfo?.isAdmin}
          isModerator={currentUserInfo?.isModerator}
          unreadCount={displayedUnreadCount}
          onNavigate={handleNavigate}
          onAuthClick={() => setAuthOpen(true)}
          onLogout={handleLogout}
          onViewProfile={handleViewProfile}
        />
      )}

      {page === 'profile' && <ProfileEditPage onBack={handleBack} />}
      {page === 'search' && <SearchPage onBack={handleBack} />}

      {page === 'settings' && (
        <SettingsPage siteName={SITE_NAME} user={user} isAdmin={currentUserInfo?.isAdmin} isModerator={currentUserInfo?.isModerator} unreadCount={displayedUnreadCount} onBack={handleBack} onNavigate={handleNavigate} onAuthClick={() => setAuthOpen(true)} onLogout={handleLogout} />
      )}

      {page === 'admin' && (
        <AdminDashboardPage
          siteName={SITE_NAME}
          user={user}
          currentUserInfo={currentUserInfo}
          unreadCount={displayedUnreadCount}
          onBack={handleBack}
          onNavigate={handleNavigate}
          onAuthClick={() => setAuthOpen(true)}
          onLogout={handleLogout}
        />
      )}

      {page === 'moderation' && (
        <ModerationDashboardPage
          siteName={SITE_NAME}
          user={user}
          currentUserInfo={currentUserInfo}
          unreadCount={displayedUnreadCount}
          onBack={handleBack}
          onNavigate={handleNavigate}
          onAuthClick={() => setAuthOpen(true)}
          onLogout={handleLogout}
        />
      )}

      {page === 'dms' && (
        <DMsPage
          siteName={SITE_NAME}
          user={user}
          isAdmin={currentUserInfo?.isAdmin}
          isModerator={currentUserInfo?.isModerator}
          unreadCount={displayedUnreadCount}
          initialOtherUser={dmTarget}
          onConsumeInitialTarget={() => setDmTarget(null)}
          onBack={handleBack}
          onNavigate={handleNavigate}
          onAuthClick={() => setAuthOpen(true)}
          onLogout={handleLogout}
          onViewProfile={handleViewProfile}
          onOpenGame={handleOpenGame}
        />
      )}

      {page === 'store' && (
        <StorePage
          siteName={SITE_NAME}
          user={user}
          isAdmin={currentUserInfo?.isAdmin}
          isModerator={currentUserInfo?.isModerator}
          unreadCount={displayedUnreadCount}
          onBack={handleBack}
          onNavigate={handleNavigate}
          onAuthClick={() => setAuthOpen(true)}
          onLogout={handleLogout}
        />
      )}

      {page === 'games' && user?.isRegistered && (
        <GamesPage
          siteName={SITE_NAME}
          currentUser={{ ...user, isPremium: currentUserInfo?.isPremium }}
          isAdmin={currentUserInfo?.isAdmin}
          isModerator={currentUserInfo?.isModerator}
          unreadCount={displayedUnreadCount}
          initialDeepLink={gameDeepLink}
          onConsumeInitialDeepLink={() => setGameDeepLink(null)}
          onBack={handleBack}
          onNavigate={handleNavigate}
        />
      )}
      {page === 'games' && !user?.isRegistered && (
        <ComingSoonPage
          page="games"
          siteName={SITE_NAME}
          user={user}
          isAdmin={currentUserInfo?.isAdmin}
          isModerator={currentUserInfo?.isModerator}
          unreadCount={displayedUnreadCount}
          onBack={handleBack}
          onNavigate={handleNavigate}
          onAuthClick={() => setAuthOpen(true)}
          onLogout={handleLogout}
        />
      )}

      {!REAL_PAGES.includes(page) && (
        <ComingSoonPage page={page} siteName={SITE_NAME} user={user} isAdmin={currentUserInfo?.isAdmin} isModerator={currentUserInfo?.isModerator} unreadCount={displayedUnreadCount} onBack={handleBack} onNavigate={handleNavigate} onAuthClick={() => setAuthOpen(true)} onLogout={handleLogout} />
      )}

      {/* Top-level so it's reachable from any page — see handleViewProfile. */}
      <ProfileCard
        userId={viewProfile?.userId}
        isGuestAvatar={viewProfile?.isGuestAvatar}
        guestHandle={viewProfile?.guestHandle}
        guestNickname={viewProfile?.guestNickname}
        currentUserId={user?.id}
        viewerIsRegistered={user?.isRegistered}
        onMessage={handleStartDm}
        onClose={() => setViewProfile(null)}
      />

      {/* Reachable from the top-left button on every page, and automatically
          when a guest taps "My Profile" (see handleNavigate above).
          isGuestUpgrade only sets the default starting mode and what
          submitting 'register' does — login is always available too, since
          a guest might want a different, already-existing account instead
          of upgrading this one. */}
      {authOpen && (
        <AuthPage
          isGuestUpgrade={!!user && !user.isRegistered}
          onAuthed={handleAuthed}
          onClose={() => setAuthOpen(false)}
        />
      )}
    </ProfileNavProvider>
    </ThemeProvider>
  );
}
