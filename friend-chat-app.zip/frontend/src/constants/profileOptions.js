// Keep these in sync with backend/src/routes/profiles.js — the backend
// validates against the same value lists, these are just the { value, label }
// pairs for rendering checkboxes/selects.

export const GENDER_OPTIONS = [
  { value: 'male', label: 'Male' },
  { value: 'female', label: 'Female' },
  { value: 'transman', label: 'Trans man' },
  { value: 'transwoman', label: 'Trans woman' },
  { value: 'nonbinary', label: 'Nonbinary' },
  { value: 'masc', label: 'Masc' },
  { value: 'fem', label: 'Fem' },
  { value: 'other', label: 'Other' },
];

export const ORIENTATION_OPTIONS = [
  { value: 'straight', label: 'Straight' },
  { value: 'gay', label: 'Gay' },
  { value: 'pan_bi', label: 'Pan / Bi' },
  { value: 'asexual', label: 'Asexual' },
  { value: 'demisexual', label: 'Demisexual' },
  { value: 'homoflexible', label: 'Homoflexible' },
  { value: 'heteroflexible', label: 'Heteroflexible' },
  { value: 'other', label: 'Other' },
];

export const HAS_KIDS_OPTIONS = [
  { value: 'has_kids', label: 'Has kids' },
  { value: 'doesnt_have_kids', label: "Doesn't have kids" },
  { value: 'wants_kids', label: 'Wants kids' },
  { value: 'doesnt_want_kids', label: "Doesn't want kids" },
  { value: 'open_to_kids', label: 'Open to kids' },
];

export const PETS_OPTIONS = [
  { value: 'has_pets', label: 'Has pets' },
  { value: 'doesnt_have_pets', label: "Doesn't have pets" },
  { value: 'wants_pets', label: 'Wants pets' },
  { value: 'doesnt_want_pets', label: "Doesn't want pets" },
  { value: 'open_to_pets', label: 'Open to pets' },
];

export const RELIGION_OPTIONS = [
  { value: 'christian', label: 'Christian' },
  { value: 'atheist', label: 'Atheist' },
  { value: 'agnostic', label: 'Agnostic' },
  { value: 'muslim', label: 'Muslim' },
  { value: 'jewish', label: 'Jewish' },
  { value: 'buddhist', label: 'Buddhist' },
  { value: 'pagan', label: 'Pagan' },
  { value: 'taoist', label: 'Taoist' },
  { value: 'shinto', label: 'Shinto' },
  { value: 'other', label: 'Other' },
];

export const COMMITMENT_OPTIONS = [
  { value: 'is_married', label: 'Is married' },
  { value: 'wants_marriage', label: 'Wants marriage' },
  { value: 'doesnt_want_marriage', label: "Doesn't want marriage" },
  { value: 'wants_qpr', label: 'Wants a QPR' },
  { value: 'open_to_qpr', label: 'Open to a QPR' },
  { value: 'open_to_marriage', label: 'Open to marriage' },
  { value: 'other', label: 'Other' },
];

export const DIET_OPTIONS = [
  { value: 'anything', label: 'Anything' },
  { value: 'carnivorous', label: 'Carnivorous' },
  { value: 'vegetarian', label: 'Vegetarian' },
  { value: 'vegan', label: 'Vegan' },
  { value: 'pescatarian', label: 'Pescatarian' },
  { value: 'flexitarian', label: 'Flexitarian' },
];

export const POLYAMORY_OPTIONS = [
  { value: 'in_polyamorous_relationship', label: 'In a polyamorous relationship' },
  { value: 'open_to_polyamory', label: 'Open to polyamory' },
  { value: 'wants_polyamory', label: 'Wants polyamory' },
  { value: 'does_not_want_polyamory', label: 'Does not want polyamory' },
];

export const BUILD_OPTIONS = [
  { value: 'thin', label: 'Thin' },
  { value: 'average', label: 'Average' },
  { value: 'fit', label: 'Fit' },
  { value: 'athlete', label: 'Athlete' },
  { value: 'curvy', label: 'Curvy' },
  { value: 'overweight', label: 'Overweight' },
  { value: 'bbp', label: 'Big beautiful person' },
];

// A deliberately short, common list — not the full ISO-3166 country list —
// since typing a country is more accurate globally than scrolling a long
// dropdown on a phone. The input itself is free text in the schema; this
// is just quick-tap suggestions.
export const COMMON_COUNTRIES = [
  'United States', 'Canada', 'United Kingdom', 'Australia', 'Germany', 'France',
  'Spain', 'Italy', 'Mexico', 'Brazil', 'Japan', 'South Korea', 'India',
  'Philippines', 'Nigeria', 'South Africa', 'Netherlands', 'Sweden', 'Ireland', 'New Zealand',
];
