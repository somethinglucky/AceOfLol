import { relativeTime } from './relativeTime.js';

// Turns a module's structured `lastEvent` (see backend/src/games/
// blackjack.js / goFish.js) into the single current-status line the
// session screen shows — nicknames and "you"/"they" phrasing live here,
// never in the backend, since the module only ever knows raw user ids.
// Returns { statusLine, turnLine } — turnLine is null once the game is
// over (the win/loss banner covers that).
export function describeGameStatus({ gameId, board, seats, currentUserId, gameOver }) {
  if (!board?.lastEvent) return { statusLine: '', turnLine: null };

  const nameFor = (userId) => {
    const seat = seats.find((s) => s.userId === userId);
    return seat ? `${seat.nickname}@${seat.handle}` : 'Opponent';
  };
  const turnLine = gameOver ? null : board.turn === currentUserId ? 'Your turn.' : "Other player's turn.";

  if (board.lastEvent.type === 'deal') {
    const { firstMoverId } = board.lastEvent;
    if (firstMoverId === currentUserId) return { statusLine: 'Cards dealt. You move first.', turnLine: null };
    const opponentSeat = seats.find((s) => s.userId !== currentUserId);
    const lastSeen = opponentSeat ? relativeTime(opponentSeat.lastActiveAt) : 'a while ago';
    return { statusLine: `Cards dealt. Waiting on ${opponentSeat?.nickname || 'the other player'} to move — last seen ${lastSeen}.`, turnLine: null };
  }

  if (gameId === 'blackjack' && board.lastEvent.type === 'move') {
    const { playerId, action, card, total, busted } = board.lastEvent;
    const isMe = playerId === currentUserId;
    const who = isMe ? 'You' : nameFor(playerId);
    let line;
    if (action === 'stand') {
      line = `${who} stood on ${total}.`;
    } else {
      const rank = card.slice(0, -1);
      line = `${who} hit and drew a ${rank} (total ${total}).`;
      if (busted) line += ` ${isMe ? 'You bust' : 'They bust'}!`;
    }
    return { statusLine: line, turnLine };
  }

  if (gameId === 'go_fish' && board.lastEvent.type === 'ask') {
    const { playerId, opponentId, rank, result, gained, booksCompleted } = board.lastEvent;
    const isMe = playerId === currentUserId;
    const who = isMe ? 'You' : nameFor(playerId);
    const themTarget = isMe ? nameFor(opponentId) : 'you';

    let line;
    if (result === 'match') {
      line = isMe
        ? `You asked for ${rank}s and got ${gained} from ${themTarget}!`
        : `${who} asked you for ${rank}s and took ${gained}!`;
    } else if (result === 'fish_drew_match') {
      line = `${who} went fish for ${rank}s and drew one anyway!`;
    } else if (result === 'fish') {
      line = `${who} asked for ${rank}s — Go Fish!`;
    } else {
      line = `${who} asked for ${rank}s — Go Fish, but the deck was empty.`;
    }

    if (booksCompleted?.length) {
      for (const b of booksCompleted) {
        line += ` ${b.playerId === currentUserId ? 'You' : nameFor(b.playerId)} completed a book of ${b.rank}s!`;
      }
    }

    return { statusLine: line, turnLine };
  }

  return { statusLine: '', turnLine };
}
