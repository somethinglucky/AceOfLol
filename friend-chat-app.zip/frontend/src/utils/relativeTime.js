// Formats an ISO timestamp as "just now" / "3 min ago" / "2 hr ago" — used
// for the game session waiting-room's "last seen" line. Deliberately
// coarse (minutes/hours, not seconds) since this is a rough presence
// signal, not a precise one.
export function relativeTime(iso) {
  if (!iso) return 'a while ago';
  const diffMs = Date.now() - new Date(iso).getTime();
  const minutes = Math.floor(diffMs / 60000);
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} hr ago`;
  return `${Math.floor(hours / 24)}d ago`;
}
