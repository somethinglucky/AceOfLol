// Turns any string (a guest's handle) into a consistent HSL color — same
// input always produces the same color, which is what lets people tell two
// different guests apart across messages without either of them having a
// real avatar photo.
export function colorFromString(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  const hue = Math.abs(hash) % 360;
  return `hsl(${hue}, 65%, 55%)`;
}
