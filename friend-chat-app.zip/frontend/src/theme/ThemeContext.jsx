import { createContext, useContext, useEffect, useState } from 'react';

// The small set of font choices offered in Settings. Keeping this to a short,
// curated list (rather than a free-text font name) means every option is
// guaranteed to render well and load instantly — no webfont downloads, no
// layout shift, since these are all system font stacks already on the phone.
export const FONT_OPTIONS = {
  system: {
    label: 'System',
    stack: '-apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Roboto, sans-serif',
  },
  rounded: {
    label: 'Rounded',
    stack: 'ui-rounded, "SF Pro Rounded", "Nunito", sans-serif',
  },
  serif: {
    label: 'Serif',
    stack: '"New York", Georgia, "Times New Roman", serif',
  },
  mono: {
    label: 'Mono',
    stack: '"SF Mono", "Menlo", "Courier New", monospace',
  },
};

// A short palette of preset accent colors for Settings, plus users can pick
// any custom hex value — this list is just the quick-tap defaults.
export const ACCENT_PRESETS = [
  { label: 'Blue', value: '#0a84ff' },
  { label: 'Pink', value: '#ff375f' },
  { label: 'Purple', value: '#bf5af2' },
  { label: 'Orange', value: '#ff9f0a' },
  { label: 'Green', value: '#30d158' },
  { label: 'Teal', value: '#64d2ff' },
];

const ThemeContext = createContext(null);

// Shared with the separately-built feed pages (public/js/theme.js reads
// this same key) — this is what keeps the accent color consistent when
// navigating from the React app into the feed's own static pages, since
// they're different documents and can't share React state directly.
const FEED_THEME_KEY = 'aceoflol_theme';

function syncFeedTheme(accent) {
  let stored = {};
  try {
    stored = JSON.parse(localStorage.getItem(FEED_THEME_KEY) || '{}');
  } catch {
    stored = {};
  }
  localStorage.setItem(
    FEED_THEME_KEY,
    JSON.stringify({ ...stored, '--color-accent': accent, '--color-accent-contrast': '#ffffff' })
  );
}

export function ThemeProvider({ initialTheme, children }) {
  const [accent, setAccent] = useState(initialTheme?.theme_color || ACCENT_PRESETS[0].value);
  const [fontKey, setFontKey] = useState(initialTheme?.theme_font || 'system');

  useEffect(() => {
    document.documentElement.style.setProperty('--theme-accent', accent);
    syncFeedTheme(accent);
  }, [accent]);

  useEffect(() => {
    const stack = FONT_OPTIONS[fontKey]?.stack || FONT_OPTIONS.system.stack;
    document.documentElement.style.setProperty('--theme-font', stack);
  }, [fontKey]);

  return (
    <ThemeContext.Provider value={{ accent, setAccent, fontKey, setFontKey }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used inside a ThemeProvider');
  return ctx;
}
