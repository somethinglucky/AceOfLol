import { createContext, useContext } from 'react';

// Lets NameTag (rendered in dozens of places — DM lists, leaderboards,
// invite rows, game seats, search results...) open a profile without
// every intermediate component between App.jsx and that leaf needing to
// thread an onViewProfile prop through just to pass it along. App.jsx
// provides the one real implementation (its existing handleViewProfile);
// everything else just calls useProfileNav().
const ProfileNavContext = createContext(null);

export function ProfileNavProvider({ onOpenProfile, children }) {
  return <ProfileNavContext.Provider value={onOpenProfile}>{children}</ProfileNavContext.Provider>;
}

// Returns a function (userId, sender?) => void. sender mirrors what
// App.jsx's handleViewProfile already expects — pass it along for a
// context (chat) where the person might be an unregistered guest;
// omit it anywhere the person is guaranteed registered (DMs, invites,
// leaderboards, game seats — all already require an account).
export function useProfileNav() {
  return useContext(ProfileNavContext);
}
