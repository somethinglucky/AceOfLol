import { io } from 'socket.io-client';

const SOCKET_URL = import.meta.env.VITE_API_BASE || undefined; // undefined = same origin

let socket = null;

// Lazily creates a single shared socket connection and authenticates it with
// the saved JWT. Call this once when the chat page mounts.
export function connectSocket() {
  if (socket) return socket;

  socket = io(SOCKET_URL, { autoConnect: true });

  socket.on('connect', () => {
    const token = localStorage.getItem('token');
    if (token) socket.emit('authenticate', token);
  });

  return socket;
}

export function getSocket() {
  if (!socket) throw new Error('Socket not connected yet — call connectSocket() first');
  return socket;
}

// Authenticates the given socket with a token and resolves once the server
// confirms it — used right after guest creation, where we need to be sure
// the socket is authenticated before emitting send_message.
export function authenticateSocket(token) {
  return new Promise((resolve, reject) => {
    const s = connectSocket();
    s.once('authenticated', resolve);
    s.once('auth_error', reject);
    s.emit('authenticate', token);
  });
}
