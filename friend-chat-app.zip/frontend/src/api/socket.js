import { io } from 'socket.io-client';

const SOCKET_URL = import.meta.env.VITE_API_BASE || undefined; // undefined = same origin

let socket = null;
const activeRooms = new Set();
const activeDmThreads = new Set(); // otherUserId values, not thread ids — see dmHandlers.js
const activeGameSessions = new Set(); // sessionId values — see gameChatHandlers.js

// Lazily creates a single shared socket connection and authenticates it with
// the saved JWT. Call this once when the chat page mounts.
export function connectSocket() {
  if (socket) return socket;

  socket = io(SOCKET_URL, { autoConnect: true });

  // Runs on the FIRST connect and every RECONNECT (mobile screen locks,
  // backgrounding the browser, brief network drops — all routine on
  // phones). Without this, a reconnect gives you a live socket that the
  // server has no memory of being "in" any room, so new messages silently
  // stop arriving until a full page reload re-triggers the join. Re-running
  // join_room here also re-fetches history, which naturally backfills
  // anything missed while disconnected.
  socket.on('connect', () => {
    const token = localStorage.getItem('token');
    if (token) socket.emit('authenticate', token);
    activeRooms.forEach((roomId) => socket.emit('join_room', roomId));
    activeDmThreads.forEach((otherUserId) => socket.emit('join_dm_thread', otherUserId));
    activeGameSessions.forEach((sessionId) => socket.emit('join_game_session', sessionId));
  });

  return socket;
}

// Wraps join_room so the room is remembered and automatically rejoined on
// any future reconnect. Use this instead of a bare socket.emit('join_room', ...).
export function joinRoom(roomId) {
  activeRooms.add(roomId);
  const s = connectSocket();
  if (s.connected) s.emit('join_room', roomId);
}

export function leaveRoom(roomId) {
  activeRooms.delete(roomId);
  connectSocket().emit('leave_room', roomId);
}

// Same reconnect-resilience idea as joinRoom/leaveRoom, for DM conversations.
// Keyed by the OTHER person's user id, not a thread id — a thread may not
// exist yet (no messages sent between these two people so far), and the
// server keys its room the same way (see dmHandlers.js). Same
// connected-check as joinRoom/joinGameSession below — join_dm_thread also
// hard-requires authentication server-side, so it's vulnerable to the
// same cold-start ordering race.
export function joinDmThread(otherUserId) {
  activeDmThreads.add(otherUserId);
  const s = connectSocket();
  if (s.connected) s.emit('join_dm_thread', otherUserId);
}

export function leaveDmThread(otherUserId) {
  activeDmThreads.delete(otherUserId);
  connectSocket().emit('leave_dm_thread', otherUserId);
}

// Same reconnect-resilience idea, for an in-game chat overlay (spec §9).
// Keyed by the GameSession id — see gameChatHandlers.js.
//
// Unlike joinRoom/joinDmThread, the server-side join_game_session handler
// hard-requires the socket to already be authenticated (it needs to know
// who you are to check you're actually seated in this game) — it can't
// tolerate a guest the way an open chat room can. That makes it sensitive
// to a race the other joins happened to paper over: emitting directly on
// a brand-new, not-yet-connected socket gets buffered and sent the
// instant the connection opens, which can beat the 'connect' handler's
// own 'authenticate' emit to the server — so join_game_session arrives
// first, finds no userId yet, and gets silently rejected. The socket
// then never actually joins the room, so it never receives anyone else's
// messages, even though its own sends keep working. Only emitting
// directly once the socket is already connected sidesteps this: for a
// fresh connection, we rely entirely on the connect handler above, which
// always emits 'authenticate' before walking activeGameSessions.
export function joinGameSession(sessionId) {
  activeGameSessions.add(sessionId);
  const s = connectSocket();
  if (s.connected) s.emit('join_game_session', sessionId);
}

export function leaveGameSession(sessionId) {
  activeGameSessions.delete(sessionId);
  connectSocket().emit('leave_game_session', sessionId);
}

export function getSocket() {
  if (!socket) throw new Error('Socket not connected yet — call connectSocket() first');
  return socket;
}

// Authenticates the given socket with a token and resolves once the server
// confirms it — used right after guest creation, where we need to be sure
// the socket is authenticated before emitting send_message.
export function authenticateSocket(token) {
  return new Promise((resolve, reject) => {
    const s = connectSocket();
    s.once('authenticated', resolve);
    s.once('auth_error', reject);
    s.emit('authenticate', token);
  });
}
