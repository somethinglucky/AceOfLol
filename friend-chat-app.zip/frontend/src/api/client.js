const API_BASE = import.meta.env.VITE_API_BASE || '';

function getToken() {
  return localStorage.getItem('token');
}

async function request(path, { method = 'GET', body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || `Request failed with status ${res.status}`);
  }
  return data;
}

// Separate from request() because store-item image upload needs
// multipart/form-data, not JSON — must NOT set Content-Type manually here,
// the browser sets it (including the multipart boundary) when the body is
// a FormData instance.
async function multipartRequest(path, { method = 'POST', formData }) {
  const headers = {};
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`${API_BASE}${path}`, { method, headers, body: formData });
  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || `Request failed with status ${res.status}`);
  }
  return data;
}

// Builds the multipart body for a store-item create/edit from a plain
// fields object plus an optional File for the image.
function storeItemFormData(fields, imageFile) {
  const fd = new FormData();
  Object.entries(fields).forEach(([key, value]) => {
    if (value !== undefined && value !== null) fd.append(key, value);
  });
  if (imageFile) fd.append('image', imageFile);
  return fd;
}

export const api = {
  // Live identity/role info — id, handle, isRegistered, isModerator,
  // isAdmin, isBot. Not part of the login/guest response since role can
  // change mid-session; fetch this whenever you need the current truth.
  getMe: () => request('/api/me'),

  // Creates a brand-new anonymous identity. Called once per browser, right
  // when someone hits Send for the first time with no token saved yet.
  guestSignup: () => request('/auth/guest', { method: 'POST' }),

  // Upgrades the CURRENT guest identity (reads the token already in
  // localStorage) into a full account — same handle, same message history.
  register: (email, password, nickname) =>
    request('/auth/register', { method: 'POST', body: { email, password, nickname } }),

  // A fresh registration with no prior guest identity at all.
  signup: (email, password, nickname) =>
    request('/auth/signup', { method: 'POST', body: { email, password, nickname } }),

  login: (email, password) =>
    request('/auth/login', { method: 'POST', body: { email, password } }),

  // Profile endpoints
  getMyProfile: () => request('/profiles/me'),
  updateMyProfile: (fields) => request('/profiles/me', { method: 'PUT', body: fields }),
  updateMultiField: (field, values) =>
    request('/profiles/me/multi', { method: 'PUT', body: { field, values } }),
  updateHobbies: (hobbies) => request('/profiles/me/hobbies', { method: 'PUT', body: { hobbies } }),
  getHobbySuggestions: () => request('/profiles/hobbies/suggestions'),
  getProfile: (userId) => request(`/profiles/${userId}`),
  searchProfiles: (params) => {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (Array.isArray(value)) value.forEach((v) => qs.append(key, v));
      else if (value !== undefined && value !== '') qs.append(key, value);
    });
    return request(`/profiles?${qs.toString()}`);
  },

  // Posts the current user has hidden from the feed, and undoing that.
  getHiddenPosts: () => request('/api/feed/hidden'),
  unhidePost: (postId) => request(`/api/feed/hidden/${postId}`, { method: 'DELETE' }),

  // Admin dashboard — every call here 403s server-side unless the caller
  // is actually an admin, this is just the client for it.
  adminSearchUsers: (handle) => request(`/api/admin/users?handle=${encodeURIComponent(handle)}`),
  adminSetRole: (userId, role) => request(`/api/admin/users/${userId}/role`, { method: 'PUT', body: { role } }),
  adminSetBot: (userId, isBot) => request(`/api/admin/users/${userId}/bot`, { method: 'PUT', body: { isBot } }),
  adminGetStoreItems: () => request('/api/admin/store-items'),
  adminCreateStoreItem: (fields, imageFile) =>
    multipartRequest('/api/admin/store-items', { method: 'POST', formData: storeItemFormData(fields, imageFile) }),
  adminUpdateStoreItem: (id, fields, imageFile) =>
    multipartRequest(`/api/admin/store-items/${id}`, { method: 'PUT', formData: storeItemFormData(fields, imageFile) }),
  adminDeleteStoreItem: (id) => request(`/api/admin/store-items/${id}`, { method: 'DELETE' }),

  // Storefront (see backend/src/routes/store.js) — items are always USD;
  // Gems (♦) are only ever earned in-game or bought via a gem_pack item here.
  getStoreItems: () => request('/api/store/items'),
  getGemWallet: () => request('/api/store/wallet'),
  getMyOrders: () => request('/api/store/orders'),
  // Returns { checkoutUrl } — caller redirects the browser there (Stripe's
  // hosted Checkout page); there's no in-app card form to build.
  startCheckout: (itemId) => request('/api/store/checkout', { method: 'POST', body: { itemId } }),

  // Follow/block — the shared system (see backend/src/routes/relationships.js),
  // usable against any user id regardless of where in the app you are.
  getRelationship: (userId) => request(`/api/users/${userId}/relationship`),
  follow: (userId) => request(`/api/users/${userId}/follow`, { method: 'POST' }),
  unfollow: (userId) => request(`/api/users/${userId}/follow`, { method: 'DELETE' }),
  block: (userId) => request(`/api/users/${userId}/block`, { method: 'POST' }),
  unblock: (userId) => request(`/api/users/${userId}/block`, { method: 'DELETE' }),
  reportUser: (userId, reason) => request(`/api/users/${userId}/report`, { method: 'POST', body: { reason } }),

  // DMs — sending/receiving happens over the socket (see api/socket.js's
  // joinDmThread/send_dm_message), everything else here.
  getDmInbox: () => request('/api/dms'),
  getDmHistory: (userId) => request(`/api/dms/with/${userId}`),
  getHiddenDmThreads: () => request('/api/dms/hidden'),
  hideDmThread: (threadId) => request(`/api/dms/${threadId}/hide`, { method: 'POST' }),
  unhideDmThread: (threadId) => request(`/api/dms/${threadId}/hide`, { method: 'DELETE' }),
  clearDmThread: (threadId) => request(`/api/dms/${threadId}/clear`, { method: 'POST' }),
  reportDmThread: (threadId, reason) => request(`/api/dms/${threadId}/report`, { method: 'POST', body: { reason } }),

  // Games (see backend/src/routes/games.js, gameQueue.js, gameInvites.js,
  // gameSessions.js) — the Shell only, gameplay itself is per-session.
  getGames: () => request('/api/games'),
  getGameLobby: (gameId) => request(`/api/games/${gameId}`),
  getGameInvitesFor: (gameId) => request(`/api/games/${gameId}/my-invites`),

  joinGameQueue: (gameId) => request(`/api/games/${gameId}/queue`, { method: 'POST' }),
  getGameQueueStatus: (gameId) => request(`/api/games/${gameId}/queue/status`),
  leaveGameQueue: (gameId) => request(`/api/games/${gameId}/queue`, { method: 'DELETE' }),

  getMyGameInvites: () => request('/api/game-invites'),
  createGameInvite: (fields) => request('/api/game-invites', { method: 'POST', body: fields }),
  respondToGameInvite: (inviteId, chosenDate) =>
    request(`/api/game-invites/${inviteId}/respond`, { method: 'POST', body: { chosenDate } }),
  cancelGameInvite: (inviteId) => request(`/api/game-invites/${inviteId}/cancel`, { method: 'POST' }),

  getMyGameSessions: (gameId) =>
    request(`/api/game-sessions/mine${gameId ? `?gameId=${encodeURIComponent(gameId)}` : ''}`),
  getGameSession: (sessionId) => request(`/api/game-sessions/${sessionId}`),
  arriveAtGameSession: (sessionId) => request(`/api/game-sessions/${sessionId}/arrive`, { method: 'POST' }),
  sendGameMove: (sessionId, moveData) =>
    request(`/api/game-sessions/${sessionId}/move`, { method: 'POST', body: { moveData } }),
};
