const API_BASE = import.meta.env.VITE_API_BASE || '';

function getToken() {
  return localStorage.getItem('token');
}

async function request(path, { method = 'GET', body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || `Request failed with status ${res.status}`);
  }
  return data;
}

export const api = {
  // Creates a brand-new anonymous identity. Called once per browser, right
  // when someone hits Send for the first time with no token saved yet.
  guestSignup: () => request('/auth/guest', { method: 'POST' }),

  // Upgrades the CURRENT guest identity (reads the token already in
  // localStorage) into a full account — same handle, same message history.
  register: (email, password, nickname) =>
    request('/auth/register', { method: 'POST', body: { email, password, nickname } }),

  // A fresh registration with no prior guest identity at all.
  signup: (email, password, nickname) =>
    request('/auth/signup', { method: 'POST', body: { email, password, nickname } }),

  login: (email, password) =>
    request('/auth/login', { method: 'POST', body: { email, password } }),

  // Profile endpoints
  getMyProfile: () => request('/profiles/me'),
  updateMyProfile: (fields) => request('/profiles/me', { method: 'PUT', body: fields }),
  updateMultiField: (field, values) =>
    request('/profiles/me/multi', { method: 'PUT', body: { field, values } }),
  updateHobbies: (hobbies) => request('/profiles/me/hobbies', { method: 'PUT', body: { hobbies } }),
  getHobbySuggestions: () => request('/profiles/hobbies/suggestions'),
  getProfile: (userId) => request(`/profiles/${userId}`),
  searchProfiles: (params) => {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (Array.isArray(value)) value.forEach((v) => qs.append(key, v));
      else if (value !== undefined && value !== '') qs.append(key, value);
    });
    return request(`/profiles?${qs.toString()}`);
  },

  // Posts the current user has hidden from the feed, and undoing that.
  getHiddenPosts: () => request('/api/feed/hidden'),
  unhidePost: (postId) => request(`/api/feed/hidden/${postId}`, { method: 'DELETE' }),
};
