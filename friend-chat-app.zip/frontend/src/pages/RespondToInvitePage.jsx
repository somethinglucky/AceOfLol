import { useEffect, useState } from 'react';
import { api } from '../api/client';
import InvitationCard from '../components/InvitationCard';

function formatDate(iso) {
  try {
    return new Date(iso).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  } catch {
    return iso;
  }
}

// The direct-from-DM landing spot for a still-pending invite — sj's
// specific complaint was that this used to land in the Lobby's Invite
// panel, which opens on a "create a new invite" form with the actual
// invite buried below it, easy to miss. This page shows nothing but the
// one invite that was tapped: the card, and a way to accept it. One tap
// on the DM card, one tap on a time, done.
export default function RespondToInvitePage({ inviteId, onBack, onResponded }) {
  const [invite, setInvite] = useState(null);
  const [error, setError] = useState('');
  const [responding, setResponding] = useState(false);

  useEffect(() => {
    api.getGameInvite(inviteId).then((data) => setInvite(data.invite)).catch(() => setError("Couldn't load that invite."));
  }, [inviteId]);

  async function handlePick(date) {
    setResponding(true);
    setError('');
    try {
      const { sessionId } = await api.respondToGameInvite(inviteId, date);
      onResponded(sessionId);
    } catch (err) {
      setError(err.message || "Couldn't accept that invite.");
      setResponding(false);
    }
  }

  if (error) {
    return (
      <div className="fixed inset-0 z-50 flex flex-col items-center justify-center gap-3 p-6" style={{ background: 'var(--color-bg)' }}>
        <p style={{ color: 'var(--color-text-secondary)' }}>{error}</p>
        <button onClick={onBack} className="text-[14px]" style={{ color: 'var(--theme-accent)' }}>Back to Games</button>
      </div>
    );
  }
  if (!invite) return <div className="fixed inset-0" style={{ background: 'var(--color-bg)' }} />;

  // Already handled elsewhere (e.g. they responded from the Invites tab
  // in another tab/device before tapping this) — don't show a stale
  // accept form for something already decided.
  if (invite.status !== 'pending') {
    return (
      <div className="fixed inset-0 z-50 flex flex-col items-center justify-center gap-4 p-6 text-center" style={{ background: 'var(--color-bg)' }}>
        <p style={{ color: 'var(--color-text-secondary)' }}>This invite is {invite.status}.</p>
        {invite.sessionId && (
          <button
            onClick={() => onResponded(invite.sessionId)}
            className="rounded-full px-5 py-2 text-[14px] font-semibold text-white"
            style={{ background: 'var(--theme-accent)' }}
          >
            Open game
          </button>
        )}
        <button onClick={onBack} className="text-[13px]" style={{ color: 'var(--color-text-secondary)' }}>Back to Games</button>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center gap-6 p-6" style={{ background: 'rgba(8,8,10,0.95)' }}>
      <InvitationCard
        templateId={invite.templateId}
        size="lg"
        title="You're Invited"
        subtitle={invite.inviter ? `from ${invite.inviter.nickname}` : undefined}
        gameIcon={invite.gameIcon}
        gameName={invite.gameName}
      />

      <div className="flex flex-col items-center gap-2">
        <p className="text-[13px]" style={{ color: 'rgba(255,255,255,0.7)' }}>Pick a time to play:</p>
        <div className="flex flex-wrap gap-2 justify-center max-w-xs">
          {invite.proposedDates.map((d) => (
            <button
              key={d}
              disabled={responding}
              onClick={() => handlePick(d)}
              className="text-[13px] px-3 py-1.5 rounded-full font-semibold text-white disabled:opacity-60"
              style={{ background: 'var(--theme-accent)' }}
            >
              {formatDate(d)}
            </button>
          ))}
        </div>
      </div>

      {error && <p className="text-[13px]" style={{ color: '#ff6b6b' }}>{error}</p>}

      <button onClick={onBack} className="text-[13px]" style={{ color: 'rgba(255,255,255,0.5)' }}>
        Not now
      </button>
    </div>
  );
}
