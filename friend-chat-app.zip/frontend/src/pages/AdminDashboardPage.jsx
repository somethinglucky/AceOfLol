import { useEffect, useState } from 'react';
import { ShieldCheck, ShieldAlert, Pencil, Trash2, Plus } from 'lucide-react';
import { api } from '../api/client';
import TopBar from '../components/TopBar';
import MenuDrawer from '../components/MenuDrawer';
import NameTag from '../components/NameTag';

const ROLES = ['user', 'moderator', 'admin'];
const ITEM_TYPES = [
  { value: 'gem_pack', label: 'Gem pack (grants ♦ gems)' },
  { value: 'digital', label: 'Digital item' },
  { value: 'physical', label: 'Physical item (ships)' },
];

const EMPTY_FORM = {
  name: '',
  description: '',
  itemType: 'digital',
  priceUsd: '',
  gemAmount: '',
  requiresShipping: false,
  isActive: true,
};

function formToFields(form) {
  return {
    name: form.name.trim(),
    description: form.description.trim(),
    itemType: form.itemType,
    priceUsdCents: Math.round(Number(form.priceUsd) * 100),
    gemAmount: form.itemType === 'gem_pack' ? form.gemAmount : '',
    requiresShipping: form.itemType === 'physical' ? form.requiresShipping : false,
    isActive: form.isActive,
  };
}

function StoreItemForm({ initial, onCancel, onSaved }) {
  const [form, setForm] = useState(initial || EMPTY_FORM);
  const [imageFile, setImageFile] = useState(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const isEdit = !!initial?.id;

  function set(key, value) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');

    if (!form.name.trim()) return setError('Name is required.');
    if (!form.priceUsd || Number(form.priceUsd) <= 0) return setError('Price must be greater than $0.');
    if (form.itemType === 'gem_pack' && (!form.gemAmount || Number(form.gemAmount) <= 0)) {
      return setError('Gem amount is required for a gem pack.');
    }

    setSaving(true);
    try {
      const fields = formToFields(form);
      const saved = isEdit
        ? await api.adminUpdateStoreItem(initial.id, fields, imageFile)
        : await api.adminCreateStoreItem(fields, imageFile);
      onSaved(saved.item);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="p-3 rounded-lg mb-3 flex flex-col gap-2" style={{ background: 'var(--color-bg-elevated)' }}>
      <input
        value={form.name}
        onChange={(e) => set('name', e.target.value)}
        placeholder="Item name"
        className="px-3 py-2 rounded-lg text-[15px]"
        style={{ background: 'var(--color-bg)', color: 'var(--color-text)' }}
      />
      <textarea
        value={form.description}
        onChange={(e) => set('description', e.target.value)}
        placeholder="Description (shown in the store)"
        rows={2}
        className="px-3 py-2 rounded-lg text-[14px]"
        style={{ background: 'var(--color-bg)', color: 'var(--color-text)' }}
      />

      <select
        value={form.itemType}
        onChange={(e) => set('itemType', e.target.value)}
        className="px-3 py-2 rounded-lg text-[14px]"
        style={{ background: 'var(--color-bg)', color: 'var(--color-text)' }}
      >
        {ITEM_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
      </select>

      <div className="flex gap-2">
        <input
          value={form.priceUsd}
          onChange={(e) => set('priceUsd', e.target.value)}
          placeholder="Price (USD, e.g. 4.99)"
          inputMode="decimal"
          className="flex-1 px-3 py-2 rounded-lg text-[14px]"
          style={{ background: 'var(--color-bg)', color: 'var(--color-text)' }}
        />
        {form.itemType === 'gem_pack' && (
          <input
            value={form.gemAmount}
            onChange={(e) => set('gemAmount', e.target.value)}
            placeholder="♦ gems granted"
            inputMode="numeric"
            className="flex-1 px-3 py-2 rounded-lg text-[14px]"
            style={{ background: 'var(--color-bg)', color: 'var(--color-text)' }}
          />
        )}
      </div>

      {form.itemType === 'physical' && (
        <label className="flex items-center gap-2 text-[13px]">
          <input type="checkbox" checked={form.requiresShipping} onChange={(e) => set('requiresShipping', e.target.checked)} />
          Collect a shipping address at checkout
        </label>
      )}

      <label className="flex items-center gap-2 text-[13px]">
        <input type="checkbox" checked={form.isActive} onChange={(e) => set('isActive', e.target.checked)} />
        Active (visible in the store)
      </label>

      <label className="text-[13px]" style={{ color: 'var(--color-text-secondary)' }}>
        Image (optional)
        <input type="file" accept="image/*" onChange={(e) => setImageFile(e.target.files?.[0] || null)} className="block text-[13px] mt-1" />
      </label>

      {error && <p className="text-[12px]" style={{ color: '#ff375f' }}>{error}</p>}

      <div className="flex gap-2 mt-1">
        <button
          type="submit"
          disabled={saving}
          className="px-4 py-2 rounded-lg text-[14px] font-semibold text-white disabled:opacity-60"
          style={{ background: 'var(--theme-accent)' }}
        >
          {saving ? 'Saving…' : isEdit ? 'Save changes' : 'Add item'}
        </button>
        <button type="button" onClick={onCancel} className="px-4 py-2 rounded-lg text-[14px]" style={{ color: 'var(--color-text-secondary)' }}>
          Cancel
        </button>
      </div>
    </form>
  );
}

function StoreItemRow({ item, onEdit, onDeleted }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function handleDelete() {
    setBusy(true);
    setError('');
    try {
      await api.adminDeleteStoreItem(item.id);
      onDeleted(item.id);
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  }

  return (
    <div className="py-3 border-b flex items-center gap-3" style={{ borderColor: 'var(--color-separator)' }}>
      <div className="w-12 h-12 rounded-lg overflow-hidden shrink-0" style={{ background: 'var(--color-bg)' }}>
        {item.imageUrl && <img src={item.imageUrl} alt="" className="w-full h-full object-cover" />}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-[14px] font-semibold truncate">{item.name}{!item.isActive && ' (inactive)'}</p>
        <p className="text-[12px]" style={{ color: 'var(--color-text-secondary)' }}>
          ${(item.priceUsdCents / 100).toFixed(2)} · {item.itemType}{item.itemType === 'gem_pack' ? ` · ${item.gemAmount}♦` : ''}
        </p>
        {error && <p className="text-[12px]" style={{ color: '#ff375f' }}>{error}</p>}
      </div>
      <button onClick={() => onEdit(item)} className="p-2" aria-label="Edit">
        <Pencil size={16} color="var(--color-text-secondary)" />
      </button>
      <button onClick={handleDelete} disabled={busy} className="p-2" aria-label="Delete">
        <Trash2 size={16} color="#ff375f" />
      </button>
    </div>
  );
}

function StoreItemsPanel() {
  const [items, setItems] = useState(null);
  const [error, setError] = useState('');
  const [editing, setEditing] = useState(null); // null = closed, {} = new, item = editing existing
  const [selectedInitial, setSelectedInitial] = useState(null);

  function load() {
    api.adminGetStoreItems().then((data) => setItems(data.items)).catch((err) => setError(err.message));
  }

  useEffect(load, []);

  function startEdit(item) {
    setSelectedInitial({
      id: item.id,
      name: item.name,
      description: item.description || '',
      itemType: item.itemType,
      priceUsd: (item.priceUsdCents / 100).toFixed(2),
      gemAmount: item.gemAmount || '',
      requiresShipping: item.requiresShipping,
      isActive: item.isActive,
    });
    setEditing(true);
  }

  function handleSaved(item) {
    setEditing(false);
    setSelectedInitial(null);
    setItems((prev) => {
      if (!prev) return [item];
      const exists = prev.some((i) => i.id === item.id);
      return exists ? prev.map((i) => (i.id === item.id ? item : i)) : [item, ...prev];
    });
  }

  function handleDeleted(id) {
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  return (
    <div>
      {!editing && (
        <button
          onClick={() => { setSelectedInitial(null); setEditing(true); }}
          className="flex items-center gap-1 px-4 py-2 rounded-lg text-[14px] font-semibold text-white mb-3"
          style={{ background: 'var(--theme-accent)' }}
        >
          <Plus size={16} /> Add store item
        </button>
      )}

      {editing && (
        <StoreItemForm
          initial={selectedInitial}
          onCancel={() => { setEditing(false); setSelectedInitial(null); }}
          onSaved={handleSaved}
        />
      )}

      {error && <p className="text-[13px] mb-2" style={{ color: '#ff375f' }}>{error}</p>}
      {items === null && !error && <p style={{ color: 'var(--color-text-secondary)' }}>Loading…</p>}
      {items?.length === 0 && <p style={{ color: 'var(--color-text-secondary)' }}>No store items yet.</p>}
      {items?.map((item) => (
        <StoreItemRow key={item.id} item={item} onEdit={startEdit} onDeleted={handleDeleted} />
      ))}
    </div>
  );
}

function UserRow({ user, onChanged }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function changeRole(role) {
    if (role === user.role) return;
    setBusy(true);
    setError('');
    try {
      await api.adminSetRole(user.id, role);
      onChanged({ ...user, role });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function toggleBot() {
    setBusy(true);
    setError('');
    try {
      await api.adminSetBot(user.id, !user.isBot);
      onChanged({ ...user, isBot: !user.isBot });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="py-3 border-b" style={{ borderColor: 'var(--color-separator)' }}>
      <div className="flex items-center justify-between gap-2">
        <div>
          <NameTag nickname={user.nickname} handle={user.handle} isRegistered={user.isRegistered} userId={user.id} sender={user} />
          <p className="text-[12px] mt-0.5" style={{ color: 'var(--color-text-secondary)' }}>
            {user.isRegistered ? 'Registered' : 'Guest'}{user.isBot ? ' · Bot' : ''} · joined {user.createdAt?.slice(0, 10)}
          </p>
        </div>
        {user.role === 'admin' && <ShieldCheck size={18} color="var(--theme-accent)" />}
        {user.role === 'moderator' && <ShieldAlert size={18} color="var(--theme-accent)" />}
      </div>

      <div className="flex gap-2 mt-2 flex-wrap">
        {ROLES.map((r) => (
          <button
            key={r}
            disabled={busy || r === user.role}
            onClick={() => changeRole(r)}
            className="px-3 py-1 rounded-full text-[13px] font-medium"
            style={
              r === user.role
                ? { background: 'var(--theme-accent)', color: '#fff' }
                : { background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }
            }
          >
            {r.charAt(0).toUpperCase() + r.slice(1)}
          </button>
        ))}
        <button
          disabled={busy}
          onClick={toggleBot}
          className="px-3 py-1 rounded-full text-[13px] font-medium"
          style={{ background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }}
        >
          {user.isBot ? 'Unmark bot' : 'Mark as bot'}
        </button>
      </div>

      {error && <p className="text-[12px] mt-1" style={{ color: '#ff375f' }}>{error}</p>}
    </div>
  );
}

export default function AdminDashboardPage({ siteName, user, currentUserInfo, unreadCount, onBack, onNavigate, onAuthClick, onLogout }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [tab, setTab] = useState('users'); // 'users' | 'store'
  const [query, setQuery] = useState('');
  const [results, setResults] = useState(null); // null = no search yet
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSearch(e) {
    e.preventDefault();
    if (!query.trim()) return;
    setLoading(true);
    setError('');
    try {
      const data = await api.adminSearchUsers(query.trim());
      setResults(data.users);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  function handleChanged(updated) {
    setResults((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
  }

  // This is UX only — someone without admin access simply can't reach this
  // page usefully, since every action above 403s server-side regardless of
  // what's shown here. currentUserInfo comes from /api/me (see App.jsx).
  if (currentUserInfo && !currentUserInfo.isAdmin) {
    return (
      <div className="h-screen flex flex-col" style={{ background: 'var(--color-bg)' }}>
        <TopBar siteName={siteName} user={user} unreadCount={unreadCount} onBack={onBack} onAuthClick={onAuthClick} onMenuClick={() => setMenuOpen(true)} onLogout={onLogout} />
        <div className="flex-1 flex items-center justify-center px-6 text-center">
          <p style={{ color: 'var(--color-text-secondary)' }}>This page is for admins only.</p>
        </div>
        <MenuDrawer open={menuOpen} onClose={() => setMenuOpen(false)} onNavigate={onNavigate} isAdmin={currentUserInfo?.isAdmin} isModerator={currentUserInfo?.isModerator} unreadCount={unreadCount} />
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col" style={{ background: 'var(--color-bg)' }}>
      <TopBar siteName={siteName} user={user} unreadCount={unreadCount} onBack={onBack} onAuthClick={onAuthClick} onMenuClick={() => setMenuOpen(true)} onLogout={onLogout} />

      <div className="flex-1 overflow-y-auto px-4 py-4">
        <h1 className="text-[17px] font-semibold mb-3">Admin Dashboard</h1>

        <div className="flex gap-2 mb-4">
          {[['users', 'Users'], ['store', 'Store Items']].map(([value, label]) => (
            <button
              key={value}
              onClick={() => setTab(value)}
              className="px-3 py-1.5 rounded-full text-[13px] font-semibold"
              style={
                tab === value
                  ? { background: 'var(--theme-accent)', color: '#fff' }
                  : { background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }
              }
            >
              {label}
            </button>
          ))}
        </div>

        {tab === 'users' && (
          <>
            <form onSubmit={handleSearch} className="flex gap-2 mb-3">
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search by handle…"
                className="flex-1 px-3 py-2 rounded-lg text-[15px]"
                style={{ background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }}
              />
              <button
                type="submit"
                disabled={loading}
                className="px-4 py-2 rounded-lg text-[15px] font-medium"
                style={{ background: 'var(--theme-accent)', color: '#fff' }}
              >
                Search
              </button>
            </form>

            {error && <p className="text-[13px] mb-2" style={{ color: '#ff375f' }}>{error}</p>}
            {loading && <p style={{ color: 'var(--color-text-secondary)' }}>Searching…</p>}

            {results !== null && results.length === 0 && !loading && (
              <p style={{ color: 'var(--color-text-secondary)' }}>No users match that handle.</p>
            )}

            {results !== null && results.map((u) => <UserRow key={u.id} user={u} onChanged={handleChanged} />)}
          </>
        )}

        {tab === 'store' && <StoreItemsPanel />}
      </div>

      <MenuDrawer open={menuOpen} onClose={() => setMenuOpen(false)} onNavigate={onNavigate} isAdmin={currentUserInfo?.isAdmin} isModerator={currentUserInfo?.isModerator} unreadCount={unreadCount} />
    </div>
  );
}
