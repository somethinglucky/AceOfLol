import { useState } from 'react';
import { ShieldCheck, ShieldAlert } from 'lucide-react';
import { api } from '../api/client';
import TopBar from '../components/TopBar';
import MenuDrawer from '../components/MenuDrawer';

const ROLES = ['user', 'moderator', 'admin'];

function UserRow({ user, onChanged }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function changeRole(role) {
    if (role === user.role) return;
    setBusy(true);
    setError('');
    try {
      await api.adminSetRole(user.id, role);
      onChanged({ ...user, role });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function toggleBot() {
    setBusy(true);
    setError('');
    try {
      await api.adminSetBot(user.id, !user.isBot);
      onChanged({ ...user, isBot: !user.isBot });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="py-3 border-b" style={{ borderColor: 'var(--color-separator)' }}>
      <div className="flex items-center justify-between gap-2">
        <div>
          <p className="text-[15px] font-medium">
            {user.nickname || 'No nickname'} <span style={{ color: 'var(--color-text-secondary)' }}>@{user.handle}</span>
          </p>
          <p className="text-[12px]" style={{ color: 'var(--color-text-secondary)' }}>
            {user.isRegistered ? 'Registered' : 'Guest'}{user.isBot ? ' · Bot' : ''} · joined {user.createdAt?.slice(0, 10)}
          </p>
        </div>
        {user.role === 'admin' && <ShieldCheck size={18} color="var(--theme-accent)" />}
        {user.role === 'moderator' && <ShieldAlert size={18} color="var(--theme-accent)" />}
      </div>

      <div className="flex gap-2 mt-2 flex-wrap">
        {ROLES.map((r) => (
          <button
            key={r}
            disabled={busy || r === user.role}
            onClick={() => changeRole(r)}
            className="px-3 py-1 rounded-full text-[13px] font-medium"
            style={
              r === user.role
                ? { background: 'var(--theme-accent)', color: '#fff' }
                : { background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }
            }
          >
            {r.charAt(0).toUpperCase() + r.slice(1)}
          </button>
        ))}
        <button
          disabled={busy}
          onClick={toggleBot}
          className="px-3 py-1 rounded-full text-[13px] font-medium"
          style={{ background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }}
        >
          {user.isBot ? 'Unmark bot' : 'Mark as bot'}
        </button>
      </div>

      {error && <p className="text-[12px] mt-1" style={{ color: '#ff375f' }}>{error}</p>}
    </div>
  );
}

export default function AdminDashboardPage({ siteName, user, currentUserInfo, onNavigate, onAuthClick }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState(null); // null = no search yet
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSearch(e) {
    e.preventDefault();
    if (!query.trim()) return;
    setLoading(true);
    setError('');
    try {
      const data = await api.adminSearchUsers(query.trim());
      setResults(data.users);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  function handleChanged(updated) {
    setResults((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
  }

  // This is UX only — someone without admin access simply can't reach this
  // page usefully, since every action above 403s server-side regardless of
  // what's shown here. currentUserInfo comes from /api/me (see App.jsx).
  if (currentUserInfo && !currentUserInfo.isAdmin) {
    return (
      <div className="h-screen flex flex-col" style={{ background: 'var(--color-bg)' }}>
        <TopBar siteName={siteName} user={user} onAuthClick={onAuthClick} onMenuClick={() => setMenuOpen(true)} />
        <div className="flex-1 flex items-center justify-center px-6 text-center">
          <p style={{ color: 'var(--color-text-secondary)' }}>This page is for admins only.</p>
        </div>
        <MenuDrawer open={menuOpen} onClose={() => setMenuOpen(false)} onNavigate={onNavigate} isAdmin={currentUserInfo?.isAdmin} />
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col" style={{ background: 'var(--color-bg)' }}>
      <TopBar siteName={siteName} user={user} onAuthClick={onAuthClick} onMenuClick={() => setMenuOpen(true)} />

      <div className="flex-1 overflow-y-auto px-4 py-4">
        <h1 className="text-[17px] font-semibold mb-3">Admin Dashboard</h1>

        <form onSubmit={handleSearch} className="flex gap-2 mb-3">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by handle…"
            className="flex-1 px-3 py-2 rounded-lg text-[15px]"
            style={{ background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }}
          />
          <button
            type="submit"
            disabled={loading}
            className="px-4 py-2 rounded-lg text-[15px] font-medium"
            style={{ background: 'var(--theme-accent)', color: '#fff' }}
          >
            Search
          </button>
        </form>

        {error && <p className="text-[13px] mb-2" style={{ color: '#ff375f' }}>{error}</p>}
        {loading && <p style={{ color: 'var(--color-text-secondary)' }}>Searching…</p>}

        {results !== null && results.length === 0 && !loading && (
          <p style={{ color: 'var(--color-text-secondary)' }}>No users match that handle.</p>
        )}

        {results !== null && results.map((u) => <UserRow key={u.id} user={u} onChanged={handleChanged} />)}
      </div>

      <MenuDrawer open={menuOpen} onClose={() => setMenuOpen(false)} onNavigate={onNavigate} isAdmin={currentUserInfo?.isAdmin} />
    </div>
  );
}
