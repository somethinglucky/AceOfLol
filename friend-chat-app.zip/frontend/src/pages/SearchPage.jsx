import { useState } from 'react';
import { ChevronLeft, Search as SearchIcon } from 'lucide-react';
import { api } from '../api/client';
import ProfileCard from '../components/ProfileCard';
import { colorFromString } from '../utils/colorHash';
import {
  GENDER_OPTIONS, ORIENTATION_OPTIONS, HAS_KIDS_OPTIONS, PETS_OPTIONS, RELIGION_OPTIONS,
  COMMITMENT_OPTIONS, DIET_OPTIONS, POLYAMORY_OPTIONS, BUILD_OPTIONS,
} from '../constants/profileOptions';

const MULTI_FILTERS = [
  { key: 'gender', label: 'Gender', options: GENDER_OPTIONS },
  { key: 'orientation', label: 'Orientation', options: ORIENTATION_OPTIONS },
  { key: 'hasKids', label: 'Kids', options: HAS_KIDS_OPTIONS },
  { key: 'pets', label: 'Pets', options: PETS_OPTIONS },
  { key: 'religion', label: 'Religion', options: RELIGION_OPTIONS },
];

const SINGLE_FILTERS = [
  { key: 'commitment', label: 'Commitment', options: COMMITMENT_OPTIONS },
  { key: 'diet', label: 'Diet', options: DIET_OPTIONS },
  { key: 'polyamory', label: 'Polyamory', options: POLYAMORY_OPTIONS },
  { key: 'build', label: 'Build', options: BUILD_OPTIONS },
];

function Chip({ selected, onClick, children }) {
  return (
    <button
      onClick={onClick}
      className="text-xs font-medium px-3 py-1.5 rounded-full border"
      style={{
        background: selected ? 'var(--theme-accent)' : 'transparent',
        color: selected ? '#fff' : 'var(--color-text)',
        borderColor: selected ? 'var(--theme-accent)' : 'var(--color-border)',
      }}
    >
      {children}
    </button>
  );
}

export default function SearchPage({ onBack }) {
  const [filters, setFilters] = useState({});
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [openProfileId, setOpenProfileId] = useState(null);

  function toggleMulti(field, value) {
    setFilters((prev) => {
      const current = prev[field] || [];
      const next = current.includes(value) ? current.filter((v) => v !== value) : [...current, value];
      return { ...prev, [field]: next };
    });
  }

  function setSingle(field, value) {
    setFilters((prev) => ({ ...prev, [field]: prev[field] === value ? undefined : value }));
  }

  async function handleSearch() {
    setLoading(true);
    try {
      const { results } = await api.searchProfiles(filters);
      setResults(results);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="h-screen flex flex-col" style={{ background: 'var(--color-bg)' }}>
      <div
        className="flex items-center justify-between px-3 py-2 border-b shrink-0"
        style={{ borderColor: 'var(--color-border)', background: 'var(--color-bg-elevated)', paddingTop: 'calc(env(safe-area-inset-top) + 8px)' }}
      >
        <button onClick={onBack} className="flex items-center gap-1 text-[15px]" style={{ color: 'var(--theme-accent)' }}>
          <ChevronLeft size={20} /> Back
        </button>
        <h1 className="text-[17px] font-semibold">Search</h1>
        <div className="w-12" />
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4">
        <div className="flex gap-2 mb-4">
          <input
            type="number"
            placeholder="Min age"
            value={filters.minAge || ''}
            onChange={(e) => setFilters((p) => ({ ...p, minAge: e.target.value }))}
            className="flex-1 rounded-xl px-3 py-2 text-[15px] outline-none"
            style={{ background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }}
          />
          <input
            type="number"
            placeholder="Max age"
            value={filters.maxAge || ''}
            onChange={(e) => setFilters((p) => ({ ...p, maxAge: e.target.value }))}
            className="flex-1 rounded-xl px-3 py-2 text-[15px] outline-none"
            style={{ background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }}
          />
        </div>

        <input
          placeholder="Country"
          value={filters.country || ''}
          onChange={(e) => setFilters((p) => ({ ...p, country: e.target.value }))}
          className="w-full rounded-xl px-3 py-2 text-[15px] outline-none mb-4"
          style={{ background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }}
        />

        <input
          placeholder="Hobby (e.g. hiking)"
          value={filters.hobby || ''}
          onChange={(e) => setFilters((p) => ({ ...p, hobby: e.target.value }))}
          className="w-full rounded-xl px-3 py-2 text-[15px] outline-none mb-4"
          style={{ background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }}
        />

        {MULTI_FILTERS.map(({ key, label, options }) => (
          <div className="mb-4" key={key}>
            <h3 className="text-[13px] font-semibold uppercase tracking-wide mb-2" style={{ color: 'var(--color-text-secondary)' }}>
              {label}
            </h3>
            <div className="flex flex-wrap gap-2">
              {options.map((opt) => (
                <Chip key={opt.value} selected={filters[key]?.includes(opt.value)} onClick={() => toggleMulti(key, opt.value)}>
                  {opt.label}
                </Chip>
              ))}
            </div>
          </div>
        ))}

        {SINGLE_FILTERS.map(({ key, label, options }) => (
          <div className="mb-4" key={key}>
            <h3 className="text-[13px] font-semibold uppercase tracking-wide mb-2" style={{ color: 'var(--color-text-secondary)' }}>
              {label}
            </h3>
            <div className="flex flex-wrap gap-2">
              {options.map((opt) => (
                <Chip key={opt.value} selected={filters[key] === opt.value} onClick={() => setSingle(key, opt.value)}>
                  {opt.label}
                </Chip>
              ))}
            </div>
          </div>
        ))}

        <button
          onClick={handleSearch}
          disabled={loading}
          className="w-full rounded-xl px-4 py-3 text-[15px] font-semibold text-white mt-2 mb-6 flex items-center justify-center gap-2"
          style={{ background: 'var(--theme-accent)' }}
        >
          <SearchIcon size={16} /> {loading ? 'Searching…' : 'Search'}
        </button>

        {results && (
          <div className="flex flex-col gap-2">
            {results.length === 0 && (
              <p className="text-center text-sm" style={{ color: 'var(--color-text-secondary)' }}>
                No one matches those filters yet — try widening them.
              </p>
            )}
            {results.map((r) => (
              <button
                key={r.userId}
                onClick={() => setOpenProfileId(r.userId)}
                className="flex items-center gap-3 p-3 rounded-xl text-left"
                style={{ background: 'var(--color-bg-elevated)' }}
              >
                <div
                  className="h-11 w-11 rounded-full overflow-hidden flex items-center justify-center shrink-0"
                  style={{ background: r.displayColor || colorFromString(r.handle) }}
                >
                  {r.avatarUrl ? (
                    <img src={r.avatarUrl} alt="" className="h-full w-full object-cover" />
                  ) : (
                    <span className="text-white font-semibold">{(r.nickname || r.handle)[0].toUpperCase()}</span>
                  )}
                </div>
                <div>
                  <p className="font-medium text-[15px]">{r.nickname || r.handle}</p>
                  <p className="text-xs" style={{ color: 'var(--color-text-secondary)' }}>
                    {[r.age, r.country].filter(Boolean).join(' · ')}
                  </p>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      <ProfileCard userId={openProfileId} onClose={() => setOpenProfileId(null)} />
    </div>
  );
}
