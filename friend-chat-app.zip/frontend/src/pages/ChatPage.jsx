import { useState } from 'react';
import AdBanner from '../components/AdBanner';
import ChatRoom from '../components/ChatRoom';
import ProfileCard from '../components/ProfileCard';
import MenuDrawer from '../components/MenuDrawer';
import TopBar from '../components/TopBar';

export default function ChatPage({ siteName, roomId, user, onNavigate, onAuthClick }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [openProfile, setOpenProfile] = useState(null);

  async function handleAvatarTap(userId) {
    setOpenProfile({ nickname: 'Loading…', handle: '', interests: [] });
    // TODO: replace with a real api.getProfile(userId) call once profiles.js exists
  }

  return (
    <div className="flex flex-col h-screen" style={{ background: 'var(--color-bg)' }}>
      <TopBar
        siteName={siteName}
        user={user}
        onAuthClick={onAuthClick}
        onMenuClick={() => setMenuOpen(true)}
      />

      <div className="shrink-0">
        <AdBanner />
      </div>

      <div className="flex-1 min-h-0">
        <ChatRoom roomId={roomId} currentUserId={user?.id} onAvatarTap={handleAvatarTap} />
      </div>

      <ProfileCard profile={openProfile} onClose={() => setOpenProfile(null)} />
      <MenuDrawer open={menuOpen} onClose={() => setMenuOpen(false)} onNavigate={onNavigate} />
    </div>
  );
}
