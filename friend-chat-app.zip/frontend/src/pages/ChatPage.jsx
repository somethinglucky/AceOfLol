import { useState } from 'react';
import ChatRoom from '../components/ChatRoom';
import MenuDrawer from '../components/MenuDrawer';
import TopBar from '../components/TopBar';

export default function ChatPage({ siteName, roomId, user, isAdmin, isModerator, unreadCount, onNavigate, onAuthClick, onLogout, onViewProfile }) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="flex flex-col h-screen" style={{ background: 'var(--color-bg)' }}>
      <TopBar
        siteName={siteName}
        user={user}
        unreadCount={unreadCount}
        onAuthClick={onAuthClick}
        onMenuClick={() => setMenuOpen(true)}
        onLogout={onLogout}
      />

      <div className="flex-1 min-h-0">
        <ChatRoom roomId={roomId} currentUserId={user?.id} onAvatarTap={onViewProfile} />
      </div>

      <MenuDrawer open={menuOpen} onClose={() => setMenuOpen(false)} onNavigate={onNavigate} isAdmin={isAdmin} isModerator={isModerator} unreadCount={unreadCount} />
    </div>
  );
}
