import { useState } from 'react';
import { Menu } from 'lucide-react';
import AdBanner from '../components/AdBanner';
import ChatRoom from '../components/ChatRoom';
import ProfileCard from '../components/ProfileCard';
import MenuDrawer from '../components/MenuDrawer';

// roomName/currentUserId are passed down from App once a room is joined and
// the user is logged in — kept as props here rather than global state so
// this page stays easy to test on its own.
export default function ChatPage({ roomId, roomName, currentUserId, onNavigate }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [openProfile, setOpenProfile] = useState(null); // profile object or null

  // Placeholder lookup — in the real app this calls GET /profiles/:userId.
  // Wired here as a stub so ChatRoom -> ProfileCard already works end-to-end.
  async function handleAvatarTap(userId) {
    setOpenProfile({ nickname: 'Loading…', handle: '', interests: [] });
    // TODO: replace with a real api.getProfile(userId) call once profiles.js exists
  }

  return (
    <div className="flex flex-col h-screen" style={{ background: 'var(--color-bg)' }}>
      <div
        className="flex items-center justify-between px-3 py-2 border-b shrink-0"
        style={{
          borderColor: 'var(--color-border)',
          background: 'var(--color-bg-elevated)',
          paddingTop: 'calc(env(safe-area-inset-top) + 8px)',
        }}
      >
        <h1 className="text-[17px] font-semibold">{roomName}</h1>
        <button
          onClick={() => setMenuOpen(true)}
          className="h-8 w-8 flex items-center justify-center"
          aria-label="Open menu"
        >
          <Menu size={22} color="var(--color-text)" />
        </button>
      </div>

      <div className="shrink-0">
        <AdBanner />
      </div>

      <div className="flex-1 min-h-0">
        <ChatRoom roomId={roomId} currentUserId={currentUserId} onAvatarTap={handleAvatarTap} />
      </div>

      <ProfileCard profile={openProfile} onClose={() => setOpenProfile(null)} />
      <MenuDrawer open={menuOpen} onClose={() => setMenuOpen(false)} onNavigate={onNavigate} />
    </div>
  );
}
