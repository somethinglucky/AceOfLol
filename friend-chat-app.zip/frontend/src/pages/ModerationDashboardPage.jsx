import { useState } from 'react';
import { ShieldAlert } from 'lucide-react';
import TopBar from '../components/TopBar';
import MenuDrawer from '../components/MenuDrawer';

export default function ModerationDashboardPage({ siteName, user, currentUserInfo, onNavigate, onAuthClick, onLogout }) {
  const [menuOpen, setMenuOpen] = useState(false);

  // UX gate only — every real moderation action will hit its own
  // requireRegistered-plus-isModerator check server-side once this page
  // actually does something. currentUserInfo comes from /api/me.
  if (currentUserInfo && !currentUserInfo.isModerator) {
    return (
      <div className="h-screen flex flex-col" style={{ background: 'var(--color-bg)' }}>
        <TopBar siteName={siteName} user={user} onAuthClick={onAuthClick} onMenuClick={() => setMenuOpen(true)} onLogout={onLogout} />
        <div className="flex-1 flex items-center justify-center px-6 text-center">
          <p style={{ color: 'var(--color-text-secondary)' }}>This page is for moderators only.</p>
        </div>
        <MenuDrawer
          open={menuOpen}
          onClose={() => setMenuOpen(false)}
          onNavigate={onNavigate}
          isAdmin={currentUserInfo?.isAdmin}
          isModerator={currentUserInfo?.isModerator}
        />
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col" style={{ background: 'var(--color-bg)' }}>
      <TopBar siteName={siteName} user={user} onAuthClick={onAuthClick} onMenuClick={() => setMenuOpen(true)} onLogout={onLogout} />

      <div className="flex-1 flex flex-col items-center justify-center gap-3 px-6 text-center">
        <ShieldAlert size={32} color="var(--color-text-secondary)" />
        <p className="text-[17px] font-semibold">Moderation Dashboard</p>
        <p className="text-[14px]" style={{ color: 'var(--color-text-secondary)' }}>
          Coming soon — this is where reports, hidden content, and moderation actions will live.
        </p>
      </div>

      <MenuDrawer
        open={menuOpen}
        onClose={() => setMenuOpen(false)}
        onNavigate={onNavigate}
        isAdmin={currentUserInfo?.isAdmin}
        isModerator={currentUserInfo?.isModerator}
      />
    </div>
  );
}
