import { useEffect, useMemo, useState } from 'react';
import { Gem } from 'lucide-react';
import { api } from '../api/client';
import TopBar from '../components/TopBar';
import MenuDrawer from '../components/MenuDrawer';

const SORT_OPTIONS = [
  { value: 'default', label: 'Featured' },
  { value: 'price_low', label: 'Price: Low to High' },
  { value: 'price_high', label: 'Price: High to Low' },
  { value: 'newest', label: 'Newest' },
];

function formatUsd(cents) {
  return `$${(cents / 100).toFixed(2)}`;
}

function StoreItemCard({ item, onBuy, buying }) {
  return (
    <div
      className="rounded-xl overflow-hidden flex flex-col"
      style={{ background: 'var(--color-bg-elevated)', border: '1px solid var(--color-border)' }}
    >
      <div className="aspect-square w-full" style={{ background: 'var(--color-bg)' }}>
        {item.imageUrl ? (
          <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            {item.itemType === 'gem_pack' ? (
              <Gem size={32} color="var(--theme-accent)" />
            ) : (
              <span className="text-[13px]" style={{ color: 'var(--color-text-secondary)' }}>No image</span>
            )}
          </div>
        )}
      </div>

      <div className="p-3 flex flex-col gap-1 flex-1">
        <p className="text-[15px] font-semibold leading-tight">{item.name}</p>
        {item.description && (
          <p className="text-[13px] leading-snug" style={{ color: 'var(--color-text-secondary)' }}>
            {item.description}
          </p>
        )}
        <div className="mt-auto pt-2 flex items-center justify-between gap-2">
          <span className="text-[15px] font-semibold">{formatUsd(item.priceUsdCents)}</span>
          <button
            onClick={() => onBuy(item)}
            disabled={buying}
            className="px-3 py-1.5 rounded-full text-[13px] font-semibold text-white disabled:opacity-60"
            style={{ background: 'var(--theme-accent)' }}
          >
            {buying ? 'Loading…' : 'Buy'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function StorePage({ siteName, user, isAdmin, isModerator, onNavigate, onAuthClick, onLogout }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [items, setItems] = useState(null); // null = loading
  const [error, setError] = useState('');
  const [sort, setSort] = useState('default');
  const [wallet, setWallet] = useState(null);
  const [buyingId, setBuyingId] = useState(null);
  const [checkoutNotice, setCheckoutNotice] = useState('');

  useEffect(() => {
    api.getStoreItems()
      .then((data) => setItems(data.items))
      .catch(() => setError("Couldn't load the store — try again in a bit."));
  }, []);

  // Returning from Stripe Checkout — success_url/cancel_url both land back
  // here with ?checkout=success|cancelled. The gem-pack purchase itself is
  // only ever confirmed server-side by the webhook (see routes/webhooks.js),
  // so "success" here just means Stripe took the payment; it can land a
  // beat before the webhook has actually credited gems, hence the refetch.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const outcome = params.get('checkout');
    if (!outcome) return;

    if (outcome === 'success') {
      setCheckoutNotice("Payment received! If this was for gems, your balance updates in a few seconds.");
      if (user?.isRegistered) {
        setTimeout(() => api.getGemWallet().then((data) => setWallet(data.balance)).catch(() => {}), 2500);
      }
    } else if (outcome === 'cancelled') {
      setCheckoutNotice('Checkout cancelled — nothing was charged.');
    }

    params.delete('checkout');
    const newSearch = params.toString();
    window.history.replaceState({}, '', `${window.location.pathname}${newSearch ? `?${newSearch}` : ''}`);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!user?.isRegistered) return;
    api.getGemWallet().then((data) => setWallet(data.balance)).catch(() => {});
  }, [user?.isRegistered]);

  const sortedItems = useMemo(() => {
    if (!items) return items;
    const copy = [...items];
    if (sort === 'price_low') copy.sort((a, b) => a.priceUsdCents - b.priceUsdCents);
    else if (sort === 'price_high') copy.sort((a, b) => b.priceUsdCents - a.priceUsdCents);
    else if (sort === 'newest') copy.reverse();
    return copy;
  }, [items, sort]);

  async function handleBuy(item) {
    if (!user?.isRegistered) {
      onAuthClick();
      return;
    }
    setError('');
    setBuyingId(item.id);
    try {
      const { checkoutUrl } = await api.startCheckout(item.id);
      window.location.href = checkoutUrl;
    } catch (err) {
      setError(err.message || "Couldn't start checkout — try again.");
      setBuyingId(null);
    }
  }

  return (
    <div className="h-screen flex flex-col" style={{ background: 'var(--color-bg)' }}>
      <TopBar siteName={siteName} user={user} onAuthClick={onAuthClick} onMenuClick={() => setMenuOpen(true)} onLogout={onLogout} />

      {/* Ad space — placeholder slot until an ad network is wired in. */}
      <div
        className="mx-3 mt-3 rounded-lg flex items-center justify-center text-[12px] shrink-0"
        style={{ height: 60, background: 'var(--color-bg-elevated)', color: 'var(--color-text-secondary)', border: '1px dashed var(--color-border)' }}
      >
        Ad space
      </div>

      <div className="px-4 pt-4 pb-2 flex items-center justify-between shrink-0">
        <h2 className="text-[22px] font-bold">The Store</h2>
        {user?.isRegistered && wallet !== null && (
          <div className="flex items-center gap-1 text-[14px] font-semibold" style={{ color: 'var(--theme-accent)' }}>
            <Gem size={16} /> {wallet}
          </div>
        )}
      </div>

      <div className="px-4 pb-3 shrink-0">
        <select
          value={sort}
          onChange={(e) => setSort(e.target.value)}
          className="text-[13px] rounded-lg px-3 py-2 w-full"
          style={{ background: 'var(--color-bg-elevated)', border: '1px solid var(--color-border)', color: 'var(--color-text)' }}
        >
          {SORT_OPTIONS.map((opt) => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
      </div>

      {checkoutNotice && (
        <p className="px-4 pb-2 text-[13px] shrink-0" style={{ color: 'var(--color-text-secondary)' }}>{checkoutNotice}</p>
      )}
      {error && (
        <p className="px-4 pb-2 text-[13px] shrink-0" style={{ color: '#ff375f' }}>{error}</p>
      )}

      <div className="flex-1 overflow-y-auto px-4 pb-6">
        {sortedItems === null && (
          <p className="text-[14px] pt-6 text-center" style={{ color: 'var(--color-text-secondary)' }}>Loading…</p>
        )}
        {sortedItems !== null && sortedItems.length === 0 && (
          <p className="text-[14px] pt-6 text-center" style={{ color: 'var(--color-text-secondary)' }}>
            Nothing in the store right now — check back soon.
          </p>
        )}
        {sortedItems !== null && sortedItems.length > 0 && (
          <div className="grid grid-cols-2 gap-3">
            {sortedItems.map((item) => (
              <StoreItemCard key={item.id} item={item} onBuy={handleBuy} buying={buyingId === item.id} />
            ))}
          </div>
        )}
      </div>

      <MenuDrawer open={menuOpen} onClose={() => setMenuOpen(false)} onNavigate={onNavigate} isAdmin={isAdmin} isModerator={isModerator} />
    </div>
  );
}
