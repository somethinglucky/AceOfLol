import { useEffect, useState } from 'react';
import { EyeOff } from 'lucide-react';
import { api } from '../api/client';
import TopBar from '../components/TopBar';
import MenuDrawer from '../components/MenuDrawer';

function HiddenPosts() {
  const [posts, setPosts] = useState(null); // null = loading
  const [error, setError] = useState('');
  const [unhidingId, setUnhidingId] = useState(null);

  useEffect(() => {
    api.getHiddenPosts()
      .then((data) => setPosts(data.posts))
      .catch(() => setError("Couldn't load your hidden posts."));
  }, []);

  async function handleUnhide(postId) {
    setUnhidingId(postId);
    try {
      await api.unhidePost(postId);
      setPosts((prev) => prev.filter((p) => p.id !== postId));
    } catch {
      setError("Couldn't unhide that post — try again.");
    } finally {
      setUnhidingId(null);
    }
  }

  return (
    <section>
      <h2 className="text-[13px] font-semibold uppercase tracking-wide mb-2" style={{ color: 'var(--color-text-secondary)' }}>
        Hidden posts
      </h2>
      <p className="text-[13px] mb-3" style={{ color: 'var(--color-text-secondary)' }}>
        Posts you've hidden from Memes. Unhide one to see it in your feed again.
      </p>

      {error && <p className="text-[13px] mb-2" style={{ color: '#ff375f' }}>{error}</p>}

      {posts === null && <p className="text-[14px]" style={{ color: 'var(--color-text-secondary)' }}>Loading…</p>}

      {posts !== null && posts.length === 0 && (
        <p className="text-[14px]" style={{ color: 'var(--color-text-secondary)' }}>
          You haven't hidden any posts.
        </p>
      )}

      {posts !== null && posts.length > 0 && (
        <div className="grid grid-cols-3 gap-2">
          {posts.map((post) => (
            <div key={post.id} className="relative aspect-square rounded-lg overflow-hidden" style={{ background: 'var(--color-bg-elevated)' }}>
              <img src={post.image_url} alt="" className="w-full h-full object-cover" />
              <button
                onClick={() => handleUnhide(post.id)}
                disabled={unhidingId === post.id}
                className="absolute inset-0 flex items-center justify-center gap-1 text-white text-[12px] font-semibold"
                style={{ background: 'rgba(0,0,0,0.45)' }}
              >
                <EyeOff size={14} /> {unhidingId === post.id ? 'Unhiding…' : 'Unhide'}
              </button>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

export default function SettingsPage({ siteName, user, isAdmin, isModerator, onNavigate, onAuthClick, onLogout }) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="h-screen flex flex-col" style={{ background: 'var(--color-bg)' }}>
      <TopBar siteName={siteName} user={user} onAuthClick={onAuthClick} onMenuClick={() => setMenuOpen(true)} onLogout={onLogout} />

      <div className="flex-1 overflow-y-auto px-4 py-4">
        <HiddenPosts />
      </div>

      <MenuDrawer open={menuOpen} onClose={() => setMenuOpen(false)} onNavigate={onNavigate} isAdmin={isAdmin} isModerator={isModerator} />
    </div>
  );
}
