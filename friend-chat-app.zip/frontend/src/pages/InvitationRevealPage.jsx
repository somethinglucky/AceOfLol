import { useState } from 'react';
import { api } from '../api/client';
import InvitationCard from '../components/InvitationCard';

// The moment sj described: before the invitee sees the actual game, they
// see the invitation card itself, full-screen — the card the inviter
// picked out. Tapping anywhere dismisses it (once, ever — see
// gameSessions.js's reveal-seen route) and reveals the game underneath.
export default function InvitationRevealPage({ sessionId, invitation, gameName, gameIcon, onRevealed }) {
  const [dismissing, setDismissing] = useState(false);

  async function handleDismiss() {
    if (dismissing) return;
    setDismissing(true);
    try {
      await api.markInviteRevealSeen(sessionId);
    } catch {
      // Even if the mark-as-seen call fails, don't trap them on this
      // screen — worst case it shows again once. Never worse than stuck.
    }
    onRevealed();
  }

  return (
    <button
      onClick={handleDismiss}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center gap-6 w-full"
      style={{ background: 'rgba(8,8,10,0.92)' }}
    >
      <InvitationCard
        templateId={invitation.templateId}
        size="lg"
        title="You're Invited"
        subtitle={`from ${invitation.inviterNickname}`}
        gameIcon={gameIcon}
        gameName={gameName}
      />
      <p className="text-[13px] animate-pulse" style={{ color: 'rgba(255,255,255,0.6)' }}>
        Tap anywhere to open
      </p>
    </button>
  );
}
