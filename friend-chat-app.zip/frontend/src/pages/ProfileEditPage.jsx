import { useEffect, useState } from 'react';
import { ChevronLeft, Check } from 'lucide-react';
import { api } from '../api/client';
import { FONT_OPTIONS, ACCENT_PRESETS } from '../theme/ThemeContext';
import {
  GENDER_OPTIONS, ORIENTATION_OPTIONS, HAS_KIDS_OPTIONS, PETS_OPTIONS, RELIGION_OPTIONS,
  COMMITMENT_OPTIONS, DIET_OPTIONS, POLYAMORY_OPTIONS, BUILD_OPTIONS,
} from '../constants/profileOptions';

const MULTI_FIELDS = [
  { key: 'gender', label: 'Gender', options: GENDER_OPTIONS },
  { key: 'orientation', label: 'Orientation', options: ORIENTATION_OPTIONS },
  { key: 'has_kids', label: 'Kids', options: HAS_KIDS_OPTIONS },
  { key: 'pets', label: 'Pets', options: PETS_OPTIONS },
  { key: 'religion', label: 'Religion', options: RELIGION_OPTIONS },
];

const SINGLE_FIELDS = [
  { key: 'commitment', label: 'Commitment', options: COMMITMENT_OPTIONS },
  { key: 'diet', label: 'Diet', options: DIET_OPTIONS },
  { key: 'polyamory', label: 'Polyamory', options: POLYAMORY_OPTIONS },
  { key: 'build', label: 'Build', options: BUILD_OPTIONS },
];

function Chip({ selected, onClick, children }) {
  return (
    <button
      onClick={onClick}
      className="text-xs font-medium px-3 py-1.5 rounded-full border"
      style={{
        background: selected ? 'var(--theme-accent)' : 'transparent',
        color: selected ? '#fff' : 'var(--color-text)',
        borderColor: selected ? 'var(--theme-accent)' : 'var(--color-border)',
      }}
    >
      {children}
    </button>
  );
}

function Section({ title, children }) {
  return (
    <div className="mb-6">
      <h2 className="text-[13px] font-semibold uppercase tracking-wide mb-2" style={{ color: 'var(--color-text-secondary)' }}>
        {title}
      </h2>
      {children}
    </div>
  );
}

function TextInput(props) {
  return (
    <input
      {...props}
      className="w-full rounded-xl px-4 py-3 text-[15px] outline-none"
      style={{ background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }}
    />
  );
}

export default function ProfileEditPage({ onBack }) {
  const [profile, setProfile] = useState(null);
  const [hobbyInput, setHobbyInput] = useState('');
  const [hobbySuggestions, setHobbySuggestions] = useState([]);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    api.getMyProfile().then(setProfile).catch((err) => setError(err.message));
    api.getHobbySuggestions().then((r) => setHobbySuggestions(r.hobbies)).catch(() => {});
  }, []);

  function set(field, value) {
    setProfile((prev) => ({ ...prev, [field]: value }));
    setSaved(false);
  }

  function toggleMulti(field, value) {
    const current = profile[field] || [];
    const next = current.includes(value) ? current.filter((v) => v !== value) : [...current, value];
    set(field, next);
  }

  function addHobby(name) {
    const clean = name.trim().toLowerCase();
    if (!clean || profile.hobbies?.includes(clean)) return;
    set('hobbies', [...(profile.hobbies || []), clean]);
    setHobbyInput('');
  }

  function removeHobby(name) {
    set('hobbies', profile.hobbies.filter((h) => h !== name));
  }

  async function handleSave() {
    setSaving(true);
    setError('');
    try {
      await api.updateMyProfile({
        nickname: profile.nickname,
        bio: profile.bio,
        lookingFor: profile.lookingFor,
        birthdate: profile.birthdate,
        displayColor: profile.displayColor,
        displayFont: profile.displayFont,
        country: profile.country,
        commitment: profile.commitment,
        diet: profile.diet,
        polyamory: profile.polyamory,
        pronouns: profile.pronouns,
        build: profile.build,
        heightCm: profile.heightCm,
        petsNote: profile.petsNote,
      });
      for (const { key } of MULTI_FIELDS) {
        await api.updateMultiField(key, profile[key] || []);
      }
      await api.updateHobbies(profile.hobbies || []);
      setSaved(true);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  if (!profile) {
    return (
      <div className="flex items-center justify-center h-screen" style={{ color: 'var(--color-text-secondary)' }}>
        {error || 'Loading your profile…'}
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col" style={{ background: 'var(--color-bg)' }}>
      <div
        className="flex items-center justify-between px-3 py-2 border-b shrink-0"
        style={{ borderColor: 'var(--color-border)', background: 'var(--color-bg-elevated)', paddingTop: 'calc(env(safe-area-inset-top) + 8px)' }}
      >
        <button onClick={onBack} className="flex items-center gap-1 text-[15px]" style={{ color: 'var(--theme-accent)' }}>
          <ChevronLeft size={20} /> Back
        </button>
        <h1 className="text-[17px] font-semibold">My Profile</h1>
        <button onClick={handleSave} disabled={saving} className="text-[15px] font-semibold" style={{ color: 'var(--theme-accent)' }}>
          {saving ? 'Saving…' : saved ? <Check size={18} /> : 'Save'}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4">
        {error && <p className="text-sm mb-4" style={{ color: '#ff375f' }}>{error}</p>}

        <Section title="Identity">
          <p className="text-xs mb-2" style={{ color: 'var(--color-text-secondary)' }}>
            Your handle (@{profile.handle}) is permanent — only your nickname can change.
          </p>
          <TextInput value={profile.nickname || ''} onChange={(e) => set('nickname', e.target.value)} placeholder="Nickname" />
        </Section>

        <Section title="Birthdate">
          <p className="text-xs mb-2" style={{ color: 'var(--color-text-secondary)' }}>
            Never shown publicly — others only see your zodiac sign and age.
          </p>
          <TextInput type="date" value={profile.birthdate || ''} onChange={(e) => set('birthdate', e.target.value)} />
        </Section>

        <Section title="Bio">
          <textarea
            value={profile.bio || ''}
            onChange={(e) => set('bio', e.target.value)}
            placeholder="Who are you?"
            rows={3}
            className="w-full rounded-xl px-4 py-3 text-[15px] outline-none resize-none"
            style={{ background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }}
          />
        </Section>

        <Section title="Looking for">
          <textarea
            value={profile.lookingFor || ''}
            onChange={(e) => set('lookingFor', e.target.value)}
            placeholder="Who are you hoping to meet?"
            rows={3}
            className="w-full rounded-xl px-4 py-3 text-[15px] outline-none resize-none"
            style={{ background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }}
          />
        </Section>

        <Section title="Hobbies">
          <div className="flex flex-wrap gap-2 mb-2">
            {(profile.hobbies || []).map((h) => (
              <Chip key={h} selected onClick={() => removeHobby(h)}>{h} ✕</Chip>
            ))}
          </div>
          <TextInput
            value={hobbyInput}
            onChange={(e) => setHobbyInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && addHobby(hobbyInput)}
            placeholder="Type a hobby and press Enter"
          />
          <div className="flex flex-wrap gap-2 mt-2">
            {hobbySuggestions
              .filter((h) => !profile.hobbies?.includes(h))
              .slice(0, 12)
              .map((h) => (
                <Chip key={h} selected={false} onClick={() => addHobby(h)}>+ {h}</Chip>
              ))}
          </div>
        </Section>

        {MULTI_FIELDS.map(({ key, label, options }) => (
          <Section title={label} key={key}>
            <div className="flex flex-wrap gap-2">
              {options.map((opt) => (
                <Chip key={opt.value} selected={profile[key]?.includes(opt.value)} onClick={() => toggleMulti(key, opt.value)}>
                  {opt.label}
                </Chip>
              ))}
            </div>
          </Section>
        ))}

        {SINGLE_FIELDS.map(({ key, label, options }) => (
          <Section title={label} key={key}>
            <div className="flex flex-wrap gap-2">
              {options.map((opt) => (
                <Chip key={opt.value} selected={profile[key] === opt.value} onClick={() => set(key, opt.value)}>
                  {opt.label}
                </Chip>
              ))}
            </div>
          </Section>
        ))}

        <Section title="Pets note">
          <TextInput
            value={profile.petsNote || ''}
            onChange={(e) => set('petsNote', e.target.value.slice(0, 100))}
            placeholder="e.g. have 2 cats, allergic to dogs (100 char max)"
          />
        </Section>

        <Section title="Pronouns">
          <TextInput
            value={profile.pronouns || ''}
            onChange={(e) => set('pronouns', e.target.value.slice(0, 15))}
            placeholder="e.g. she/her (15 char max)"
          />
        </Section>

        <Section title="Country">
          <TextInput value={profile.country || ''} onChange={(e) => set('country', e.target.value)} placeholder="Country" />
        </Section>

        <Section title="Height (cm)">
          <TextInput
            type="number"
            value={profile.heightCm || ''}
            onChange={(e) => set('heightCm', e.target.value ? Number(e.target.value) : null)}
            placeholder="e.g. 170"
          />
        </Section>

        <Section title="Profile appearance (shown to others viewing your profile)">
          <p className="text-xs mb-2" style={{ color: 'var(--color-text-secondary)' }}>
            Separate from your own app theme in Settings — this is what other people see when they open your profile.
          </p>
          <div className="flex flex-wrap gap-2 mb-3">
            {ACCENT_PRESETS.map((preset) => (
              <button
                key={preset.value}
                onClick={() => set('displayColor', preset.value)}
                className="h-8 w-8 rounded-full border-2"
                style={{ background: preset.value, borderColor: profile.displayColor === preset.value ? 'var(--color-text)' : 'transparent' }}
                aria-label={preset.label}
              />
            ))}
          </div>
          <select
            value={profile.displayFont || 'system'}
            onChange={(e) => set('displayFont', e.target.value)}
            className="w-full rounded-xl px-4 py-3 text-[15px] outline-none"
            style={{ background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }}
          >
            {Object.entries(FONT_OPTIONS).map(([key, { label }]) => (
              <option key={key} value={key}>{label}</option>
            ))}
          </select>
        </Section>
      </div>
    </div>
  );
}
