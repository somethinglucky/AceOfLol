import { useEffect, useState } from 'react';
import { api } from '../api/client';
import NameTag from '../components/NameTag';
import InvitationCard from '../components/InvitationCard';

function formatDate(iso) {
  try {
    return new Date(iso).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  } catch {
    return iso;
  }
}

// Global view of every game invite the person has sent or received,
// across every game — separate from GameInvitePanel.jsx (the per-game
// modal reached via a Lobby's Invite button, still used to CREATE a new
// invite for that specific game). This tab is purely for finding and
// acting on invites that already exist, from one place, instead of only
// being discoverable by happening to reopen the exact game's lobby.
export default function InvitesTab({ currentUserId, onOpenGame }) {
  const [invites, setInvites] = useState(null);
  const [error, setError] = useState('');

  function load() {
    api.getMyGameInvites().then((data) => setInvites(data.invites)).catch(() => setError("Couldn't load invites."));
  }
  useEffect(load, []);

  async function handleRespond(invite, chosenDate) {
    setError('');
    try {
      const { sessionId } = await api.respondToGameInvite(invite.id, chosenDate);
      onOpenGame({ gameId: invite.gameId, sessionId });
    } catch (err) {
      setError(err.message || "Couldn't confirm that invite.");
      load();
    }
  }

  async function handleCancel(invite) {
    setError('');
    try {
      await api.cancelGameInvite(invite.id);
      load();
    } catch (err) {
      setError(err.message || "Couldn't cancel that invite.");
    }
  }

  if (!invites) return <div className="flex-1" />;

  const received = invites.filter((i) => i.inviteeId === currentUserId);
  const sent = invites.filter((i) => i.inviterId === currentUserId);

  if (received.length === 0 && sent.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center px-6 text-center">
        <p style={{ color: 'var(--color-text-secondary)' }}>
          No game invites yet — invite someone from a game's lobby to get started.
        </p>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-5">
      {error && <p className="text-[13px]" style={{ color: '#ff375f' }}>{error}</p>}

      {received.length > 0 && (
        <div className="flex flex-col gap-2">
          <p className="text-[13px] font-semibold" style={{ color: 'var(--color-text-secondary)' }}>Invites for you</p>
          {received.map((invite) => (
            <div key={invite.id} className="rounded-xl p-3 flex gap-3" style={{ background: 'var(--color-bg-elevated)', border: '1px solid var(--color-border)' }}>
              <InvitationCard templateId={invite.templateId} size="sm" />
              <div className="flex-1 min-w-0 flex flex-col gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-[20px]">{invite.gameIcon}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-[14px] font-semibold">{invite.gameName}</p>
                    {invite.inviter && (
                      <NameTag nickname={invite.inviter.nickname} handle={invite.inviter.handle} userId={invite.inviter.id} size="sm" />
                    )}
                  </div>
                  <span className="text-[12px] shrink-0" style={{ color: 'var(--color-text-secondary)' }}>{invite.status}</span>
                </div>
                {invite.status === 'pending' && (
                  <div className="flex flex-wrap gap-2">
                    {invite.proposedDates.map((d) => (
                      <button
                        key={d}
                        onClick={() => handleRespond(invite, d)}
                        className="text-[12px] px-2 py-1 rounded-full text-white"
                        style={{ background: 'var(--theme-accent)' }}
                      >
                        {formatDate(d)}
                      </button>
                    ))}
                  </div>
                )}
                {invite.status === 'confirmed' && invite.sessionId && (
                  <button
                    onClick={() => onOpenGame({ gameId: invite.gameId, sessionId: invite.sessionId })}
                    className="self-start text-[13px] font-semibold"
                    style={{ color: 'var(--theme-accent)' }}
                  >
                    Open game →
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {sent.length > 0 && (
        <div className="flex flex-col gap-2">
          <p className="text-[13px] font-semibold" style={{ color: 'var(--color-text-secondary)' }}>Your sent invites</p>
          {sent.map((invite) => (
            <div key={invite.id} className="rounded-xl p-3 flex gap-3" style={{ background: 'var(--color-bg-elevated)', border: '1px solid var(--color-border)' }}>
              <InvitationCard templateId={invite.templateId} size="sm" />
              <div className="flex-1 min-w-0 flex flex-col gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-[20px]">{invite.gameIcon}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-[14px] font-semibold">{invite.gameName}</p>
                    {invite.invitee ? (
                      <NameTag nickname={invite.invitee.nickname} handle={invite.invitee.handle} userId={invite.invitee.id} size="sm" />
                    ) : (
                      <p className="text-[12px]" style={{ color: 'var(--color-text-secondary)' }}>{invite.inviteeEmail}</p>
                    )}
                  </div>
                  <span className="text-[12px] shrink-0" style={{ color: 'var(--color-text-secondary)' }}>
                    {invite.status}{invite.gemCost > 0 ? ` · ${invite.gemCost}♦` : ''}
                  </span>
                </div>
                <div className="flex gap-3">
                  {invite.status === 'pending' && (
                    <button onClick={() => handleCancel(invite)} className="text-[13px]" style={{ color: '#ff375f' }}>Cancel</button>
                  )}
                  {invite.status === 'confirmed' && invite.sessionId && (
                    <button
                      onClick={() => onOpenGame({ gameId: invite.gameId, sessionId: invite.sessionId })}
                      className="text-[13px] font-semibold"
                      style={{ color: 'var(--theme-accent)' }}
                    >
                      Open game →
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
