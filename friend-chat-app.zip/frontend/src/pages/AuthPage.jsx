import { useState } from 'react';
import { X } from 'lucide-react';
import { api } from '../api/client';

// isGuestUpgrade: true when the visitor already has a guest identity
// (they've chatted anonymously). It only changes the DEFAULT starting
// mode and what submitting 'register' does (adds credentials to this
// guest's existing identity via /auth/register, rather than creating a
// brand new one via /auth/signup) — it does NOT lock out login, since a
// guest might actually want to log into a different, separate account
// they made earlier rather than upgrade this one.
export default function AuthPage({ isGuestUpgrade, onAuthed, onClose }) {
  const [mode, setMode] = useState(isGuestUpgrade ? 'register' : 'login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [nickname, setNickname] = useState('');
  const [error, setError] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    try {
      let data;
      if (mode === 'login') {
        data = await api.login(email, password);
      } else if (isGuestUpgrade) {
        data = await api.register(email, password, nickname);
      } else {
        data = await api.signup(email, password, nickname);
      }
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      onAuthed(data.user);
    } catch (err) {
      setError(err.message);
    }
  }

  const isUpgradeRegister = isGuestUpgrade && mode === 'register';

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col justify-center px-6"
      style={{ background: 'var(--color-bg)' }}
    >
      <button
        onClick={onClose}
        className="absolute top-3 right-3 h-8 w-8 rounded-full flex items-center justify-center"
        style={{ background: 'var(--color-bubble-received)', top: 'calc(env(safe-area-inset-top) + 12px)' }}
        aria-label="Close"
      >
        <X size={18} color="var(--color-text-secondary)" />
      </button>

      <h1 className="text-2xl font-semibold mb-2 text-center">
        {mode === 'login' ? 'Welcome back' : isUpgradeRegister ? 'Save your spot' : 'Create your account'}
      </h1>
      {isUpgradeRegister && (
        <p className="text-sm text-center mb-6" style={{ color: 'var(--color-text-secondary)' }}>
          Your messages and handle stay exactly as they are — this just adds a password so you can log back in.
        </p>
      )}

      <form onSubmit={handleSubmit} className="flex flex-col gap-3">
        {mode !== 'login' && (
          <input
            value={nickname}
            onChange={(e) => setNickname(e.target.value)}
            placeholder="Nickname"
            className="rounded-xl px-4 py-3 text-[15px] outline-none"
            style={{ background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }}
          />
        )}
        <input
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Email"
          type="email"
          className="rounded-xl px-4 py-3 text-[15px] outline-none"
          style={{ background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }}
        />
        <input
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          type="password"
          className="rounded-xl px-4 py-3 text-[15px] outline-none"
          style={{ background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }}
        />

        {error && <p className="text-sm text-red-500">{error}</p>}

        <button
          type="submit"
          className="rounded-xl px-4 py-3 text-[15px] font-semibold text-white mt-2"
          style={{ background: 'var(--theme-accent)' }}
        >
          {mode === 'login' ? 'Log In' : isUpgradeRegister ? 'Complete Registration' : 'Sign Up'}
        </button>
      </form>

      {/* Always available now — a guest can still choose to log into a
          different, already-existing account instead of upgrading this
          guest identity. */}
      <button
        onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
        className="text-sm mt-4 text-center"
        style={{ color: 'var(--theme-accent)' }}
      >
        {mode === 'login' ? "Don't have an account? Sign up" : 'Already have an account? Log in'}
      </button>
    </div>
  );
}
