import { useState } from 'react';
import { api } from '../api/client';

export default function AuthPage({ onAuthed }) {
  const [mode, setMode] = useState('login'); // 'login' | 'signup'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [nickname, setNickname] = useState('');
  const [error, setError] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    try {
      const data =
        mode === 'login'
          ? await api.login(email, password)
          : await api.signup(email, password, nickname);
      localStorage.setItem('token', data.token);
      onAuthed(data.user);
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div
      className="flex flex-col justify-center h-screen px-6"
      style={{ background: 'var(--color-bg)' }}
    >
      <h1 className="text-2xl font-semibold mb-6 text-center">
        {mode === 'login' ? 'Welcome back' : 'Create your account'}
      </h1>

      <form onSubmit={handleSubmit} className="flex flex-col gap-3">
        {mode === 'signup' && (
          <input
            value={nickname}
            onChange={(e) => setNickname(e.target.value)}
            placeholder="Nickname"
            className="rounded-xl px-4 py-3 text-[15px] outline-none"
            style={{ background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }}
          />
        )}
        <input
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Email"
          type="email"
          className="rounded-xl px-4 py-3 text-[15px] outline-none"
          style={{ background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }}
        />
        <input
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          type="password"
          className="rounded-xl px-4 py-3 text-[15px] outline-none"
          style={{ background: 'var(--color-bg-elevated)', color: 'var(--color-text)' }}
        />

        {error && <p className="text-sm text-red-500">{error}</p>}

        <button
          type="submit"
          className="rounded-xl px-4 py-3 text-[15px] font-semibold text-white mt-2"
          style={{ background: 'var(--theme-accent)' }}
        >
          {mode === 'login' ? 'Log In' : 'Sign Up'}
        </button>
      </form>

      <button
        onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}
        className="text-sm mt-4 text-center"
        style={{ color: 'var(--theme-accent)' }}
      >
        {mode === 'login' ? "Don't have an account? Sign up" : 'Already have an account? Log in'}
      </button>
    </div>
  );
}
