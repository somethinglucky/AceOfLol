import { useEffect, useRef, useState } from 'react';
import { Send } from 'lucide-react';
import { connectSocket, authenticateSocket } from '../api/socket';
import { api } from '../api/client';
import MessageBubble from '../components/MessageBubble';

// onJoined(user) fires the instant a visitor becomes a guest (first Send) —
// App.jsx uses this to switch into the full ChatPage.
export default function LandingPage({ siteName, onJoined }) {
  const [messages, setMessages] = useState([]);
  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);
  const scrollRef = useRef(null);

  // Anyone can watch #everyone with zero identity — this join_room call
  // works even before any guest account exists, since the backend allows
  // unauthenticated viewers into rooms that don't require registration.
  useEffect(() => {
    const socket = connectSocket();
    socket.emit('join_room', 'everyone');

    const handleNewMessage = (msg) => {
      if (msg.room_id === 'everyone') setMessages((prev) => [...prev, msg]);
    };
    socket.on('new_message', handleNewMessage);

    return () => socket.off('new_message', handleNewMessage);
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ block: 'end' });
  }, [messages]);

  async function handleSend() {
    if (!draft.trim() || sending) return;
    setSending(true);

    try {
      let token = localStorage.getItem('token');

      // First message ever from this browser — mint a guest identity and
      // authenticate the socket with it before we're allowed to send.
      if (!token) {
        const { token: newToken, user } = await api.guestSignup();
        localStorage.setItem('token', newToken);
        localStorage.setItem('user', JSON.stringify(user));
        token = newToken;
        await authenticateSocket(token);
        onJoined(user);
      }

      connectSocket().emit('send_message', { roomId: 'everyone', content: draft.trim() });
      setDraft('');
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="min-h-screen" style={{ background: 'var(--color-bg)' }}>
      {/* Hero / intro section — this is the hook, shown before any chat is visible */}
      <div className="flex flex-col items-center justify-center text-center px-6 py-20 min-h-[70vh]">
        <h1 className="text-3xl font-bold mb-3">{siteName}</h1>
        <p className="text-[17px] mb-8 max-w-xs" style={{ color: 'var(--color-text-secondary)' }}>
          Real conversations with real people, nearby and around the world. No profile required to say hello.
        </p>
        <div className="animate-bounce text-sm" style={{ color: 'var(--color-text-secondary)' }}>
          ↓ Scroll to see who's chatting right now
        </div>
      </div>

      {/* Live preview of #everyone — viewable by anyone, postable by anyone,
          and posting is what silently creates a guest identity. */}
      <div className="flex flex-col h-[80vh] border-t" style={{ borderColor: 'var(--color-border)' }}>
        <div className="px-3 py-2 text-[13px] font-medium text-center" style={{ color: 'var(--color-text-secondary)' }}>
          #everyone — live
        </div>

        <div className="flex-1 overflow-y-auto">
          {messages.map((msg) => (
            <MessageBubble key={msg.id} message={msg} currentUserId={null} onAvatarTap={() => {}} />
          ))}
          <div ref={scrollRef} />
        </div>

        <div
          className="flex items-center gap-2 px-3 py-2 border-t"
          style={{
            borderColor: 'var(--color-border)',
            background: 'var(--color-bg-elevated)',
            paddingBottom: 'calc(env(safe-area-inset-bottom) + 8px)',
          }}
        >
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Say hello — no signup needed"
            className="flex-1 rounded-full px-4 py-2 text-[15px] outline-none"
            style={{ background: 'var(--color-bubble-received)', color: 'var(--color-text)' }}
          />
          <button
            onClick={handleSend}
            disabled={!draft.trim() || sending}
            className="h-9 w-9 rounded-full flex items-center justify-center shrink-0 disabled:opacity-40"
            style={{ background: 'var(--theme-accent)' }}
            aria-label="Send message"
          >
            <Send size={16} color="#ffffff" />
          </button>
        </div>
      </div>
    </div>
  );
}
