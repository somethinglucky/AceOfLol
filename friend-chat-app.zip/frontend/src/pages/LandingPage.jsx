import { useEffect, useRef, useState } from 'react';
import { Send } from 'lucide-react';
import { connectSocket, authenticateSocket } from '../api/socket';
import { api } from '../api/client';
import MessageBubble from '../components/MessageBubble';
import TopBar from '../components/TopBar';
import MenuDrawer from '../components/MenuDrawer';

function mergeMessages(existing, incoming) {
  const byId = new Map(incoming.map((m) => [m.id, m]));
  existing.forEach((m) => {
    if (!byId.has(m.id)) byId.set(m.id, m);
  });
  return Array.from(byId.values()).sort((a, b) => a.created_at.localeCompare(b.created_at));
}

const ROOM_ID = 'everyone';

// onJoined(user) fires once a visitor becomes a guest AND their first
// message is confirmed sent — App.jsx uses this to switch into the full
// ChatPage. onAuthClick opens the shared login/signup overlay.
export default function LandingPage({ siteName, onJoined, onAuthClick }) {
  const [messages, setMessages] = useState([]);
  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    const socket = connectSocket();
    socket.emit('join_room', ROOM_ID);

    const handleNewMessage = (msg) => {
      if (msg.room_id === ROOM_ID) setMessages((prev) => [...prev, msg]);
    };
    const handleHistory = ({ roomId, messages: history }) => {
      if (roomId === ROOM_ID) setMessages((prev) => mergeMessages(prev, history));
    };

    socket.on('new_message', handleNewMessage);
    socket.on('room_history', handleHistory);

    return () => {
      socket.off('new_message', handleNewMessage);
      socket.off('room_history', handleHistory);
    };
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ block: 'end' });
  }, [messages]);

  async function handleSend() {
    if (!draft.trim() || sending) return;
    setSending(true);
    setSendError('');

    try {
      let token = localStorage.getItem('token');
      let newGuest = null;

      if (!token) {
        const { token: newToken, user } = await api.guestSignup();
        localStorage.setItem('token', newToken);
        localStorage.setItem('user', JSON.stringify(user));
        token = newToken;
        await authenticateSocket(token);
        newGuest = user;
      }

      // Send — and only THEN transition pages, so the message is confirmed
      // on the wire before anything unmounts this component. This also
      // means it shows up right here in the preview first, instantly.
      connectSocket().emit('send_message', { roomId: ROOM_ID, content: draft.trim() });
      setDraft('');

      if (newGuest) onJoined(newGuest);
    } catch (err) {
      setSendError(err.message || 'Something went wrong sending that — please try again.');
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'var(--color-bg)' }}>
      <TopBar siteName={siteName} user={null} onAuthClick={onAuthClick} onMenuClick={() => setMenuOpen(true)} />

      {/* Hero / intro section — the hook, shown before any chat is visible */}
      <div className="flex flex-col items-center justify-center text-center px-6 py-20 min-h-[60vh]">
        <h1 className="text-3xl font-bold mb-3">{siteName}</h1>
        <p className="text-[17px] mb-8 max-w-xs" style={{ color: 'var(--color-text-secondary)' }}>
          Real conversations with real people, nearby and around the world. No profile required to say hello.
        </p>
        <div className="animate-bounce text-sm" style={{ color: 'var(--color-text-secondary)' }}>
          ↓ Scroll to see who's chatting right now
        </div>
      </div>

      {/* Live preview of #everyone — viewable by anyone, postable by anyone,
          and posting is what silently creates a guest identity. */}
      <div className="flex flex-col flex-1 min-h-[70vh] border-t" style={{ borderColor: 'var(--color-border)' }}>
        <div className="px-3 py-2 text-[13px] font-medium text-center" style={{ color: 'var(--color-text-secondary)' }}>
          #everyone — live
        </div>

        <div className="flex-1 overflow-y-auto">
          {messages.map((msg) => (
            <MessageBubble key={msg.id} message={msg} currentUserId={null} onAvatarTap={() => {}} />
          ))}
          <div ref={scrollRef} />
        </div>

        {sendError && (
          <p className="text-xs text-center px-3 pb-1" style={{ color: '#ff375f' }}>
            {sendError}
          </p>
        )}

        <div
          className="flex items-center gap-2 px-3 py-2 border-t"
          style={{
            borderColor: 'var(--color-border)',
            background: 'var(--color-bg-elevated)',
            paddingBottom: 'calc(env(safe-area-inset-bottom) + 8px)',
          }}
        >
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Say hello — no signup needed"
            className="flex-1 rounded-full px-4 py-2 text-[15px] outline-none"
            style={{ background: 'var(--color-bubble-received)', color: 'var(--color-text)' }}
          />
          <button
            onClick={handleSend}
            disabled={!draft.trim() || sending}
            className="h-9 w-9 rounded-full flex items-center justify-center shrink-0 disabled:opacity-40"
            style={{ background: 'var(--theme-accent)' }}
            aria-label="Send message"
          >
            <Send size={16} color="#ffffff" />
          </button>
        </div>
      </div>

      <MenuDrawer open={menuOpen} onClose={() => setMenuOpen(false)} onNavigate={() => {}} />
    </div>
  );
}
