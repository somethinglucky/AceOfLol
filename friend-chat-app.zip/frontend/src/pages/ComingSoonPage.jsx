import { useState } from 'react';
import { Hammer } from 'lucide-react';
import TopBar from '../components/TopBar';
import MenuDrawer from '../components/MenuDrawer';

const LABELS = {
  dms: "DM's & Likes",
  store: 'Store',
  premium: 'Premium',
  discover: 'Discover',
  games: 'Games',
  about: 'About',
  review: 'Review',
};

// page: one of the LABELS keys above. Anything not in that list falls back
// to a title-cased version of the key itself, so a stray/unexpected page
// value still gets a real screen instead of breaking.
export default function ComingSoonPage({ page, siteName, user, isAdmin, isModerator, onNavigate, onAuthClick, onLogout }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const label = LABELS[page] || (page.charAt(0).toUpperCase() + page.slice(1));

  return (
    <div className="h-screen flex flex-col" style={{ background: 'var(--color-bg)' }}>
      <TopBar siteName={siteName} user={user} onAuthClick={onAuthClick} onMenuClick={() => setMenuOpen(true)} onLogout={onLogout} />

      <div className="flex-1 flex flex-col items-center justify-center gap-3 px-6 text-center">
        <Hammer size={32} color="var(--color-text-secondary)" />
        <p className="text-[17px] font-semibold">{label}</p>
        <p className="text-[14px]" style={{ color: 'var(--color-text-secondary)' }}>
          This one's still being built — check back soon.
        </p>
        <button onClick={() => onNavigate('chat')} className="text-[15px] font-medium mt-2" style={{ color: 'var(--theme-accent)' }}>
          Back to Chat
        </button>
      </div>

      <MenuDrawer open={menuOpen} onClose={() => setMenuOpen(false)} onNavigate={onNavigate} isAdmin={isAdmin} isModerator={isModerator} />
    </div>
  );
}
