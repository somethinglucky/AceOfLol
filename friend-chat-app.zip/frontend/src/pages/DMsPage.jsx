import { useEffect, useRef, useState } from 'react';
import { ChevronLeft, MoreVertical, EyeOff, Flag, Trash2, Send } from 'lucide-react';
import { api } from '../api/client';
import { connectSocket, joinDmThread, leaveDmThread } from '../api/socket';
import TopBar from '../components/TopBar';
import MenuDrawer from '../components/MenuDrawer';
import NameTag from '../components/NameTag';
import InvitationCard from '../components/InvitationCard';
import InvitesTab from './InvitesTab';
import { colorFromString } from '../utils/colorHash';

function timeAgo(iso) {
  const diff = (Date.now() - new Date(iso.replace(' ', 'T') + 'Z').getTime()) / 1000;
  if (diff < 60) return 'now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h`;
  return `${Math.floor(diff / 86400)}d`;
}

function mergeMessages(existing, incoming) {
  const byId = new Map(existing.map((m) => [m.id, m]));
  incoming.forEach((m) => byId.set(m.id, m));
  return Array.from(byId.values()).sort((a, b) => a.created_at.localeCompare(b.created_at));
}

// -------------------- Inbox list --------------------

function Inbox({ threads, loading, error, onOpenThread }) {
  if (loading) return <p className="p-4 text-[14px]" style={{ color: 'var(--color-text-secondary)' }}>Loading…</p>;
  if (error) return <p className="p-4 text-[14px]" style={{ color: '#ff375f' }}>{error}</p>;
  if (threads.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center px-6 text-center">
        <p style={{ color: 'var(--color-text-secondary)' }}>
          No conversations yet — message someone from their profile to start one.
        </p>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto">
      {threads.map((t) => (
        <div
          key={t.threadId}
          role="button"
          tabIndex={0}
          onClick={() => onOpenThread(t.otherUser)}
          onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') onOpenThread(t.otherUser); }}
          className="w-full flex items-center gap-3 px-4 py-3 border-b text-left cursor-pointer"
          style={{ borderColor: 'var(--color-separator)' }}
        >
          {t.otherUser.avatarUrl ? (
            <img src={t.otherUser.avatarUrl} alt="" className="h-12 w-12 rounded-full object-cover shrink-0" />
          ) : (
            <div
              className="h-12 w-12 rounded-full shrink-0 flex items-center justify-center text-white font-semibold"
              style={{ background: colorFromString(t.otherUser.handle) }}
            >
              {(t.otherUser.nickname || t.otherUser.handle)[0].toUpperCase()}
            </div>
          )}
          <div className="flex-1 min-w-0">
            <NameTag nickname={t.otherUser.nickname} handle={t.otherUser.handle} isRegistered={t.otherUser.isRegistered} userId={t.otherUser.id} sender={t.otherUser} size="sm" />
            <p className="text-[13px] truncate mt-0.5" style={{ color: t.unreadCount > 0 ? 'var(--color-text)' : 'var(--color-text-secondary)' }}>
              {t.lastMessagePreview}
            </p>
          </div>
          <div className="flex flex-col items-end gap-1 shrink-0">
            <span className="text-[12px]" style={{ color: 'var(--color-text-secondary)' }}>{timeAgo(t.lastMessageAt)}</span>
            {t.unreadCount > 0 && (
              <span
                className="h-5 min-w-5 px-1 rounded-full text-[11px] font-semibold text-white flex items-center justify-center"
                style={{ background: 'var(--theme-accent)' }}
              >
                {t.unreadCount}
              </span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

// -------------------- Conversation view --------------------

function Conversation({ otherUser, currentUserId, onBack, onThreadGone, onOpenGame }) {
  const [messages, setMessages] = useState([]);
  const [threadId, setThreadId] = useState(null);
  const [draft, setDraft] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);
  const [error, setError] = useState('');
  const scrollRef = useRef(null);

  useEffect(() => {
    const socket = connectSocket();
    joinDmThread(otherUser.id);

    api.getDmHistory(otherUser.id).then((data) => {
      if (data.thread) setThreadId(data.thread.id);
      setMessages((prev) => mergeMessages(prev, data.messages));
    }).catch(() => {});

    const handleHistory = (data) => {
      if (data.otherUserId !== otherUser.id) return;
      if (data.thread) setThreadId(data.thread.id);
      setMessages((prev) => mergeMessages(prev, data.messages));
    };
    const handleNewMessage = ({ threadId: tid, message }) => {
      setThreadId(tid);
      setMessages((prev) => mergeMessages(prev, [message]));
    };
    const handleError = (msg) => setError(msg);

    socket.on('dm_thread_history', handleHistory);
    socket.on('new_dm_message', handleNewMessage);
    socket.on('dm_error', handleError);

    return () => {
      leaveDmThread(otherUser.id);
      socket.off('dm_thread_history', handleHistory);
      socket.off('new_dm_message', handleNewMessage);
      socket.off('dm_error', handleError);
    };
  }, [otherUser.id]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ block: 'end' });
  }, [messages]);

  function handleSend() {
    if (!draft.trim()) return;
    connectSocket().emit('send_dm_message', { otherUserId: otherUser.id, body: draft.trim() });
    setDraft('');
  }

  async function handleHide() {
    setMenuOpen(false);
    if (!threadId) return;
    await api.hideDmThread(threadId);
    onThreadGone();
  }

  async function handleDelete() {
    setMenuOpen(false);
    if (!threadId) return;
    if (!window.confirm('Delete this conversation? It\u2019ll come back if they message you again.')) return;
    await api.clearDmThread(threadId);
    onThreadGone();
  }

  async function handleReport() {
    setMenuOpen(false);
    if (!threadId) return;
    const reason = window.prompt('What\u2019s wrong with this conversation? (optional)') || undefined;
    await api.reportDmThread(threadId, reason);
  }

  return (
    <div className="flex flex-col h-full">
      <div
        className="flex items-center gap-2 px-3 py-2 border-b shrink-0"
        style={{ borderColor: 'var(--color-border)', background: 'var(--color-bg-elevated)' }}
      >
        <button onClick={onBack} className="h-8 w-8 flex items-center justify-center -ml-1" aria-label="Back">
          <ChevronLeft size={22} color="var(--theme-accent)" />
        </button>
        <NameTag nickname={otherUser.nickname} handle={otherUser.handle} isRegistered={otherUser.isRegistered} userId={otherUser.id} size="sm" className="flex-1 min-w-0" />
        <div className="relative">
          <button onClick={() => setMenuOpen((v) => !v)} className="h-8 w-8 flex items-center justify-center" aria-label="Conversation options">
            <MoreVertical size={20} color="var(--color-text-secondary)" />
          </button>
          {menuOpen && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setMenuOpen(false)} />
              <div
                className="absolute right-0 top-9 z-20 rounded-xl overflow-hidden shadow-lg w-44"
                style={{ background: 'var(--color-bg-elevated)' }}
              >
                <button onClick={handleHide} className="w-full flex items-center gap-2 px-3 py-2.5 text-[14px]" style={{ color: 'var(--color-text)' }}>
                  <EyeOff size={15} /> Hide
                </button>
                <button onClick={handleReport} className="w-full flex items-center gap-2 px-3 py-2.5 text-[14px]" style={{ color: 'var(--color-text)' }}>
                  <Flag size={15} /> Report
                </button>
                <button onClick={handleDelete} className="w-full flex items-center gap-2 px-3 py-2.5 text-[14px]" style={{ color: '#ff375f' }}>
                  <Trash2 size={15} /> Delete
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto py-2 px-3">
        {messages.map((m) => {
          const isMine = m.sender_id === currentUserId;
          // A system-generated game-invite notification (see
          // services/dmMessages.js) is deliberately NOT styled like an
          // ordinary bubble — sj wants it to feel like finding a card in
          // a bouquet, not just another text. So instead of the usual
          // left/right bubble alignment, it's centered in the flow, uses
          // the actual InvitationCard design the inviter picked, and
          // reads as an object you'd receive, not a sentence someone
          // typed. Tapping it jumps straight into that game.
          if (m.kind === 'game_invite' && m.metadataJson) {
            let meta;
            try {
              meta = JSON.parse(m.metadataJson);
            } catch {
              meta = null;
            }
            return (
              <div key={m.id} className="flex flex-col items-center my-3">
                <p className="text-[11px] uppercase tracking-wide mb-1.5" style={{ color: 'var(--color-text-secondary)' }}>
                  {isMine ? 'Invitation sent' : '✉ You have an invitation'}
                </p>
                <button onClick={() => meta && onOpenGame({ gameId: meta.gameId, sessionId: meta.sessionId, inviteId: meta.inviteId })} className="active:scale-[0.98] transition-transform">
                  <InvitationCard templateId={meta?.templateId} size="md" title={m.body} />
                </button>
              </div>
            );
          }
          return (
            <div key={m.id} className={`flex mb-1.5 ${isMine ? 'justify-end' : 'justify-start'}`}>
              <div
                className="max-w-[75%] px-3 py-2 rounded-2xl text-[15px]"
                style={
                  isMine
                    ? { background: 'var(--theme-accent)', color: '#fff' }
                    : { background: 'var(--color-bubble-received)', color: 'var(--color-text)' }
                }
              >
                {m.body}
              </div>
            </div>
          );
        })}
        <div ref={scrollRef} />
      </div>

      {error && <p className="px-3 text-[13px]" style={{ color: '#ff375f' }}>{error}</p>}

      <div
        className="flex items-center gap-2 px-3 py-2 border-t"
        style={{
          borderColor: 'var(--color-border)',
          background: 'var(--color-bg-elevated)',
          paddingBottom: 'calc(env(safe-area-inset-bottom) + 8px)',
        }}
      >
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Message"
          className="flex-1 rounded-full px-4 py-2 text-[15px] outline-none"
          style={{ background: 'var(--color-bg)', color: 'var(--color-text)' }}
        />
        <button
          onClick={handleSend}
          disabled={!draft.trim()}
          className="h-9 w-9 rounded-full flex items-center justify-center shrink-0 disabled:opacity-40"
          style={{ background: 'var(--theme-accent)' }}
          aria-label="Send message"
        >
          <Send size={16} color="#ffffff" />
        </button>
      </div>
    </div>
  );
}

// -------------------- Page --------------------

// initialOtherUser: set when arriving here via ProfileCard's Message
// button, to jump straight into that conversation instead of the inbox.
export default function DMsPage({ siteName, user, isAdmin, isModerator, unreadCount, initialOtherUser, onConsumeInitialTarget, onBack, onNavigate, onAuthClick, onLogout, onViewProfile, onOpenGame }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('dms'); // 'dms' | 'friends' | 'invites'
  const [threads, setThreads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [openUser, setOpenUser] = useState(null); // the other person's { id, nickname, handle, ... } | null

  function loadInbox() {
    setLoading(true);
    api.getDmInbox()
      .then((data) => setThreads(data.threads))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    if (!user?.isRegistered) return;
    loadInbox();
  }, [user?.isRegistered]);

  useEffect(() => {
    if (initialOtherUser) {
      setOpenUser(initialOtherUser);
      onConsumeInitialTarget();
    }
  }, [initialOtherUser]);

  if (!user?.isRegistered) {
    return (
      <div className="h-screen flex flex-col" style={{ background: 'var(--color-bg)' }}>
        <TopBar siteName={siteName} user={user} unreadCount={unreadCount} onBack={onBack} onAuthClick={onAuthClick} onMenuClick={() => setMenuOpen(true)} onLogout={onLogout} />
        <div className="flex-1 flex flex-col items-center justify-center gap-3 px-6 text-center">
          <p style={{ color: 'var(--color-text-secondary)' }}>Sign up to send and receive direct messages.</p>
          <button onClick={onAuthClick} className="px-4 py-2 rounded-full text-[15px] font-semibold text-white" style={{ background: 'var(--theme-accent)' }}>
            Sign Up/In
          </button>
        </div>
        <MenuDrawer open={menuOpen} onClose={() => setMenuOpen(false)} onNavigate={onNavigate} isAdmin={isAdmin} isModerator={isModerator} unreadCount={unreadCount} />
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col" style={{ background: 'var(--color-bg)' }}>
      {!openUser && (
        <>
          <TopBar siteName={siteName} user={user} unreadCount={unreadCount} onBack={onBack} onAuthClick={onAuthClick} onMenuClick={() => setMenuOpen(true)} onLogout={onLogout} />
          <TabBar activeTab={activeTab} onChange={setActiveTab} />
          {activeTab === 'dms' && <Inbox threads={threads} loading={loading} error={error} onOpenThread={setOpenUser} />}
          {activeTab === 'invites' && <InvitesTab currentUserId={user.id} onOpenGame={onOpenGame} />}
          {activeTab === 'friends' && <FriendsPlaceholder />}
        </>
      )}

      {openUser && (
        <Conversation
          otherUser={openUser}
          currentUserId={user.id}
          onBack={() => { setOpenUser(null); loadInbox(); }}
          onThreadGone={() => { setOpenUser(null); loadInbox(); }}
          onOpenGame={onOpenGame}
        />
      )}

      <MenuDrawer open={menuOpen} onClose={() => setMenuOpen(false)} onNavigate={onNavigate} isAdmin={isAdmin} isModerator={isModerator} unreadCount={unreadCount} />
    </div>
  );
}

function TabBar({ activeTab, onChange }) {
  const tabs = [
    { key: 'dms', label: 'DMs' },
    { key: 'friends', label: 'Friends' },
    { key: 'invites', label: 'Invites' },
  ];
  return (
    <div className="flex border-b shrink-0" style={{ borderColor: 'var(--color-border)', background: 'var(--color-bg-elevated)' }}>
      {tabs.map((t) => (
        <button
          key={t.key}
          onClick={() => onChange(t.key)}
          className="flex-1 py-2.5 text-[14px] font-semibold text-center border-b-2"
          style={{
            color: activeTab === t.key ? 'var(--theme-accent)' : 'var(--color-text-secondary)',
            borderColor: activeTab === t.key ? 'var(--theme-accent)' : 'transparent',
          }}
        >
          {t.label}
        </button>
      ))}
    </div>
  );
}

// The follow/bookmark system itself (the ♥ button on a profile, who
// you've followed) isn't built yet — this is a placeholder so the tab
// exists and is honest about its state, rather than pretending the
// feature is further along than it is. A clean, scoped follow-up: a
// `follows` table, a heart toggle on ProfileCard, and this tab reading
// from it — deliberately not rushed into the same pass as everything
// else here.
function FriendsPlaceholder() {
  return (
    <div className="flex-1 flex items-center justify-center px-6 text-center">
      <p style={{ color: 'var(--color-text-secondary)' }}>
        Friends (people you've ♥) is coming soon.
      </p>
    </div>
  );
}
