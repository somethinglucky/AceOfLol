import { useEffect, useRef, useState } from 'react';
import { ChevronLeft, MoreVertical, EyeOff, Flag, Trash2, Send } from 'lucide-react';
import { api } from '../api/client';
import { connectSocket, joinDmThread, leaveDmThread } from '../api/socket';
import TopBar from '../components/TopBar';
import MenuDrawer from '../components/MenuDrawer';
import NameTag from '../components/NameTag';
import { colorFromString } from '../utils/colorHash';

function timeAgo(iso) {
  const diff = (Date.now() - new Date(iso.replace(' ', 'T') + 'Z').getTime()) / 1000;
  if (diff < 60) return 'now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h`;
  return `${Math.floor(diff / 86400)}d`;
}

function mergeMessages(existing, incoming) {
  const byId = new Map(existing.map((m) => [m.id, m]));
  incoming.forEach((m) => byId.set(m.id, m));
  return Array.from(byId.values()).sort((a, b) => a.created_at.localeCompare(b.created_at));
}

// -------------------- Inbox list --------------------

function Inbox({ threads, loading, error, onOpenThread }) {
  if (loading) return <p className="p-4 text-[14px]" style={{ color: 'var(--color-text-secondary)' }}>Loading…</p>;
  if (error) return <p className="p-4 text-[14px]" style={{ color: '#ff375f' }}>{error}</p>;
  if (threads.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center px-6 text-center">
        <p style={{ color: 'var(--color-text-secondary)' }}>
          No conversations yet — message someone from their profile to start one.
        </p>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto">
      {threads.map((t) => (
        <button
          key={t.threadId}
          onClick={() => onOpenThread(t.otherUser)}
          className="w-full flex items-center gap-3 px-4 py-3 border-b text-left"
          style={{ borderColor: 'var(--color-separator)' }}
        >
          {t.otherUser.avatarUrl ? (
            <img src={t.otherUser.avatarUrl} alt="" className="h-12 w-12 rounded-full object-cover shrink-0" />
          ) : (
            <div
              className="h-12 w-12 rounded-full shrink-0 flex items-center justify-center text-white font-semibold"
              style={{ background: colorFromString(t.otherUser.handle) }}
            >
              {(t.otherUser.nickname || t.otherUser.handle)[0].toUpperCase()}
            </div>
          )}
          <div className="flex-1 min-w-0">
            <NameTag nickname={t.otherUser.nickname} handle={t.otherUser.handle} isRegistered={t.otherUser.isRegistered} size="sm" />
            <p className="text-[13px] truncate mt-0.5" style={{ color: t.unreadCount > 0 ? 'var(--color-text)' : 'var(--color-text-secondary)' }}>
              {t.lastMessagePreview}
            </p>
          </div>
          <div className="flex flex-col items-end gap-1 shrink-0">
            <span className="text-[12px]" style={{ color: 'var(--color-text-secondary)' }}>{timeAgo(t.lastMessageAt)}</span>
            {t.unreadCount > 0 && (
              <span
                className="h-5 min-w-5 px-1 rounded-full text-[11px] font-semibold text-white flex items-center justify-center"
                style={{ background: 'var(--theme-accent)' }}
              >
                {t.unreadCount}
              </span>
            )}
          </div>
        </button>
      ))}
    </div>
  );
}

// -------------------- Conversation view --------------------

function Conversation({ otherUser, currentUserId, onBack, onThreadGone, onViewProfile }) {
  const [messages, setMessages] = useState([]);
  const [threadId, setThreadId] = useState(null);
  const [draft, setDraft] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);
  const [error, setError] = useState('');
  const scrollRef = useRef(null);

  useEffect(() => {
    const socket = connectSocket();
    joinDmThread(otherUser.id);

    api.getDmHistory(otherUser.id).then((data) => {
      if (data.thread) setThreadId(data.thread.id);
      setMessages((prev) => mergeMessages(prev, data.messages));
    }).catch(() => {});

    const handleHistory = (data) => {
      if (data.otherUserId !== otherUser.id) return;
      if (data.thread) setThreadId(data.thread.id);
      setMessages((prev) => mergeMessages(prev, data.messages));
    };
    const handleNewMessage = ({ threadId: tid, message }) => {
      setThreadId(tid);
      setMessages((prev) => mergeMessages(prev, [message]));
    };
    const handleError = (msg) => setError(msg);

    socket.on('dm_thread_history', handleHistory);
    socket.on('new_dm_message', handleNewMessage);
    socket.on('dm_error', handleError);

    return () => {
      leaveDmThread(otherUser.id);
      socket.off('dm_thread_history', handleHistory);
      socket.off('new_dm_message', handleNewMessage);
      socket.off('dm_error', handleError);
    };
  }, [otherUser.id]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ block: 'end' });
  }, [messages]);

  function handleSend() {
    if (!draft.trim()) return;
    connectSocket().emit('send_dm_message', { otherUserId: otherUser.id, body: draft.trim() });
    setDraft('');
  }

  async function handleHide() {
    setMenuOpen(false);
    if (!threadId) return;
    await api.hideDmThread(threadId);
    onThreadGone();
  }

  async function handleDelete() {
    setMenuOpen(false);
    if (!threadId) return;
    if (!window.confirm('Delete this conversation? It\u2019ll come back if they message you again.')) return;
    await api.clearDmThread(threadId);
    onThreadGone();
  }

  async function handleReport() {
    setMenuOpen(false);
    if (!threadId) return;
    const reason = window.prompt('What\u2019s wrong with this conversation? (optional)') || undefined;
    await api.reportDmThread(threadId, reason);
  }

  return (
    <div className="flex flex-col h-full">
      <div
        className="flex items-center gap-2 px-3 py-2 border-b shrink-0"
        style={{ borderColor: 'var(--color-border)', background: 'var(--color-bg-elevated)' }}
      >
        <button onClick={onBack} className="h-8 w-8 flex items-center justify-center -ml-1" aria-label="Back">
          <ChevronLeft size={22} color="var(--theme-accent)" />
        </button>
        <button onClick={() => onViewProfile(otherUser.id)} className="flex-1 min-w-0 text-left">
          <NameTag nickname={otherUser.nickname} handle={otherUser.handle} isRegistered={otherUser.isRegistered} size="sm" />
        </button>
        <div className="relative">
          <button onClick={() => setMenuOpen((v) => !v)} className="h-8 w-8 flex items-center justify-center" aria-label="Conversation options">
            <MoreVertical size={20} color="var(--color-text-secondary)" />
          </button>
          {menuOpen && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setMenuOpen(false)} />
              <div
                className="absolute right-0 top-9 z-20 rounded-xl overflow-hidden shadow-lg w-44"
                style={{ background: 'var(--color-bg-elevated)' }}
              >
                <button onClick={handleHide} className="w-full flex items-center gap-2 px-3 py-2.5 text-[14px]" style={{ color: 'var(--color-text)' }}>
                  <EyeOff size={15} /> Hide
                </button>
                <button onClick={handleReport} className="w-full flex items-center gap-2 px-3 py-2.5 text-[14px]" style={{ color: 'var(--color-text)' }}>
                  <Flag size={15} /> Report
                </button>
                <button onClick={handleDelete} className="w-full flex items-center gap-2 px-3 py-2.5 text-[14px]" style={{ color: '#ff375f' }}>
                  <Trash2 size={15} /> Delete
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto py-2 px-3">
        {messages.map((m) => {
          const isMine = m.sender_id === currentUserId;
          return (
            <div key={m.id} className={`flex mb-1.5 ${isMine ? 'justify-end' : 'justify-start'}`}>
              <div
                className="max-w-[75%] px-3 py-2 rounded-2xl text-[15px]"
                style={
                  isMine
                    ? { background: 'var(--theme-accent)', color: '#fff' }
                    : { background: 'var(--color-bubble-received)', color: 'var(--color-text)' }
                }
              >
                {m.body}
              </div>
            </div>
          );
        })}
        <div ref={scrollRef} />
      </div>

      {error && <p className="px-3 text-[13px]" style={{ color: '#ff375f' }}>{error}</p>}

      <div
        className="flex items-center gap-2 px-3 py-2 border-t"
        style={{
          borderColor: 'var(--color-border)',
          background: 'var(--color-bg-elevated)',
          paddingBottom: 'calc(env(safe-area-inset-bottom) + 8px)',
        }}
      >
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Message"
          className="flex-1 rounded-full px-4 py-2 text-[15px] outline-none"
          style={{ background: 'var(--color-bg)', color: 'var(--color-text)' }}
        />
        <button
          onClick={handleSend}
          disabled={!draft.trim()}
          className="h-9 w-9 rounded-full flex items-center justify-center shrink-0 disabled:opacity-40"
          style={{ background: 'var(--theme-accent)' }}
          aria-label="Send message"
        >
          <Send size={16} color="#ffffff" />
        </button>
      </div>
    </div>
  );
}

// -------------------- Page --------------------

// initialOtherUser: set when arriving here via ProfileCard's Message
// button, to jump straight into that conversation instead of the inbox.
export default function DMsPage({ siteName, user, isAdmin, isModerator, initialOtherUser, onConsumeInitialTarget, onNavigate, onAuthClick, onLogout, onViewProfile }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [threads, setThreads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [openUser, setOpenUser] = useState(null); // the other person's { id, nickname, handle, ... } | null

  function loadInbox() {
    setLoading(true);
    api.getDmInbox()
      .then((data) => setThreads(data.threads))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    if (!user?.isRegistered) return;
    loadInbox();
  }, [user?.isRegistered]);

  useEffect(() => {
    if (initialOtherUser) {
      setOpenUser(initialOtherUser);
      onConsumeInitialTarget();
    }
  }, [initialOtherUser]);

  if (!user?.isRegistered) {
    return (
      <div className="h-screen flex flex-col" style={{ background: 'var(--color-bg)' }}>
        <TopBar siteName={siteName} user={user} onAuthClick={onAuthClick} onMenuClick={() => setMenuOpen(true)} onLogout={onLogout} />
        <div className="flex-1 flex flex-col items-center justify-center gap-3 px-6 text-center">
          <p style={{ color: 'var(--color-text-secondary)' }}>Sign up to send and receive direct messages.</p>
          <button onClick={onAuthClick} className="px-4 py-2 rounded-full text-[15px] font-semibold text-white" style={{ background: 'var(--theme-accent)' }}>
            Sign Up/In
          </button>
        </div>
        <MenuDrawer open={menuOpen} onClose={() => setMenuOpen(false)} onNavigate={onNavigate} isAdmin={isAdmin} isModerator={isModerator} />
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col" style={{ background: 'var(--color-bg)' }}>
      {!openUser && (
        <>
          <TopBar siteName={siteName} user={user} onAuthClick={onAuthClick} onMenuClick={() => setMenuOpen(true)} onLogout={onLogout} />
          <Inbox threads={threads} loading={loading} error={error} onOpenThread={setOpenUser} />
        </>
      )}

      {openUser && (
        <Conversation
          otherUser={openUser}
          currentUserId={user.id}
          onBack={() => { setOpenUser(null); loadInbox(); }}
          onThreadGone={() => { setOpenUser(null); loadInbox(); }}
          onViewProfile={onViewProfile}
        />
      )}

      <MenuDrawer open={menuOpen} onClose={() => setMenuOpen(false)} onNavigate={onNavigate} isAdmin={isAdmin} isModerator={isModerator} />
    </div>
  );
}
