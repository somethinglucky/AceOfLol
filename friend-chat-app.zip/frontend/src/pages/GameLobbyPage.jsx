import { useEffect, useState } from 'react';
import { ArrowLeft, Menu, Settings, BookOpen, Mail, Dices } from 'lucide-react';
import { api } from '../api/client';
import NameTag from '../components/NameTag';
import GameInvitePanel from '../components/GameInvitePanel';

// The per-game Lobby (Games spec §5): ad slot, leaderboard, and the four
// buttons (Settings/Rules/Invite/Play a Stranger). This is Shell UI — it
// knows nothing about how any individual game is played.
export default function GameLobbyPage({ gameId, currentUser, unreadCount, onBack, onMenuClick, onOpenSession }) {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [modal, setModal] = useState(null); // null | 'settings' | 'rules' | 'invite'
  const [queueing, setQueueing] = useState(false);
  const [queueStatus, setQueueStatus] = useState(null); // null | 'waiting'

  function load() {
    api.getGameLobby(gameId).then(setData).catch(() => setError("Couldn't load this game."));
  }
  useEffect(load, [gameId]);

  // Poll while queued for a stranger match — small tables, so this
  // resolves in a handful of polls once a second player shows up.
  useEffect(() => {
    if (queueStatus !== 'waiting') return undefined;
    const interval = setInterval(async () => {
      try {
        const res = await api.getGameQueueStatus(gameId);
        if (res.sessionId) {
          setQueueStatus(null);
          onOpenSession(res.sessionId);
        } else if (!res.queued) {
          setQueueStatus(null);
        }
      } catch {
        // transient — next poll will retry
      }
    }, 2000);
    return () => clearInterval(interval);
  }, [queueStatus, gameId, onOpenSession]);

  async function handlePlayStranger() {
    setError('');
    setQueueing(true);
    try {
      const res = await api.joinGameQueue(gameId);
      if (res.sessionId) {
        onOpenSession(res.sessionId);
      } else {
        setQueueStatus('waiting');
      }
    } catch (err) {
      setError(err.message || "Couldn't join the queue.");
    } finally {
      setQueueing(false);
    }
  }

  async function handleLeaveQueue() {
    setQueueStatus(null);
    try {
      await api.leaveGameQueue(gameId);
    } catch {
      // best-effort
    }
  }

  if (error) {
    return (
      <div className="flex flex-col h-full items-center justify-center gap-3 p-6">
        <p style={{ color: 'var(--color-text-secondary)' }}>{error}</p>
        <button onClick={onBack} className="text-[14px]" style={{ color: 'var(--theme-accent)' }}>Back to Games</button>
      </div>
    );
  }
  if (!data) return <div className="flex-1" />;

  const { game, someoneWaiting, leaderboard, resumableSessionId } = data;
  const isPremium = !!currentUser?.isPremium;
  const showAd = game.accessTier === 'free' && !isPremium;

  return (
    <div className="flex flex-col h-full" style={{ background: 'var(--color-bg)' }}>
      {showAd && (
        <div className="text-center text-[11px] py-1" style={{ background: 'var(--color-bg-elevated)', color: 'var(--color-text-secondary)' }}>
          Ad space
        </div>
      )}

      <div
        className="flex items-center justify-between px-3 py-2 border-b shrink-0"
        style={{ borderColor: 'var(--color-border)', background: 'var(--color-bg-elevated)' }}
      >
        <button onClick={onBack} aria-label="Back"><ArrowLeft size={22} color="var(--color-text)" /></button>
        <h1 className="text-[17px] font-semibold truncate">{game.icon} {game.displayName}</h1>
        <button onClick={onMenuClick} className="relative" aria-label="Menu">
          <Menu size={22} color="var(--color-text)" />
          {unreadCount > 0 && (
            <span
              className="absolute -top-0.5 -right-0.5 h-4 min-w-4 px-1 rounded-full text-[10px] font-semibold text-white flex items-center justify-center"
              style={{ background: '#ff375f' }}
            >
              {unreadCount > 99 ? '99+' : unreadCount}
            </span>
          )}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-5">
        {resumableSessionId && (
          <button
            onClick={() => onOpenSession(resumableSessionId)}
            className="rounded-xl py-3 text-[15px] font-semibold text-white"
            style={{ background: 'var(--theme-accent)' }}
          >
            Resume your game
          </button>
        )}

        <div>
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-[15px] font-semibold">Leaderboard</h2>
            <span
              className="text-[11px] px-2 py-0.5 rounded-full"
              style={{ background: game.accessTier === 'free' ? 'var(--color-bg-elevated)' : 'var(--theme-accent)', color: game.accessTier === 'free' ? 'var(--color-text-secondary)' : 'white' }}
            >
              {game.accessTier === 'free' ? 'Free' : 'Premium / Pay to play'}
            </span>
          </div>
          {leaderboard.length === 0 ? (
            <p className="text-[13px]" style={{ color: 'var(--color-text-secondary)' }}>No games played yet — be the first!</p>
          ) : (
            <div className="flex flex-col gap-1.5">
              {leaderboard.map((row, i) => (
                <div key={row.userId} className="flex items-center gap-2 text-[14px]">
                  <span className="w-5 text-right" style={{ color: 'var(--color-text-secondary)' }}>{i + 1}.</span>
                  <NameTag nickname={row.nickname} handle={row.handle} size="sm" />
                  <span className="ml-auto" style={{ color: 'var(--color-text-secondary)' }}>{row.wins}W</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {someoneWaiting && (
          <p className="text-[13px] text-center" style={{ color: 'var(--theme-accent)' }}>
            Someone's already waiting to play this — Play a Stranger to match instantly.
          </p>
        )}

        {queueStatus === 'waiting' ? (
          <div className="rounded-xl p-4 flex flex-col items-center gap-2" style={{ background: 'var(--color-bg-elevated)' }}>
            <p className="text-[14px]">Waiting for another player…</p>
            <button onClick={handleLeaveQueue} className="text-[13px]" style={{ color: '#ff375f' }}>Cancel</button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            <LobbyButton icon={Settings} label="Settings" onClick={() => setModal('settings')} />
            <LobbyButton icon={BookOpen} label="Rules" onClick={() => setModal('rules')} />
            <LobbyButton icon={Mail} label="Invite" onClick={() => setModal('invite')} />
            <LobbyButton icon={Dices} label="Play a Stranger" onClick={handlePlayStranger} disabled={queueing} />
          </div>
        )}
      </div>

      {modal === 'rules' && (
        <SimpleModal title={`${game.displayName} rules`} onClose={() => setModal(null)}>
          <p className="text-[14px]" style={{ color: 'var(--color-text-secondary)' }}>{game.shortRules}</p>
        </SimpleModal>
      )}

      {modal === 'settings' && (
        <SimpleModal title="Settings" onClose={() => setModal(null)}>
          <p className="text-[14px]" style={{ color: 'var(--color-text-secondary)' }}>
            {game.usesCardTheme
              ? 'Card and background themes are coming soon — they’ll be a site-wide preference under Settings, applied here automatically.'
              : 'This game doesn’t have session settings yet.'}
          </p>
        </SimpleModal>
      )}

      {modal === 'invite' && (
        <GameInvitePanel
          gameId={game.gameId}
          gameName={game.displayName}
          currentUserId={currentUser?.id}
          onClose={() => setModal(null)}
          onSessionCreated={(sessionId) => {
            setModal(null);
            onOpenSession(sessionId);
          }}
        />
      )}
    </div>
  );
}

function LobbyButton({ icon: Icon, label, onClick, disabled }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="rounded-xl py-4 flex flex-col items-center gap-1.5 disabled:opacity-60"
      style={{ background: 'var(--color-bg-elevated)', border: '1px solid var(--color-border)' }}
    >
      <Icon size={22} color="var(--theme-accent)" />
      <span className="text-[13px]">{label}</span>
    </button>
  );
}

function SimpleModal({ title, onClose, children }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" style={{ background: 'rgba(0,0,0,0.35)' }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="w-full rounded-t-2xl p-4" style={{ background: 'var(--color-bg-elevated)' }}>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-[17px] font-semibold">{title}</h3>
          <button onClick={onClose} className="text-[14px]" style={{ color: 'var(--color-text-secondary)' }}>Close</button>
        </div>
        {children}
      </div>
    </div>
  );
}
