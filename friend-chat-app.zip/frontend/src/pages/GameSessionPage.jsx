import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, Send, Bell } from 'lucide-react';
import { api } from '../api/client';
import { getSocket, joinGameSession, leaveGameSession } from '../api/socket';
import NameTag from '../components/NameTag';
import PlayingCard from '../components/PlayingCard';
import CountdownTimer from '../components/CountdownTimer';
import JokerRiddle from '../components/JokerRiddle';
import CheckersBoard from '../components/CheckersBoard';
import InvitationRevealPage from './InvitationRevealPage';
import { describeGameStatus } from '../utils/gameStatusText';
import { relativeTime } from '../utils/relativeTime';

// A GameSession screen — renders whatever a module's renderState() hands
// back. The Shell (this component) knows the SHAPE for Blackjack/Go Fish
// specifically (to draw a nice board) but falls back to a generic log
// view for anything on the stub module, so a not-yet-built game still
// works end to end.
export default function GameSessionPage({ sessionId, currentUserId, onBack, onRematch }) {
  const [session, setSession] = useState(null);
  const [error, setError] = useState('');
  const [moveError, setMoveError] = useState('');
  const [sendingMove, setSendingMove] = useState(false);
  const [messages, setMessages] = useState([]);
  const [chatInput, setChatInput] = useState('');
  const [chatError, setChatError] = useState('');
  const [rematching, setRematching] = useState(false);
  const chatEndRef = useRef(null);

  async function load() {
    try {
      const { session: s } = await api.getGameSession(sessionId);
      setSession(s);
    } catch (err) {
      setError(err.message || "Couldn't load this game.");
    }
  }

  // Tapping into this screen IS "tapping the confirmation link" from spec
  // §6 step 8 — mark arrived every time it mounts. Idempotent on the
  // backend, and a no-op for stranger matches (already arrived for you).
  useEffect(() => {
    api.arriveAtGameSession(sessionId).finally(load);
  }, [sessionId]);

  // Socket: join the session's chat room, and refetch on any state nudge
  // (see backend/src/sockets/ioBridge.js — it never sends raw state, only
  // "something changed", so a refetch always re-sanitizes per viewer).
  useEffect(() => {
    joinGameSession(sessionId);
    const socket = getSocket();
    const onUpdate = () => load();
    const onMessage = (msg) => {
      if (msg.sessionId === sessionId) setMessages((prev) => [...prev, msg]);
    };
    // Full history replay on every successful join (including reconnects)
    // — see gameChatHandlers.js. Replacing (not appending) is correct
    // here: this is the authoritative persisted record, and a reconnect
    // re-sends it in full so nothing missed while disconnected is lost.
    const onHistory = ({ sessionId: sid, messages: history }) => {
      if (sid === sessionId) setMessages(history);
    };
    // Backstop for the join race described in api/socket.js's
    // joinGameSession — if the server ever rejects the join (e.g. it
    // arrived before authentication for some other reason), retry once
    // rather than silently never receiving anyone else's messages again.
    // TEMPORARY: also surfaces the raw error on screen (not just server
    // logs) so a live test immediately shows *why*, without needing
    // server console access — safe to remove once this is confirmed fixed.
    let retried = false;
    const onChatError = (reason) => {
      console.warn('[gameChat] error:', reason);
      setChatError(reason);
      if (retried) return;
      retried = true;
      setTimeout(() => joinGameSession(sessionId), 500);
    };
    socket.on('game_state_update', onUpdate);
    socket.on('new_game_message', onMessage);
    socket.on('game_chat_history', onHistory);
    socket.on('game_chat_error', onChatError);
    // The OTHER player also tapping "Play Again" — see
    // games/sessionEngine.js's requestRematch. Whoever asked first is
    // still sitting on this (old, completed) session's screen with
    // nothing telling them anything happened until this arrives.
    const onRematchReady = ({ oldSessionId, newSessionId }) => {
      if (oldSessionId === sessionId) onRematch(newSessionId);
    };
    socket.on('rematch_ready', onRematchReady);
    return () => {
      leaveGameSession(sessionId);
      socket.off('game_state_update', onUpdate);
      socket.off('new_game_message', onMessage);
      socket.off('game_chat_history', onHistory);
      socket.off('game_chat_error', onChatError);
      socket.off('rematch_ready', onRematchReady);
    };
  }, [sessionId]);

  // Fallback poll — covers the "waiting for the other player to arrive"
  // window, where nothing has happened yet for a socket nudge to fire.
  useEffect(() => {
    if (session?.status === 'completed') return undefined;
    const interval = setInterval(load, 3000);
    return () => clearInterval(interval);
  }, [sessionId, session?.status]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ block: 'nearest' });
  }, [messages]);

  async function sendMove(moveData) {
    setMoveError('');
    setSendingMove(true);
    try {
      const { session: s } = await api.sendGameMove(sessionId, moveData);
      setSession(s);
    } catch (err) {
      setMoveError(err.message || "That move didn't work.");
    } finally {
      setSendingMove(false);
    }
  }

  function sendChat(e) {
    e.preventDefault();
    if (!chatInput.trim()) return;
    getSocket().emit('send_game_message', { sessionId, body: chatInput.trim() });
    setChatInput('');
  }

  // "Play Again" — see games/sessionEngine.js's requestRematch for the
  // mutual-agreement mechanics. The first tap just records the request
  // and re-fetches (so the UI flips to "waiting"); the second tap gets a
  // sessionId back directly and jumps straight there — the first player
  // gets the same result via the rematch_ready socket event above.
  async function handlePlayAgain() {
    setError('');
    setRematching(true);
    try {
      const result = await api.requestRematch(sessionId);
      if (result.sessionId) {
        onRematch(result.sessionId);
      } else {
        load();
      }
    } catch (err) {
      setError(err.message || "Couldn't start a rematch.");
    } finally {
      setRematching(false);
    }
  }

  if (error) {
    return (
      <div className="flex flex-col h-full items-center justify-center gap-3 p-6">
        <p style={{ color: 'var(--color-text-secondary)' }}>{error}</p>
        <button onClick={onBack} className="text-[14px]" style={{ color: 'var(--theme-accent)' }}>Back to Games</button>
      </div>
    );
  }
  if (!session) return <div className="flex-1" />;

  // The reveal moment sj described: before the invitee sees anything
  // about the game itself, they see the invitation card the inviter
  // picked. Only ever true once per person per session (see
  // gameSessions.js's reveal-seen route) — dismissing it just re-fetches
  // the session, which now comes back with pendingReveal already false.
  if (session.invitation?.pendingReveal) {
    return (
      <InvitationRevealPage
        sessionId={sessionId}
        invitation={session.invitation}
        gameName={session.gameName}
        gameIcon={session.gameIcon}
        onRevealed={load}
      />
    );
  }

  const isMyTurn = session.turnUserId === currentUserId;
  // Alone in the waiting room — you've arrived, they haven't yet. This is
  // really only ever true for an invite session (a stranger match starts
  // the instant it's made, both seats already arrived) — which fits sj's
  // framing well: it's specifically the "waiting for your date" moment
  // this is meant to fill.
  const mySeat = session.seats.find((s) => s.userId === currentUserId);
  const isAloneWaiting = session.status === 'waiting' && mySeat?.arrived && !session.seats.every((s) => s.arrived);

  return (
    <div className="flex flex-col h-full relative" style={{ background: 'var(--color-bg)' }}>
      <div
        className="flex items-center gap-3 px-3 py-2 border-b shrink-0"
        style={{ borderColor: 'var(--color-border)', background: 'var(--color-bg-elevated)' }}
      >
        <button onClick={onBack} aria-label="Back"><ArrowLeft size={22} color="var(--color-text)" /></button>
        <h1 className="text-[16px] font-semibold truncate">{session.gameName}</h1>
        <div className="ml-auto flex gap-1.5">
          {session.seats.map((seat) => (
            <div key={seat.userId} title={seat.nickname} className="text-[11px] px-2 py-1 rounded-full" style={{ background: 'var(--color-bg)', border: '1px solid var(--color-border)' }}>
              <NameTag nickname={seat.nickname} handle={seat.handle} size="sm" />
            </div>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3 pb-40">
        {session.status === 'waiting' && (
          <div className="flex flex-col items-center gap-2">
            {session.invitation?.scheduledFor && <CountdownTimer targetIso={session.invitation.scheduledFor} />}
            {isAloneWaiting ? (
              // Compact one-liner instead of the full per-seat list + a
              // separate NotificationPrompt banner below it — when Joker
              // is up, screen space is genuinely scarce once a phone
              // keyboard opens for typing a guess, so this trades the
              // fuller waiting-room detail for room to actually play.
              <div className="flex items-center gap-2 text-[12px]" style={{ color: 'var(--color-text-secondary)' }}>
                <span>Waiting for {session.seats.find((s) => !s.arrived)?.nickname || 'the other player'}…</span>
                <NotificationPrompt compact />
              </div>
            ) : (
              <>
                <p className="text-[15px]">Waiting for everyone to join…</p>
                {session.seats.map((seat) => (
                  <p key={seat.userId} className="text-[13px]" style={{ color: seat.arrived ? 'var(--theme-accent)' : 'var(--color-text-secondary)' }}>
                    {seat.nickname} — {seat.arrived ? 'here' : `not here yet — last seen ${relativeTime(seat.lastActiveAt)}`}
                  </p>
                ))}
                <NotificationPrompt />
              </>
            )}
            {isAloneWaiting && <JokerRiddle />}
          </div>
        )}

        {session.status === 'completed' && (
          <div className="rounded-xl p-4 mb-4 flex flex-col items-center gap-3 text-center" style={{ background: 'var(--color-bg-elevated)' }}>
            <p className="text-[15px] font-semibold">
              {session.result?.winnerId
                ? session.result.winnerId === currentUserId ? 'You won! 🎉' : `${session.seats.find((s) => s.userId === session.result.winnerId)?.nickname} won.`
                : "It's a tie."}
            </p>
            {(() => {
              const opponent = session.seats.find((s) => s.userId !== currentUserId);
              if (session.rematchRequestedBy === currentUserId) {
                return (
                  <p className="text-[13px]" style={{ color: 'var(--color-text-secondary)' }}>
                    Waiting for {opponent?.nickname} to accept a rematch…
                  </p>
                );
              }
              return (
                <button
                  onClick={handlePlayAgain}
                  disabled={rematching}
                  className="rounded-full px-5 py-2 text-[14px] font-semibold text-white disabled:opacity-60"
                  style={{ background: 'var(--theme-accent)' }}
                >
                  {session.rematchRequestedBy ? `${opponent?.nickname} wants a rematch — Play Again` : 'Play Again'}
                </button>
              );
            })()}
          </div>
        )}

        {(session.status === 'active' || session.status === 'completed') && (
          <GameBoard
            gameId={session.gameId}
            board={session.board}
            seats={session.seats}
            currentUserId={currentUserId}
            isMyTurn={isMyTurn && session.status === 'active'}
            gameOver={session.status === 'completed'}
            sending={sendingMove}
            onMove={sendMove}
          />
        )}
        {moveError && <p className="text-[13px] mt-2" style={{ color: '#ff375f' }}>{moveError}</p>}
      </div>

      {/* In-game chat overlay (spec §9) — sits over the board, bottom of
          the window extends past it so the most recent messages read
          clearly while older ones fade into the translucent backdrop. */}
      <div className="absolute bottom-0 inset-x-0 flex flex-col" style={{ maxHeight: '45%' }}>
        <div
          className="flex-1 overflow-y-auto px-3 pt-6 pb-1 flex flex-col gap-1.5"
          style={{ background: 'linear-gradient(to bottom, transparent, var(--color-bg-elevated) 70%)' }}
        >
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.senderId === currentUserId ? 'justify-end' : 'justify-start'}`}>
              <div
                className="max-w-[75%] px-3 py-1.5 rounded-2xl text-[13px]"
                style={
                  m.senderId === currentUserId
                    ? { background: 'var(--theme-accent)', color: '#fff', opacity: 0.75 }
                    : { background: 'var(--color-bubble-received)', color: 'var(--color-text)', opacity: 0.75 }
                }
              >
                {m.body}
              </div>
            </div>
          ))}
          <div ref={chatEndRef} />
        </div>
        {chatError && (
          <p className="text-[11px] text-center px-3" style={{ color: '#ff375f', background: 'var(--color-bg-elevated)' }}>
            Chat error: {chatError}
          </p>
        )}
        <form
          onSubmit={sendChat}
          className="flex items-center gap-2 px-3 py-2 border-t shrink-0"
          style={{ borderColor: 'var(--color-border)', background: 'var(--color-bg-elevated)', paddingBottom: 'calc(env(safe-area-inset-bottom) + 8px)' }}
        >
          <input
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            placeholder="Message"
            className="flex-1 rounded-full px-4 py-2 text-[14px]"
            style={{ background: 'var(--color-bg)', border: '1px solid var(--color-border)', color: 'var(--color-text)' }}
          />
          <button type="submit" className="h-9 w-9 rounded-full flex items-center justify-center shrink-0" style={{ background: 'var(--theme-accent)' }}>
            <Send size={16} color="white" />
          </button>
        </form>
      </div>
    </div>
  );
}

// ---- Board renderers -------------------------------------------------
// The Shell only needs to know how to draw each game's renderState()
// output — it never touches move-validation logic (that already happened
// server-side in the module). A game without a specific renderer here
// still works via the generic fallback (used today by War/Hearts' stub).
// Layout convention across all three: opponent's cards up top (drawn 10%
// smaller, so the eye reads them as "across the table"), your own hand
// at the bottom near the move controls and the chat input.

function GameBoard({ gameId, board, seats, currentUserId, isMyTurn, gameOver, sending, onMove }) {
  const { statusLine, turnLine } = describeGameStatus({ gameId, board, seats, currentUserId, gameOver });
  const shared = { board, currentUserId, isMyTurn, sending, onMove };
  const knownGames = ['blackjack', 'go_fish', 'checkers'];

  return (
    <div className="flex flex-col gap-4">
      {gameId === 'blackjack' && <BlackjackBoard {...shared} />}
      {gameId === 'go_fish' && <GoFishBoard {...shared} />}
      {gameId === 'checkers' && <CheckersBoard {...shared} />}
      {!knownGames.includes(gameId) && <GenericBoard {...shared} />}

      {statusLine && (
        <div className="text-center">
          <p className="text-[13px]" style={{ color: 'var(--color-text-secondary)' }}>{statusLine}</p>
          {turnLine && <p className="text-[13px] font-semibold mt-0.5">{turnLine}</p>}
        </div>
      )}
    </div>
  );
}

// NOTE: board.hands is keyed by userId (it's state.hands from
// blackjack.js's renderState, straight off the module's internal state) —
// so the opponent's hand is found by excluding OUR OWN userId, not by
// comparing array identity. (An earlier version of this compared
// `hand !== board.yourHand` by reference, which happened to work against
// the in-memory object but silently breaks the moment it round-trips
// through JSON over HTTP, since JSON.parse always produces new array
// instances — caught before this ever shipped.)
function BlackjackBoard({ board, currentUserId, isMyTurn, sending, onMove }) {
  const opponentHand = Object.entries(board.hands).find(([userId]) => userId !== currentUserId)?.[1] || [];
  const opponentId = Object.keys(board.hands).find((userId) => userId !== currentUserId);
  return (
    <div className="flex flex-col gap-4">
      <div>
        <p className="text-[13px] mb-1" style={{ color: 'var(--color-text-secondary)' }}>Opponent ({board.totals?.[opponentId]})</p>
        <div className="flex gap-1.5 flex-wrap">
          {opponentHand.map((c, i) => <PlayingCard key={i} card={c} scale={0.9} />)}
        </div>
      </div>

      <div>
        <p className="text-[13px] mb-1" style={{ color: 'var(--color-text-secondary)' }}>Your hand ({board.totals?.[currentUserId]})</p>
        <div className="flex gap-1.5 flex-wrap">
          {board.yourHand.map((c, i) => <PlayingCard key={i} card={c} />)}
        </div>
      </div>
      {isMyTurn && (
        <div className="flex gap-3">
          <button disabled={sending} onClick={() => onMove({ action: 'hit' })} className="flex-1 rounded-full py-2.5 text-[14px] font-semibold text-white disabled:opacity-60" style={{ background: 'var(--theme-accent)' }}>Hit</button>
          <button disabled={sending} onClick={() => onMove({ action: 'stand' })} className="flex-1 rounded-full py-2.5 text-[14px] font-semibold" style={{ border: '1px solid var(--color-border)' }}>Stand</button>
        </div>
      )}
    </div>
  );
}

function GoFishBoard({ board, isMyTurn, sending, onMove }) {
  const heldRanks = [...new Set(board.yourHand.map((c) => c.slice(0, -1)))];
  return (
    <div className="flex flex-col gap-4">
      <div>
        <p className="text-[13px] mb-1" style={{ color: 'var(--color-text-secondary)' }}>
          Opponent · {board.opponentHandCount} cards
        </p>
        <div className="flex gap-1.5 flex-wrap">
          {Array.from({ length: board.opponentHandCount }).map((_, i) => (
            <PlayingCard key={i} faceDown scale={0.9} />
          ))}
        </div>
      </div>

      <p className="text-[12px] text-center" style={{ color: 'var(--color-text-secondary)' }}>{board.cardsLeft} cards left in the deck</p>

      <div>
        <p className="text-[13px] mb-1" style={{ color: 'var(--color-text-secondary)' }}>Your hand</p>
        <div className="flex gap-1.5 flex-wrap">
          {board.yourHand.map((c, i) => <PlayingCard key={i} card={c} />)}
        </div>
      </div>
      {isMyTurn && (
        <div>
          <p className="text-[13px] mb-1" style={{ color: 'var(--color-text-secondary)' }}>Ask for a rank you hold:</p>
          <div className="flex gap-1.5 flex-wrap">
            {heldRanks.map((rank) => (
              <button key={rank} disabled={sending} onClick={() => onMove({ rank })} className="w-9 h-9 rounded-lg text-[13px] font-semibold disabled:opacity-60" style={{ background: 'var(--theme-accent)', color: 'white' }}>
                {rank}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function GenericBoard({ board, isMyTurn, sending, onMove }) {
  return (
    <div className="flex flex-col gap-4">
      {board.note && <p className="text-[14px]" style={{ color: 'var(--color-text-secondary)' }}>{board.note}</p>}
      {isMyTurn && (
        <button disabled={sending} onClick={() => onMove({ action: 'end_stub' })} className="rounded-full py-2.5 text-[14px] font-semibold text-white disabled:opacity-60" style={{ background: 'var(--theme-accent)' }}>
          End (stub)
        </button>
      )}
    </div>
  );
}

// Asks for browser notification permission while a player waits for the
// other seat to arrive, so they can hear about it without babysitting the
// tab. Only rendered during the waiting screen (see below), and only
// prompts if permission hasn't already been decided one way or the other.
// compact: a single-line text-link version instead of the full card —
// used when screen space is tight (alone with Joker up), so the option
// stays available without competing for room with the riddle widget.
function NotificationPrompt({ compact }) {
  const supported = typeof window !== 'undefined' && 'Notification' in window;
  const [permission, setPermission] = useState(supported ? Notification.permission : 'unsupported');

  if (!supported || permission !== 'default') return null;

  if (compact) {
    return (
      <button
        onClick={() => Notification.requestPermission().then(setPermission)}
        className="flex items-center gap-1 text-[11px]"
        style={{ color: 'var(--theme-accent)' }}
      >
        <Bell size={12} /> Notify me when they join
      </button>
    );
  }

  return (
    <div className="rounded-xl p-3 flex items-center gap-3 mt-2" style={{ background: 'var(--color-bg-elevated)', border: '1px solid var(--color-border)' }}>
      <Bell size={18} color="var(--theme-accent)" />
      <p className="text-[13px] flex-1" style={{ color: 'var(--color-text-secondary)' }}>Get notified the moment your opponent joins?</p>
      <button
        onClick={() => Notification.requestPermission().then(setPermission)}
        className="text-[13px] font-semibold shrink-0"
        style={{ color: 'var(--theme-accent)' }}
      >
        Allow
      </button>
    </div>
  );
}
