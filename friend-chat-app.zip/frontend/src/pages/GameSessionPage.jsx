import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, Send } from 'lucide-react';
import { api } from '../api/client';
import { getSocket, joinGameSession, leaveGameSession } from '../api/socket';
import NameTag from '../components/NameTag';
import PlayingCard from '../components/PlayingCard';

// A GameSession screen — renders whatever a module's renderState() hands
// back. The Shell (this component) knows the SHAPE for Blackjack/Go Fish
// specifically (to draw a nice board) but falls back to a generic log
// view for anything on the stub module, so a not-yet-built game still
// works end to end.
export default function GameSessionPage({ sessionId, currentUserId, onBack }) {
  const [session, setSession] = useState(null);
  const [error, setError] = useState('');
  const [moveError, setMoveError] = useState('');
  const [sendingMove, setSendingMove] = useState(false);
  const [messages, setMessages] = useState([]);
  const [chatInput, setChatInput] = useState('');
  const chatEndRef = useRef(null);

  async function load() {
    try {
      const { session: s } = await api.getGameSession(sessionId);
      setSession(s);
    } catch (err) {
      setError(err.message || "Couldn't load this game.");
    }
  }

  // Tapping into this screen IS "tapping the confirmation link" from spec
  // §6 step 8 — mark arrived every time it mounts. Idempotent on the
  // backend, and a no-op for stranger matches (already arrived for you).
  useEffect(() => {
    api.arriveAtGameSession(sessionId).finally(load);
  }, [sessionId]);

  // Socket: join the session's chat room, and refetch on any state nudge
  // (see backend/src/sockets/ioBridge.js — it never sends raw state, only
  // "something changed", so a refetch always re-sanitizes per viewer).
  useEffect(() => {
    joinGameSession(sessionId);
    const socket = getSocket();
    const onUpdate = () => load();
    const onMessage = (msg) => {
      if (msg.sessionId === sessionId) setMessages((prev) => [...prev, msg]);
    };
    socket.on('game_state_update', onUpdate);
    socket.on('new_game_message', onMessage);
    return () => {
      leaveGameSession(sessionId);
      socket.off('game_state_update', onUpdate);
      socket.off('new_game_message', onMessage);
    };
  }, [sessionId]);

  // Fallback poll — covers the "waiting for the other player to arrive"
  // window, where nothing has happened yet for a socket nudge to fire.
  useEffect(() => {
    if (session?.status === 'completed') return undefined;
    const interval = setInterval(load, 3000);
    return () => clearInterval(interval);
  }, [sessionId, session?.status]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ block: 'nearest' });
  }, [messages]);

  async function sendMove(moveData) {
    setMoveError('');
    setSendingMove(true);
    try {
      const { session: s } = await api.sendGameMove(sessionId, moveData);
      setSession(s);
    } catch (err) {
      setMoveError(err.message || "That move didn't work.");
    } finally {
      setSendingMove(false);
    }
  }

  function sendChat(e) {
    e.preventDefault();
    if (!chatInput.trim()) return;
    getSocket().emit('send_game_message', { sessionId, body: chatInput.trim() });
    setChatInput('');
  }

  if (error) {
    return (
      <div className="flex flex-col h-full items-center justify-center gap-3 p-6">
        <p style={{ color: 'var(--color-text-secondary)' }}>{error}</p>
        <button onClick={onBack} className="text-[14px]" style={{ color: 'var(--theme-accent)' }}>Back to Games</button>
      </div>
    );
  }
  if (!session) return <div className="flex-1" />;

  const isMyTurn = session.turnUserId === currentUserId;

  return (
    <div className="flex flex-col h-full relative" style={{ background: 'var(--color-bg)' }}>
      <div
        className="flex items-center gap-3 px-3 py-2 border-b shrink-0"
        style={{ borderColor: 'var(--color-border)', background: 'var(--color-bg-elevated)' }}
      >
        <button onClick={onBack} aria-label="Back"><ArrowLeft size={22} color="var(--color-text)" /></button>
        <h1 className="text-[16px] font-semibold truncate">{session.gameName}</h1>
        <div className="ml-auto flex -space-x-2">
          {session.seats.map((seat) => (
            <div key={seat.userId} title={seat.nickname} className="text-[11px] px-2 py-1 rounded-full" style={{ background: 'var(--color-bg)', border: '1px solid var(--color-border)' }}>
              <NameTag nickname={seat.nickname} handle={seat.handle} size="sm" />
            </div>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 pb-40">
        {session.status === 'waiting' && (
          <div className="flex flex-col items-center gap-2 mt-10">
            <p className="text-[15px]">Waiting for everyone to join…</p>
            {session.seats.map((seat) => (
              <p key={seat.userId} className="text-[13px]" style={{ color: seat.arrived ? 'var(--theme-accent)' : 'var(--color-text-secondary)' }}>
                {seat.nickname} — {seat.arrived ? 'here' : 'not here yet'}
              </p>
            ))}
          </div>
        )}

        {session.status === 'completed' && (
          <div className="rounded-xl p-4 mb-4 text-center" style={{ background: 'var(--color-bg-elevated)' }}>
            <p className="text-[15px] font-semibold">
              {session.result?.winnerId
                ? session.result.winnerId === currentUserId ? 'You won! 🎉' : `${session.seats.find((s) => s.userId === session.result.winnerId)?.nickname} won.`
                : "It's a tie."}
            </p>
          </div>
        )}

        {(session.status === 'active' || session.status === 'completed') && (
          <GameBoard
            gameId={session.gameId}
            board={session.board}
            currentUserId={currentUserId}
            isMyTurn={isMyTurn && session.status === 'active'}
            sending={sendingMove}
            onMove={sendMove}
          />
        )}
        {moveError && <p className="text-[13px] mt-2" style={{ color: '#ff375f' }}>{moveError}</p>}
      </div>

      {/* In-game chat overlay (spec §9) — sits over the board, bottom of
          the window extends past it so the most recent messages read
          clearly while older ones fade into the translucent backdrop. */}
      <div className="absolute bottom-0 inset-x-0 flex flex-col" style={{ maxHeight: '45%' }}>
        <div
          className="flex-1 overflow-y-auto px-3 pt-6 pb-1 flex flex-col gap-1.5"
          style={{ background: 'linear-gradient(to bottom, transparent, var(--color-bg-elevated) 70%)' }}
        >
          {messages.map((m, i) => (
            <div key={i} className={`max-w-[75%] px-3 py-1.5 rounded-2xl text-[13px] ${m.senderId === currentUserId ? 'self-end' : 'self-start'}`}
              style={{
                background: m.senderId === currentUserId ? 'var(--color-bubble-sent)' : 'var(--color-bubble-received)',
                color: 'var(--color-text)',
                opacity: 0.7,
              }}
            >
              {m.body}
            </div>
          ))}
          <div ref={chatEndRef} />
        </div>
        <form
          onSubmit={sendChat}
          className="flex items-center gap-2 px-3 py-2 border-t shrink-0"
          style={{ borderColor: 'var(--color-border)', background: 'var(--color-bg-elevated)', paddingBottom: 'calc(env(safe-area-inset-bottom) + 8px)' }}
        >
          <input
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            placeholder="Message"
            className="flex-1 rounded-full px-4 py-2 text-[14px]"
            style={{ background: 'var(--color-bg)', border: '1px solid var(--color-border)', color: 'var(--color-text)' }}
          />
          <button type="submit" className="h-9 w-9 rounded-full flex items-center justify-center shrink-0" style={{ background: 'var(--theme-accent)' }}>
            <Send size={16} color="white" />
          </button>
        </form>
      </div>
    </div>
  );
}

// ---- Board renderers -------------------------------------------------
// The Shell only needs to know how to draw each game's renderState()
// output — it never touches move-validation logic (that already happened
// server-side in the module). A game without a specific renderer here
// still works via the generic fallback (used today by War/Hearts' stub).

function GameBoard({ gameId, board, currentUserId, isMyTurn, sending, onMove }) {
  if (gameId === 'blackjack') return <BlackjackBoard board={board} currentUserId={currentUserId} isMyTurn={isMyTurn} sending={sending} onMove={onMove} />;
  if (gameId === 'go_fish') return <GoFishBoard board={board} isMyTurn={isMyTurn} sending={sending} onMove={onMove} />;
  return <GenericBoard board={board} isMyTurn={isMyTurn} sending={sending} onMove={onMove} />;
}

// NOTE: board.hands is keyed by userId (it's state.hands from
// blackjack.js's renderState, straight off the module's internal state) —
// so the opponent's hand is found by excluding OUR OWN userId, not by
// comparing array identity. (An earlier version of this compared
// `hand !== board.yourHand` by reference, which happened to work against
// the in-memory object but silently breaks the moment it round-trips
// through JSON over HTTP, since JSON.parse always produces new array
// instances — caught before this ever shipped.)
function BlackjackBoard({ board, currentUserId, isMyTurn, sending, onMove }) {
  const opponentHand = Object.entries(board.hands).find(([userId]) => userId !== currentUserId)?.[1] || [];
  return (
    <div className="flex flex-col gap-4">
      <div>
        <p className="text-[13px] mb-1" style={{ color: 'var(--color-text-secondary)' }}>Your hand ({board.totals?.[currentUserId]})</p>
        <div className="flex gap-1.5 flex-wrap">
          {board.yourHand.map((c, i) => <PlayingCard key={i} card={c} />)}
        </div>
      </div>
      <div>
        <p className="text-[13px] mb-1" style={{ color: 'var(--color-text-secondary)' }}>Opponent</p>
        <div className="flex gap-1.5 flex-wrap">
          {opponentHand.map((c, i) => <PlayingCard key={i} card={c} />)}
        </div>
      </div>
      {isMyTurn && (
        <div className="flex gap-3">
          <button disabled={sending} onClick={() => onMove({ action: 'hit' })} className="flex-1 rounded-full py-2.5 text-[14px] font-semibold text-white disabled:opacity-60" style={{ background: 'var(--theme-accent)' }}>Hit</button>
          <button disabled={sending} onClick={() => onMove({ action: 'stand' })} className="flex-1 rounded-full py-2.5 text-[14px] font-semibold" style={{ border: '1px solid var(--color-border)' }}>Stand</button>
        </div>
      )}
      <GameLog log={board.log} />
    </div>
  );
}

function GoFishBoard({ board, isMyTurn, sending, onMove }) {
  const heldRanks = [...new Set(board.yourHand.map((c) => c.slice(0, -1)))];
  return (
    <div className="flex flex-col gap-4">
      <div>
        <p className="text-[13px] mb-1" style={{ color: 'var(--color-text-secondary)' }}>Your hand</p>
        <div className="flex gap-1.5 flex-wrap">
          {board.yourHand.map((c, i) => <PlayingCard key={i} card={c} />)}
        </div>
      </div>
      <p className="text-[13px]" style={{ color: 'var(--color-text-secondary)' }}>
        Opponent has {board.opponentHandCount} cards · {board.cardsLeft} left in the deck
      </p>
      {isMyTurn && (
        <div>
          <p className="text-[13px] mb-1" style={{ color: 'var(--color-text-secondary)' }}>Ask for a rank you hold:</p>
          <div className="flex gap-1.5 flex-wrap">
            {heldRanks.map((rank) => (
              <button key={rank} disabled={sending} onClick={() => onMove({ rank })} className="w-9 h-9 rounded-lg text-[13px] font-semibold disabled:opacity-60" style={{ background: 'var(--theme-accent)', color: 'white' }}>
                {rank}
              </button>
            ))}
          </div>
        </div>
      )}
      <GameLog log={board.log} />
    </div>
  );
}

function GenericBoard({ board, isMyTurn, sending, onMove }) {
  return (
    <div className="flex flex-col gap-4">
      {board.note && <p className="text-[14px]" style={{ color: 'var(--color-text-secondary)' }}>{board.note}</p>}
      {isMyTurn && (
        <button disabled={sending} onClick={() => onMove({ action: 'end_stub' })} className="rounded-full py-2.5 text-[14px] font-semibold text-white disabled:opacity-60" style={{ background: 'var(--theme-accent)' }}>
          End (stub)
        </button>
      )}
      <GameLog log={board.log} />
    </div>
  );
}

function GameLog({ log }) {
  if (!log?.length) return null;
  return (
    <div className="flex flex-col gap-0.5 mt-2">
      {log.map((line, i) => (
        <p key={i} className="text-[12px]" style={{ color: 'var(--color-text-secondary)' }}>{line}</p>
      ))}
    </div>
  );
}
