import { useEffect, useState } from 'react';
import { Menu } from 'lucide-react';
import { api } from '../api/client';
import MenuDrawer from '../components/MenuDrawer';
import GameLobbyPage from './GameLobbyPage';
import GameSessionPage from './GameSessionPage';

// Screen Flow Overview (Games spec §3):
//   Games Page (hub) -> Game Lobby (per game) -> Invite/Stranger -> Game Session
// This component owns which of those three screens is showing; it's the
// only "Games" entry App.jsx needs to know about. It also owns the
// hamburger MenuDrawer itself, same as every other top-level page in this
// app (StorePage, etc. each keep their own menuOpen state rather than
// App.jsx controlling one globally — there's no shared menu state to hook
// into).
export default function GamesPage({ currentUser, isAdmin, isModerator, unreadCount, initialDeepLink, onConsumeInitialDeepLink, onNavigate }) {
  const [screen, setScreen] = useState({ view: 'hub' }); // {view:'hub'} | {view:'lobby', gameId, autoOpenInvite?} | {view:'session', sessionId}
  const [games, setGames] = useState(null);
  const [error, setError] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);

  // Arriving via a game-invite DM card or the Invites tab (App.jsx's
  // handleOpenGame) — jump straight past the hub instead of making the
  // person find their way back to this specific game themselves. A
  // sessionId means the invite's already confirmed and the game exists;
  // otherwise land in that game's lobby with the Invite panel already
  // open, since that's the whole reason they tapped the link.
  useEffect(() => {
    if (!initialDeepLink) return;
    if (initialDeepLink.sessionId) {
      setScreen({ view: 'session', sessionId: initialDeepLink.sessionId });
    } else if (initialDeepLink.gameId) {
      setScreen({ view: 'lobby', gameId: initialDeepLink.gameId, autoOpenInvite: true });
    }
    onConsumeInitialDeepLink();
  }, [initialDeepLink]);

  useEffect(() => {
    if (screen.view !== 'hub') return;
    api.getGames().then((data) => setGames(data.games)).catch(() => setError("Couldn't load games."));
  }, [screen.view]);

  return (
    <>
      {screen.view === 'lobby' && (
        <GameLobbyPage
          gameId={screen.gameId}
          currentUser={currentUser}
          unreadCount={unreadCount}
          autoOpenInvite={screen.autoOpenInvite}
          onBack={() => setScreen({ view: 'hub' })}
          onMenuClick={() => setMenuOpen(true)}
          onOpenSession={(sessionId) => setScreen({ view: 'session', sessionId })}
        />
      )}

      {screen.view === 'session' && (
        <GameSessionPage
          sessionId={screen.sessionId}
          currentUserId={currentUser?.id}
          onBack={() => setScreen({ view: 'hub' })}
          onRematch={(newSessionId) => setScreen({ view: 'session', sessionId: newSessionId })}
        />
      )}

      {screen.view === 'hub' && (
        <div className="flex flex-col h-full" style={{ background: 'var(--color-bg)' }}>
          <div
            className="flex items-center justify-between px-3 py-2 border-b shrink-0"
            style={{ borderColor: 'var(--color-border)', background: 'var(--color-bg-elevated)' }}
          >
            <div className="w-8" />
            <h1 className="text-[17px] font-semibold">Games</h1>
            <button onClick={() => setMenuOpen(true)} className="relative" aria-label="Menu">
              <Menu size={22} color="var(--color-text)" />
              {unreadCount > 0 && (
                <span
                  className="absolute -top-0.5 -right-0.5 h-4 min-w-4 px-1 rounded-full text-[10px] font-semibold text-white flex items-center justify-center"
                  style={{ background: '#ff375f' }}
                >
                  {unreadCount > 99 ? '99+' : unreadCount}
                </span>
              )}
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4">
            {error && <p className="text-[14px]" style={{ color: 'var(--color-text-secondary)' }}>{error}</p>}
            {!games && !error && <div className="flex-1" />}
            {games && (
              <div className="grid grid-cols-2 gap-3">
                {games.map((game) => (
                  <button
                    key={game.gameId}
                    onClick={() => setScreen({ view: 'lobby', gameId: game.gameId })}
                    className="rounded-2xl p-4 flex flex-col items-start gap-2 text-left relative"
                    style={{ background: 'var(--color-bg-elevated)', border: '1px solid var(--color-border)' }}
                  >
                    {game.accessTier === 'free' && (
                      <div className="absolute top-2 right-2 text-[9px] px-1.5 py-0.5 rounded" style={{ background: 'var(--color-bg)', color: 'var(--color-text-secondary)' }}>
                        Ad
                      </div>
                    )}
                    <span className="text-[28px]">{game.icon}</span>
                    <span className="text-[15px] font-semibold">{game.displayName}</span>
                    <span
                      className="text-[11px] px-2 py-0.5 rounded-full"
                      style={{ background: game.accessTier === 'free' ? 'var(--color-bg)' : 'var(--theme-accent)', color: game.accessTier === 'free' ? 'var(--color-text-secondary)' : 'white' }}
                    >
                      {game.accessTier === 'free' ? 'Free' : 'Premium'}
                    </span>
                    {game.someoneWaiting && (
                      <span className="text-[11px]" style={{ color: 'var(--theme-accent)' }}>● Someone's waiting</span>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      <MenuDrawer open={menuOpen} onClose={() => setMenuOpen(false)} onNavigate={onNavigate} isAdmin={isAdmin} isModerator={isModerator} unreadCount={unreadCount} />
    </>
  );
}

