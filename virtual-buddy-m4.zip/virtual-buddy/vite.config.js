import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
export default defineConfig({
  plugins: [react()],
  optimizeDeps: { exclude: ['@wllama/wllama'] }, // ships its own worker/wasm; keep it out of dep pre-bundling
})
