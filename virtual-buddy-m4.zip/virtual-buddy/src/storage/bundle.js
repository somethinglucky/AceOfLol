import JSZip from 'jszip'
import { STORES, getAll, put, clearStore, putSettings, getSettings } from './db.js'

export const BUNDLE_VERSION = 1

// Rows -> JSON-safe rows. Image blobs go to media/ in the zip; embeddings are regenerated on import.
function clean(zip, store, rows) {
  return rows.map((r) => {
    const o = {}
    for (const [k, v] of Object.entries(r)) {
      if (k === 'embedding') continue
      if (v instanceof Blob) {
        const path = `media/${store}-${r.id}-${k}`
        zip.file(path, v)
        o[`${k}File`] = path
        continue
      }
      o[k] = v
    }
    if (store === 'settings' && o.providers) { // API keys never leave the device unless the user opts in (later)
      o.providers = Object.fromEntries(Object.entries(o.providers).map(([p, c]) => [p, { ...c, apiKey: '' }]))
    }
    return o
  })
}

export async function exportBundle() {
  const zip = new JSZip()
  zip.file('manifest.json', JSON.stringify({ version: BUNDLE_VERSION, createdAt: new Date().toISOString(), appVersion: '0.4.0' }, null, 2))
  for (const s of STORES) zip.file(`${s}.json`, JSON.stringify(clean(zip, s, await getAll(s))))
  const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE' })
  await putSettings({ lastBackupAt: new Date().toISOString() })
  return blob
}

export function downloadBlob(blob, name) {
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob); a.download = name; a.click()
  setTimeout(() => URL.revokeObjectURL(a.href), 5000)
}

// mode: 'merge' (keep existing, overwrite same ids) | 'replace' (wipe first)
export async function importBundle(file, mode = 'merge') {
  const zip = await JSZip.loadAsync(file)
  const manifest = JSON.parse(await zip.file('manifest.json').async('string'))
  if (manifest.version > BUNDLE_VERSION) throw new Error('This backup was made by a newer version of the app.')
  for (const s of STORES) {
    const f = zip.file(`${s}.json`); if (!f) continue
    const rows = JSON.parse(await f.async('string'))
    if (mode === 'replace') await clearStore(s)
    for (const r of rows) {
      for (const k of Object.keys(r)) {
        if (!k.endsWith('File')) continue
        const media = zip.file(r[k])
        if (media) r[k.slice(0, -4)] = await media.async('blob')
        delete r[k]
      }
      if (s === 'settings' && mode === 'merge') { // keep this device's API keys when merging
        const cur = await getSettings()
        for (const p of Object.keys(r.providers || {})) r.providers[p].apiKey = cur.providers[p]?.apiKey || r.providers[p].apiKey || ''
      }
      await put(s, r)
    }
  }
}
