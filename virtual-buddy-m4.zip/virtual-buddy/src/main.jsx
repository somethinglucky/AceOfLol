import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App.jsx'
import { initTheme } from './state/theme.js'
import './styles.css'

initTheme()
if ('storage' in navigator && navigator.storage.persist) navigator.storage.persist().catch(() => {})
if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}))

createRoot(document.getElementById('root')).render(<BrowserRouter><App /></BrowserRouter>)
