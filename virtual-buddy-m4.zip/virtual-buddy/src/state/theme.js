import { getSettings, putSettings } from '../storage/db.js'
export const THEMES = [
  { id: 'light', label: 'Light' },
  { id: 'ice', label: 'Dark Ice' },
  { id: 'mint', label: 'Dark Mint' },
  { id: 'lilac', label: 'Dark Lilac' },
]
const LEGACY = { ios: 'ice', android: 'mint', custom: 'lilac' } // ids used before v0.1.1
export const normalizeTheme = (id) => LEGACY[id] || (THEMES.some((t) => t.id === id) ? id : 'ice')
const BAR = { light: '#ffffff', ice: '#0b0b0f', mint: '#121212', lilac: '#14101f' }
export function applyTheme(id) {
  id = normalizeTheme(id)
  document.documentElement.dataset.theme = id
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', BAR[id])
}
export async function initTheme() {
  const s = await getSettings()
  const id = normalizeTheme(s.theme)
  if (id !== s.theme) await putSettings({ theme: id })
  applyTheme(id)
}
export async function setTheme(id) { applyTheme(id); await putSettings({ theme: normalizeTheme(id) }) }
