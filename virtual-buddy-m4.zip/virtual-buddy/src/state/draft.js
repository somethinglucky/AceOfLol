// Unsaved-form drafts, kept in localStorage so a reload or accidental navigation never loses typing.
const k = (key) => `vb-draft:${key}`
export function loadDraft(key) { try { return JSON.parse(localStorage.getItem(k(key))) } catch { return null } }
export function saveDraft(key, v) { try { localStorage.setItem(k(key), JSON.stringify(v)) } catch { /* storage full/blocked: ignore */ } }
export function clearDraft(key) { try { localStorage.removeItem(k(key)) } catch { /* ignore */ } }
export const blobToDataUrl = (blob) => new Promise((res) => { const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(blob) })
export const dataUrlToBlob = async (u) => (await fetch(u)).blob()
