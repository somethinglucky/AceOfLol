import { getSettings, getProfile, getMessages } from '../storage/db.js'
import { completeChat } from '../ai/provider.js'
import { limitsFor } from '../ai/local/models.js'
import { listMemories, addMemory, getCursor, setCursor, normText, KINDS } from './store.js'

const running = new Set()

// Pulls {summary, memories[]} out of a model reply, tolerating code fences and chatter around the JSON.
export function parseExtraction(raw) {
  const a = raw.indexOf('{'), b = raw.lastIndexOf('}')
  if (a < 0 || b <= a) throw new Error('The AI did not return memories in a readable format.')
  const j = JSON.parse(raw.slice(a, b + 1))
  const memories = (Array.isArray(j.memories) ? j.memories : [])
    .map((m) => (typeof m === 'string' ? { text: m, kind: 'fact' } : m))
    .filter((m) => m && typeof m.text === 'string' && m.text.trim().length > 2)
    .map((m) => ({ text: m.text.trim().slice(0, 400), kind: KINDS.includes(m.kind) && m.kind !== 'summary' ? m.kind : 'fact' }))
    .slice(0, 10)
  const summary = typeof j.summary === 'string' ? j.summary.trim().slice(0, 600) : ''
  return { summary, memories }
}

export async function pendingInfo(buddyId) {
  const cursor = await getCursor(buddyId)
  const msgs = (await getMessages(buddyId)).filter((m) => m.ts > cursor)
  return { msgs, userCount: msgs.filter((m) => m.role === 'user').length, lastTs: msgs.length ? msgs[msgs.length - 1].ts : 0 }
}

function buildPrompt({ buddy, profile, existing, msgs }) {
  const who = profile?.name?.trim() || 'the user'
  const system = `You maintain the long-term memory of a companion character named ${buddy.name}. Read the conversation and decide what ${buddy.name} should remember about ${who} for future conversations.

Rules:
- Keep only durable or useful things: people and pets (with names), birthdays and dates, plans, ongoing projects, preferences, important events, and ongoing situations.
- Write each memory as one short, specific statement in the third person, e.g. "${who} has a cat named Pickles." Maximum about 25 words each.
- Do not repeat anything already remembered. If something changed, write the new fact.
- Never store passwords, payment card numbers, government ID numbers, or exact street addresses.
- Zero memories is fine if nothing is worth keeping. Never more than 8.
- Also write a summary of 1-2 sentences saying what was discussed and any open threads worth following up on.
- kind must be one of: fact, event, preference, project.

Reply with ONLY JSON, no other text, in this shape:
{"summary": "...", "memories": [{"text": "...", "kind": "fact"}]}

Already remembered (do not repeat):
${existing.length ? existing.map((m) => '- ' + m.text).join('\n') : '(nothing yet)'}`
  const transcript = msgs.map((m) => `${m.role === 'user' ? who : buddy.name}: ${m.text.slice(0, 800)}`).join('\n')
  return { system, messages: [{ role: 'user', content: `Conversation:\n${transcript}\n\nReturn the JSON now.` }] }
}

// opts: { force, minUserMsgs, quietMs }. Returns { status: 'ok'|'skipped'|'error', added, message }.
export async function extractNow(buddy, { force = false, minUserMsgs = 3, quietMs = 0 } = {}) {
  if (running.has(buddy.id)) return { status: 'skipped', added: 0, message: 'Already updating.' }
  running.add(buddy.id)
  try {
    const info = await pendingInfo(buddy.id)
    if (!info.userCount) return { status: 'skipped', added: 0, message: 'Nothing new to learn from yet.' }
    if (!force && info.userCount < minUserMsgs) return { status: 'skipped', added: 0, message: 'Not enough new messages yet.' }
    if (!force && quietMs && Date.now() - info.lastTs < quietMs) return { status: 'skipped', added: 0, message: 'Conversation still in progress.' }
    const s = await getSettings()
    const cfg = s.providers[s.activeProvider]
    const isLocal = s.activeProvider === 'local'
    if (isLocal ? !cfg?.model : !cfg?.apiKey) return { status: 'skipped', added: 0, message: isLocal ? 'Download an on-device model in Settings so your buddy can update their memories.' : 'Add an API key in Settings so your buddy can update their memories.' }

    const [profile, existingAll] = await Promise.all([getProfile(), listMemories(buddy.id)])
    const small = isLocal // small on-device models get a much shorter prompt
    const existing = existingAll.slice(0, small ? 20 : 60)
    const msgs = info.msgs.slice(small ? -14 : -60).map((m) => ({ ...m, text: m.text.slice(0, small ? 300 : 800) }))
    const { system, messages } = buildPrompt({ buddy, profile, existing, msgs })
    const raw = await completeChat({ provider: s.activeProvider, apiKey: cfg.apiKey, model: cfg.model, system, messages })
    const { summary, memories } = parseExtraction(raw)

    const seen = new Set(existingAll.map((m) => normText(m.text)))
    const convId = `conv-${msgs[0].ts}`
    let added = 0
    for (const m of memories) {
      const key = normText(m.text)
      if (seen.has(key)) continue
      seen.add(key)
      await addMemory(buddy.id, { text: m.text, kind: m.kind, isNew: true, sourceConversationId: convId })
      added++
    }
    if (summary && !seen.has(normText(summary))) {
      await addMemory(buddy.id, { text: summary, kind: 'summary', isNew: true, sourceConversationId: convId, createdAt: msgs[msgs.length - 1].ts })
      added++
    }
    await setCursor(buddy.id, info.msgs[info.msgs.length - 1].ts)
    return { status: 'ok', added, message: added ? `Added ${added} new ${added === 1 ? 'memory' : 'memories'}.` : 'Nothing new worth remembering.' }
  } catch (e) {
    return { status: 'error', added: 0, message: e.message || 'Something went wrong.' }
  } finally {
    running.delete(buddy.id)
  }
}
