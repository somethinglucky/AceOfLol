import { db, getAll, put, get, newId, getSettings, putSettings } from '../storage/db.js'

export const KINDS = ['fact', 'event', 'preference', 'project', 'summary']

export async function listMemories(buddyId) {
  const rows = (await (await db()).getAllFromIndex('memory', 'byBuddy', buddyId)) || []
  return rows.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0))
}

export async function addMemory(buddyId, { text, kind = 'fact', status = 'active', pinned = false, isNew = false, sourceConversationId = null, createdAt }) {
  const now = Date.now()
  const m = { id: newId(), buddyId, text: text.trim(), kind: KINDS.includes(kind) ? kind : 'fact', status, pinned, isNew, sourceConversationId, createdAt: createdAt || now, updatedAt: now }
  await put('memory', m)
  return m
}
export async function updateMemory(id, patch) {
  const m = await get('memory', id); if (!m) return null
  const next = { ...m, ...patch, updatedAt: Date.now() }
  await put('memory', next); return next
}
export async function deleteMemories(ids) {
  const d = await db()
  for (const id of ids) await d.delete('memory', id)
}
export async function clearNewFlags(buddyId) {
  for (const m of await listMemories(buddyId)) if (m.isNew) await put('memory', { ...m, isNew: false })
}

// Extraction cursor per buddy: timestamp of the last message already processed.
export async function getCursor(buddyId) { return ((await getSettings()).memoryCursors || {})[buddyId] || 0 }
export async function setCursor(buddyId, ts) {
  const s = await getSettings()
  await putSettings({ memoryCursors: { ...(s.memoryCursors || {}), [buddyId]: ts } })
}

export const normText = (t) => t.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, '').replace(/\s+/g, ' ').trim()
