// Memory retrieval v1: lexical (BM25-style) scoring. No model download needed.
// pickMemories() is the single entry point, so embedding-based scoring can be added later without touching callers.
const STOP = new Set('a an the and or but if then so of to in on at by for with about as is are was were be been am do does did have has had i me my you your we our they them their he she it its this that these those not no yes just really very can will would should could what when where who how why from up out over again into than too also'.split(' '))

export function tokenize(text) {
  const words = (text.toLowerCase().match(/[\p{L}\p{N}]+/gu) || []).filter((w) => w.length > 1 && !STOP.has(w))
  return words.map((w) => {
    if (w.length > 5 && w.endsWith('ing')) return w.slice(0, -3)
    if (w.length > 4 && w.endsWith('ed')) return w.slice(0, -2)
    if (w.length > 3 && w.endsWith('s')) return w.slice(0, -1)
    return w
  })
}

export function pickMemories(memories, queryText, { max = 12, charBudget = 2500, allBelow = 15 } = {}) {
  const active = memories.filter((m) => m.status !== 'archived')
  let ranked
  if (active.length <= allBelow) {
    ranked = [...active].sort((a, b) => Number(b.pinned) - Number(a.pinned) || (b.createdAt || 0) - (a.createdAt || 0))
  } else {
    const docs = active.map((m) => ({ m, toks: tokenize(m.text) }))
    const df = new Map()
    for (const d of docs) for (const t of new Set(d.toks)) df.set(t, (df.get(t) || 0) + 1)
    const q = new Set(tokenize(queryText))
    const N = docs.length
    const newest = Math.max(...active.map((m) => m.createdAt || 0)) || 1
    const scored = docs.map(({ m, toks }) => {
      let s = 0
      for (const t of new Set(toks)) if (q.has(t)) s += Math.log(1 + (N - df.get(t) + 0.5) / (df.get(t) + 0.5))
      s /= Math.sqrt(Math.max(toks.length, 4)) / 2
      s += 0.15 * ((m.createdAt || 0) / newest)          // gentle recency nudge
      if (m.kind === 'summary') s *= 0.6                 // summaries rank below specific facts
      return { m, s: s + (m.pinned ? 100 : 0) }
    })
    ranked = scored.sort((a, b) => b.s - a.s).map((x) => x.m)
  }
  const out = []
  let used = 0
  for (const m of ranked) {
    if (out.length >= max) break
    if (used + m.text.length > charBudget && out.length) break
    out.push(m); used += m.text.length
  }
  return out
}
