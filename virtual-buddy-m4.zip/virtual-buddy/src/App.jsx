import { Routes, Route, useLocation } from 'react-router-dom'
import MenuBar from './components/MenuBar.jsx'
import Landing from './screens/Landing.jsx'
import Settings from './screens/Settings.jsx'
import BuddyEditor from './screens/BuddyEditor.jsx'
import UserProfile from './screens/UserProfile.jsx'
import Chat from './screens/Chat.jsx'
import About from './screens/About.jsx'
import Help from './screens/Help.jsx'
import EditMemories from './screens/EditMemories.jsx'
import Demo from './screens/Demo.jsx'
import * as P from './screens/Placeholders.jsx'

// path -> [title, component]. Screen numbers refer to the flow in the spec.
const ROUTES = {
  '/signin': ['Sign in', P.SignIn], '/demo': ['Demo', Demo], '/buddy/edit': ['Buddy', BuddyEditor],
  '/call/incoming': ['Incoming call', P.IncomingCall], '/call/outgoing': ['Calling', P.OutgoingCall],
  '/chat': ['Messages', Chat], '/settings': ['Settings', Settings], '/premium': ['Premium', P.Premium],
  '/profile': ['Your profile', UserProfile], '/about': ['About', About], '/help': ['Help', Help],
  '/memories': ['Memories', EditMemories],
}
const NO_MENU = ['/', '/home']

export default function App() {
  const { pathname } = useLocation()
  const [title] = ROUTES[pathname] || ['']
  return (
    <>
      {!NO_MENU.includes(pathname) && <MenuBar title={title} />}
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/home" element={<P.Splash />} />
        {Object.entries(ROUTES).map(([path, [, C]]) => <Route key={path} path={path} element={<C />} />)}
      </Routes>
    </>
  )
}
