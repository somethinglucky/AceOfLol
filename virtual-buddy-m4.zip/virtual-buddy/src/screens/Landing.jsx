import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { getBuddies, getSettings } from '../storage/db.js'
export default function Landing() {
  const [info, setInfo] = useState(null)
  useEffect(() => { Promise.all([getBuddies(), getSettings()]).then(([b, s]) => setInfo({ n: b.length, premium: s.premium })) }, [])
  if (!info) return null
  return (
    <div className="screen center">
      <h1>Virtual Buddy</h1>
      <p className="muted">An AI companion who can be whoever you need. Your conversations can stay on your device.</p>
      <div className="stack">
        {info.n > 0 && <Link className="btn" to="/chat">Open messages</Link>}
        <Link className="btn alt" to="/signin">Sign in / Sign up</Link>
        <Link className="btn alt" to="/demo">Try Demo Buddy</Link>
        {(info.n === 0 || info.premium) && <Link className="btn alt" to="/buddy/edit">Create new buddy</Link>}
        <Link className="plain" to="/settings">Settings</Link>
      </div>
    </div>
  )
}
