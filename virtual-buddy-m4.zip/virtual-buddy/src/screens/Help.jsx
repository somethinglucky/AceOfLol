export default function Help() {
  return (
    <div className="screen prose">
      <h2>Getting started</h2>
      <ol>
        <li>Open <strong>Settings</strong> and create your buddy, then fill in your own profile.</li>
        <li>Choose how your buddy thinks: <strong>On this device</strong> (free and private; download a model once) or a cloud provider (paste your own API key).</li>
        <li>Open <strong>Messages</strong> and say hi.</li>
      </ol>
      <h2>Where is my data?</h2>
      <p>Your buddies, messages and settings are stored on this device. Clearing your browser's site data erases them, so use <strong>Settings → Export backup</strong> regularly. To move to a new phone, export a backup and import it there.</p>
      <h2>On-device AI</h2>
      <p>On-device models run on your phone, so your conversations don't leave it. Smaller models are faster and fit more phones; bigger ones sound smarter. Models are large downloads (a few hundred megabytes up to about a gigabyte), so use Wi-Fi if you can. They stay on this device and are not part of backups. On some iPhones the first load also fetches a small compatibility file, so an internet connection may be needed then.</p>
      <h2>API keys</h2>
      <p>Your key is stored on this device only and is never included in backups. You are billed by your AI provider, not by Virtual Buddy.</p>
      <h2>Need real help?</h2>
      <p>If you are in crisis, please contact local emergency services or a crisis line (in the US, call or text 988).</p>
      <h2>Report a bug</h2>
      <p className="muted">Coming soon.</p>
    </div>
  )
}
