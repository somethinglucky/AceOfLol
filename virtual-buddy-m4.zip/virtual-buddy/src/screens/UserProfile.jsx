import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { getProfile, saveProfile } from '../storage/db.js'
import { loadDraft, saveDraft, clearDraft } from '../state/draft.js'
import Field from '../components/Field.jsx'

const EMPTY = { name: '', nicknames: '', pronouns: '', family: '', pets: '', topics: '', about: '' }
const KEY = 'profile'

export default function UserProfile() {
  const nav = useNavigate()
  const [p, setP] = useState(EMPTY)
  const [ready, setReady] = useState(false)
  const [dirty, setDirty] = useState(false)
  const [restored, setRestored] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => { (async () => {
    let base = { ...EMPTY, ...((await getProfile()) || {}) }
    const d = loadDraft(KEY)
    if (d) { base = { ...base, ...d }; setDirty(true); setRestored(true) }
    setP(base); setReady(true)
  })() }, [])
  useEffect(() => { if (ready && dirty) saveDraft(KEY, p) }, [p, dirty, ready])

  const set = (k) => (e) => { setP({ ...p, [k]: e.target.value }); setDirty(true); setError('') }
  async function save() {
    if (saving) return
    setSaving(true)
    try { await saveProfile(p); clearDraft(KEY); nav('/settings', { replace: true }) }
    catch (e) { setSaving(false); setError(`Couldn't save: ${e.message || 'storage error'}. Your text is safe in this form; try again.`) }
  }
  if (!ready) return null
  return (
    <div className="screen">
      {restored && <p className="notice">We restored what you were typing. Press Save to keep it.</p>}
      <p className="muted">This helps your buddy avoid mix-ups. It stays on this device.</p>
      <Field label="Your name"><input value={p.name} onChange={set('name')} /></Field>
      <Field label="Nicknames you like" hint="Separate with commas."><input value={p.nicknames} onChange={set('nicknames')} /></Field>
      <Field label="Pronouns / gender"><input value={p.pronouns} onChange={set('pronouns')} /></Field>
      <Field label="Family" hint="Who should your buddy know about?"><textarea rows={3} value={p.family} onChange={set('family')} /></Field>
      <Field label="Pets and friends" hint="Names, and anything your buddy should remember about them."><textarea rows={3} value={p.pets} onChange={set('pets')} /></Field>
      <Field label="Topics you like to talk about"><textarea rows={2} value={p.topics} onChange={set('topics')} /></Field>
      <Field label="Anything else" hint="Work, hobbies, goals, things that worry you, things to avoid..."><textarea rows={4} value={p.about} onChange={set('about')} /></Field>
      <div className="savebar">
        {error && <p className="error">{error}</p>}
        <button className="btn" disabled={saving} onClick={save}>{saving ? 'Saving...' : 'Save'}</button>
      </div>
    </div>
  )
}
