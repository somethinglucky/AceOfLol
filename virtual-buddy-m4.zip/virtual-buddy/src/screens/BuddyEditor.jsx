import { useEffect, useRef, useState } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { get, put, getBuddies, getProfile, getSettings, putSettings, deleteBuddy, getMessages, newId } from '../storage/db.js'
import { toAvatarBlob } from '../storage/image.js'
import { loadDraft, saveDraft, clearDraft, blobToDataUrl, dataUrlToBlob } from '../state/draft.js'
import Avatar from '../components/Avatar.jsx'
import Field from '../components/Field.jsx'

const EMPTY = { name: '', gender: 'f', personality: '', family: '', role: '', style: '', avatar: null }

export default function BuddyEditor() {
  const nav = useNavigate()
  const [params] = useSearchParams()
  const id = params.get('id')
  const draftKey = `buddy:${id || 'new'}`
  const [b, setB] = useState(EMPTY)
  const [dirty, setDirty] = useState(false)
  const [hasChat, setHasChat] = useState(false)
  const [blocked, setBlocked] = useState(false)
  const [ready, setReady] = useState(false)
  const [restored, setRestored] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const file = useRef()

  useEffect(() => { (async () => {
    let base = EMPTY
    if (id) {
      const found = await get('buddy', id)
      if (found) { base = found; setHasChat((await getMessages(id)).length > 0) }
    } else {
      const [all, s] = await Promise.all([getBuddies(), getSettings()])
      if (all.length >= 1 && !s.premium) setBlocked(true)
    }
    const d = loadDraft(draftKey)
    if (d) {
      const { avatarData, ...fields } = d
      base = { ...base, ...fields, avatar: avatarData ? await dataUrlToBlob(avatarData) : base.avatar }
      setDirty(true); setRestored(true)
    }
    setB(base); setReady(true)
  })() }, [id])

  // Autosave the draft whenever the user has changed something.
  useEffect(() => {
    if (!ready || !dirty) return
    let cancelled = false
    ;(async () => {
      const { avatar, ...fields } = b
      const avatarData = avatar ? await blobToDataUrl(avatar) : null
      if (!cancelled) saveDraft(draftKey, { ...fields, avatarData })
    })()
    return () => { cancelled = true }
  }, [b, dirty, ready])

  const update = (patch) => { setB((cur) => ({ ...cur, ...patch })); setDirty(true); setError('') }
  const set = (k) => (e) => update({ [k]: e.target.value })

  async function save() {
    if (saving) return
    if (!b.name.trim()) { setError('Please give your buddy a name first.'); return }
    setSaving(true); setError('')
    try {
      const buddy = { ...b, name: b.name.trim(), id: b.id || newId(), createdAt: b.createdAt || Date.now(), status: b.status || 'awake' }
      await put('buddy', buddy)
      await putSettings({ activeBuddyId: buddy.id })
      clearDraft(draftKey)
      // First-time setup continues to the user profile (screen 11); edits go back to settings.
      nav((await getProfile()) ? '/settings' : '/profile', { replace: true })
    } catch (e) {
      setSaving(false)
      setError(`Couldn't save: ${e.message || 'storage error'}. Your text is safe in this form; try again, or export a backup from Settings.`)
    }
  }
  async function remove() {
    if (!confirm(`Say goodbye to ${b.name}? Their messages and memories will be deleted from this device. This can't be undone.`)) return
    clearDraft(draftKey); await deleteBuddy(b.id); nav('/settings', { replace: true })
  }
  async function pickPhoto(e) {
    const f = e.target.files[0]; if (!f) return
    try { update({ avatar: await toAvatarBlob(f) }) } catch { setError("Couldn't read that image.") }
    e.target.value = ''
  }

  if (!ready) return null
  if (blocked) return (
    <div className="screen center">
      <h2>One buddy on the free plan</h2>
      <p className="muted">Premium lets you create more buddies, each with their own personality and memories.</p>
      <div className="stack"><Link className="btn" to="/premium">See premium</Link><Link className="plain" to="/chat">Back to my buddy</Link></div>
    </div>
  )

  return (
    <div className="screen">
      {restored && <p className="notice">We restored what you were typing. Press Save to keep it.</p>}
      <div className="avatar-pick">
        <Avatar blob={b.avatar} name={b.name || '?'} size={96} />
        <button onClick={() => file.current.click()}>{b.avatar ? 'Change photo' : 'Add photo'}</button>
        <input ref={file} type="file" accept="image/*" hidden onChange={pickPhoto} />
        <p className="muted small">Pictures only. Your buddy's photo stays on this device.</p>
      </div>

      <Field label="Name"><input value={b.name} onChange={set('name')} placeholder="What do you call your buddy?" /></Field>
      <Field label="Voice" hint="Sets your buddy's default voice for calls.">
        <select value={b.gender} onChange={set('gender')}><option value="f">Female</option><option value="m">Male</option></select>
      </Field>
      <Field label="Who are they?" hint="Please describe your buddy: hobbies, interests, work, goals, culture or ethnicity, where they were born and live now, kids, exes, religion, and so on.">
        <textarea rows={6} value={b.personality} onChange={set('personality')} />
      </Field>
      <Field label="People they know" hint="Family and others your buddy knows. Example: You have a sister you're close to named Margret, an accountant in New York.">
        <textarea rows={3} value={b.family} onChange={set('family')} />
      </Field>
      <Field label="Their role in your life" hint="What are they to you? Friend, mentor, partner, accountability buddy, practice partner for interviews...">
        <textarea rows={2} value={b.role} onChange={set('role')} />
      </Field>
      <Field label="How they talk" hint="Their style, common phrases, how often they joke, how formal they are...">
        <textarea rows={3} value={b.style} onChange={set('style')} />
      </Field>

      <div className="savebar">
        {error && <p className="error">{error}</p>}
        <button className="btn" disabled={saving} onClick={save}>{saving ? 'Saving...' : 'Save'}</button>
      </div>

      {hasChat && (
        <section className="after">
          <Link className="plain-btn" to={`/memories?id=${b.id}`}>Edit memories</Link>
          <p className="muted small">See, fix, add, or remove the things {b.name || 'your buddy'} remembers about you and your conversations.</p>
        </section>
      )}

      {b.id && (
        <section className="goodbye">
          <p className="muted small">Saying goodbye to {b.name}? Deleting a buddy also deletes all of their messages and memories from this device. If you might want them back, export a backup from Settings first.</p>
          <button className="quiet" onClick={remove}>Delete {b.name}</button>
        </section>
      )}
    </div>
  )
}
