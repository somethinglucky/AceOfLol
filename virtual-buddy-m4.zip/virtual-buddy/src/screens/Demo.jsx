import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { getBuddies } from '../storage/db.js'

export default function Demo() {
  const [none, setNone] = useState(null)
  useEffect(() => { getBuddies().then((b) => setNone(b.length === 0)) }, [])
  return (
    <div className="screen">
      <h2>Meet Demo Buddy</h2>
      <p className="muted">Try Virtual Buddy right now, with nothing to set up. Demo Buddy is an AI that is honest about being an AI. It runs on your own device, so it's free and private.</p>
      <div className="stack">
        <Link className="btn" to="/chat?b=demo">Text Demo Buddy</Link>
        <Link className="btn alt" to="/call/outgoing?b=demo">Call Demo Buddy <span className="chip">soon</span></Link>
        <Link className="btn alt" to="/call/incoming?b=demo">Demo Buddy calls me <span className="chip">soon</span></Link>
        {none && <Link className="btn alt" to="/buddy/edit">Create new buddy</Link>}
      </div>
      <section className="prose" style={{ marginTop: 28 }}>
        <h2>About Virtual Buddy</h2>
        <p>Virtual Buddy is an AI companion that can be whoever you need: a friend, a mentor, an accountability partner, or a practice partner for a hard conversation. You decide who your buddy is, how they talk, and what they remember.</p>
        <p>Talk by text or by voice. Your buddy remembers the things that matter to you, and you can view and edit those memories any time. AI models can run directly on your device, so your conversations never have to leave it.</p>
        <p className="muted">Virtual Buddy is an AI, not a person, and is not a substitute for professional or emergency help.</p>
      </section>
    </div>
  )
}
