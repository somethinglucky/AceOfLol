import { useEffect, useMemo, useRef, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { get, getBuddies, resolveActiveBuddy, downloadText } from '../storage/db.js'
import { KINDS, listMemories, addMemory, updateMemory, deleteMemories, clearNewFlags, normText } from '../memory/store.js'
import { extractNow, pendingInfo } from '../memory/extract.js'

const KIND_LABEL = { fact: 'Fact', event: 'Event', preference: 'Preference', project: 'Project', summary: 'Conversation summary' }

export default function EditMemories() {
  const [params] = useSearchParams()
  const [buddy, setBuddy] = useState(null)
  const [mems, setMems] = useState([])
  const [tab, setTab] = useState('active')
  const [q, setQ] = useState('')
  const [sel, setSel] = useState(new Set())
  const [editing, setEditing] = useState(null) // { id, text }
  const [draft, setDraft] = useState({ text: '', kind: 'fact' })
  const [adding, setAdding] = useState(false)
  const [status, setStatus] = useState('')
  const [busy, setBusy] = useState(false)
  const [pending, setPending] = useState(0)
  const file = useRef()

  const reload = async (b = buddy) => { if (b) { setMems(await listMemories(b.id)); setPending((await pendingInfo(b.id)).userCount) } }
  useEffect(() => { (async () => {
    const id = params.get('id')
    const b = (id && (await get('buddy', id))) || (await resolveActiveBuddy()).buddy || (await getBuddies())[0]
    setBuddy(b || null)
    if (b) await reload(b)
  })() }, [])
  // "New" badges stay visible while you look, then clear: after a few seconds, on leaving, or when the tab closes.
  useEffect(() => {
    if (!buddy) return
    const clear = () => clearNewFlags(buddy.id)
    const t = setTimeout(clear, 4000)
    window.addEventListener('pagehide', clear)
    return () => { clearTimeout(t); window.removeEventListener('pagehide', clear); clear() }
  }, [buddy])

  const list = useMemo(() => {
    const f = normText(q)
    return mems.filter((m) => (tab === 'archived' ? m.status === 'archived' : m.status !== 'archived') && (!f || normText(m.text).includes(f)))
      .sort((a, b) => Number(b.pinned) - Number(a.pinned) || (b.createdAt || 0) - (a.createdAt || 0))
  }, [mems, tab, q])
  const counts = { active: mems.filter((m) => m.status !== 'archived').length, archived: mems.filter((m) => m.status === 'archived').length }

  if (!buddy) return <div className="screen center"><p className="muted">Create a buddy first, and their memories will show up here.</p></div>

  const toggle = (id) => setSel((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n })
  const act = async (fn) => { await fn(); await reload() }

  async function addManual() {
    if (draft.text.trim().length < 3) return
    await act(() => addMemory(buddy.id, { text: draft.text, kind: draft.kind }))
    setDraft({ text: '', kind: 'fact' }); setAdding(false)
  }
  async function saveEdit() {
    if (editing.text.trim().length < 3) return
    await act(() => updateMemory(editing.id, { text: editing.text.trim(), isNew: false })); setEditing(null)
  }
  async function bulk(kind) {
    const ids = [...sel]; if (!ids.length) return
    if (kind === 'delete' && !confirm(`Are you sure? ${ids.length} ${ids.length === 1 ? 'memory' : 'memories'} will be deleted for good.`)) return
    await act(async () => {
      if (kind === 'delete') await deleteMemories(ids)
      else for (const id of ids) await updateMemory(id, { status: kind === 'archive' ? 'archived' : 'active' })
    })
    setSel(new Set())
  }
  async function updateFromChats() {
    setBusy(true); setStatus('')
    const r = await extractNow(buddy, { force: true })
    setStatus(r.message); setBusy(false); await reload()
  }
  async function download() {
    const out = { app: 'virtual-buddy', type: 'memories', buddy: buddy.name, exportedAt: new Date().toISOString(),
      memories: mems.map(({ text, kind, status, pinned, createdAt }) => ({ text, kind, status, pinned, createdAt })) }
    downloadText(JSON.stringify(out, null, 2), `${buddy.name}-memories-${new Date().toISOString().slice(0, 10)}.json`, 'application/json')
  }
  async function importFile(e) {
    const f = e.target.files[0]; e.target.value = ''; if (!f) return
    try {
      const j = JSON.parse(await f.text())
      const rows = Array.isArray(j) ? j : j.memories
      if (!Array.isArray(rows)) throw new Error('bad file')
      const have = new Set(mems.map((m) => normText(m.text)))
      let n = 0
      for (const r of rows) {
        if (!r?.text || have.has(normText(r.text))) continue
        have.add(normText(r.text)); n++
        await addMemory(buddy.id, { text: r.text, kind: r.kind, status: r.status === 'archived' ? 'archived' : 'active', pinned: !!r.pinned, createdAt: r.createdAt })
      }
      setStatus(`Imported ${n} ${n === 1 ? 'memory' : 'memories'}.`); await reload()
    } catch { setStatus("That doesn't look like a memories file.") }
  }

  return (
    <div className="screen">
      <p className="muted">Everything {buddy.name} remembers about you. Fix mistakes, add things you want them to know, or let go of what no longer matters.</p>

      <div className="row gap-b">
        <button onClick={() => setAdding(!adding)}>Add a memory</button>
        <button disabled={busy} onClick={updateFromChats}>{busy ? 'Thinking...' : 'Update from recent chats'}</button>
      </div>
      <p className="muted small">{buddy.name} updates their memories on their own after longer chats{pending ? ` (${pending} new ${pending === 1 ? 'message' : 'messages'} since the last update)` : ''}. You can also do it now.</p>
      {status && <p className="notice">{status}</p>}

      {adding && (
        <section className="card">
          <textarea rows={3} value={draft.text} onChange={(e) => setDraft({ ...draft, text: e.target.value })} placeholder={`e.g. ${buddy.name} should know that my birthday is in May.`} />
          <div className="row" style={{ marginTop: 8 }}>
            <select style={{ width: 'auto' }} value={draft.kind} onChange={(e) => setDraft({ ...draft, kind: e.target.value })}>
              {KINDS.filter((k) => k !== 'summary').map((k) => <option key={k} value={k}>{KIND_LABEL[k]}</option>)}
            </select>
            <button className="on" onClick={addManual}>Add</button>
            <button onClick={() => setAdding(false)}>Cancel</button>
          </div>
        </section>
      )}

      <div className="tabs">
        <button className={tab === 'active' ? 'on' : ''} onClick={() => { setTab('active'); setSel(new Set()) }}>Remembered ({counts.active})</button>
        <button className={tab === 'archived' ? 'on' : ''} onClick={() => { setTab('archived'); setSel(new Set()) }}>Set aside ({counts.archived})</button>
      </div>
      {tab === 'archived' && <p className="muted small">Set-aside memories are kept but not used in conversations, until you restore them.</p>}
      <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search memories" style={{ marginBottom: 12 }} />

      {list.length === 0 && <p className="muted center-text">{mems.length ? 'Nothing matches.' : `${buddy.name} hasn't made any memories yet. Chat for a while, or add one yourself.`}</p>}
      {list.map((m) => (
        <div key={m.id} className={`mem ${sel.has(m.id) ? 'sel' : ''}`}>
          <label className="mem-check"><input type="checkbox" checked={sel.has(m.id)} onChange={() => toggle(m.id)} aria-label="Select" /></label>
          <div className="mem-body">
            <div className="chips">
              <span className="chip">{KIND_LABEL[m.kind] || 'Fact'}</span>
              {m.isNew && <span className="chip new">New</span>}
              {m.pinned && <span className="chip pin">Pinned</span>}
              <span className="small muted">{new Date(m.createdAt).toLocaleDateString()}</span>
            </div>
            {editing?.id === m.id ? (
              <>
                <textarea rows={3} value={editing.text} onChange={(e) => setEditing({ ...editing, text: e.target.value })} />
                <div className="row" style={{ marginTop: 8 }}><button className="on" onClick={saveEdit}>Save</button><button onClick={() => setEditing(null)}>Cancel</button></div>
              </>
            ) : (
              <>
                <p className="mem-text">{m.text}</p>
                <div className="mem-actions">
                  <button className="link" onClick={() => setEditing({ id: m.id, text: m.text })}>Edit</button>
                  <button className="link" onClick={() => act(() => updateMemory(m.id, { pinned: !m.pinned }))}>{m.pinned ? 'Unpin' : 'Pin'}</button>
                  <button className="link" onClick={() => act(() => updateMemory(m.id, { status: m.status === 'archived' ? 'active' : 'archived' }))}>{m.status === 'archived' ? 'Restore' : 'Set aside'}</button>
                </div>
              </>
            )}
          </div>
        </div>
      ))}

      {sel.size > 0 && (
        <div className="savebar bulkbar">
          <span>{sel.size} selected</span>
          <div className="row">
            <button onClick={() => bulk(tab === 'archived' ? 'restore' : 'archive')}>{tab === 'archived' ? 'Restore' : 'Set aside'}</button>
            <button className="quiet" onClick={() => bulk('delete')}>Delete…</button>
            <button className="link" onClick={() => setSel(new Set())}>Clear</button>
          </div>
        </div>
      )}

      <section className="card" style={{ marginTop: 28 }}>
        <h2>Backup</h2>
        <p className="muted small">Download these memories as a file you can keep, or bring memories back from one. They're also included in the full backup in Settings.</p>
        <div className="row">
          <button onClick={download}>Download memories</button>
          <button onClick={() => file.current.click()}>Import memories</button>
        </div>
        <input ref={file} type="file" accept=".json,application/json" hidden onChange={importFile} />
      </section>
    </div>
  )
}
