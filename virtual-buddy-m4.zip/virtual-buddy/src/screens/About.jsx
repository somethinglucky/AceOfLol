export default function About() {
  return (
    <div className="screen prose">
      <h2>About Virtual Buddy</h2>
      <p>Virtual Buddy is an AI companion that can be whoever you need: a friend, a mentor, an accountability partner, a practice partner for a hard conversation, or a familiar voice when no one else is around. You decide who your buddy is, how they talk, what they remember, and when they reach out.</p>
      <p>Talk by text or by voice, like a phone call. Practice interviews, small talk, or ordering food. Set up daily check-ins, reminders, or a call to help you out of a tricky situation. Your buddy remembers the things that matter to you, and you can view and edit those memories any time.</p>
      <p>Your privacy comes first. Virtual Buddy can run AI models directly on your device, so your conversations never have to leave it. If you want more advanced conversation, you can optionally connect a cloud AI of your choice.</p>
      <p className="muted">Virtual Buddy is an AI, not a person, and is not a substitute for professional or emergency help. If you're in crisis, please contact local emergency services or a crisis line.</p>
    </div>
  )
}
