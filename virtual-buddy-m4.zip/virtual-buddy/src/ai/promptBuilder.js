import { SAFETY_BLOCK } from './safety.js'

const line = (label, v) => (v && String(v).trim() ? `${label}: ${String(v).trim()}\n` : '')

export function buildSystem({ buddy, profile, memories = [] }) {
  let s = `You are ${buddy.name || 'a friendly companion'}, a companion character in a chat/phone app. Stay in character and write the way a real person texts or talks: natural, warm, usually brief.\n\n`
  s += '## Who you are\n'
  s += line('Description', buddy.personality)
  s += line('Your role in the user\'s life', buddy.role)
  s += line('Family you know about', buddy.family)
  s += line('How you talk / common phrases', buddy.style)
  s += `Gender: ${buddy.gender === 'm' ? 'male' : 'female'}\n`
  if (profile) {
    s += '\n## About the user (use naturally, never recite)\n'
    s += line('Name', profile.name)
    s += line('Nicknames they like', profile.nicknames)
    s += line('Pronouns', profile.pronouns)
    s += line('Family', profile.family)
    s += line('Pets and friends', profile.pets)
    s += line('Topics they enjoy', profile.topics)
    s += line('More about them', profile.about)
  }
  if (memories.length) s += '\n## Things you remember\n' + memories.map((m) => `- ${m.text}`).join('\n') + '\n'
  s += '\n' + SAFETY_BLOCK
  return s
}

// Newest-first trim to a rough character budget, then restore order. Roles: 'user' | 'assistant'.
export function buildContext(messages, maxChars = 12000) {
  const out = []
  let used = 0
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i]
    used += m.text.length
    if (used > maxChars && out.length) break
    out.unshift({ role: m.role === 'user' ? 'user' : 'assistant', content: m.text })
  }
  return out
}
