// On-device AI via wllama (llama.cpp compiled to WebAssembly, with WebGPU when the browser has it).
// Everything is loaded lazily so people who never use local models never download the engine.
import { LOCAL_LIMITS, IMPORT_PREFIX, modelLabel } from './models.js'

const mock = () => globalThis.__VB_MOCK_ENGINE__ // test seam: lets automated tests swap in a fake engine

let wl = null
let loadedUrl = null
let lock = Promise.resolve()
let status = { phase: 'idle', url: null } // idle | loading | ready | error
const listeners = new Set()
const setStatus = (s) => { status = { ...status, ...s }; listeners.forEach((f) => f(status)) }
export const getStatus = () => status
export function subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn) }

async function lib() {
  if (!wl) {
    const [{ Wllama }, wasm] = await Promise.all([import('@wllama/wllama/esm/index.js'), import('@wllama/wllama/esm/wasm/wllama.wasm?url')])
    wl = new Wllama({ default: wasm.default }, { suppressNativeLog: true, allowOffline: true })
  }
  return wl
}
function acquire() {
  let release
  const prev = lock
  lock = new Promise((r) => { release = r })
  return prev.then(() => release)
}

export async function listInstalled() {
  if (mock()) return mock().listInstalled()
  const w = await lib()
  return (await w.modelManager.getModels()).filter((m) => m.size > 0)
    .map((m) => ({ url: m.url, size: m.size, name: modelLabel(m.url), imported: m.url.startsWith(IMPORT_PREFIX) }))
}

export async function downloadModel(url, { onProgress, signal } = {}) {
  if (mock()) return mock().downloadModel(url, { onProgress, signal })
  if (!/^https:\/\//i.test(url) && !/^http:\/\/localhost[:/]/i.test(url)) throw new Error('Model links must start with https://')
  if (!/\.gguf(\?.*)?$/i.test(url)) throw new Error('That link should end in .gguf')
  const w = await lib()
  try {
    await w.modelManager.downloadModel(url, { signal, progressCallback: ({ loaded, total }) => onProgress?.(loaded, total) })
  } catch (e) {
    if (e?.name === 'AbortError' || signal?.aborted) throw e
    const msg = String(e?.message || e)
    if (/404|not found/i.test(msg)) throw new Error("That model file couldn't be found. The host may have moved it. You can pick a different one, or choose a .gguf file from your device.")
    if (/quota|space|storage/i.test(msg)) throw new Error('Not enough free storage on this device for that model.')
    throw new Error(`Download failed: ${msg}`)
  }
}

export async function importFile(file, { onProgress } = {}) {
  if (mock()) return mock().importFile(file, { onProgress })
  if (!/\.gguf$/i.test(file.name)) throw new Error('Please choose a .gguf model file.')
  if ((await file.slice(0, 4).text()) !== 'GGUF') throw new Error("That file doesn't look like a GGUF model.")
  const w = await lib()
  const url = IMPORT_PREFIX + encodeURIComponent(file.name)
  const name = await w.cacheManager.getNameFromURL(url)
  let n = 0
  const counted = file.stream().pipeThrough(new TransformStream({ transform(chunk, c) { n += chunk.byteLength; onProgress?.(n, file.size); c.enqueue(chunk) } }))
  await w.cacheManager.write(name, counted, { etag: 'local-import', originalSize: file.size, originalURL: url })
  return url
}

export async function removeModel(url) {
  if (mock()) return mock().removeModel(url)
  const w = await lib()
  if (loadedUrl === url) { await w.exit(); loadedUrl = null; setStatus({ phase: 'idle', url: null }) }
  const m = (await w.modelManager.getModels({ includeInvalid: true })).find((x) => x.url === url)
  if (m) await m.remove()
}

async function ensureLoaded(url) {
  const w = await lib()
  if (loadedUrl === url && w.isModelLoaded()) return w
  if (w.isModelLoaded()) await w.exit()
  loadedUrl = null
  setStatus({ phase: 'loading', url })
  const model = (await w.modelManager.getModels()).find((m) => m.url === url)
  if (!model) { setStatus({ phase: 'error' }); throw new Error("That model isn't on this device any more. Open Settings, then AI model, to download one.") }
  const params = { n_ctx: LOCAL_LIMITS.nCtx }
  try {
    await w.loadModel(model, params)
  } catch {
    // Some phones can't give the model graphics memory: try again on the processor.
    try { if (w.isModelLoaded()) await w.exit(); await w.loadModel(model, { ...params, n_gpu_layers: 0 }) }
    catch (e2) {
      setStatus({ phase: 'error' })
      throw new Error(`This device couldn't load ${modelLabel(url)}. It may not have enough memory; try a smaller model. (${String(e2?.message || e2).slice(0, 120)})`)
    }
  }
  loadedUrl = url
  setStatus({ phase: 'ready', url })
  return w
}

// Same shape as the cloud providers: yields text pieces. One request at a time.
export async function* streamLocal({ modelUrl, system, messages, signal }) {
  if (mock()) { yield* mock().stream({ modelUrl, system, messages, signal }); return }
  if (!modelUrl) throw new Error('No on-device model yet. Open Settings, then AI model, to download one.')
  const release = await acquire()
  try {
    const w = await ensureLoaded(modelUrl)
    const it = await w.createChatCompletion({
      messages: [{ role: 'system', content: system }, ...messages],
      stream: true, abortSignal: signal, max_tokens: LOCAL_LIMITS.maxTokens, temperature: 0.8,
    })
    for await (const c of it) { const d = c.choices?.[0]?.delta?.content; if (d) yield d }
  } catch (e) {
    const msg = String(e?.message || e)
    if (/exceeds the available context|context size/i.test(msg)) throw new Error("That was too much for this model to hold in mind at once. Try a shorter message, or a model with more memory in Settings.")
    throw e
  } finally {
    release()
  }
}
