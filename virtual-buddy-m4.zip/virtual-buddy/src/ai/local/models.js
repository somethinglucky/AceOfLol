// Curated on-device models (GGUF, 4-bit). Sizes are approximate. If a link ever 404s the app says so and
// people can still pick their own .gguf file or paste a link in Settings.
export const CATALOG = [
  { id: 'qwen25-05b', name: 'Qwen2.5 0.5B', tier: 'tiny', sizeMB: 400, license: 'Apache 2.0',
    blurb: 'Smallest and fastest. Best for older or low-memory phones.',
    url: 'https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf' },
  { id: 'gemma3-1b', name: 'Gemma 3 1B', tier: 'small', sizeMB: 810, license: 'Gemma Terms of Use',
    blurb: 'A good balance of quality, speed and size.',
    url: 'https://huggingface.co/ggml-org/gemma-3-1b-it-GGUF/resolve/main/gemma-3-1b-it-Q4_K_M.gguf' },
  { id: 'llama32-1b', name: 'Llama 3.2 1B', tier: 'small', sizeMB: 810, license: 'Llama 3.2 Community License',
    blurb: 'A friendly conversationalist of about the same size.',
    url: 'https://huggingface.co/bartowski/Llama-3.2-1B-Instruct-GGUF/resolve/main/Llama-3.2-1B-Instruct-Q4_K_M.gguf' },
  { id: 'qwen25-15b', name: 'Qwen2.5 1.5B', tier: 'good', sizeMB: 1100, license: 'Apache 2.0',
    blurb: 'Noticeably smarter, needs a newer phone with plenty of memory.',
    url: 'https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf' },
]
export const DEMO_MODEL = CATALOG[0]
export const IMPORT_PREFIX = 'https://imported.local/'

// Small models have small context windows, so everything sent to them is trimmed harder.
export const LOCAL_LIMITS = { nCtx: 3072, historyChars: 3500, memoryChars: 1000, maxTokens: 512 }
export const CLOUD_LIMITS = { historyChars: 12000, memoryChars: 2500, maxTokens: 1024 }
export const limitsFor = (provider) => (provider === 'local' ? LOCAL_LIMITS : CLOUD_LIMITS)

export function modelLabel(url) {
  if (!url) return 'an on-device model'
  const hit = CATALOG.find((m) => m.url === url)
  if (hit) return hit.name
  try { return decodeURIComponent(url.split('/').pop()).replace(/\.gguf$/i, '') } catch { return 'an on-device model' }
}
