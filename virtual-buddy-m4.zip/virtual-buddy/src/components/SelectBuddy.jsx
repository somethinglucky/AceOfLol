import Avatar from './Avatar.jsx'
// Popup for choosing which buddy a screen applies to. "Create New Buddy" comes first when allowed.
export default function SelectBuddy({ buddies, canCreate, onPick, onCreate, onClose }) {
  return (
    <div className="modal-back" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <h2>Choose a buddy</h2>
        {canCreate && <button className="pick" onClick={onCreate}><span className="avatar ph" style={{ width: 40, height: 40 }}>+</span>Create new buddy</button>}
        {buddies.map((b) => (
          <button key={b.id} className="pick" onClick={() => onPick(b)}><Avatar blob={b.avatar} name={b.name} />{b.name}</button>
        ))}
        {onClose && <button className="plain" onClick={onClose}>Cancel</button>}
      </div>
    </div>
  )
}
