import { useEffect, useState } from 'react'
export default function Avatar({ blob, name = '?', size = 40 }) {
  const [url, setUrl] = useState(null)
  useEffect(() => {
    if (!blob) { setUrl(null); return }
    const u = URL.createObjectURL(blob); setUrl(u)
    return () => URL.revokeObjectURL(u)
  }, [blob])
  const style = { width: size, height: size, fontSize: size * 0.45 }
  return url
    ? <img className="avatar" style={style} src={url} alt="" />
    : <div className="avatar ph" style={style}>{(name.trim()[0] || '?').toUpperCase()}</div>
}
