// A labelled input with a permanent caption underneath (placeholders vanish while typing; captions don't).
export default function Field({ label, hint, children }) {
  return (
    <label className="field">
      <span className="lbl">{label}</span>
      {children}
      {hint && <span className="hint">{hint}</span>}
    </label>
  )
}
