import { useEffect, useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'

const ITEMS = [['Settings', '/settings'], ['Make call', '/call/outgoing'], ['Receive call', '/call/incoming'], ['Messaging', '/chat'], ['About', '/about'], ['Help', '/help']]

export default function MenuBar({ title }) {
  const nav = useNavigate()
  const { pathname } = useLocation()
  const [open, setOpen] = useState(false)
  useEffect(() => setOpen(false), [pathname])
  useEffect(() => {
    if (!open) return
    const onKey = (e) => e.key === 'Escape' && setOpen(false)
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open])
  return (
    <header className="menubar">
      <button aria-label="Back" onClick={() => nav(-1)}>‹</button>
      <h1>{title}</h1>
      <button aria-label="Menu" aria-expanded={open} onClick={() => setOpen(!open)}>☰</button>
      {open && (
        <>
          <div className="menu-back" onClick={() => setOpen(false)} />
          <nav className="menu">
            {ITEMS.map(([label, to]) => <Link key={to} to={to} onClick={() => setOpen(false)}>{label}</Link>)}
          </nav>
        </>
      )}
    </header>
  )
}
