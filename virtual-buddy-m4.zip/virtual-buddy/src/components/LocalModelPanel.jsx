import { useEffect, useRef, useState } from 'react'
import { checkDevice, recommend, fitFor, describeDevice, UNSUPPORTED_MESSAGE } from '../device/capability.js'
import { CATALOG } from '../ai/local/models.js'
import { listInstalled, downloadModel, importFile, removeModel } from '../ai/local/engine.js'
import { putSettings } from '../storage/db.js'

const mb = (n) => (n >= 1e9 ? (n / 1e9).toFixed(1) + ' GB' : Math.round(n / 1e6) + ' MB')

export default function LocalModelPanel({ settings, onChange }) {
  const [device, setDevice] = useState(null)
  const [installed, setInstalled] = useState([])
  const [busy, setBusy] = useState(null)      // { label, loaded, total }
  const [error, setError] = useState('')
  const [custom, setCustom] = useState('')
  const abort = useRef(null)
  const file = useRef()
  const active = settings.providers.local?.model || ''

  const refresh = async () => { try { setInstalled(await listInstalled()) } catch (e) { setError(e.message) } }
  useEffect(() => { checkDevice().then(setDevice); refresh() }, [])

  const setActive = async (url) => { await putSettings({ providers: { ...settings.providers, local: { ...settings.providers.local, model: url } } }); onChange() }
  const afterInstall = async (url) => { await refresh(); if (!active || !installed.some((m) => m.url === active)) await setActive(url) }

  async function download(url, label, sizeMB) {
    if (navigator.connection?.type === 'cellular' && !confirm(`This download is large${sizeMB ? ` (about ${sizeMB} MB)` : ''} and you seem to be on mobile data. Download anyway?`)) return
    setError(''); abort.current = new AbortController(); setBusy({ label, loaded: 0, total: 0 })
    try {
      await downloadModel(url, { signal: abort.current.signal, onProgress: (loaded, total) => setBusy({ label, loaded, total }) })
      await afterInstall(url)
    } catch (e) { if (e.name !== 'AbortError') setError(e.message) }
    setBusy(null)
  }
  async function pickFile(e) {
    const f = e.target.files[0]; e.target.value = ''; if (!f) return
    setError(''); setBusy({ label: f.name, loaded: 0, total: f.size })
    try { afterInstall(await importFile(f, { onProgress: (loaded, total) => setBusy({ label: f.name, loaded, total }) })); await refresh() } catch (err) { setError(err.message) }
    setBusy(null)
  }
  async function remove(m) {
    if (!confirm(`Remove ${m.name} from this device? You can download it again later.`)) return
    await removeModel(m.url); if (active === m.url) await setActive(''); await refresh()
  }

  if (!device) return <p className="muted small">Checking your device...</p>
  const rec = recommend(device)
  const installedUrls = new Set(installed.map((m) => m.url))
  const total = installed.reduce((n, m) => n + m.size, 0)
  const pct = busy && busy.total ? Math.round((busy.loaded / busy.total) * 100) : 0

  return (
    <div className="local">
      <p className={`notice ${device.supported ? '' : 'warn'}`}>
        {device.supported ? `Your device can run AI on its own: ${describeDevice(device)}.` : UNSUPPORTED_MESSAGE}
      </p>

      {installed.length > 0 && (
        <>
          <h3>On this device</h3>
          {installed.map((m) => (
            <div key={m.url} className={`model ${active === m.url ? 'inuse' : ''}`}>
              <div><strong>{m.name}</strong>{m.imported && <span className="chip">Your file</span>}<div className="small muted">{mb(m.size)}</div></div>
              <div className="row">
                {active === m.url ? <span className="chip pin">In use</span> : <button onClick={() => setActive(m.url)}>Use</button>}
                <button className="quiet" onClick={() => remove(m)}>Remove</button>
              </div>
            </div>
          ))}
          <p className="muted small">Models use about {mb(total)}. They live only on this device and are not included in backups.</p>
        </>
      )}

      {device.supported && (
        <>
          <h3>Download a model</h3>
          <p className="muted small">Smaller models are faster and fit more phones; bigger ones sound smarter. One download, then it works offline. Use Wi-Fi if you can.</p>
          {CATALOG.filter((m) => !installedUrls.has(m.url)).map((m) => (
            <div key={m.id} className="model">
              <div>
                <strong>{m.name}</strong>
                {rec?.id === m.id && <span className="chip new">Recommended</span>}
                {fitFor(device, m) === 'heavy' && <span className="chip">May be slow here</span>}
                <div className="small muted">{m.blurb}</div>
                <div className="small muted">About {m.sizeMB >= 1000 ? (m.sizeMB / 1000).toFixed(1) + ' GB' : m.sizeMB + ' MB'} · {m.license}</div>
              </div>
              <button disabled={!!busy} onClick={() => download(m.url, m.name, m.sizeMB)}>Download</button>
            </div>
          ))}

          <h3>Use your own model</h3>
          <div className="row"><button disabled={!!busy} onClick={() => file.current.click()}>Choose a .gguf file</button></div>
          <input ref={file} type="file" accept=".gguf" hidden onChange={pickFile} />
          <label className="field" style={{ marginTop: 12 }}>
            <span className="lbl">Or download from a link</span>
            <input value={custom} onChange={(e) => setCustom(e.target.value)} placeholder="https://.../model-q4_k_m.gguf" inputMode="url" />
            <span className="hint">Only use models from sources you trust. Check the model's license before using it.</span>
          </label>
          <button disabled={!!busy || !custom.trim()} onClick={() => download(custom.trim(), 'your model')}>Download from link</button>
        </>
      )}

      {busy && (
        <div className="progress">
          <div className="small">{busy.label}: {busy.total ? `${pct}% (${mb(busy.loaded)} of ${mb(busy.total)})` : 'starting...'}</div>
          <div className="bar"><div style={{ width: `${pct}%` }} /></div>
          {abort.current && <button className="quiet" onClick={() => abort.current.abort()}>Cancel</button>}
        </div>
      )}
      {error && <p className="error">{error}</p>}
    </div>
  )
}
