import { CATALOG } from '../ai/local/models.js'

let cached
// Looks at what this browser/device can do. Cheap, but cached for the session.
export async function checkDevice(force = false) {
  if (cached && !force) return cached
  const ua = navigator.userAgent || ''
  const isIOS = /iPad|iPhone|iPod/.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1)
  const wasm = typeof WebAssembly === 'object'
  const secure = !!window.isSecureContext
  const opfs = !!(navigator.storage && navigator.storage.getDirectory)
  let webgpu = false
  try { webgpu = !!(navigator.gpu && (await navigator.gpu.requestAdapter())) } catch { /* no GPU access */ }
  let quotaMB = null, usedMB = null
  try { const e = await navigator.storage.estimate(); quotaMB = Math.round((e.quota || 0) / 1e6); usedMB = Math.round((e.usage || 0) / 1e6) } catch { /* unknown */ }
  const memoryGB = navigator.deviceMemory || null // Chrome only, capped at 8
  const freeMB = quotaMB != null ? Math.max(0, quotaMB - (usedMB || 0)) : null

  const supported = wasm && secure && opfs
  let tier = 'tiny'
  if (supported) {
    if (memoryGB && memoryGB >= 6) tier = 'good'
    else if (memoryGB && memoryGB >= 4) tier = 'small'
    else if (!memoryGB && !isIOS) tier = 'small'          // unknown memory on desktop-class browsers
    else if (!memoryGB && isIOS && webgpu) tier = 'small' // newer iPhones
    else tier = 'tiny'
  }
  cached = { isIOS, wasm, secure, opfs, webgpu, memoryGB, quotaMB, usedMB, freeMB, supported, tier,
    cores: navigator.hardwareConcurrency || null }
  return cached
}

export const UNSUPPORTED_MESSAGE = "This device can't run AI on its own. Upgrade to premium to use cloud AI, or try a newer phone."

const ORDER = ['tiny', 'small', 'good']
// Which catalog entry to suggest for this device.
export function recommend(device) {
  if (!device?.supported) return null
  return device.tier === 'tiny' ? CATALOG.find((m) => m.id === 'qwen25-05b') : CATALOG.find((m) => m.id === 'gemma3-1b')
}
// 'ok' | 'heavy' (bigger than the device tier suggests) for a catalog entry.
export function fitFor(device, model) {
  if (!device?.supported) return 'no'
  return ORDER.indexOf(model.tier) > ORDER.indexOf(device.tier) ? 'heavy' : 'ok'
}
export function describeDevice(d) {
  const bits = [d.webgpu ? 'graphics acceleration available' : 'no graphics acceleration (will use the processor)']
  if (d.memoryGB) bits.push(`about ${d.memoryGB}${d.memoryGB >= 8 ? '+' : ''} GB memory`)
  if (d.freeMB != null) bits.push(`${d.freeMB >= 1000 ? (d.freeMB / 1000).toFixed(1) + ' GB' : d.freeMB + ' MB'} free storage`)
  return bits.join(', ')
}
