#!/usr/bin/env bash
# Run on the droplet from the repo root: ./deploy/deploy.sh
set -e
git pull
npm install
npm run build
sudo mkdir -p /var/www/virtual-buddy
sudo rsync -a --delete dist/ /var/www/virtual-buddy/
echo "Deployed."
