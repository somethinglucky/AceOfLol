'use strict';
// Attic: a tiny personal file locker. One password, one folder, no dependencies.

const http = require('http');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');
const { pipeline } = require('stream/promises');
const { streamZip } = require('./zip');

// ---------------------------------------------------------------- config
const PORT = parseInt(process.env.PORT || '3000', 10);
const HOST = process.env.HOST || '127.0.0.1';
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data'));
const PASSWORD = process.env.APP_PASSWORD || '';
const TRUST_PROXY = process.env.TRUST_PROXY === '1'; // set when behind Caddy/nginx
const SESSION_MS = 30 * 24 * 3600 * 1000; // stay signed in for 30 days

if (PASSWORD.length < 8) {
  console.error('Set APP_PASSWORD to something at least 8 characters long.');
  process.exit(1);
}

const TMP_DIR = path.join(DATA_DIR, '.tmp'); // dot-folders are hidden from the app
try {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.rmSync(TMP_DIR, { recursive: true, force: true }); // leftovers from interrupted uploads
  fs.mkdirSync(TMP_DIR, { recursive: true });
} catch (e) {
  console.error(`Can't write to ${DATA_DIR} (${e.code}).`);
  console.error('Make sure that folder exists and the user running Attic owns it, e.g.:  sudo chown -R 1000:1000 <folder>');
  process.exit(1);
}

const PAGE_LOGIN = fs.readFileSync(path.join(__dirname, 'public', 'login.html'));
const PAGE_APP = fs.readFileSync(path.join(__dirname, 'public', 'index.html'));

// ---------------------------------------------------------------- helpers
class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
const sha256 = (s) => crypto.createHash('sha256').update(s).digest();

function sendJson(res, status, obj) {
  const body = Buffer.from(JSON.stringify(obj));
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': body.length,
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

function sendHtml(res, buf) {
  res.writeHead(200, {
    'Content-Type': 'text/html; charset=utf-8',
    'Content-Length': buf.length,
    'Cache-Control': 'no-store',
  });
  res.end(buf);
}

async function readBody(req, limit = 5 * 1024 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > limit) throw new HttpError(413, 'Request too large');
    chunks.push(c);
  }
  return Buffer.concat(chunks).toString('utf8');
}

async function readJson(req) {
  const text = await readBody(req);
  try {
    return text ? JSON.parse(text) : {};
  } catch {
    throw new HttpError(400, 'Bad JSON');
  }
}

// ---------------------------------------------------------------- auth
const SECRET = sha256('attic-session:' + PASSWORD); // changing the password signs everyone out
const PASS_HASH = sha256(PASSWORD);
const sign = (s) => crypto.createHmac('sha256', SECRET).update(s).digest('base64url');

function makeToken() {
  const exp = String(Date.now() + SESSION_MS);
  return exp + '.' + sign(exp);
}

function validToken(token) {
  if (!token) return false;
  const i = token.indexOf('.');
  if (i < 1) return false;
  const exp = token.slice(0, i);
  const sig = token.slice(i + 1);
  const good = sign(exp);
  if (sig.length !== good.length) return false;
  return crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(good)) && Number(exp) > Date.now();
}

function getCookie(req, name) {
  for (const part of (req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0 && part.slice(0, i).trim() === name) return decodeURIComponent(part.slice(i + 1).trim());
  }
  return null;
}

const isAuthed = (req) => validToken(getCookie(req, 'attic_session'));

function clientIp(req) {
  if (TRUST_PROXY) {
    const xff = String(req.headers['x-forwarded-for'] || '');
    if (xff) return xff.split(',').pop().trim();
  }
  return req.socket.remoteAddress || 'unknown';
}

function isHttps(req) {
  return !!req.socket.encrypted || (TRUST_PROXY && req.headers['x-forwarded-proto'] === 'https');
}

function setSessionCookie(req, res, token, maxAgeSec) {
  const parts = [`attic_session=${token}`, 'HttpOnly', 'SameSite=Lax', 'Path=/', `Max-Age=${maxAgeSec}`];
  if (isHttps(req)) parts.push('Secure');
  res.setHeader('Set-Cookie', parts.join('; '));
}

// 5 wrong passwords from one address locks it out for 15 minutes
const failures = new Map();
const MAX_FAILS = 5;
const LOCK_MS = 15 * 60 * 1000;

async function handleLogin(req, res) {
  const ip = clientIp(req);
  const rec = failures.get(ip);
  if (rec && rec.lockedUntil > Date.now()) {
    const mins = Math.ceil((rec.lockedUntil - Date.now()) / 60000);
    throw new HttpError(429, `Too many attempts. Try again in ${mins} minute${mins === 1 ? '' : 's'}.`);
  }
  const body = await readJson(req);
  const ok = crypto.timingSafeEqual(sha256(String(body.password || '')), PASS_HASH);
  if (!ok) {
    const r = failures.get(ip) || { count: 0, lockedUntil: 0 };
    r.count += 1;
    if (r.count >= MAX_FAILS) {
      r.lockedUntil = Date.now() + LOCK_MS;
      r.count = 0;
    }
    failures.set(ip, r);
    await new Promise((r2) => setTimeout(r2, 600));
    throw new HttpError(401, 'That password is not right.');
  }
  failures.delete(ip);
  setSessionCookie(req, res, makeToken(), SESSION_MS / 1000);
  sendJson(res, 200, { ok: true });
}

// ---------------------------------------------------------------- paths & names
// Every path from the browser is a "relative path" like "Trips/2026". This turns it into a
// real path inside DATA_DIR and refuses anything that could escape it or touch hidden files.
function resolveRel(rel) {
  const s = String(rel || '').replace(/\\/g, '/');
  if (s.includes('\0')) throw new HttpError(400, 'Bad path');
  const parts = s.split('/').filter(Boolean);
  for (const p of parts) if (p.startsWith('.')) throw new HttpError(400, 'Bad path');
  return { rel: parts.join('/'), abs: path.join(DATA_DIR, ...parts), parts };
}

function checkName(name) {
  const n = String(name || '').trim();
  if (!n || n.length > 255 || /[\/\\\0]/.test(n) || n.startsWith('.')) throw new HttpError(400, 'That name is not allowed.');
  return n;
}

function cleanUploadName(name) {
  let n = String(name || 'file').replace(/[\/\\\0]/g, '_').replace(/^\.+/, '').trim();
  return n || 'file';
}

async function assertDir(abs) {
  let st;
  try {
    st = await fsp.stat(abs);
  } catch {
    throw new HttpError(404, 'Folder not found');
  }
  if (!st.isDirectory()) throw new HttpError(400, 'Not a folder');
}

const joinRel = (dir, name) => (dir ? dir + '/' + name : name);

// ---------------------------------------------------------------- file types
const KINDS = {
  image: 'jpg jpeg png gif webp heic heif avif bmp tif tiff svg dng raw',
  video: 'mp4 m4v mov avi mkv webm 3gp mpg mpeg',
  audio: 'm4a mp3 wav aac caf flac ogg oga amr aiff',
  pdf: 'pdf',
  text: 'txt md csv json log xml yml yaml html htm',
};
const KIND_OF = {};
for (const [k, exts] of Object.entries(KINDS)) for (const e of exts.split(' ')) KIND_OF[e] = k;

const MIME = {
  jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp',
  heic: 'image/heic', heif: 'image/heif', avif: 'image/avif', bmp: 'image/bmp', tif: 'image/tiff',
  tiff: 'image/tiff', svg: 'image/svg+xml',
  mp4: 'video/mp4', m4v: 'video/x-m4v', mov: 'video/quicktime', webm: 'video/webm', avi: 'video/x-msvideo',
  mkv: 'video/x-matroska', '3gp': 'video/3gpp', mpg: 'video/mpeg', mpeg: 'video/mpeg',
  mp3: 'audio/mpeg', m4a: 'audio/mp4', wav: 'audio/wav', aac: 'audio/aac', caf: 'audio/x-caf',
  flac: 'audio/flac', ogg: 'audio/ogg', oga: 'audio/ogg', amr: 'audio/amr', aiff: 'audio/aiff',
  pdf: 'application/pdf',
  txt: 'text/plain; charset=utf-8', md: 'text/plain; charset=utf-8', csv: 'text/plain; charset=utf-8',
  json: 'text/plain; charset=utf-8', log: 'text/plain; charset=utf-8', xml: 'text/plain; charset=utf-8',
  yml: 'text/plain; charset=utf-8', yaml: 'text/plain; charset=utf-8',
};
// These could run scripts if opened inline from our own origin, so they always download.
const FORCE_DOWNLOAD = new Set(['html', 'htm', 'svg', 'xhtml', 'js', 'mjs']);

const extOf = (name) => path.extname(name).slice(1).toLowerCase();
const kindOf = (name) => KIND_OF[extOf(name)] || 'file';

function contentDisposition(type, filename) {
  const ascii = filename.replace(/[^\x20-\x7e]/g, '_').replace(/["\\]/g, '_');
  const utf8 = encodeURIComponent(filename).replace(/['()*]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase());
  return `${type}; filename="${ascii}"; filename*=UTF-8''${utf8}`;
}

// ---------------------------------------------------------------- serving files (with Range support for video/audio)
function serveFile(req, res, abs, st, forceDownload) {
  const name = path.basename(abs);
  const ext = extOf(name);
  const download = forceDownload || FORCE_DOWNLOAD.has(ext);
  const headers = {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Accept-Ranges': 'bytes',
    'Last-Modified': st.mtime.toUTCString(),
    'Cache-Control': 'private, no-cache',
    'Content-Disposition': contentDisposition(download ? 'attachment' : 'inline', name),
  };

  const ims = req.headers['if-modified-since'];
  if (ims && !req.headers.range) {
    const t = Date.parse(ims);
    if (!Number.isNaN(t) && Math.floor(st.mtimeMs / 1000) * 1000 <= t) {
      res.writeHead(304, headers);
      return res.end();
    }
  }

  let start = 0;
  let end = st.size - 1;
  let status = 200;
  const range = req.headers.range;
  const m = range && /^bytes=(\d*)-(\d*)$/.exec(range.trim());
  if (m && (m[1] || m[2])) {
    if (m[1]) {
      start = parseInt(m[1], 10);
      if (m[2]) end = Math.min(parseInt(m[2], 10), st.size - 1);
    } else {
      start = Math.max(0, st.size - parseInt(m[2], 10));
    }
    if (start > end || start >= st.size) {
      res.writeHead(416, { 'Content-Range': `bytes */${st.size}` });
      return res.end();
    }
    status = 206;
    headers['Content-Range'] = `bytes ${start}-${end}/${st.size}`;
  }
  headers['Content-Length'] = st.size === 0 ? 0 : end - start + 1;
  res.writeHead(status, headers);
  if (req.method === 'HEAD' || st.size === 0) return res.end();
  pipeline(fs.createReadStream(abs, { start, end }), res).catch(() => res.destroy());
}

// ---------------------------------------------------------------- API handlers
async function apiList(url, res) {
  const dir = resolveRel(url.searchParams.get('path'));
  await assertDir(dir.abs);
  const ents = await fsp.readdir(dir.abs, { withFileTypes: true });
  const wanted = ents.filter((e) => !e.name.startsWith('.') && (e.isFile() || e.isDirectory()));
  const items = await Promise.all(
    wanted.map(async (e) => {
      const st = await fsp.stat(path.join(dir.abs, e.name));
      const isDir = e.isDirectory();
      return {
        name: e.name,
        type: isDir ? 'dir' : 'file',
        kind: isDir ? 'dir' : kindOf(e.name),
        ext: isDir ? '' : extOf(e.name),
        size: isDir ? null : st.size,
        mtime: st.mtimeMs,
        ctime: st.birthtimeMs > 0 ? st.birthtimeMs : st.ctimeMs, // when it landed on the server
      };
    })
  );
  sendJson(res, 200, { path: dir.rel, items });
}

async function apiStats(res) {
  const s = await fsp.statfs(DATA_DIR);
  sendJson(res, 200, { free: Number(s.bavail) * Number(s.bsize), total: Number(s.blocks) * Number(s.bsize) });
}

async function walkFolders(abs, rel, out, depth) {
  if (out.length > 5000 || depth > 12) return;
  const ents = (await fsp.readdir(abs, { withFileTypes: true }))
    .filter((e) => e.isDirectory() && !e.name.startsWith('.'))
    .sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
  for (const e of ents) {
    const r = joinRel(rel, e.name);
    out.push(r);
    await walkFolders(path.join(abs, e.name), r, out, depth + 1);
  }
}

async function apiFolders(res) {
  const out = [''];
  await walkFolders(DATA_DIR, '', out, 0);
  sendJson(res, 200, { folders: out });
}

async function placeFile(tmp, dirAbs, name) {
  const ext = path.extname(name);
  const base = name.slice(0, name.length - ext.length);
  for (let i = 0; i < 1000; i++) {
    const candidate = i === 0 ? name : `${base} (${i})${ext}`;
    const dest = path.join(dirAbs, candidate);
    try {
      await fsp.link(tmp, dest); // fails if the name is taken, so we never overwrite anything
      await fsp.unlink(tmp);
      return candidate;
    } catch (e) {
      if (e.code === 'EEXIST') continue;
      if (['EPERM', 'ENOTSUP', 'EXDEV', 'EMLINK', 'ENOSYS'].includes(e.code)) {
        try {
          await fsp.access(dest);
          continue;
        } catch {}
        await fsp.rename(tmp, dest);
        return candidate;
      }
      throw e;
    }
  }
  throw new HttpError(500, 'Too many files with the same name');
}

async function apiUpload(req, url, res) {
  const dir = resolveRel(url.searchParams.get('path'));
  await assertDir(dir.abs);
  const name = cleanUploadName(url.searchParams.get('name'));
  const mtime = Number(url.searchParams.get('mtime'));
  const tmp = path.join(TMP_DIR, crypto.randomBytes(9).toString('hex'));
  try {
    await pipeline(req, fs.createWriteStream(tmp));
    if (!req.complete) throw new HttpError(400, 'Upload was cut off');
    if (Number.isFinite(mtime) && mtime > 631152000000 && mtime < Date.now() + 86400000) {
      const d = new Date(mtime); // keep the original date from the phone
      await fsp.utimes(tmp, d, d);
    }
    const finalName = await placeFile(tmp, dir.abs, name);
    const st = await fsp.stat(path.join(dir.abs, finalName));
    sendJson(res, 200, { name: finalName, size: st.size });
  } catch (e) {
    await fsp.rm(tmp, { force: true }).catch(() => {});
    if (e.code === 'ENOSPC') throw new HttpError(507, 'The server disk is full.');
    throw e;
  }
}

async function apiMkdir(req, res) {
  const b = await readJson(req);
  const parent = resolveRel(b.path);
  await assertDir(parent.abs);
  const name = checkName(b.name);
  try {
    await fsp.mkdir(path.join(parent.abs, name));
  } catch (e) {
    if (e.code === 'EEXIST') throw new HttpError(409, 'Something with that name already exists.');
    throw e;
  }
  sendJson(res, 200, { ok: true });
}

async function apiRename(req, res) {
  const b = await readJson(req);
  const item = resolveRel(b.path);
  if (!item.rel) throw new HttpError(400, 'Bad path');
  const newName = checkName(b.newName);
  const dest = path.join(path.dirname(item.abs), newName);
  if (dest === item.abs) return sendJson(res, 200, { ok: true });
  try {
    await fsp.access(dest);
    throw new HttpError(409, 'Something with that name already exists.');
  } catch (e) {
    if (e instanceof HttpError) throw e;
  }
  await fsp.rename(item.abs, dest);
  sendJson(res, 200, { ok: true });
}

async function apiMove(req, res) {
  const b = await readJson(req);
  const dest = resolveRel(b.dest);
  await assertDir(dest.abs);
  const errors = [];
  let moved = 0;
  for (const raw of Array.isArray(b.items) ? b.items : []) {
    const item = resolveRel(raw);
    const base = path.basename(item.abs);
    if (!item.rel) continue;
    if (dest.rel === item.rel || dest.rel.startsWith(item.rel + '/')) {
      errors.push(`${base}: can't move a folder into itself`);
      continue;
    }
    const target = path.join(dest.abs, base);
    if (target === item.abs) continue;
    try {
      await fsp.access(target);
      errors.push(`${base}: a file or folder with that name is already there`);
      continue;
    } catch {}
    try {
      await fsp.rename(item.abs, target);
      moved++;
    } catch (e) {
      errors.push(`${base}: ${e.code || 'failed'}`);
    }
  }
  sendJson(res, 200, { moved, errors });
}

async function apiDelete(req, res) {
  const b = await readJson(req);
  let deleted = 0;
  for (const raw of Array.isArray(b.items) ? b.items : []) {
    const item = resolveRel(raw);
    if (!item.rel) continue; // never delete the root
    await fsp.rm(item.abs, { recursive: true, force: true });
    deleted++;
  }
  sendJson(res, 200, { deleted });
}

async function apiFile(req, url, res) {
  const f = resolveRel(url.searchParams.get('path'));
  let st;
  try {
    st = await fsp.stat(f.abs);
  } catch {
    throw new HttpError(404, 'Not found');
  }
  if (!st.isFile()) throw new HttpError(404, 'Not found');
  serveFile(req, res, f.abs, st, url.searchParams.get('dl') === '1');
}

async function collectZip(abs, zipName, entries) {
  const st = await fsp.lstat(abs);
  if (st.isDirectory()) {
    entries.push({ name: zipName + '/', dir: true, size: 0, mtime: st.mtime });
    const ents = await fsp.readdir(abs, { withFileTypes: true });
    for (const e of ents) {
      if (e.name.startsWith('.') || !(e.isFile() || e.isDirectory())) continue;
      await collectZip(path.join(abs, e.name), zipName + '/' + e.name, entries);
    }
  } else if (st.isFile()) {
    entries.push({ name: zipName, abs, size: st.size, mtime: st.mtime });
  }
}

async function apiZip(req, res) {
  const form = new URLSearchParams(await readBody(req));
  const rels = form.getAll('items');
  if (!rels.length) throw new HttpError(400, 'Nothing selected');
  const entries = [];
  for (const raw of rels) {
    const item = resolveRel(raw);
    if (!item.rel) continue;
    await collectZip(item.abs, path.basename(item.abs), entries);
  }
  let name = (form.get('name') || 'attic-download').replace(/[\/\\\0"]/g, '_');
  if (!name.toLowerCase().endsWith('.zip')) name += '.zip';
  res.writeHead(200, {
    'Content-Type': 'application/zip',
    'Content-Disposition': contentDisposition('attachment', name),
    'Cache-Control': 'no-store',
  });
  try {
    await streamZip(entries, res);
  } catch (e) {
    res.destroy();
  }
}

// ---------------------------------------------------------------- router
async function route(req, res) {
  const url = new URL(req.url, 'http://local');
  const p = url.pathname;
  const method = req.method;

  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-Robots-Tag', 'noindex, nofollow');

  // basic CSRF guard on top of SameSite cookies: writes must come from our own page
  if (method !== 'GET' && method !== 'HEAD' && req.headers.origin) {
    let originHost = '';
    try {
      originHost = new URL(req.headers.origin).host;
    } catch {}
    if (originHost !== req.headers.host) throw new HttpError(403, 'Bad origin');
  }

  // pages
  if (p === '/login' && method === 'GET') {
    if (isAuthed(req)) {
      res.writeHead(302, { Location: '/' });
      return res.end();
    }
    return sendHtml(res, PAGE_LOGIN);
  }
  if (p === '/' && method === 'GET') {
    if (!isAuthed(req)) {
      res.writeHead(302, { Location: '/login' });
      return res.end();
    }
    return sendHtml(res, PAGE_APP);
  }

  if (p === '/api/login' && method === 'POST') return handleLogin(req, res);
  if (p === '/api/logout' && method === 'POST') {
    setSessionCookie(req, res, '', 0);
    return sendJson(res, 200, { ok: true });
  }

  if (!p.startsWith('/api/')) throw new HttpError(404, 'Not found');
  if (!isAuthed(req)) throw new HttpError(401, 'Please sign in');

  if (p === '/api/list' && method === 'GET') return apiList(url, res);
  if (p === '/api/stats' && method === 'GET') return apiStats(res);
  if (p === '/api/folders' && method === 'GET') return apiFolders(res);
  if (p === '/api/file' && (method === 'GET' || method === 'HEAD')) return apiFile(req, url, res);
  if (p === '/api/upload' && method === 'PUT') return apiUpload(req, url, res);
  if (p === '/api/mkdir' && method === 'POST') return apiMkdir(req, res);
  if (p === '/api/rename' && method === 'POST') return apiRename(req, res);
  if (p === '/api/move' && method === 'POST') return apiMove(req, res);
  if (p === '/api/delete' && method === 'POST') return apiDelete(req, res);
  if (p === '/api/zip' && method === 'POST') return apiZip(req, res);

  throw new HttpError(404, 'Not found');
}

const server = http.createServer((req, res) => {
  route(req, res).catch((e) => {
    const dropped = ['ECONNRESET', 'ERR_STREAM_PREMATURE_CLOSE', 'ECONNABORTED'].includes(e && e.code);
    if (!(e instanceof HttpError) && !dropped) console.error(e); // phone lost signal mid-upload: not worth a stack trace
    if (res.headersSent) return res.destroy();
    const status = e instanceof HttpError ? e.status : 500;
    const message = e instanceof HttpError ? e.message : 'Something went wrong on the server.';
    if (req.headers.accept && req.headers.accept.includes('text/html') && !req.url.startsWith('/api/')) {
      res.writeHead(status, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end(message);
    }
    sendJson(res, status, { error: message });
  });
});

server.requestTimeout = 0; // big video uploads on slow connections must not time out
server.headersTimeout = 60 * 1000;

server.listen(PORT, HOST, () => {
  console.log(`Attic is running on http://${HOST}:${PORT}`);
  console.log(`Storing files in ${DATA_DIR}`);
});
