# Attic

A tiny personal file locker for your own server. Upload photos, videos, voice recordings and PDFs from your iPhone or iPad, browse them, view them, sort them, organize them into folders, and download folders as zips.

- One password. One folder on disk. **No dependencies**: it's plain Node.js (no `npm install`).
- Sort by name, created, modified, size or type. Filter by name. Built-in viewer for photos, video, audio, PDFs and text files.
- Uploads keep the original date from your phone, never overwrite an existing file, and skip files that are already there, so you can re-select the same photos safely.
- Multi-select, rename, move, delete, and download folders or selections as a zip (works past 4 GB).

## Put it on your droplet

You need: a droplet with Docker installed, and a domain or subdomain pointed at the droplet's IP (a $10/year domain works; so does a free DuckDNS subdomain). The domain is what gets you `https://`, which your phone needs for a secure login.

1. **Copy this folder to the droplet** (`scp -r attic root@YOUR_IP:~/` or use git).
2. **Create your settings:**
   ```
   cd attic
   cp .env.example .env
   nano .env        # set APP_PASSWORD and DOMAIN
   ```
3. **Give it storage.** Droplet disks fill up fast. In the DigitalOcean dashboard, create a **Volume** (start with 100–250 GB), attach it, and note where it's mounted. Then in `.env` set `DATA_PATH` to a folder on it and let the app's user own that folder:
   ```
   sudo mkdir -p /mnt/YOUR_VOLUME/attic
   sudo chown -R 1000:1000 /mnt/YOUR_VOLUME/attic
   ```
4. **Start it:**
   ```
   docker compose up -d --build
   ```
5. Open `https://YOUR_DOMAIN` on your phone and sign in. Ports 80 and 443 must be open in the droplet firewall.

Update later with `git pull` (or copy new files) and `docker compose up -d --build`. Your files live in `DATA_PATH`, not inside the container, so rebuilding never touches them.

**Without Docker:** `APP_PASSWORD=yourpassword HOST=127.0.0.1 node server.js` (Node 20+), then put any HTTPS reverse proxy (Caddy, nginx) in front and set `TRUST_PROXY=1`. Don't expose it over plain `http://` on the internet.

## Getting things off your iPhone / iPad

1. Open the site in Safari and tap **Share → Add to Home Screen** so it feels like an app.
2. Tap **Upload**, choose **Photo Library** and select as many as you like. Tap **Options** in the picker and choose to keep all photo data or originals if it offers that. Safari's picker can convert HEIC to JPEG and compress video by default.
3. **Keep the screen on and Safari in the foreground** while uploading. iOS pauses web pages in the background. Attic asks the phone to keep the screen awake, and it retries dropped connections. Do big video libraries in batches of 20–50 at first.
4. **Voice Memos:** open a recording → Share → **Save to Files**. Then in Attic tap Upload → **Choose Files** and pick them.
5. **PDFs** already in the Files app: Upload → Choose Files. They open in the built-in viewer.
6. **Only delete things from your phone after you've opened a few of them in Attic and confirmed they're intact.**

## Text messages (iMessage / SMS)

Attic can store and show an exported archive, but iOS doesn't let any app or website read your messages directly. Apple only allows it through a full backup to a computer. The workable path:

1. On a Mac or Windows PC, make a **full, encrypted backup** with Finder or iTunes (encrypted so it includes everything). On Linux, `idevicebackup2` from libimobiledevice does the same.
2. Run the open-source tool **imessage-exporter** ([github.com/ReagentX/imessage-exporter](https://github.com/ReagentX/imessage-exporter)) on that backup. It writes your conversations, with their photos and attachments, to readable files organized per conversation. Follow its README for the exact command.
3. Upload the exported folder to Attic. Text (`.txt`) exports open right in the viewer; `.html` exports download and open in your browser from your computer.

If you go to Android, your message history can't be imported into it. This archive is how you keep it.

## Keep a second copy

A single server disk is not a backup. Turn on DigitalOcean **Volume snapshots** or run a nightly `rclone`/`restic` copy of `DATA_PATH` to Backblaze B2 or Spaces. This matters most if the droplet becomes your only copy after you clear your phone.

## Security notes

- Passwords are compared in constant time. Five wrong attempts from one address lock it out for 15 minutes. Sessions last 30 days and end if you change the password.
- Files can only be read or written inside `DATA_PATH`. Hidden files and `..` paths are refused.
- `.html`, `.svg` and `.js` files always download instead of opening in the browser.
- It's built for one person. There are no separate accounts.

## Ideas to ask your AI to add next

- Thumbnail grid for photos and videos (uses `sharp` and `ffmpeg`)
- Uploading whole folders from a desktop browser
- Resumable uploads for huge videos (chunked)
- Auto-sorting new uploads into `Year/Month` folders by photo date
- A "Trash" folder before permanent delete
