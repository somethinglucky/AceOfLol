'use strict';
// Minimal streaming ZIP writer. No dependencies.
// - "Store" method only (photos/videos are already compressed, so this is fast).
// - Uses zip64 automatically when the archive is too big for classic ZIP (~4 GB) or has 65k+ files.
// - Streams straight to the response, so memory use stays flat no matter how big the folder is.

const fs = require('fs');
const zlib = require('zlib');

const TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(buf, prev = 0) {
  if (typeof zlib.crc32 === 'function') return zlib.crc32(buf, prev); // Node 22+, native and fast
  let c = (prev ^ 0xffffffff) >>> 0;
  for (let i = 0; i < buf.length; i++) c = TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function dosDateTime(d) {
  const y = Math.max(1980, d.getFullYear());
  const time = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
  const date = ((y - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  return { time, date };
}

const U32_MAX = 0xffffffff;
const ZIP64_LIMIT = 0xf0000000; // switch to zip64 a little before 4 GB to leave room for headers

// entries: [{ name: 'a/b.jpg' | 'folder/', abs, size, mtime: Date, dir?: true }]
async function streamZip(entries, out) {
  const totalBytes = entries.reduce((n, e) => n + (e.size || 0), 0);
  const zip64 = totalBytes > ZIP64_LIMIT || entries.length >= 65000;

  let offset = 0;
  const write = (buf) => {
    if (out.destroyed) throw new Error('Client disconnected');
    offset += buf.length;
    if (out.write(buf)) return null;
    return new Promise((resolve, reject) => {
      const done = (err) => {
        out.off('drain', onDrain);
        out.off('close', onClose);
        err ? reject(err) : resolve();
      };
      const onDrain = () => done();
      const onClose = () => done(new Error('Client disconnected'));
      out.once('drain', onDrain);
      out.once('close', onClose);
    });
  };

  const central = [];

  for (const e of entries) {
    const nameBuf = Buffer.from(e.name, 'utf8');
    const { time, date } = dosDateTime(e.mtime || new Date());
    const isDir = !!e.dir;
    const flags = isDir ? 0x0800 : 0x0808; // bit 11 = UTF-8 names, bit 3 = sizes follow the data
    const localOffset = offset;

    // ---- local file header
    const extra = zip64 && !isDir ? Buffer.alloc(20) : Buffer.alloc(0);
    if (extra.length) {
      extra.writeUInt16LE(0x0001, 0);
      extra.writeUInt16LE(16, 2); // sizes are 0 here, real ones come in the data descriptor
    }
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0);
    lh.writeUInt16LE(zip64 && !isDir ? 45 : 20, 4);
    lh.writeUInt16LE(flags, 6);
    lh.writeUInt16LE(0, 8); // stored
    lh.writeUInt16LE(time, 10);
    lh.writeUInt16LE(date, 12);
    lh.writeUInt32LE(0, 14); // crc (in descriptor)
    lh.writeUInt32LE(zip64 && !isDir ? U32_MAX : 0, 18);
    lh.writeUInt32LE(zip64 && !isDir ? U32_MAX : 0, 22);
    lh.writeUInt16LE(nameBuf.length, 26);
    lh.writeUInt16LE(extra.length, 28);
    await write(Buffer.concat([lh, nameBuf, extra]));

    // ---- file data
    let crc = 0;
    let size = 0;
    if (!isDir) {
      const stream = fs.createReadStream(e.abs, { highWaterMark: 1 << 20 });
      for await (const chunk of stream) {
        crc = crc32(chunk, crc);
        size += chunk.length;
        await write(chunk);
      }
      // ---- data descriptor
      const dd = Buffer.alloc(zip64 ? 24 : 16);
      dd.writeUInt32LE(0x08074b50, 0);
      dd.writeUInt32LE(crc, 4);
      if (zip64) {
        dd.writeBigUInt64LE(BigInt(size), 8);
        dd.writeBigUInt64LE(BigInt(size), 16);
      } else {
        dd.writeUInt32LE(size, 8);
        dd.writeUInt32LE(size, 12);
      }
      await write(dd);
    }

    central.push({ nameBuf, time, date, flags, crc, size, localOffset, isDir });
  }

  // ---- central directory
  const cdStart = offset;
  for (const c of central) {
    const extra = zip64 ? Buffer.alloc(28) : Buffer.alloc(0);
    if (zip64) {
      extra.writeUInt16LE(0x0001, 0);
      extra.writeUInt16LE(24, 2);
      extra.writeBigUInt64LE(BigInt(c.size), 4);
      extra.writeBigUInt64LE(BigInt(c.size), 12);
      extra.writeBigUInt64LE(BigInt(c.localOffset), 20);
    }
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0);
    ch.writeUInt16LE(zip64 ? 45 : 20, 4); // made by
    ch.writeUInt16LE(zip64 && !c.isDir ? 45 : 20, 6); // needed
    ch.writeUInt16LE(c.flags, 8);
    ch.writeUInt16LE(0, 10);
    ch.writeUInt16LE(c.time, 12);
    ch.writeUInt16LE(c.date, 14);
    ch.writeUInt32LE(c.crc, 16);
    ch.writeUInt32LE(zip64 ? U32_MAX : c.size, 20);
    ch.writeUInt32LE(zip64 ? U32_MAX : c.size, 24);
    ch.writeUInt16LE(c.nameBuf.length, 28);
    ch.writeUInt16LE(extra.length, 30);
    ch.writeUInt16LE(0, 32); // comment
    ch.writeUInt16LE(0, 34); // disk
    ch.writeUInt16LE(0, 36); // internal attrs
    ch.writeUInt32LE(c.isDir ? 0x10 : 0, 38); // external attrs (0x10 = directory on DOS)
    ch.writeUInt32LE(zip64 ? U32_MAX : c.localOffset, 42);
    await write(Buffer.concat([ch, c.nameBuf, extra]));
  }
  const cdSize = offset - cdStart;

  // ---- end of central directory
  if (zip64) {
    const z64Offset = offset;
    const z = Buffer.alloc(56);
    z.writeUInt32LE(0x06064b50, 0);
    z.writeBigUInt64LE(44n, 4);
    z.writeUInt16LE(45, 12);
    z.writeUInt16LE(45, 14);
    z.writeUInt32LE(0, 16);
    z.writeUInt32LE(0, 20);
    z.writeBigUInt64LE(BigInt(central.length), 24);
    z.writeBigUInt64LE(BigInt(central.length), 32);
    z.writeBigUInt64LE(BigInt(cdSize), 40);
    z.writeBigUInt64LE(BigInt(cdStart), 48);
    const loc = Buffer.alloc(20);
    loc.writeUInt32LE(0x07064b50, 0);
    loc.writeUInt32LE(0, 4);
    loc.writeBigUInt64LE(BigInt(z64Offset), 8);
    loc.writeUInt32LE(1, 16);
    await write(Buffer.concat([z, loc]));
  }
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(zip64 ? 0xffff : central.length, 8);
  end.writeUInt16LE(zip64 ? 0xffff : central.length, 10);
  end.writeUInt32LE(zip64 ? U32_MAX : cdSize, 12);
  end.writeUInt32LE(zip64 ? U32_MAX : cdStart, 16);
  end.writeUInt16LE(0, 20);
  await write(end);
  out.end();
}

module.exports = { streamZip, crc32 };
