import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'

const ITEMS = [['Settings', '/settings'], ['Make call', '/call/outgoing'], ['Receive call', '/call/incoming'], ['Messaging', '/chat'], ['About', '/about'], ['Help', '/help']]

export default function MenuBar({ title }) {
  const nav = useNavigate()
  const [open, setOpen] = useState(false)
  return (
    <header className="menubar">
      <button aria-label="Back" onClick={() => nav(-1)}>‹</button>
      <h1>{title}</h1>
      <button aria-label="Menu" onClick={() => setOpen(!open)}>☰</button>
      {open && (
        <nav className="menu" onClick={() => setOpen(false)}>
          {ITEMS.map(([label, to]) => <Link key={to} to={to}>{label}</Link>)}
        </nav>
      )}
    </header>
  )
}
