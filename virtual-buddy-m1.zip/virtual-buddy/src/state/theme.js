import { getSettings, putSettings } from '../storage/db.js'
// 'custom' is the placeholder for the third theme (to be decided).
export const THEMES = [{ id: 'ios', label: 'iOS' }, { id: 'android', label: 'Android' }, { id: 'custom', label: 'Third theme (TBD)' }]
export function applyTheme(id) { document.documentElement.dataset.theme = id }
export async function initTheme() { applyTheme((await getSettings()).theme) }
export async function setTheme(id) { applyTheme(id); await putSettings({ theme: id }) }
