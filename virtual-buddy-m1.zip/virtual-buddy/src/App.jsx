import { Routes, Route, useLocation } from 'react-router-dom'
import MenuBar from './components/MenuBar.jsx'
import Landing from './screens/Landing.jsx'
import Settings from './screens/Settings.jsx'
import * as P from './screens/Placeholders.jsx'

// path -> [title, component]. Screen numbers refer to the flow in the spec.
const ROUTES = {
  '/signin': ['Sign in', P.SignIn], '/demo': ['Demo', P.Demo], '/buddy/edit': ['Buddy', P.BuddyEditor],
  '/call/incoming': ['Incoming call', P.IncomingCall], '/call/outgoing': ['Calling', P.OutgoingCall],
  '/chat': ['Messages', P.Chat], '/settings': ['Settings', Settings], '/premium': ['Premium', P.Premium],
  '/profile': ['Your profile', P.UserProfile], '/about': ['About', P.About], '/help': ['Help', P.Help],
  '/memories': ['Memories', P.EditMemories],
}
const NO_MENU = ['/', '/home']

export default function App() {
  const { pathname } = useLocation()
  const [title] = ROUTES[pathname] || ['']
  return (
    <>
      {!NO_MENU.includes(pathname) && <MenuBar title={title} />}
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/home" element={<P.Splash />} />
        {Object.entries(ROUTES).map(([path, [, C]]) => <Route key={path} path={path} element={<C />} />)}
      </Routes>
    </>
  )
}
