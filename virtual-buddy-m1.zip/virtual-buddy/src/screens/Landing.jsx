import { Link } from 'react-router-dom'
export default function Landing() {
  return (
    <div className="screen center">
      <h1>Virtual Buddy</h1>
      <p className="muted">An AI companion who can be whoever you need. Your conversations can stay on your device.</p>
      <div className="stack">
        <Link className="btn" to="/signin">Sign in / Sign up</Link>
        <Link className="btn" to="/demo">Try Demo Buddy</Link>
        <Link className="btn" to="/buddy/edit">Create new buddy</Link>
      </div>
    </div>
  )
}
