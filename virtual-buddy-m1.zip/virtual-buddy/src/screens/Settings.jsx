import { useEffect, useRef, useState } from 'react'
import { getSettings } from '../storage/db.js'
import { exportBundle, importBundle, downloadBlob } from '../storage/bundle.js'
import { THEMES, setTheme } from '../state/theme.js'

export default function Settings() {
  const [s, setS] = useState(null)
  const [msg, setMsg] = useState('')
  const file = useRef()
  const refresh = () => getSettings().then(setS)
  useEffect(() => { refresh() }, [])
  if (!s) return null

  async function doExport() { downloadBlob(await exportBundle(), `virtualbuddy-${new Date().toISOString().slice(0, 10)}.vbbundle`); setMsg('Backup downloaded.'); refresh() }
  async function doImport(e, mode) {
    const f = e.target.files[0]; if (!f) return
    if (mode === 'replace' && !confirm('Replace everything on this device with the backup?')) return
    try { await importBundle(f, mode); setMsg('Backup imported.') } catch (err) { setMsg(err.message) }
    refresh()
  }

  return (
    <div className="screen">
      <section className="card">
        <h2>Theme</h2>
        <div className="row">{THEMES.map((t) => (
          <button key={t.id} className={s.theme === t.id ? 'on' : ''} onClick={async () => { await setTheme(t.id); refresh() }}>{t.label}</button>
        ))}</div>
      </section>
      <section className="card">
        <h2>Backup</h2>
        <p className="muted">Last backup: {s.lastBackupAt ? new Date(s.lastBackupAt).toLocaleString() : 'never'}</p>
        <div className="row">
          <button onClick={doExport}>Export backup</button>
          <button onClick={() => { file.current.dataset.mode = 'merge'; file.current.click() }}>Import (merge)</button>
          <button onClick={() => { file.current.dataset.mode = 'replace'; file.current.click() }}>Import (replace)</button>
        </div>
        <input ref={file} type="file" accept=".vbbundle,.zip" hidden onChange={(e) => { doImport(e, e.target.dataset.mode); e.target.value = '' }} />
        {msg && <p>{msg}</p>}
      </section>
    </div>
  )
}
