import { openDB } from 'idb'

export const STORES = ['buddy', 'userProfile', 'message', 'memory', 'schedule', 'settings']
const DEFAULT_SETTINGS = {
  id: 'main', theme: 'ice', splashFit: 'cover', buttonLayout: [], activeProvider: 'local',
  apiKeys: {}, localModelRef: null, exitMessage: "You seem to be having a bad day. Let's talk later when you're feeling more like yourself.",
  onboarded: false, lastBackupAt: null,
}

let dbp
export function db() {
  dbp ||= openDB('virtual-buddy', 1, {
    upgrade(d) {
      d.createObjectStore('buddy', { keyPath: 'id' })
      d.createObjectStore('userProfile', { keyPath: 'id' })
      const msg = d.createObjectStore('message', { keyPath: 'id' }); msg.createIndex('byBuddy', 'buddyId')
      const mem = d.createObjectStore('memory', { keyPath: 'id' }); mem.createIndex('byBuddy', 'buddyId')
      const sch = d.createObjectStore('schedule', { keyPath: 'id' }); sch.createIndex('byBuddy', 'buddyId')
      d.createObjectStore('settings', { keyPath: 'id' })
    },
  })
  return dbp
}

export async function getSettings() { return { ...DEFAULT_SETTINGS, ...((await (await db()).get('settings', 'main')) || {}) } }
export async function putSettings(patch) { const next = { ...(await getSettings()), ...patch }; await (await db()).put('settings', next); return next }
export async function getAll(store) { return (await db()).getAll(store) }
export async function put(store, value) { return (await db()).put(store, value) }
export async function clearStore(store) { return (await db()).clear(store) }
