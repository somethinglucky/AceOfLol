import JSZip from 'jszip'
import { STORES, getAll, put, clearStore, putSettings } from './db.js'

export const BUNDLE_VERSION = 1

// Blobs (avatars, splash image) and embeddings are not JSON; handled in a later milestone (media/ folder).
function clean(store, rows) {
  return rows.map((r) => {
    const o = {}
    for (const [k, v] of Object.entries(r)) {
      if (v instanceof Blob || k === 'embedding') continue
      o[k] = v
    }
    if (store === 'settings') o.apiKeys = {} // keys never leave the device unless the user opts in (later)
    return o
  })
}

export async function exportBundle() {
  const zip = new JSZip()
  zip.file('manifest.json', JSON.stringify({ version: BUNDLE_VERSION, createdAt: new Date().toISOString(), appVersion: '0.1.0' }, null, 2))
  for (const s of STORES) zip.file(`${s}.json`, JSON.stringify(clean(s, await getAll(s))))
  const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE' })
  await putSettings({ lastBackupAt: new Date().toISOString() })
  return blob
}

export function downloadBlob(blob, name) {
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob); a.download = name; a.click()
  setTimeout(() => URL.revokeObjectURL(a.href), 5000)
}

// mode: 'merge' (keep existing, overwrite same ids) | 'replace' (wipe first)
export async function importBundle(file, mode = 'merge') {
  const zip = await JSZip.loadAsync(file)
  const manifest = JSON.parse(await zip.file('manifest.json').async('string'))
  if (manifest.version > BUNDLE_VERSION) throw new Error('This backup was made by a newer version of the app.')
  for (const s of STORES) {
    const f = zip.file(`${s}.json`); if (!f) continue
    const rows = JSON.parse(await f.async('string'))
    if (mode === 'replace') await clearStore(s)
    for (const r of rows) await put(s, r)
  }
}
