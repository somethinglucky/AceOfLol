# Virtual Buddy (v0.2.0, M2)
Dev: `npm install && npm run dev`. Deploy: see deploy/. HTTPS is required in production (PWA, mic, push).
Milestones: M1 shell/storage/bundle (this) -> M2 buddy+chat -> M3 memory -> M4 local model+demo -> M5 voice -> M6 calls/splash -> M7 accounts/push -> M8 premium.
