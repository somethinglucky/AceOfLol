import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { getProfile, saveProfile } from '../storage/db.js'

const EMPTY = { name: '', nicknames: '', pronouns: '', family: '', pets: '', topics: '', about: '' }

export default function UserProfile() {
  const nav = useNavigate()
  const [p, setP] = useState(EMPTY)
  useEffect(() => { getProfile().then((x) => x && setP({ ...EMPTY, ...x })) }, [])
  const set = (k) => (e) => setP({ ...p, [k]: e.target.value })
  async function save() { await saveProfile(p); nav('/settings', { replace: true }) }
  return (
    <div className="screen">
      <p className="muted">This helps your buddy avoid mix-ups. It stays on this device.</p>
      <label>Your name<input value={p.name} onChange={set('name')} /></label>
      <label>Nicknames you like<input value={p.nicknames} onChange={set('nicknames')} placeholder="Comma separated" /></label>
      <label>Pronouns / gender<input value={p.pronouns} onChange={set('pronouns')} /></label>
      <label>Family<textarea rows={3} value={p.family} onChange={set('family')} placeholder="Who should your buddy know about?" /></label>
      <label>Pets and friends<textarea rows={3} value={p.pets} onChange={set('pets')} /></label>
      <label>Topics you like to talk about<textarea rows={2} value={p.topics} onChange={set('topics')} /></label>
      <label>Anything else<textarea rows={4} value={p.about} onChange={set('about')} placeholder="Work, hobbies, goals, things that worry you, things to avoid..." /></label>
      <div className="stack"><button className="btn" onClick={save}>Save</button></div>
    </div>
  )
}
