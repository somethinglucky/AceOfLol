// Screens built in later milestones. Replace each export with a real file as it is built.
const P = (name, milestone) => () => (
  <div className="screen center"><h2>{name}</h2><p className="muted">Coming in {milestone}.</p></div>
)
export const SignIn = P('Sign in / Sign up', 'M7')
export const Demo = P('Try Demo Buddy', 'M4')
export const IncomingCall = P('Incoming call', 'M6')
export const OutgoingCall = P('Calling...', 'M6')
export const Splash = P('Home', 'M6')
export const Premium = P('Premium', 'M8')
export const EditMemories = P('Edit memories', 'M3')
