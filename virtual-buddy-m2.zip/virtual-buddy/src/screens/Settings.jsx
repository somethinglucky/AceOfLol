import { useEffect, useRef, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { getSettings, putSettings, getBuddies } from '../storage/db.js'
import { exportBundle, importBundle, downloadBlob } from '../storage/bundle.js'
import { THEMES, setTheme } from '../state/theme.js'
import { PROVIDERS } from '../ai/provider.js'
import SelectBuddy from '../components/SelectBuddy.jsx'

export default function Settings() {
  const nav = useNavigate()
  const [s, setS] = useState(null)
  const [buddies, setBuddies] = useState([])
  const [msg, setMsg] = useState('')
  const [picking, setPicking] = useState(false)
  const file = useRef()
  const refresh = async () => { setS(await getSettings()); setBuddies(await getBuddies()) }
  useEffect(() => { refresh() }, [])
  if (!s) return null

  const prov = s.activeProvider
  const cfg = s.providers[prov] || { apiKey: '', model: '' }
  const setCfg = (patch) => putSettings({ providers: { ...s.providers, [prov]: { ...cfg, ...patch } } }).then(setS)
  const canCreate = s.premium || buddies.length === 0

  function editBuddy() {
    if (buddies.length === 0) return nav('/buddy/edit')
    if (buddies.length === 1 && !canCreate) return nav(`/buddy/edit?id=${buddies[0].id}`)
    setPicking(true)
  }
  async function doExport() { downloadBlob(await exportBundle(), `virtualbuddy-${new Date().toISOString().slice(0, 10)}.vbbundle`); setMsg('Backup downloaded.'); refresh() }
  async function doImport(e, mode) {
    const f = e.target.files[0]; if (!f) return
    if (mode === 'replace' && !confirm('Replace everything on this device with the backup?')) return
    try { await importBundle(f, mode); setMsg('Backup imported.') } catch (err) { setMsg(err.message) }
    refresh()
  }

  return (
    <div className="screen">
      <section className="card">
        <h2>You and your buddy</h2>
        <div className="row">
          <button onClick={editBuddy}>{buddies.length ? 'Edit buddy' : 'Create buddy'}</button>
          <Link className="plain-btn" to="/profile">Edit my profile</Link>
          {buddies.length > 0 && <Link className="plain-btn" to="/chat">Open messages</Link>}
        </div>
      </section>

      <section className="card">
        <h2>AI model</h2>
        <label>Provider
          <select value={prov} onChange={async (e) => setS(await putSettings({ activeProvider: e.target.value }))}>
            {Object.entries(PROVIDERS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
          </select>
        </label>
        <label>API key
          <input type="password" autoComplete="off" value={cfg.apiKey} placeholder={PROVIDERS[prov]?.keyHint} onChange={(e) => setCfg({ apiKey: e.target.value })} />
        </label>
        <label>Model
          <input value={cfg.model} onChange={(e) => setCfg({ model: e.target.value })} />
        </label>
        <p className="muted small">Your key is saved only on this device and is sent only to {PROVIDERS[prov]?.label}. You pay that provider directly for usage. Local on-device models are coming in a later update.</p>
      </section>

      <section className="card">
        <h2>If a conversation turns abusive</h2>
        <p className="muted small">What your buddy says when they step away. Make it sound like them.</p>
        <textarea rows={3} value={s.exitMessage} onChange={(e) => setS({ ...s, exitMessage: e.target.value })} onBlur={() => putSettings({ exitMessage: s.exitMessage })} />
      </section>

      <section className="card">
        <h2>Theme</h2>
        <div className="row">{THEMES.map((t) => (
          <button key={t.id} className={s.theme === t.id ? 'on' : ''} onClick={async () => { await setTheme(t.id); refresh() }}>{t.label}</button>
        ))}</div>
      </section>

      <section className="card">
        <h2>Backup</h2>
        <p className="muted">Last backup: {s.lastBackupAt ? new Date(s.lastBackupAt).toLocaleString() : 'never'}</p>
        <div className="row">
          <button onClick={doExport}>Export backup</button>
          <button onClick={() => { file.current.dataset.mode = 'merge'; file.current.click() }}>Import (merge)</button>
          <button onClick={() => { file.current.dataset.mode = 'replace'; file.current.click() }}>Import (replace)</button>
        </div>
        <input ref={file} type="file" accept=".vbbundle,.zip" hidden onChange={(e) => { doImport(e, e.target.dataset.mode); e.target.value = '' }} />
        {msg && <p>{msg}</p>}
      </section>

      {picking && <SelectBuddy buddies={buddies} canCreate={canCreate} onClose={() => setPicking(false)}
        onCreate={() => nav('/buddy/edit')} onPick={(b) => nav(`/buddy/edit?id=${b.id}`)} />}
    </div>
  )
}
