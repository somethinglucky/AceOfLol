import { useEffect, useRef, useState } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { get, put, getBuddies, getProfile, getSettings, putSettings, deleteBuddy, getMessages, newId } from '../storage/db.js'
import { toAvatarBlob } from '../storage/image.js'
import Avatar from '../components/Avatar.jsx'

const EMPTY = { name: '', gender: 'f', personality: '', family: '', role: '', style: '', avatar: null }

export default function BuddyEditor() {
  const nav = useNavigate()
  const [params] = useSearchParams()
  const id = params.get('id')
  const [b, setB] = useState(EMPTY)
  const [hasChat, setHasChat] = useState(false)
  const [blocked, setBlocked] = useState(false)
  const [ready, setReady] = useState(false)
  const file = useRef()

  useEffect(() => { (async () => {
    if (id) {
      const found = await get('buddy', id)
      if (found) { setB(found); setHasChat((await getMessages(id)).length > 0) }
    } else {
      const [all, s] = await Promise.all([getBuddies(), getSettings()])
      if (all.length >= 1 && !s.premium) setBlocked(true)
    }
    setReady(true)
  })() }, [id])

  const set = (k) => (e) => setB({ ...b, [k]: e.target.value })

  async function save() {
    if (!b.name.trim()) { alert('Please give your buddy a name.'); return }
    const buddy = { ...b, name: b.name.trim(), id: b.id || newId(), createdAt: b.createdAt || Date.now(), status: b.status || 'awake' }
    await put('buddy', buddy)
    await putSettings({ activeBuddyId: buddy.id })
    // First-time setup continues to the user profile (screen 11); edits go back to settings.
    nav((await getProfile()) ? '/settings' : '/profile', { replace: true })
  }
  async function remove() {
    if (!confirm(`Delete ${b.name} and all of their messages and memories? This can't be undone.`)) return
    await deleteBuddy(b.id); nav('/settings', { replace: true })
  }
  async function pickPhoto(e) {
    const f = e.target.files[0]; if (!f) return
    try { setB({ ...b, avatar: await toAvatarBlob(f) }) } catch { alert("Couldn't read that image.") }
    e.target.value = ''
  }

  if (!ready) return null
  if (blocked) return (
    <div className="screen center">
      <h2>One buddy on the free plan</h2>
      <p className="muted">Premium lets you create more buddies, each with their own personality and memories.</p>
      <div className="stack"><Link className="btn" to="/premium">See premium</Link><Link className="plain" to="/chat">Back to my buddy</Link></div>
    </div>
  )

  return (
    <div className="screen">
      <div className="avatar-pick">
        <Avatar blob={b.avatar} name={b.name || '?'} size={96} />
        <button onClick={() => file.current.click()}>{b.avatar ? 'Change photo' : 'Add photo'}</button>
        <input ref={file} type="file" accept="image/*" hidden onChange={pickPhoto} />
        <p className="muted small">Photos stay on this device.</p>
      </div>
      <label>Name<input value={b.name} onChange={set('name')} placeholder="What do you call your buddy?" /></label>
      <label>Voice
        <select value={b.gender} onChange={set('gender')}><option value="f">Female</option><option value="m">Male</option></select>
      </label>
      <label>Who are they?
        <textarea rows={5} value={b.personality} onChange={set('personality')} placeholder="Describe your buddy: hobbies, interests, work, goals, culture, where they were born and live now, kids, exes, religion, and so on." />
      </label>
      <label>People they know
        <textarea rows={3} value={b.family} onChange={set('family')} placeholder="e.g. You have a sister you're close to named Margret, an accountant in New York." />
      </label>
      <label>Their role in your life
        <textarea rows={2} value={b.role} onChange={set('role')} placeholder="Friend, mentor, partner, accountability buddy, practice partner for interviews..." />
      </label>
      <label>How they talk
        <textarea rows={3} value={b.style} onChange={set('style')} placeholder="Style, common phrases, how often they joke, how formal they are..." />
      </label>
      <div className="stack">
        <button className="btn" onClick={save}>Save</button>
        {hasChat && <Link className="plain" to="/memories">Edit memories</Link>}
        {b.id && <button className="danger" onClick={remove}>Delete buddy</button>}
      </div>
    </div>
  )
}
