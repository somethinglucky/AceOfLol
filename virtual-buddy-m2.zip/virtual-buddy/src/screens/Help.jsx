export default function Help() {
  return (
    <div className="screen prose">
      <h2>Getting started</h2>
      <ol>
        <li>Open <strong>Settings</strong> and create your buddy, then fill in your own profile.</li>
        <li>Choose an AI provider, paste your API key, and check the model name.</li>
        <li>Open <strong>Messages</strong> and say hi.</li>
      </ol>
      <h2>Where is my data?</h2>
      <p>Your buddies, messages and settings are stored on this device. Clearing your browser's site data erases them, so use <strong>Settings → Export backup</strong> regularly. To move to a new phone, export a backup and import it there.</p>
      <h2>API keys</h2>
      <p>Your key is stored on this device only and is never included in backups. You are billed by your AI provider, not by Virtual Buddy.</p>
      <h2>Need real help?</h2>
      <p>If you are in crisis, please contact local emergency services or a crisis line (in the US, call or text 988).</p>
      <h2>Report a bug</h2>
      <p className="muted">Coming soon.</p>
    </div>
  )
}
